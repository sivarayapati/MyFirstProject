package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.util.List;

import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonInclude.Include;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;

@JsonInclude(Include.NON_NULL)
public class TransportHeader{

private List<OdsParamConfig> transportHeadersList;

public List<OdsParamConfig> getTransportHeadersList() {
	return transportHeadersList;
}

public void setTransportHeadersList(List<OdsParamConfig> transportHeadersList) {
	this.transportHeadersList = transportHeadersList;
}


}
