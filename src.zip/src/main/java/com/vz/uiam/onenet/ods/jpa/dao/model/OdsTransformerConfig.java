/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author Anand Badiger
 *
 */
@Entity
@Table(name = "ods_transformer_config")
public class OdsTransformerConfig implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ods_transformer_config_id")
	private Integer odsTransformerId;

	@Column(name = "transformer_key")
	private String transformerKey;

	@Column(name = "transformer_type")
	private String transformerType;

	@Column(name = "transformer_schema")
	private String transformerSchema;
	
	
	public OdsTransformerConfig(String transformerKey) {
		super();
		this.transformerKey = transformerKey;
	}

	/**
	 * @return the odsTransformerId
	 */
	public Integer getOdsTransformerId() {
		return odsTransformerId;
	}

	/**
	 * @param odsTransformerId
	 *            the odsTransformerId to set
	 */
	public void setOdsTransformerId(Integer odsTransformerId) {
		this.odsTransformerId = odsTransformerId;
	}

	/**
	 * @return the transformerKey
	 */
	public String getTransformerKey() {
		return transformerKey;
	}

	/**
	 * @param transformerKey
	 *            the transformerKey to set
	 */
	public void setTransformerKey(String transformerKey) {
		this.transformerKey = transformerKey;
	}

	/**
	 * @return the transformerType
	 */
	public String getTransformerType() {
		return transformerType;
	}

	/**
	 * @param transformerType
	 *            the transformerType to set
	 */
	public void setTransformerType(String transformerType) {
		this.transformerType = transformerType;
	}

	/**
	 * @return the transformerSchema
	 */
	public String getTransformerSchema() {
		return transformerSchema;
	}

	/**
	 * @param transformerSchema
	 *            the transformerSchema to set
	 */
	public void setTransformerSchema(String transformerSchema) {
		this.transformerSchema = transformerSchema;
	}

	/**
	 * @param transformerKey
	 * @param transformerType
	 * @param transformerSchema
	 */
	public OdsTransformerConfig(String transformerKey, String transformerType, String transformerSchema) {
		super();
		this.transformerKey = transformerKey;
		this.transformerType = transformerType;
		this.transformerSchema = transformerSchema;
	}

	public OdsTransformerConfig() {
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
