package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class WorkflowParamsResponse {

	private ResponseStatus status;
	private Map<String, String> workflowParameters;
	
	public ResponseStatus getStatus() {
		return status;
	}
	
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	
	public Map<String, String> getWorkflowParameters() {
		return workflowParameters;
	}
	
	public void setWorkflowParameters(Map<String, String> workflowParameters) {
		this.workflowParameters = workflowParameters;
	}
	
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
