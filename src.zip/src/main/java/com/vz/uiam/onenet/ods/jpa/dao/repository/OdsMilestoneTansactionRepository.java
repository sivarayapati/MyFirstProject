package com.vz.uiam.onenet.ods.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneTransaction;

public interface OdsMilestoneTansactionRepository extends JpaRepository<OdsMilestoneTransaction, Integer> {

    public List<OdsMilestoneTransaction> findByRootCaseId(String rootCaseId);

    public OdsMilestoneTransaction findByOdsMilestoneTransactionId(Integer odsMilestoneTransactionId);

    public OdsMilestoneTransaction  findByRootCaseIdAndProcessNameAndStepNameAndOdsMilestoneConfig(String rootCaseID,
	    String flowNodeProcessName, String flowNodeStepName,OdsMilestoneConfig odsMilestoneConfig);
}
