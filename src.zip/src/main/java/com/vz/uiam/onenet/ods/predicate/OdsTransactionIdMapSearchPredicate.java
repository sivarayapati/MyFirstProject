package com.vz.uiam.onenet.ods.predicate;

import org.apache.commons.lang3.StringUtils;

import com.mysema.query.types.expr.BooleanExpression;
import com.vz.uiam.onenet.ods.jpa.dao.model.QOdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.QOdsResponseTransactionIdMap;

public class OdsTransactionIdMapSearchPredicate {

	private static QOdsRequestTransactionIdMap odsRequestTransIDMap= QOdsRequestTransactionIdMap.odsRequestTransactionIdMap;
	private static QOdsResponseTransactionIdMap odsResponseTransIDMapQdsl= QOdsResponseTransactionIdMap.odsResponseTransactionIdMap;
	
	public OdsTransactionIdMapSearchPredicate() {
		super();
	}
	
	public BooleanExpression isTransactionIdKey(String transIdKey) {
		return !StringUtils.isEmpty(transIdKey) ? odsRequestTransIDMap.transactionIdKey.startsWithIgnoreCase(transIdKey) : null;
	}
	
	public BooleanExpression isFlowNodeProcessNameLike(String flowNodeProcessName) {
		return !StringUtils.isEmpty(flowNodeProcessName) ? odsRequestTransIDMap.flowNodeProcessName.startsWithIgnoreCase(flowNodeProcessName) : null;
	}
	
	public BooleanExpression isFlowNodeStepNameLike(String flowNodeStepName) {
		return !StringUtils.isEmpty(flowNodeStepName) ? odsRequestTransIDMap.flowNodeStepName.startsWithIgnoreCase(flowNodeStepName) : null;
	}
	public BooleanExpression isResTransactionIdKey(String transIdKey) {
		return !StringUtils.isEmpty(transIdKey) ? odsResponseTransIDMapQdsl.transactionIdKey.startsWithIgnoreCase(transIdKey) : null;
	}
	
	public BooleanExpression isRootTagNameLike(String rootTagName) {
		return !StringUtils.isEmpty(rootTagName) ? odsResponseTransIDMapQdsl.rootTagName.startsWithIgnoreCase(rootTagName) : null;
	}	
	
}
