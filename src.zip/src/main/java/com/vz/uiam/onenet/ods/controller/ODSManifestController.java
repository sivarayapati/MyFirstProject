/**
 * 
 */
package com.vz.uiam.onenet.ods.controller;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSManifestResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.service.ODSService;
import com.vz.uiam.onenet.ods.service.OdsMandatoryAttrsService;
import com.vz.uiam.onenet.ods.service.OdsServiceRouteMapService;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author ODS.
 *
 */
@RestController
@RequestMapping("/manifest")
@PreAuthorize("hasAnyAuthority('ROLE:IVAPP_USER','ROLE:IVAPP_TESTER')")
public class ODSManifestController {
	private static final Logger LOGGER = Logger.getLogger(ODSManifestController.class);

	@Autowired
	ODSService odsService;
	
	@Autowired
	ServiceUtils serviceUtils;

	@Autowired
	OdsServiceRouteMapService odsServiceRouteMapService;

	@Autowired
	OdsMandatoryAttrsService odsMandatoryAttrsService;

	/**
	 * @param request
	 * @return ResponseEntity<ODSResponse>
	 */
	@RequestMapping(value = "/healthcheck", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "ODS Manifest Controller Healthcheck page", notes = "ODS Manifest Controller Healthcheck page", response = OdsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "ODS Manifest Controller Service alive", response = OdsResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Service is unavaialble") })
	public ResponseEntity<OdsResponse> healthCheck() {
		LOGGER.debug(">>healthCheck()");
		OdsResponse response = new OdsResponse();
		String statusCode = StatusCode.SUCCESS.getCode();
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(statusCode);
		responseStatus.setDescription("ODS Manifest Conroller Service alive");
		response.setStatus(responseStatus);
		LOGGER.debug("<<healthCheck()");
		return ResponseEntity.ok(response);
	}

	/**
	 * @param request
	 * @return ResponseEntity<TransformationResponse>
	 * @throws ApplicationException
	 * @throws JSONException
	 */
	@RequestMapping(value = "/fetchManifestDocs", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Fetch Manifest documents", notes = "Fetch Manifest documents", response = ODSManifestResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully retrieved the manifest documents", response = ODSManifestResponse.class) })
	public ResponseEntity<ODSManifestResponse> fetchManifestDocuments(@RequestBody String request)
			throws JSONException, ApplicationException {
		LOGGER.info(">>fetchManifestDocs()");

		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		
		LOGGER.info("<<fetchManifestDocs()");
		return new ResponseEntity<>(odsService.getManifestDocs(request), headers, HttpStatus.OK);
	}
}
