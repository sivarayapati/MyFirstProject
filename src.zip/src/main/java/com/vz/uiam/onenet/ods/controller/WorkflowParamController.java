package com.vz.uiam.onenet.ods.controller;

import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.jpa.dto.model.WfParamRequestDTO;
import com.vz.uiam.onenet.ods.jpa.dto.model.WorkflowParam;
import com.vz.uiam.onenet.ods.jpa.dto.model.WorkflowParamsResponse;
import com.vz.uiam.onenet.ods.service.WorkflowParamService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/oneDispatcher/workflowParam")
@PreAuthorize("hasAnyAuthority('ROLE:IVAPP_USER','ROLE:IVAPP_TESTER')")
public class WorkflowParamController {

	private static final Logger LOGGER = Logger.getLogger(WorkflowParamController.class);

	@Autowired
	WorkflowParamService workflowParamService;


	/**
	 * @param request
	 * @return ResponseEntity<ServiceRouterResponse>
	 */
	@RequestMapping(value = "/healthcheck", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "ServiceRouter Healthcheck page", notes = "ServiceRouter Healthcheck page", response = OdsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "ServiceRouter Service alive", response = OdsResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Service is unavaialble") })
	public ResponseEntity<OdsResponse> healthCheck() {
		LOGGER.debug(">>healthCheck()");
		OdsResponse response = new OdsResponse();
		String statusCode = StatusCode.SUCCESS.getCode();
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(statusCode);
		responseStatus.setDescription("ServiceRouter Service alive");
		response.setStatus(responseStatus);
		LOGGER.debug("<<healthCheck()");
		return ResponseEntity.ok(response);
	}
	
	
	/**
	 * @param request
	 * @return ResponseEntity<ResponseStatus>
	 */
	@RequestMapping(value = "/createOrUpdateWfParams", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create or Update WF Param", notes = "Create or Update WF Param", response = ResponseStatus.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully Added or updated WF Param", response = ResponseStatus.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Workflow Param does not exist") })
	public ResponseEntity<ResponseStatus> addWfParams(@RequestBody WfParamRequestDTO request) {
		LOGGER.info(">>addWfParam()");
		Boolean returnStatus = true;
		ResponseStatus response = new ResponseStatus();

		response.setCode(StatusCode.SUCCESS.getCode());
		response.setDescription("Successfully Inserted the WfParam");
		LOGGER.info("request::::"+request.toString());
		try {
			if (!CollectionUtils.isEmpty(request.getWorkflowParams())) {
				for (WorkflowParam param : request.getWorkflowParams()) {
						workflowParamService.createWorkflowParams(request.getRootCaseId(), param.getParamName(),
								param.getParamValue());
				}
			}
			LOGGER.info("Successfully Inserted the WfParam");
		} catch (Exception e) {
			LOGGER.info("Exception Occured........"+e.getMessage());
			returnStatus = false;
			response.setCode(StatusCode.ERROR_WHILE_CREATE_OR_UPDATE_WORKFLOW_PARAMS.getCode());
			response.setDescription(StatusCode.ERROR_WHILE_CREATE_OR_UPDATE_WORKFLOW_PARAMS.getDesc() + ". " + e.getMessage());
			LOGGER.error(StatusCode.ERROR_WHILE_CREATE_OR_UPDATE_WORKFLOW_PARAMS.getDesc() + e);
		}
		
		if (returnStatus) {
			return ResponseEntity.ok(response);
		} else {
			LOGGER.info("<<addWfParam()");
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(response);
		}
	}

	/**
	 * @param request
	 * @return ResponseEntity<WfParamResponse>
	 */
	@RequestMapping(value = "/getWorkflowParam", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Workflow Parameter", notes = "Get Workflow Parameter", response = WorkflowParamsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful Retrieved Workflow Parameter", response = WorkflowParamsResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Workflow param does not exist") })
	public ResponseEntity<WorkflowParamsResponse> getWfParam(@RequestBody WfParamRequestDTO request) {
		LOGGER.info(">>getWfParam()");
	
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(StatusCode.SUCCESS.getCode());
		responseStatus.setDescription(StatusCode.SUCCESS.getDesc());
		
		WorkflowParamsResponse workflowParamsResponse = new WorkflowParamsResponse();

		try {
			LOGGER.info(request);
			Map<String, String> workflowParams = workflowParamService.getWorkflowParams(request);
			
			workflowParamsResponse.setWorkflowParameters(workflowParams);
		} catch (ApplicationException e) {
			LOGGER.error("getWfParam Service: ApplicationException - ", e);
			responseStatus.setCode(StatusCode.FAILED.getCode());
			responseStatus.setDescription("Error while getting workflow params. " + e.getMessage());
		}
		
		workflowParamsResponse.setStatus(responseStatus);
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(workflowParamsResponse, headers, HttpStatus.OK);
	}

}