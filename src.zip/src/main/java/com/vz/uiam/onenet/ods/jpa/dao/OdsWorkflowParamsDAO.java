package com.vz.uiam.onenet.ods.jpa.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsWorkflowParams;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsWorkflowParamsId;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsWorkflowParamsRepository;

@Component
public class OdsWorkflowParamsDAO{

	private static final Logger LOGGER = Logger.getLogger(OdsWorkflowParamsDAO.class);
	@Autowired
	OdsWorkflowParamsRepository odsWorkflowParamsRepository;

	@Autowired
	EntityManager entityManager;

	/**
	 * @param pk
	 * @return OdsWorkflowParams
	 */
	public OdsWorkflowParams findByPrimaryKey(OdsWorkflowParamsId pk) {
		return odsWorkflowParamsRepository.findOne(pk);

	}

	/**
	 * @param odsWfParam
	 */
	@Transactional(propagation=Propagation.REQUIRES_NEW,isolation=Isolation.READ_UNCOMMITTED)
	public void updateParam(OdsWorkflowParams odsWfParam) {
			try {
				entityManager.merge(odsWfParam);
				entityManager.flush();
			} catch (Exception e) {
				LOGGER.error("#######################UPDATE EXCEPTION##############################");
				LOGGER.error(e.getMessage());
			}
	}

	/**
	 * @param odsWfParam
	 */
	@Transactional(propagation=Propagation.REQUIRES_NEW,isolation=Isolation.READ_UNCOMMITTED)
	public void createParam(OdsWorkflowParams odsWfParam) {
		
			try {
				entityManager.persist(odsWfParam);
				entityManager.flush();
			} catch (Exception e) {
				LOGGER.error("#######################CREATE EXCEPTION##############################");
				LOGGER.error(e.getMessage());
			}
	}

	/**
	 * @param parseInt
	 * @return
	 */
	public List<OdsWorkflowParams> findByRootCaseId(Integer rootCaseId) {
		return odsWorkflowParamsRepository.findByOdsWorkflowParamsIdRootCaseId(rootCaseId);
	}

}
