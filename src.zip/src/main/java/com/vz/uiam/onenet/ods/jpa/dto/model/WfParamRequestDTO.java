/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Request Model class
 * 
 * @author V130073
 *
 */
public class WfParamRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String rootCaseId;
	private List<WorkflowParam> workflowParams;


	/**
	 * @return the workflowParams
	 */
	public List<WorkflowParam> getWorkflowParams() {
		return workflowParams;
	}


	/**
	 * @param workflowParams the workflowParams to set
	 */
	public void setWorkflowParams(List<WorkflowParam> workflowParams) {
		this.workflowParams = workflowParams;
	}


	/**
	 * @return the rootCaseId
	 */
	public String getRootCaseId() {
		return rootCaseId;
	}

	/**
	 * @param rootCaseId the rootCaseId to set
	 */
	public void setRootCaseId(String rootCaseId) {
		this.rootCaseId = rootCaseId;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
	
}
