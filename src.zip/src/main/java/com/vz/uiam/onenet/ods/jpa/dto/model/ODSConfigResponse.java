package com.vz.uiam.onenet.ods.jpa.dto.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


/**
 * @author Ashish Goyal
 *
 */
@JsonInclude(Include.NON_NULL)
public class ODSConfigResponse {

	private String statusCode;
	private String statusDesc;
	private ODSConfigPayload odsConfigPayload;
	
	
	public String getStatusCode() {
		return statusCode;
	}
	
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	public String getStatusDesc() {
		return statusDesc;
	}
	
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	public ODSConfigPayload getOdsConfigPayload() {
		return odsConfigPayload;
	}
	
	public void setOdsConfigPayload(ODSConfigPayload odsConfigPayload) {
		this.odsConfigPayload = odsConfigPayload;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
