/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.ResolveWorkflowFalloutConfig;

/**
 * @author Kiran
 *
 */
@Transactional
@Repository
public interface ResolveWorkflowFalloutConfigRepo extends JpaRepository<ResolveWorkflowFalloutConfig, Integer> {
	static final long serialVersionUID = 1L;
	
	public ResolveWorkflowFalloutConfig findByWorkFlowStepNameAndWorkFlowFalloutErrorCode(String workFlowStepName, String workFlowFalloutErrorCode);
	
	public ResolveWorkflowFalloutConfig findByWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndWorkFlowProcessName(String workFlowStepName, String workFlowFalloutErrorCode,String workFlowProcessName);
}