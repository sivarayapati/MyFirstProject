package com.vz.uiam.onenet.ods.jpa.dto.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.json.JSONObject;

public class ResponseConfigParams {

	private String rootProcessName;
	private String flowNodeProcessName;
	private String flowNodeStepName;
	private String caseID;
	private String parentCaseID;
	private String rootCaseID;
	private String responseDocumentName;
	private String transformationType;
	private String appKey;
	private String activityInstanceId;
	private Integer serviceRouteMapId;
	private Boolean sendMilestone;
	private String sourceSystemName;
	private String destinationSystemName;
	
	public String getSourceSystemName() {
		return sourceSystemName;
	}

	public void setSourceSystemName(String sourceSystemName) {
		this.sourceSystemName = sourceSystemName;
	}

	public String getDestinationSystemName() {
		return destinationSystemName;
	}

	public void setDestinationSystemName(String destinationSystemName) {
		this.destinationSystemName = destinationSystemName;
	}

	public Boolean getSendMilestone() {
		return sendMilestone;
	}

	public String getRootProcessName() {
		return rootProcessName;
	}

	public void setRootProcessName(String rootProcessName) {
		this.rootProcessName = rootProcessName;
	}

	public String getCaseID() {
		return caseID;
	}

	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}

	public String getActivityInstanceId() {
		return activityInstanceId;
	}

	public void setActivityInstanceId(String activityInstanceId) {
		this.activityInstanceId = activityInstanceId;
	}

	public String getFlowNodeProcessName() {
		return flowNodeProcessName;
	}

	public void setFlowNodeProcessName(String flowNodeProcessName) {
		this.flowNodeProcessName = flowNodeProcessName;
	}

	public String getFlowNodeStepName() {
		return flowNodeStepName;
	}

	public void setFlowNodeStepName(String flowNodeStepName) {
		this.flowNodeStepName = flowNodeStepName;
	}

	public String getParentCaseID() {
		return parentCaseID;
	}

	public void setParentCaseID(String parentCaseID) {
		this.parentCaseID = parentCaseID;
	}

	public String getRootCaseID() {
		return rootCaseID;
	}

	public void setRootCaseID(String rootCaseID) {
		this.rootCaseID = rootCaseID;
	}

	public String getResponseDocumentName() {
		return responseDocumentName;
	}

	public void setResponseDocumentName(String responseDocumentName) {
		this.responseDocumentName = responseDocumentName;
	}

	public String getTransformationType() {
		return transformationType;
	}

	public void setTransformationType(String transformationType) {
		this.transformationType = transformationType;
	}
	
	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public Integer getServiceRouteMapId() {
	    return serviceRouteMapId;
	}

	public void setServiceRouteMapId(Integer serviceRouteMapId) {
	    this.serviceRouteMapId = serviceRouteMapId;
	}

	public Boolean isSendMilestone() {
	    return sendMilestone;
	}

	public void setSendMilestone(Boolean sendMilestone) {
	    this.sendMilestone = sendMilestone;
	}

	/**
	 * @param flowNodeProcessName
	 * @param flowNodeStepName
	 * @param caseID
	 * @param parentCaseID
	 * @param rootCaseID
	 */
	public ResponseConfigParams(String flowNodeProcessName, String flowNodeStepName, String caseID, String parentCaseID,
			String rootCaseID) {
		this.flowNodeProcessName = flowNodeProcessName;
		this.flowNodeStepName = flowNodeStepName;
		this.caseID = caseID;
		this.parentCaseID = parentCaseID;
		this.rootCaseID = rootCaseID;
	}

	public ResponseConfigParams() {
		
	}
	
	public String toJSONString() {
		JSONObject jsonObject = new JSONObject(this);
		return jsonObject.toString();
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
