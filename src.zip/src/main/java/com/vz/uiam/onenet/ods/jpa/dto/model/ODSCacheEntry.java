package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author Loganathan Murugesan
 *
 */
@JsonInclude(Include.NON_NULL)
public class ODSCacheEntry {
	
	private String cacheName;
	private List<String> cacheKeys;
	private String statusCode;
	private String statusDesc;
	
	/**
	 * @return the cacheName
	 */
	public String getCacheName() {
		return cacheName;
	}
	/**
	 * @param cacheName the cacheName to set
	 */
	public void setCacheName(String cacheName) {
		this.cacheName = cacheName;
	}
	/**
	 * @return the cacheKeys
	 */
	public List<String> getCacheKeys() {
		return cacheKeys;
	}
	/**
	 * @param cacheKeys the cacheKeys to set
	 */
	public void setCacheKeys(List<String> cacheKeys) {
		this.cacheKeys = cacheKeys;
	}
	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}
	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	/**
	 * @return the statusDesc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}
	/**
	 * @param statusDesc the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

}
