package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;



@JsonInclude(Include.NON_NULL)
public class OdsRequestLogResponse {

	private String statusCode;
	private String statusDesc;
	private List<OdsRequestLog> odsRequestLogDetails;

	
	public String getStatusCode() {
		return statusCode;
	}




	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}




	public String getStatusDesc() {
		return statusDesc;
	}




	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}



	public List<OdsRequestLog> getOdsRequestLogDetails() {
		return odsRequestLogDetails;
	}




	public void setOdsRequestLogDetails(List<OdsRequestLog> odsRequestLogDetails) {
		this.odsRequestLogDetails = odsRequestLogDetails;
	}




	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
