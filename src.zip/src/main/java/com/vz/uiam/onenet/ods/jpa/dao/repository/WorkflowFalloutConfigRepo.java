/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.repository;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFalloutConfig;

/**
 * @author Anand
 *
 */
@Transactional
@Repository
public interface WorkflowFalloutConfigRepo extends JpaRepository<WorkflowFalloutConfig, Integer> {
	static final long serialVersionUID = 1L;
	
	@Cacheable(value="odsWorkflowFalloutConfig", key="#p0.concat('|').concat(#p1)", unless="#result == null", condition="#p0!=null && #p1!=null")
	public WorkflowFalloutConfig findByWorkFlowStepNameAndWorkFlowFalloutErrorCode(String workFlowStepName, String workFlowFalloutErrorCode);
	
	public WorkflowFalloutConfig findByWorkFlowStepNameAndWorkflowProcessNameAndWorkFlowFalloutErrorCode(String workFlowStepName , String workflowProcessName , String workFlowFalloutErrorCode);
	
	@Cacheable(value="odsWorkflowFalloutConfig", key="#p0.concat('|').concat(#p1).concat('|').concat(#p2)", unless="#result == null", condition="#p0!=null && #p1!=null && #p2!=null")
	public WorkflowFalloutConfig findByWorkflowProcessNameAndWorkFlowStepNameAndWorkFlowFalloutErrorCode(String workflowProcessName,
			String workFlowStepName, String workFlowFalloutErrorCode);
	
	@Caching(evict = {
			  @CacheEvict(value = "odsWorkflowFalloutConfig", key="#p0.workFlowStepName.concat('|').concat(#p0.workFlowFalloutErrorCode)", condition="#p0.workFlowStepName!=null && #p0.workFlowFalloutErrorCode!=null"),
			  @CacheEvict(value = "odsWorkflowFalloutConfig", key="#p0.workflowProcessName.concat('|').concat(#p0.workFlowStepName).concat('|').concat(#p0.workFlowFalloutErrorCode)", condition="#p0.workflowProcessName!=null && #p0.workFlowStepName!=null && #p0.workFlowFalloutErrorCode!=null")
			})
	public WorkflowFalloutConfig save(WorkflowFalloutConfig workflowFalloutConfig);
	
}
