package com.vz.uiam.onenet.ods.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFalloutConfig;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSWorkFlowFalloutConfigResponse;
import com.vz.uiam.onenet.ods.service.ODSWorkFlowFalloutConfigService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


/**
 * @author Ashish Goyal
 *
 */
@RestController
@RequestMapping("/oneDispatcher/workFlowFalloutConfig")
public class ODSWorkFlowFalloutConfigController {
	
	private static final Logger LOGGER = Logger.getLogger(ODSWorkFlowFalloutConfigController.class);
	
	@Autowired
	ODSWorkFlowFalloutConfigService odsWorkFlowFalloutConfigService;

	
	@RequestMapping(value = "/createOrUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create or Update a record in Service Route Map", notes = "Create or Update a record in workFlowFalloutConfig", response = ODSWorkFlowFalloutConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Created or Updated workFlowFalloutConfig record", response = ODSWorkFlowFalloutConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "createOrUpdate workFlowFalloutConfig Service is unavaialble") })
	public ResponseEntity<ODSWorkFlowFalloutConfigResponse> createOrUpdateWorkFlowFalloutConfig(@RequestBody WorkflowFalloutConfig request)
														throws ApplicationException {
		
		LOGGER.info("Entering createOrUpdateWorkFlowFalloutConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		ODSWorkFlowFalloutConfigResponse response = new ODSWorkFlowFalloutConfigResponse();
		
		try {
			WorkflowFalloutConfig workFlwFOConfigResp =  odsWorkFlowFalloutConfigService.createOrUpdateWorkflowFalloutConfig(request);
			
			if(null == workFlwFOConfigResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setWorkflowFalloutConfig(workFlwFOConfigResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting createOrUpdateServiceRouteMap");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
		
	}

	
	@RequestMapping(value = "/get", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get workFlowFalloutConfig", notes = "Get workFlowFalloutConfig", response = ODSWorkFlowFalloutConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved workFlowFalloutConfig record", response = ODSWorkFlowFalloutConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "get workFlowFalloutConfig Service is unavaialble") })
	public ResponseEntity<ODSWorkFlowFalloutConfigResponse> getWorkFlowFalloutConfig(@RequestBody WorkflowFalloutConfig request)
														throws ApplicationException {
		
		LOGGER.info("Entering getWorkFlowFalloutConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		ODSWorkFlowFalloutConfigResponse response = new ODSWorkFlowFalloutConfigResponse();
		
		try {
			List<WorkflowFalloutConfig> workflowFalloutConfigList =  odsWorkFlowFalloutConfigService.getWorkflowFalloutConfig(request);
			
			if(null == workflowFalloutConfigList) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setWorkflowFalloutConfigList(workflowFalloutConfigList);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting getWorkFlowFalloutConfig");
			
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Delete workFlowFalloutConfig", notes = "Delete workFlowFalloutConfig", response = ODSWorkFlowFalloutConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Delete workFlowFalloutConfig record", response = ODSWorkFlowFalloutConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Delete workFlowFalloutConfig Service is unavaialble") })
	public ResponseEntity<ODSWorkFlowFalloutConfigResponse> deleteWorkFlowFalloutConfig(@RequestBody List<WorkflowFalloutConfig> request)
														throws ApplicationException {
		
		LOGGER.info("Entering deleteWorkFlowFalloutConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		ODSWorkFlowFalloutConfigResponse response = new ODSWorkFlowFalloutConfigResponse();
		
		try {
			odsWorkFlowFalloutConfigService.deleteWorkflowFalloutConfigRecord(request);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting deleteWorkFlowFalloutConfig");

		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
}
