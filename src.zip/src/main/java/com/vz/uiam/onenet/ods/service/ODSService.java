package com.vz.uiam.onenet.ods.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestTransactionIdMapRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsServiceRouterMapRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSInterfaceServiceRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSManifestResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.QueryParam;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformedResponsePayload;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransportHeader;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

/**
 * @author Anand
 *
 */
@Service
public class ODSService {
	private static final Logger LOGGER = Logger.getLogger(ODSService.class);

	/**
	 * Line Separator constant.
	 */
	private static final String LINE_SEPARATOR = "line.separator";

	@Autowired
	OdsServiceRouteMapService odsServiceRouteMapService;

	@Autowired
	OdsMandatoryAttrsService odsMandatoryAttrsService;

	@Autowired
	ServiceUtils serviceUtils;

	@Autowired
	OdsInterfaceRequestRepository odsRequestRepo;

	@Autowired
	OdsParamConfigRepository odsParamConfigRepository;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	OdsRequestTransactionIdMapRepository odsRequestTransactionIdMapRepository;

	@Autowired
	NotesService notesService;

	@Autowired
	ApplicationContext appcontext;

	@Autowired
	ManifestService manifestService;

	@Autowired
	OdsRequestLogService odsRequestLogService;

	@Autowired
	OdsRequestResponseTransactionIdMapService odsRequestResponseTransactionIdMapService;

	@Autowired
	ODSInterfaceRequestService odsInterfaceRequestService;

	@Autowired
	ODSTransformationService odsTransformationService;

	@Autowired
	OdsParamConfigService odsParamConfigService;

	@Autowired
	OdsServiceRouterMapRepository odsServiceRouterMapRepository;

	@Autowired
	OdsRequestLogRepository odsRequestLogRepository;

	/**
	 * Method to handle the ODS Request and return ODSResponse object.
	 * 
	 * @param String
	 *            odsRequest
	 * @return OdsResposne
	 * @throws ODSRequestValidationException
	 * @throws ApplicationException
	 */
	public OdsResponse handleOdsRequest(String odsRequest) throws ApplicationException {
		LOGGER.info("Entering handleODSRequest with " + odsRequest);

		JSONObject workflowRequest = new JSONObject(odsRequest);

		// Validate the Request Attributes.
		validateRequest(workflowRequest);

		// Validate the other dependent attributes.
		validateDependentAttributes(workflowRequest);

		return handleOdsRequest(workflowRequest);
	}

	/**
	 * Method to validate if process name and step name are present in the ODS
	 * Request.
	 * 
	 * @param JSONObject
	 *            workflowRequest
	 * @throws ODSRequestValidationException
	 * @throws ApplicationException
	 */
	public void validateRequest(JSONObject workflowRequest) throws ApplicationException {
		LOGGER.info("Entering validateRequestAttributes");

		// Validate if process name and step name are present in the ODS
		// Request.
		if (StringUtils.isEmpty(workflowRequest.getString(Constants.FLOW_PROCESS_NAME))
				|| StringUtils.isEmpty(workflowRequest.getString(Constants.FLOW_STEP_NAME))) {
			LOGGER.error("Either Process Name or Step Name is missing in the ODS Request.");
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(),
					"Either Process Name or Step Name is missing in the ODS Request.");
		}
		LOGGER.info("Exiting validateRequestAttributes");
	}

	/**
	 * Method to validate mandatory attributes for an ODS Request. - Target End
	 * Point URL - Routing Protocol - if Request Document Name is present then - App
	 * Key - Request Schema - Transformation Type
	 * 
	 * @param JSONObject
	 *            workflowRequest
	 * @throws ODSRequestValidationException
	 * @throws ApplicationException
	 */
	public void validateDependentAttributes(JSONObject workflowRequest)
			throws ApplicationException {

		// Fetch the ODS Service Route Map entry from the DB/Cache.
		OdsServiceRouterMapDetails odsServiceRouteMapDetails = getServiceRouterMapDetails(
				workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequest.getString(Constants.FLOW_STEP_NAME), workflowRequest.optString(Constants.ODS_REGION));

		// Validate other mandatory attributes for the ODS Request.
		validateOdsMandatoryAttributes(odsServiceRouteMapDetails);
	}

	/**
	 * Method to validate mandatory attributes for an ODS Request. - Target End
	 * Point URL - Routing Protocol - if Request Document Name is present then - App
	 * Key - Request Schema - Transformation Type
	 * 
	 * @param JSONObject
	 *            workflowRequest @param OdsServiceRouterMapDetails
	 *            odsServiceRouteMapDetails @throws
	 *            ODSRequestValidationException @throws ApplicationException @throws
	 */
	private void validateOdsMandatoryAttributes(OdsServiceRouterMapDetails odsServiceRouteMapDetails) throws ApplicationException {
		StringBuilder validationErrors = new StringBuilder();
		if (StringUtils.isEmpty(odsServiceRouteMapDetails.getTargetEndPointUrl())) {
			LOGGER.error("Target End point URL is not configured in ODS Service Route Map table.");
			validationErrors.append("Target End point URL is not configured in ODS Service Route Map table.")
					.append(System.getProperty(ODSService.LINE_SEPARATOR));
		}
		if (StringUtils.isEmpty(odsServiceRouteMapDetails.getRouterProtocol())) {
			LOGGER.error("Routing Protocol is not configured in ODS Service Route Map table.");
			validationErrors.append("Routing Protocol is not configured in ODS Service Route Map table.")
					.append(System.getProperty(ODSService.LINE_SEPARATOR));
		}
		if (!StringUtils.isEmpty(odsServiceRouteMapDetails.getRequestDocumentName())) {
			if (StringUtils.isEmpty(odsServiceRouteMapDetails.getRequestSchema())) {
				LOGGER.error("Request Schema is not configured in ODS Service Route Map table.");
				validationErrors.append("Request Schema is not configured in ODS Service Route Map table.")
						.append(System.getProperty(ODSService.LINE_SEPARATOR));
			}
			if (StringUtils.isEmpty(odsServiceRouteMapDetails.getTransformationType())) {
				LOGGER.error("Request Transformation Type is not configured in ODS Service Route Map table.");
				validationErrors.append("Request Transformation Type is not configured in ODS Service Route Map table.")
						.append(System.getProperty(ODSService.LINE_SEPARATOR));
			}
		}
		if (!StringUtils.isEmpty(validationErrors.toString())) {
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), validationErrors.toString());
		}
	}

	/**
	 * @param workflowRequest
	 * @return
	 * @throws ODSRequestValidationException
	 * @throws ApplicationException
	 */
	public OdsResponse handleOdsRequest(JSONObject workflowRequest)
			throws ApplicationException {

		OdsRequestLog odsRequestLog = createOdsRequestLogEntry(workflowRequest);

		// Manifest Fetch Begins
		JSONObject manifestRequestPayload = buildManifestRequestPayload(workflowRequest);

		JSONObject documentPayload = fetchManifestDocuments(manifestRequestPayload, workflowRequest);
		// Manifest Fetch Ends

		// Validate mandatory attributes in Manifest response
		validateMandatoryAttributesinManifestResponse(documentPayload, workflowRequest);

		// Generate TransactionId
		String transactionId = generateTransactionId(workflowRequest, documentPayload);

		// Merge manfiest docs with workflow payload from bonita and transactionId
		JSONObject finalMergedDocument = mergeManifestAndRequestDocuments(workflowRequest, documentPayload,
				transactionId);
		LOGGER.info("Final Merged Manifest Document : " + finalMergedDocument);

		// Request Transformation Begins
		String requestPayloadForTargetEndPoint = createRequestPayloadForTargetEndPoint(workflowRequest, documentPayload,
				transactionId);

		LOGGER.info("Request Payload for Target Endpoint : " + requestPayloadForTargetEndPoint);

		String targetEndPointUrl = getTargetEndPointURL(finalMergedDocument, workflowRequest);

		TransformedResponsePayload transformedResponsePayload = getTransformedResponsePayload(workflowRequest,
				requestPayloadForTargetEndPoint);
		// Request Transformation Ends

		// CreateC Corelation Payload
		JSONObject corelationPayload = buildCorelationPayload(workflowRequest);

		JSONObject contentSchema = buildContentSchema(workflowRequest);

		updateOdsRequestLogWithTaskCompletionPayload(odsRequestLog, corelationPayload, contentSchema);

		// Create Response Config Params
		ResponseConfigParams responseConfigParams = createResponseConfigParam(workflowRequest);

		createInterfaceServiceRecord(manifestRequestPayload, corelationPayload, responseConfigParams,
				requestPayloadForTargetEndPoint, transactionId,
				workflowRequest.getString(Constants.ACTIVITY_INSTANCE_ID));

		// Add Request in Notes
		addRequestInNotesService(workflowRequest, finalMergedDocument, requestPayloadForTargetEndPoint, transactionId, odsRequestLog);

		String encodedCredentials = getEncodedCredentialsForTargetEndPointURL(workflowRequest);

		QueryParam queryParams = extractQueryParameters(targetEndPointUrl, finalMergedDocument);
		
		// Retrieving the transportHeader
		TransportHeader transportHeader = getTransportHeaders(workflowRequest);

		return populateOdsResponse(transformedResponsePayload, targetEndPointUrl, transactionId, encodedCredentials,
				queryParams, workflowRequest,transportHeader);
	}

	public void updateOdsRequestLogWithTaskCompletionPayload(OdsRequestLog odsRequestLog, JSONObject corelationPayload,
			JSONObject contentSchema) throws ApplicationException {

		JSONObject finalCorrelationJsonData = serviceUtils.mergeJSONObjects(corelationPayload, contentSchema);
		odsRequestLog.setWfTaskCompletionPayload(finalCorrelationJsonData.toString());
		odsRequestLogRepository.save(odsRequestLog);

	}

	/**
	 * API to validate mandatory attributes in manifest document
	 *
	 * @param manifestDocument
	 * @param workflowRequest
	 * @return
	 */
	public void validateMandatoryAttributesinManifestResponse(JSONObject manifestDocument, JSONObject workflowRequest)
			throws ApplicationException {

		String requestKey = serviceUtils.buildKey(workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequest.getString(Constants.FLOW_STEP_NAME));
		validateMandatoryAttributes(manifestDocument, requestKey);
	}

	/**
	 * API to create ResponseConfigParams for OdsInterfaceRequest
	 *
	 * @param requestPayload
	 * @return
	 * @throws ApplicationException
	 * @throws JSONException
	 */
	public ResponseConfigParams createResponseConfigParam(JSONObject requestPayload)
			throws JSONException, ApplicationException {
		LOGGER.info("Entering createResponseConfigParam");

		// Fetch the ODS Service Route Map entry from the DB/Cache.
		OdsServiceRouterMapDetails routerDetails = getServiceRouterMapDetails(
				requestPayload.getString(Constants.FLOW_PROCESS_NAME),
				requestPayload.getString(Constants.FLOW_STEP_NAME), requestPayload.optString(Constants.ODS_REGION));

		ResponseConfigParams responseConfigParam = new ResponseConfigParams();

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.FLOW_PROCESS_NAME)))
			responseConfigParam.setFlowNodeProcessName(requestPayload.getString(Constants.FLOW_PROCESS_NAME));

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.FLOW_STEP_NAME)))
			responseConfigParam.setFlowNodeStepName(requestPayload.getString(Constants.FLOW_STEP_NAME));

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.ACTIVITY_INSTANCE_ID)))
			responseConfigParam.setActivityInstanceId(requestPayload.getString(Constants.ACTIVITY_INSTANCE_ID));

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.CASE_ID)))
			responseConfigParam.setCaseID(requestPayload.getString(Constants.CASE_ID));

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.PARENT_CASE_ID)))
			responseConfigParam.setParentCaseID(requestPayload.getString(Constants.PARENT_CASE_ID));

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.ROOT_CASE_ID)))
			responseConfigParam.setRootCaseID(requestPayload.getString(Constants.ROOT_CASE_ID));

		responseConfigParam.setResponseDocumentName(routerDetails.getResponseDocumentName());
		responseConfigParam.setTransformationType(routerDetails.getTransformationType());
		responseConfigParam.setSourceSystemName(routerDetails.getSrcSystemName() != null ? routerDetails.getSrcSystemName() : "");
		responseConfigParam.setDestinationSystemName(routerDetails.getDestSystemName() != null ? routerDetails.getDestSystemName() : "");
		
		String appKey = requestPayload.getString(Constants.MANIFEST_APP_KEY_STR);
		if (null == appKey) {
			responseConfigParam.setAppKey(routerDetails.getAppKey());
		} else {
			responseConfigParam.setAppKey(appKey);
		}
		if (StringUtils.isNotEmpty(routerDetails.getSendMilestoneFlag())
				&& "YES".equalsIgnoreCase(routerDetails.getSendMilestoneFlag()))
			responseConfigParam.setSendMilestone(true);
		else
			responseConfigParam.setSendMilestone(false);
		
		
		LOGGER.info("Exiting createResponseConfigParam");
		return responseConfigParam;
	}

	public OdsRequestLog createOdsRequestLogEntry(JSONObject workflowRequest)
			throws JSONException, ApplicationException {

		String appKey = workflowRequest.optString("app-key");
		List<String> titleParams = new ArrayList();
		titleParams.add(Constants.TITLE_LITERAL);
		titleParams.add(Constants.TITLE_VERSION_LITERAL);

		List<OdsParamConfig> titleParamsPath = odsParamConfigRepository.findByParamKeyAndTypeAndNameIn(appKey,
				OdsParamConfigType.APPLICATION_PARAM.toString(), titleParams);
		String title = null, titleVersion = null;
		for (OdsParamConfig titleParam : titleParamsPath) {
			String path = titleParam.getValue();
			if (Constants.TITLE_LITERAL.equalsIgnoreCase(titleParam.getName())) {
				title = JsonPath.read(workflowRequest.toString(), path);
			} else if (Constants.TITLE_VERSION_LITERAL.equalsIgnoreCase(titleParam.getName())) {
				titleVersion = JsonPath.read(workflowRequest.toString(), path);
			}

		}
		return odsRequestLogService.createOdsRequestLogEntry(workflowRequest, title, titleVersion);
	}
	
	/**
	 * @param JSONObject
	 *            workflowRequest
	 * 
	 * @throws ApplicationException
	 */
	public JSONObject getTitleAndTitleVersion(JSONObject workflowRequest) {
		
		LOGGER.info("Entering getTitleAndTitleVersion");
		
		String appKey = workflowRequest.getString("app-key");
		List<String> titleParams = new ArrayList<String>();
		titleParams.add(Constants.TITLE_LITERAL);
		titleParams.add(Constants.TITLE_VERSION_LITERAL);

		List<OdsParamConfig> titleParamsPath = odsParamConfigRepository.findByParamKeyAndTypeAndNameIn(appKey,
				OdsParamConfigType.APPLICATION_PARAM.toString(), titleParams);
		String title = null, titleVersion = null;
		for (OdsParamConfig titleParam : titleParamsPath) {
			String path = titleParam.getValue();
			if (Constants.TITLE_LITERAL.equalsIgnoreCase(titleParam.getName())) {
				title = JsonPath.read(workflowRequest.toString(), path);
			} else if (Constants.TITLE_VERSION_LITERAL.equalsIgnoreCase(titleParam.getName())) {
				titleVersion = JsonPath.read(workflowRequest.toString(), path);
			}

		}
		
		JSONObject titleJson = new JSONObject();
		titleJson.put("title", title);
		titleJson.put("titleVersion", titleVersion);
		
		LOGGER.info("Exiting getTitleAndTitleVersion");
		
		return titleJson;
	}

	/**
	 * @param JSONObject
	 *            workflowRequest
	 * @param JSONObject
	 *            manifestDocument
	 * @throws ODSRequestValidationException
	 */
	private String generateTransactionId(JSONObject workflowRequest, JSONObject manifestDocument)
			throws ApplicationException {
		OdsRequestTransactionIdMap odsRequestTransactionIdMap = odsRequestResponseTransactionIdMapService
				.findByFlowNodeProcessNameAndFlowNodeStepName(workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
						workflowRequest.getString(Constants.FLOW_STEP_NAME));
		if (odsRequestTransactionIdMap == null
				|| StringUtils.isEmpty(odsRequestTransactionIdMap.getTransactionIdKey())) {
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(),
					"ODS Request Transaction Id Map Table entry not found.");
		}
		if (odsRequestTransactionIdMap.getTransactionIdKey().equalsIgnoreCase(Constants.DEFAULT)) {
			return generateDefaultTransactionId(workflowRequest.getString(Constants.PROCESS_INSTANCE_ID),
					workflowRequest.getString(Constants.ACTIVITY_INSTANCE_ID));
		} else {
			// Appending the Request Document to the Manifest Document to
			// provide a flexible option to read the attributes.
			String finalDocument = serviceUtils.mergeDocumentByName(manifestDocument, workflowRequest,
					Constants.REQUEST_PAYLOAD);
			return odsRequestResponseTransactionIdMapService.generateTransactionIdUsingTransactionIdKey(finalDocument,
					odsRequestTransactionIdMap.getTransactionIdKey());
		}
	}

	/**
	 * @param workflowRequest
	 * @param targetEndPointUrl
	 * @param encodedCredentials
	 * @param queryParams
	 * @param transportHeader
	 * @return
	 * @throws ApplicationException
	 */
	private OdsResponse populateOdsResponse(TransformedResponsePayload payload, String targetEndPointUrl,
			String transactionId, String encodedCredentials, QueryParam queryParams, JSONObject workflowRequest,TransportHeader transportHeader )
			throws ApplicationException {
		LOGGER.info("Entering populateOdsResponse");
		// Fetch the ODS Service Route Map entry from the DB/Cache.
		OdsServiceRouterMapDetails serviceRouteMapDetails = getServiceRouterMapDetails(
				workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequest.getString(Constants.FLOW_STEP_NAME), workflowRequest.optString(Constants.ODS_REGION));

		String routeProtocol = serviceRouteMapDetails.getRouterProtocol();
		String transformationType = serviceRouteMapDetails.getTransformationType();
		String replyToQueueName = serviceRouteMapDetails.getReplyToQueueName();
		String requestMethod = serviceRouteMapDetails.getRequestMethod();
		String serviceMode = serviceRouteMapDetails.getServiceMode();
		LOGGER.info("Exiting populateOdsResponse");
		return new OdsResponse(payload, targetEndPointUrl, routeProtocol, transactionId, encodedCredentials,
				transformationType, queryParams, replyToQueueName, requestMethod,serviceMode,transportHeader);
	}

	/**
	 * @param workflowRequest
	 * @param requestPayloadForTargetEndPoint
	 * @return
	 * @throws ApplicationException
	 */
	private TransformedResponsePayload getTransformedResponsePayload(JSONObject workflowRequest,
			String requestPayloadForTargetEndPoint) throws ApplicationException {
		// Fetch the ODS Service Route Map entry from the DB/Cache.
		OdsServiceRouterMapDetails serviceRouteMapDetails = getServiceRouterMapDetails(
				workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequest.getString(Constants.FLOW_STEP_NAME), workflowRequest.optString(Constants.ODS_REGION));
		return serviceUtils.getTransformationPayload(null, requestPayloadForTargetEndPoint,
				serviceRouteMapDetails.getRouterProtocol());
	}

	/**
	 * Method to add the request payload to the Notes Service.
	 * @param odsRequestLog 
	 * 
	 * @param JSONObject
	 *            workflowRequest
	 * @param JSONObject
	 *            manifestPayload
	 * @param String
	 *            requestPayloadForTargetEndPoint
	 * @param String
	 *            transactionId
	 * @throws ApplicationException
	 */
	private void addRequestInNotesService(JSONObject workflowRequest, JSONObject finalDocument, String requestPayloadForTargetEndPoint,
			String transactionId, OdsRequestLog odsRequestLog) throws ApplicationException {

		String requestKey = serviceUtils.buildKey(workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequest.getString(Constants.FLOW_STEP_NAME));
		
		// Fetch the ODS Service Route Map entry from the DB/Cache.
		OdsServiceRouterMapDetails serviceRouteMapDetails = getServiceRouterMapDetails(
				workflowRequest.getString(Constants.FLOW_PROCESS_NAME), workflowRequest.getString(Constants.FLOW_STEP_NAME),
				workflowRequest.optString(Constants.ODS_REGION));
				
		// Prepare notes payload JSON for transformation
		JSONObject notesJsonForTransformation = notesService.prepareNotesPayload(odsRequestLog.getTitle(),
				odsRequestLog.getTitleVersion(), Constants.REQUEST_SENT_SUCCESSFULLY, requestPayloadForTargetEndPoint,
				workflowRequest.getString(Constants.FLOW_STEP_NAME),
				serviceRouteMapDetails.getSrcSystemName() != null ? serviceRouteMapDetails.getSrcSystemName() : "",
				serviceRouteMapDetails.getDestSystemName() != null ? serviceRouteMapDetails.getDestSystemName() : "");

		// Add Notes
		notesService.addNotes(notesJsonForTransformation, requestKey);

	}

	/**
	 * Method to extract query parameters from the target endpoint URL.
	 * 
	 * @param JSONObject
	 *            workflowRequest
	 * @return QueryParam
	 * @throws ApplicationException
	 */
	private QueryParam extractQueryParameters(String targetEndPointURL, JSONObject finalDocument)
			throws ApplicationException {
		return serviceUtils.extractQueryParameters(targetEndPointURL, finalDocument);
	}

	/**
	 * Method to get the encoded credentials if username and password are configured
	 * for a step.
	 * 
	 * @param JSONObject
	 *            workflowRequest
	 * @throws ApplicationException
	 */
	private String getEncodedCredentialsForTargetEndPointURL(JSONObject workflowRequest) throws ApplicationException {
		// encoding UsernamePassword
		String encodedCredentials = "";

		// Fetch the ODS Service Route Map entry from the DB/Cache.
		OdsServiceRouterMapDetails serviceRouteMapDetails = getServiceRouterMapDetails(
				workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequest.getString(Constants.FLOW_STEP_NAME), workflowRequest.optString(Constants.ODS_REGION));

		String userName = serviceRouteMapDetails.getUserName();
		String password = serviceRouteMapDetails.getPassword();

		if (!(StringUtils.isEmpty(userName) && StringUtils.isEmpty(password))) {
			LOGGER.info("User Name and Password configured for the step");
			encodedCredentials = serviceUtils.userNamePasswordEncoder(userName, password);
		} else if (StringUtils.isEmpty(userName) && !StringUtils.isEmpty(password)) {
			LOGGER.info("Encoded Password configured for the step");
			encodedCredentials = password;
		}
		return encodedCredentials;
	}

	/**
	 * Method to fetch the target service end point URL.
	 * 
	 * @param JSONObject
	 *            workflowRequest
	 * @param String
	 *            requestPayloadForTargetEndPoint
	 * @throws ApplicationException
	 * @throws JSONException
	 * 
	 */
	private String getTargetEndPointURL(JSONObject finalDocument, JSONObject workflowRequest)
			throws JSONException, ApplicationException {
		// preparing targetEndpoint dynamically
		// Fetch the ODS Service Route Map entry from the DB/Cache.
		OdsServiceRouterMapDetails serviceRouteMapDetails = getServiceRouterMapDetails(
				workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequest.getString(Constants.FLOW_STEP_NAME), workflowRequest.optString(Constants.ODS_REGION));
		return serviceUtils.generateDynamicTargetEndPointUrl(finalDocument,
				serviceRouteMapDetails.getTargetEndPointUrl(), serviceRouteMapDetails.getFlowNodeProcessName());
	}

	/**
	 * @param documentPayload
	 * @param corelationPayload
	 * @param responseConfigParams
	 * @param requestPayloadForTargetEndPoint
	 * @param transactionId
	 */
	public void createInterfaceServiceRecord(JSONObject documentPayload, JSONObject corelationPayload,
			ResponseConfigParams responseConfigParams, String requestPayloadForTargetEndPoint, String transactionId,
			String taskId) {
		ODSInterfaceServiceRequest interfaceServiceRequest = new ODSInterfaceServiceRequest(transactionId, taskId,
				requestPayloadForTargetEndPoint, documentPayload.toString(), corelationPayload.toString(),
				responseConfigParams.toJSONString());
		odsInterfaceRequestService.createInterfaceServiceRecord(interfaceServiceRequest);
	}

	private JSONObject mergeManifestAndRequestDocuments(JSONObject workflowRequest, JSONObject documentPayload,
			String transactionId) throws ApplicationException {
		JSONObject finalDocument = documentPayload;
		LOGGER.info("Appending the TRANSACTION_ID and Original Payload sent to One Dispatcher to Manifest Document");
		finalDocument.put(Constants.TRANSACTION_ID, transactionId);
		finalDocument.put(Constants.REQUEST_PAYLOAD, workflowRequest);

		return finalDocument;
	}

	/**
	 * @param workflowRequest
	 * @param documentPayload
	 * @param transactionId
	 * @return
	 * @throws ApplicationException
	 */
	private String createRequestPayloadForTargetEndPoint(JSONObject workflowRequest, JSONObject documentPayload,
			String transactionId) throws ApplicationException {
		String requestPayloadForTargetEndPoint;
		if (documentPayload.length() == 0) {
			requestPayloadForTargetEndPoint = workflowRequest.toString();
		} else {
			LOGGER.info(
					"Appending the TRANSACTION_ID and Original Payload sent to One Dispatcher to Manifest Document");
			documentPayload.put(Constants.TRANSACTION_ID, transactionId);
			documentPayload.put(Constants.REQUEST_PAYLOAD, workflowRequest);

			// Fetch the ODS Service Route Map entry from the DB/Cache.
			OdsServiceRouterMapDetails serviceRouteMapDetails = getServiceRouterMapDetails(
					workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
					workflowRequest.getString(Constants.FLOW_STEP_NAME),
					workflowRequest.optString(Constants.ODS_REGION));

			TransformRequest transformRequest = new TransformRequest(
					workflowRequest.optString(Constants.MANIFEST_APP_KEY_STR).toString(),
					serviceRouteMapDetails.getTransformationType(), documentPayload.toString(),
					serviceRouteMapDetails.getRequestSchema());

			LOGGER.info("Transformation Type is:::" + serviceRouteMapDetails.getTransformationType());

			// Do Transformation
			String tranformedDocument=null;
			if(StringUtils.isEmpty(serviceRouteMapDetails.getRequestSchema())) {
				tranformedDocument = workflowRequest.toString();
			}
			else {
				tranformedDocument = odsTransformationService.doTransformation(transformRequest);
			}
			

			if (Constants.TRANSFORMATION_XML_TYPE.equalsIgnoreCase(serviceRouteMapDetails.getTransformationType())) {
				requestPayloadForTargetEndPoint = StringEscapeUtils.unescapeXml(tranformedDocument);
			} else {
				requestPayloadForTargetEndPoint = tranformedDocument;
			}
		}
		LOGGER.info("Request Payload for target endpoint::: \n" + requestPayloadForTargetEndPoint);
		return requestPayloadForTargetEndPoint;
	}

	/**
	 * ODS Redesign - validate the co-relation from ods_wf_corelation_config with
	 * payload from workflow.
	 *
	 * @param requestObj
	 * @return JSONObject
	 * @throws ApplicationException
	 */
	public JSONObject buildCorelationPayload(JSONObject workflowRequest) throws ApplicationException {
		LOGGER.info("Entering buildCorelationPayload");
		JSONObject corelationPayload = new JSONObject();

		try {
			String requestKey = serviceUtils.buildKey(workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
					workflowRequest.getString(Constants.FLOW_STEP_NAME));
			/* Get correlation schema from App Param table */
			OdsParamConfig odsParam = odsParamConfigService.findByParamKeyAndTypeAndName(requestKey,
					OdsParamConfigType.WORKFLOW_CORRELATION_PARAM.toString(), Constants.CORRELATION_SCHEMA);
			if (odsParam != null) {
				serviceUtils.populateJsonPayload(odsParam.getValue(), workflowRequest.toString(), corelationPayload);
			}
		} catch (Exception e) {
			LOGGER.warn(StatusCode.ERROR_WF_CORELATION_NOTFOUND.getDesc(), e);
		}

		LOGGER.info("Correlation defined is :::" + corelationPayload.toString());
		LOGGER.info("Exiting buildCorelationPayload");

		return corelationPayload;
	}

	/**
	 * ODS Redesign - validate the co-relation from ods_wf_corelation_config with
	 * payload from workflow.
	 *
	 * @param requestObj
	 * @return JSONObject
	 * @throws ApplicationException
	 */
	public JSONObject buildContentSchema(JSONObject workflowRequest) throws ApplicationException {
		LOGGER.info("Entering buildContentSchema");
		JSONObject contentSchema = new JSONObject();

		try {
			String requestKey = serviceUtils.buildKey(workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
					workflowRequest.getString(Constants.FLOW_STEP_NAME));
			/* Get correlation schema from App Param table */
			OdsParamConfig odsParam = odsParamConfigService.findByParamKeyAndTypeAndName(requestKey,
					OdsParamConfigType.WORKFLOW_CORRELATION_PARAM.toString(), Constants.CONTENT_SCHEMA);
			if (odsParam != null) {
				serviceUtils.populateJsonPayload(odsParam.getValue(), "{}", contentSchema);
			} else {
				String contentSchemaStr = "{contents:{}}";
				contentSchema = new JSONObject(contentSchemaStr);
			}
		} catch (Exception e) {
			LOGGER.warn(StatusCode.ERROR_WF_CORELATION_NOTFOUND.getDesc(), e);
		}

		LOGGER.info("ContentSchema defined is :::" + contentSchema.toString());
		LOGGER.info("Exiting buildContentSchema");

		return contentSchema;
	}

	/**
	 * Method to fetch the ODS Service Route Map entry from the DB/Cache.
	 * 
	 * @param String
	 *            processName
	 * @param String
	 *            stepName
	 * @param string
	 *            region
	 * @return OdsServiceRouterMapDetails
	 * @throws ApplicationException
	 */
	public OdsServiceRouterMapDetails getServiceRouterMapDetails(String processName, String stepName, String region)
			throws ApplicationException {
		OdsServiceRouterMapDetails details = null;
		if (StringUtils.isEmpty(region))
			details = odsServiceRouterMapRepository.findByFlowNodeProcessNameAndFlowNodeStepName(processName, stepName);
		else
			details = odsServiceRouterMapRepository.findByFlowNodeProcessNameAndFlowNodeStepNameAndRegion(processName,
					stepName, region);
		if (null == details) {
			LOGGER.error("ODS Service router configuration not found");
			throw new ApplicationException(StatusCode.ERROR_ODS_ROUTER_MAP_CONFIG_NOTCONFIGURED.getCode(),
					StatusCode.ERROR_ODS_ROUTER_MAP_CONFIG_NOTCONFIGURED.getDesc());
		}
		return details;
	}

	/**
	 * @param workflowRequest
	 * @return
	 * @throws ODSRequestValidationException
	 * @throws ApplicationException
	 */
	public JSONObject buildManifestRequestPayload(JSONObject workflowRequest)
			throws ApplicationException {

		// Fetch the ODS Service Route Map entry from the DB/Cache.
		OdsServiceRouterMapDetails odsServiceRouteMapDetails = getServiceRouterMapDetails(
				workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequest.getString(Constants.FLOW_STEP_NAME), workflowRequest.optString(Constants.ODS_REGION));

		String requestDocumentName = odsServiceRouteMapDetails.getRequestDocumentName();

		if (StringUtils.isEmpty(requestDocumentName)) {
			return new JSONObject();
		}
		JSONObject documentPayload = new JSONObject();
		// Check the given Step has any data service url is configured. if Yes, then get
		// the input document by calling the Service
		// what if the data service is SOAP ? TBD****************
		// Assuming the Data Service configured is REST
		String requestKey = serviceUtils.buildKey(workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequest.getString(Constants.FLOW_STEP_NAME));
		OdsParamConfig odsParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(requestKey,
				OdsParamConfigType.DATA_SERVICE_REQUEST.toString(), Constants.DATA_SERVICE_REQUEST_URL);
		// Generate the TRANSACTION_ID- Either DEFAULT or GET it from path
		if (odsParam != null && StringUtils.isNotEmpty(odsParam.getValue())) {
			JSONObject customerPayload = workflowRequest.getJSONObject(Constants.SEED_INFO);
			String documentPayloadStr = getDocumentFromCustomService(odsParam.getValue(), customerPayload.toString());
			documentPayload = new JSONObject(documentPayloadStr);
		} else {
			documentPayload = manifestService.fetchManifestRequestPayload(workflowRequest);
		}
		return documentPayload;
	}

	/**
	 * @param workflowRequest
	 * @param manifestRequestPayload
	 * @return
	 * @throws ODSRequestValidationException
	 * @throws ApplicationException
	 */
	public JSONObject fetchManifestDocuments(JSONObject manifestRequestPayload, JSONObject workflowRequest)
			throws JSONException, ApplicationException {

		// Fetch the ODS Service Route Map entry from the DB/Cache.
		OdsServiceRouterMapDetails odsServiceRouteMapDetails = getServiceRouterMapDetails(
				workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequest.getString(Constants.FLOW_STEP_NAME), workflowRequest.optString(Constants.ODS_REGION));
		
		if (StringUtils.isEmpty(odsServiceRouteMapDetails.getRequestDocumentName())) {
			return new JSONObject();
		}

		return manifestService.buildManifestDocument(manifestRequestPayload,
				odsServiceRouteMapDetails.getRequestDocumentName());
	}

	/**
	 * @param request
	 * @return TransformationResponse
	 * @throws ApplicationException
	 */
	public OdsResponse getTransformedResponse(String request) throws ApplicationException {
		LOGGER.info("Entering getTransformedResponse");
		String manifestPayload = null;
		OdsResponse resp;
		String header = null;
		String documentPayload = null;

		String requestKey = null;
		String appKey = null;

		// Convert input JSON string into JSON Object
		JSONObject workflowRequestJsonObj = new JSONObject(request);

		// Get appKey from the request
		if (workflowRequestJsonObj.has(Constants.MANIFEST_APP_KEY_STR)) {
			appKey = workflowRequestJsonObj.get(Constants.MANIFEST_APP_KEY_STR).toString();
		}

		// Get the ODS Service Router Map Details
		OdsServiceRouterMapDetails details = odsServiceRouteMapService.getServiceRouterMapDetails(
				workflowRequestJsonObj.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequestJsonObj.getString(Constants.FLOW_STEP_NAME),
				workflowRequestJsonObj.optString(Constants.ODS_REGION));

		validateTargetEndPointUrl(details);
		if (!StringUtils.isEmpty(details.getTargetEndPointUrl()) && !StringUtils.isEmpty(details.getRouterProtocol())) {

			LOGGER.info("Request Schema is not null");
			// Prepare the request key
			requestKey = serviceUtils.buildKey(workflowRequestJsonObj.getString(Constants.FLOW_PROCESS_NAME),
					workflowRequestJsonObj.getString(Constants.FLOW_STEP_NAME));

			LOGGER.info("Request Key : " + requestKey);
			LOGGER.info("App Key : " + appKey);

			// Check the given Step has any data service url is configured. if Yes, then get
			// the input document by calling the Service
			// what if the data service is SOAP ? TBD****************
			// Assuming the Data Service configured is REST
			OdsParamConfig odsParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(requestKey,
					OdsParamConfigType.DATA_SERVICE_REQUEST.toString(), Constants.DATA_SERVICE_REQUEST_URL);
			// Generate the TRANSACTION_ID- Either DEFAULT or GET it from path
			if (odsParam != null && StringUtils.isNotEmpty(odsParam.getValue())) {
				JSONObject customerPayload = workflowRequestJsonObj.getJSONObject(Constants.SEED_INFO);
				documentPayload = getDocumentFromCustomService(odsParam.getValue(), customerPayload.toString());
			} else {
				manifestPayload = validateAndBuildManifestPayload(workflowRequestJsonObj, details);
				if (!StringUtils.isEmpty(details.getRequestDocumentName()) && null != manifestPayload) {
					documentPayload = serviceUtils.buildManifestDocument(manifestPayload,
							details.getRequestDocumentName());
				}
			}
			// Get the TransactionID from DEFAULT if not configured or else read form
			// requestDocument from Manifest
			String transactionId = getGeneratedTransactionId(workflowRequestJsonObj, documentPayload);
			LOGGER.info("GENERATED TRANSACTION_ID IS::::::::::::::::::::::::::::::::::: : " + transactionId);
			JSONObject corelationPayload = validateAndBuildCorelationPayload(workflowRequestJsonObj, requestKey);
			// Make sure we have transformation Type and request Schema
			if (StringUtils.isNotEmpty(details.getRequestSchema())
					&& StringUtils.isNotEmpty(details.getTransformationType())) {
				// Asking ODS to do the transformation and Routing
				resp = handleTransformationAndRouting(transactionId, workflowRequestJsonObj, details, documentPayload,
						manifestPayload, corelationPayload.toString());
			} else {
				// Just Route it with original request payload
				resp = handleRestRouting(details, request, header, transactionId, workflowRequestJsonObj, appKey,
						requestKey);
			}

		} else {
			LOGGER.error("ODS Service router configuration not found");
			throw new ApplicationException(StatusCode.ERROR_ODS_ROUTER_MAP_CONFIG_NOTCONFIGURED.getCode(),
					StatusCode.ERROR_ODS_ROUTER_MAP_CONFIG_NOTCONFIGURED.getDesc());
		}
		LOGGER.info("Exiting getTransformedResponse");
		return resp;
	}

	/**
	 * @param transactionId
	 * @param workflowRequestJsonObj
	 * @param details
	 * @param documentPayload
	 * @param manifestPayload
	 * @param correlationPayload
	 * @return OdsResponse
	 * @throws ApplicationException
	 */
	public OdsResponse handleTransformationAndRouting(String transactionId, JSONObject workflowRequestJsonObj,
			OdsServiceRouterMapDetails details, String documentPayload, String manifestPayload,
			String correlationPayload) throws ApplicationException {
		LOGGER.info(">>Entering handleTransformationAndRouting");

		TransformedResponsePayload payload = null;
		String appKey = details.getAppKey();
		ResponseConfigParams responseConfigParam = createResponseConfigParam(details, workflowRequestJsonObj, appKey);

		// Convert Object to JSON String
		String responseConfigParamJsonString = serviceUtils.convertObjectToJsonString(responseConfigParam);
		LOGGER.info("responseConfigParam : " + responseConfigParamJsonString);

		JSONObject finalDocument = new JSONObject(documentPayload);

		LOGGER.info("Appending the TRANSACTION_ID and Original Payload sent to One Dispatcher to Manifest Document");
		finalDocument.put(Constants.TRANSACTION_ID, transactionId);
		finalDocument.put(Constants.REQUEST_PAYLOAD, workflowRequestJsonObj);

		TransformRequest tranformReq = new TransformRequest(details.getTransformationType(), finalDocument.toString(),
				details.getRequestSchema());

		LOGGER.info("Required Transformation Type is:::" + details.getTransformationType());

		String tranformedDocument;
		String requestKey = serviceUtils.buildKey(details.getFlowNodeProcessName(), details.getFlowNodeStepName());

		// Do Transformation
		String tranformedDocumentStr = doTransformation(tranformReq, appKey, requestKey);

		if (details.getTransformationType().equalsIgnoreCase(Constants.TRANSFORMATION_XML_TYPE)) {
			tranformedDocument = StringEscapeUtils.unescapeXml(tranformedDocumentStr);
		} else {
			tranformedDocument = tranformedDocumentStr;
		}
		LOGGER.info("Tranformed Document is ::: \n" + tranformedDocument);

		// SAVE the TRANSACTION BEFORE RETURNING
		OdsInterfaceRequest requestFromDb = odsRequestRepo.findByTransactionIdAndStatus(transactionId,
				StatusCode.REQUEST_PENDING.toString());
		if (null != requestFromDb && StringUtils.isNotEmpty(requestFromDb.getRequest())) {
			requestFromDb.setCoreleationPayload(correlationPayload);
			requestFromDb.setManifestPayload(manifestPayload);
			requestFromDb.setRequest(tranformedDocument);
			requestFromDb.setStatus(StatusCode.REQUEST_PENDING.toString());
			requestFromDb.setRequestTime(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
			requestFromDb.setResponseConfigParam(responseConfigParamJsonString);
		} else {
			requestFromDb = new OdsInterfaceRequest(transactionId, correlationPayload, manifestPayload,
					tranformedDocument, new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()),
					StatusCode.REQUEST_PENDING.toString(), responseConfigParamJsonString);
		}

		LOGGER.info("ODS INTERFACE REQUEST OBJECT NEEDS TO BE INSERTED IS:::::" + requestFromDb.toString());
		LOGGER.info("########CREATING THE TRANSACTION BEFORE SENDING IT TO TARGET#########");
		odsRequestRepo.save(requestFromDb);

		// Prepare response payload
		LOGGER.info("Extracting the body and header in order to send to target");
		payload = serviceUtils.getTransformationPayload(payload, tranformedDocument, details.getRouterProtocol());

		// encoding UsernamePassword
		String encodedCredentials = "";
		if (!(StringUtils.isEmpty(details.getUserName()) && StringUtils.isEmpty(details.getPassword()))) {
			LOGGER.info("User Name and Password configured for the step");
			encodedCredentials = serviceUtils.userNamePasswordEncoder(details.getUserName(), details.getPassword());
		} else if (StringUtils.isEmpty(details.getUserName()) && !StringUtils.isEmpty(details.getPassword())) {
			LOGGER.info("Encoded Password configured for the step");
			encodedCredentials = details.getPassword();
		}

		// preparing targetEndpoint dynamically
		String targetEndPointUrl = serviceUtils.generateDynamicTargetEndPointUrl(finalDocument,
				details.getTargetEndPointUrl(), details.getFlowNodeProcessName());
		QueryParam queryParams = serviceUtils.extractQueryParameters(targetEndPointUrl, finalDocument);

		// call the Notes AddOrUpdate Service
		finalDocument.put(Constants.SOURCE_SYSTEM_NAME,
				details.getSrcSystemName() != null ? details.getSrcSystemName() : "");
		finalDocument.put(Constants.DESTINATION_SYSTEM_NAME,
				details.getDestSystemName() != null ? details.getDestSystemName() : "");
		notesService.addRequestInNotesService(tranformedDocument, transactionId,
				workflowRequestJsonObj.getString(Constants.FLOW_STEP_NAME), finalDocument, requestKey);

		LOGGER.info("<< Exiting handleTransformationAndRouting");
		return new OdsResponse(payload, targetEndPointUrl, details.getRouterProtocol(), transactionId,
				encodedCredentials, details.getTransformationType(), queryParams, details.getReplyToQueueName(),
				details.getRequestMethod());
	}

	/**
	 * @param details
	 * @param request
	 * @param header
	 * @param notesPayLoad
	 * @param transactionId
	 * @param workflowRequestJsonObj
	 * @return OdsResponse
	 * @throws ApplicationException
	 */
	public OdsResponse handleRestRouting(OdsServiceRouterMapDetails details, String request, String header,
			String transactionId, JSONObject workflowRequestJsonObj, String appKey, String requestKey)
			throws ApplicationException {
		LOGGER.info(">> Entering handleRestRouting");
		// Since the request payload is not defined hence the user is not
		// interested in the transform feature of ODS. He just want to to use
		// Route capability of the ODS, Hence appending the Original Bonita
		// Workflow request payload and routing it to target end point.
		LOGGER.info("ODS CUSTOM HANDLING REQUEST::::Request Schema is null hence appending"
				+ " the original Payload sent to One Dispatcher for target proxy");

		ResponseConfigParams responseConfigParam = createResponseConfigParam(details, workflowRequestJsonObj, appKey);
		// Convert Object to JSON String
		String responseConfigParamJsonString = serviceUtils.convertObjectToJsonString(responseConfigParam);

		// SAVE the TRANSACTION BEFORE RETURNING
		OdsInterfaceRequest requestFromDb = odsRequestRepo.findByTransactionIdAndStatus(transactionId,
				StatusCode.REQUEST_PENDING.toString());
		if (null == requestFromDb || StringUtils.isEmpty(requestFromDb.getRequest())) {
			requestFromDb = new OdsInterfaceRequest();
			requestFromDb.setTransactionId(transactionId);
		}

		requestFromDb.setRequest(request);
		requestFromDb.setStatus(StatusCode.REQUEST_PENDING.toString());
		requestFromDb.setRequestTime(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
		requestFromDb.setResponseConfigParam(responseConfigParamJsonString);

		LOGGER.info("ODS INTERFACE REQUEST OBJECT NEEDS TO BE INSERTED IS : " + requestFromDb.toString());
		LOGGER.info("########CREATING THE TRANSACTION BEFORE SENDING IT TO TARGET#########");
		odsRequestRepo.save(requestFromDb);

		TransformedResponsePayload payload = new TransformedResponsePayload(request, header);
		// encoding UsernamePassword
		String encodedCredentials = "";
		if (!(StringUtils.isEmpty(details.getUserName()) && StringUtils.isEmpty(details.getPassword()))) {
			LOGGER.info("User Name and Password configured for the step");
			encodedCredentials = serviceUtils.userNamePasswordEncoder(details.getUserName(), details.getPassword());
		} else if (StringUtils.isEmpty(details.getUserName()) && !StringUtils.isEmpty(details.getPassword())) {
			LOGGER.info("Encoded Password configured for the step");
			encodedCredentials = details.getPassword();
		}

		// preparing targetEndpoint dynamically
		String targetEndPointUrl = serviceUtils.generateDynamicTargetEndPointUrl(workflowRequestJsonObj,
				details.getTargetEndPointUrl(), details.getFlowNodeProcessName());
		QueryParam queryParams = serviceUtils.extractQueryParameters(targetEndPointUrl, workflowRequestJsonObj);
		OdsResponse resp = new OdsResponse(payload, targetEndPointUrl, details.getRouterProtocol(), transactionId,
				encodedCredentials, details.getTransformationType(), queryParams, details.getReplyToQueueName(),
				details.getRequestMethod());

		// call the Notes AddOrUpdate Service
		workflowRequestJsonObj.put(Constants.SOURCE_SYSTEM_NAME,
				details.getSrcSystemName() != null ? details.getSrcSystemName() : "");
		workflowRequestJsonObj.put(Constants.DESTINATION_SYSTEM_NAME,
				details.getDestSystemName() != null ? details.getDestSystemName() : "");
		notesService.addRequestInNotesService(request, transactionId,
				workflowRequestJsonObj.getString(Constants.FLOW_STEP_NAME), workflowRequestJsonObj, requestKey);

		LOGGER.info("<< Existing handleRestRouting");
		return resp;
	}

	/**
	 * Method Retrieves the Transaction via RequestJsonPath Configured in the
	 * ODS_REQUEST_TRANSACTION_ID_MAP TABLE
	 *
	 * @param workflowRequestJsonObj
	 * @param documentPayload
	 * @return String
	 */
	public String getGeneratedTransactionId(JSONObject workflowRequestJsonObj, String documentPayload)
			throws ApplicationException {
		OdsRequestTransactionIdMap odsRequestTransactionIdMap = null;

		try {
			odsRequestTransactionIdMap = odsRequestTransactionIdMapRepository
					.findByFlowNodeProcessNameAndFlowNodeStepName(
							workflowRequestJsonObj.getString(Constants.FLOW_PROCESS_NAME),
							workflowRequestJsonObj.getString(Constants.FLOW_STEP_NAME));
		} catch (Exception e) {
			LOGGER.error("Error while calling Manifest GET Service", e);
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(),
					"ODS REQUEST TRANSACTION TABLE IS NOT HAVING THE TRANSACTION ID MAPPING. Please check");
		}
		if (null != odsRequestTransactionIdMap
				&& StringUtils.isNotEmpty(odsRequestTransactionIdMap.getTransactionIdKey())) {
			if (odsRequestTransactionIdMap.getTransactionIdKey().equalsIgnoreCase(Constants.DEFAULT)) {
				return generateDefaultTransactionId(workflowRequestJsonObj.getString(Constants.PROCESS_INSTANCE_ID),
						workflowRequestJsonObj.getString(Constants.ACTIVITY_INSTANCE_ID));
			} else {
				// Appending the Request payload to provide user for more flexible option to
				// read the attributes from botj
				//
				String finalDocument = serviceUtils.mergeDocumentByName(new JSONObject(documentPayload),
						workflowRequestJsonObj, Constants.REQUEST_PAYLOAD);
				return serviceUtils.generateTransactionIdUsingTransactionIdKey(finalDocument,
						odsRequestTransactionIdMap.getTransactionIdKey());
			}
		} else {
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(),
					"ODS REQUEST TRANSACTION TABLE IS NOT HAVING THE TRANSACTION ID MAPPING. Please check");
		}
	}

	/**
	 * @param caseId
	 * @param taskId
	 * @return String
	 */
	public String generateDefaultTransactionId(String caseId, String taskId) {
		return System.currentTimeMillis() + "|" + caseId + "|" + taskId;
	}

	/**
	 * Custom Service returns the document required for ODS Request transformation
	 * Service
	 * 
	 * @param customServiceUrl
	 * @param customServicePayload
	 * @return String
	 * @throws ApplicationException
	 */
	public String getDocumentFromCustomService(String customServiceUrl, String customServicePayload)
			throws ApplicationException {
		LOGGER.info("Entering getDocumentFromCustomService");

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(customServicePayload, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(customServiceUrl, HttpMethod.POST, httpEntity, String.class);
		} catch (Exception e) {
			LOGGER.error("Error while calling Manifest GET Service", e);
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Error while calling Manifest GET Service. " + e.getMessage());
		}

		String manifestResponse;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			manifestResponse = responseEntity.getBody();
			if (StringUtils.isEmpty(manifestResponse)) {
				LOGGER.error(StatusCode.MANIFEST_RESPONSE_IS_NULL.getDesc());
				throw new ApplicationException(StatusCode.MANIFEST_RESPONSE_IS_NULL.getCode(),
						StatusCode.MANIFEST_RESPONSE_IS_NULL.getDesc());
			}
		} else {
			LOGGER.error("Error Received failure response from Manifest GET Service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from Manifest GET Service");
		}

		LOGGER.info("Retrived Manifest Document is:::" + manifestResponse);
		LOGGER.info("Exiting getDocumentFromCustomService");
		return manifestResponse;
	}

	/**
	 * @param details
	 * @throws ApplicationException
	 */
	public void validateTargetEndPointUrl(OdsServiceRouterMapDetails details) throws ApplicationException {
		if (StringUtils.isEmpty(details.getTargetEndPointUrl())) {
			LOGGER.error("Target End point URL is not configured in ODS config");
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(),
					"Target End point URL is not configured in ODS config");
		}
	}

	/**
	 * @param details
	 * @throws ApplicationException
	 */
	public void checkRequestDocumentNamePresent(OdsServiceRouterMapDetails details) throws ApplicationException {
		if (StringUtils.isEmpty(details.getRequestDocumentName())) {
			LOGGER.error("Request Document Name is not configured in ODS config");
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(),
					"Request Document Name is not configured in ODS config");
		}

	}

	/**
	 * @param req
	 * @throws ApplicationException
	 */
	public void validateAppkey(JSONObject req) throws ApplicationException {
		if (StringUtils.isEmpty(req.get(Constants.MANIFEST_APP_KEY_STR).toString())) {
			LOGGER.error("AppKey is null or empty");
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "AppKey is null or empty");
		}
	}

	/**
	 * The method verifies the mandatory attributes configured in the
	 * ods_mandatory_attrs for given APPKEY. These attributes are required in order
	 * to fetch the document from Manifest DB.
	 *
	 * @param requestObj
	 * @param details
	 * @throws ApplicationException
	 */
	public String validateAndBuildManifestPayload(JSONObject requestObj, OdsServiceRouterMapDetails details)
			throws ApplicationException {
		String entityData = null;
		// Check if the target URL is present or not

		// Step1 - Check if the request schema is present in the ODS config
		// table if yes then proceed for transform
		if (!StringUtils.isEmpty(details.getRequestSchema())) {
			validateAppkey(requestObj);
			// Check the request document name
			checkRequestDocumentNamePresent(details);
			// Validate Manifest attributes
			List<OdsMandatoryAttributes> mandatoryAttrbsList = odsMandatoryAttrsService
					.getMandatoryAttributeList(requestObj.getString(Constants.MANIFEST_APP_KEY_STR));
			if (CollectionUtils.isEmpty(mandatoryAttrbsList)) {
				LOGGER.error(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
				throw new ApplicationException(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getCode(),
						StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
			}
			JSONArray manifestAttributesArray = new JSONArray();
			validateManifestAttributes(requestObj, mandatoryAttrbsList, manifestAttributesArray);
			LOGGER.info("Manifest Attributes Array is :::::" + manifestAttributesArray.toString());
			// Prepare Manifest Get Request
			entityData = buildManifestPayload(requestObj, manifestAttributesArray);
			LOGGER.info("Manifest Payload is :::::" + entityData);
		}
		return entityData;
	}

	/**
	 * @param requestObj
	 * @param manifestAttributesArray
	 * @return JSONObject
	 * @throws JSONException
	 */
	public String buildManifestPayload(JSONObject requestObj, JSONArray manifestAttributesArray) throws JSONException {
		return serviceUtils.buildManifestPayload(requestObj.getString(Constants.MANIFEST_APP_KEY_STR),
				manifestAttributesArray);
	}

	/**
	 * ODS Redesign - validate the mandatory attribute for manifest from
	 * ods_mandatory_attrs table with workflow payload.
	 *
	 * @param requestObj
	 * @param mandatoryAttrbsList
	 * @param manifestAttributesArray
	 * @throws ApplicationException
	 */
	public void validateManifestAttributes(JSONObject requestObj, List<OdsMandatoryAttributes> mandatoryAttrbsList,
			JSONArray manifestAttributesArray) throws ApplicationException {
		JSONObject attributes;
		for (OdsMandatoryAttributes mandatoryAttribObj : mandatoryAttrbsList) {
			String jsonString = requestObj.toString();
			String jsonPath = mandatoryAttribObj.getJsonPath();
			Object objectValues = null;
			try {
				objectValues = JsonPath.read(jsonString, jsonPath);
			} catch (PathNotFoundException ex) {
				LOGGER.error(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc(), ex);
				throw new ApplicationException(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getCode(),
						StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
			}
			if (objectValues != null) {
				String stringValues = String.valueOf(objectValues);
				if (StringUtils.isEmpty(stringValues.trim())) {
					LOGGER.error(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NULL.getDesc());
					throw new ApplicationException(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NULL.getCode(),
							StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NULL.getDesc());
				} else {
					// Build Manifest Attribute List
					String[] keyStr = jsonPath.split(Constants.SPLIT_STRING_BY_PERIOD_EXPRESSION);
					attributes = new JSONObject();
					attributes.put(Constants.MANIFEST_NAME_KEY_STR, keyStr[2]);
					attributes.put(Constants.MANIFEST_VALUE_KEY_STR, stringValues);
					manifestAttributesArray.put(attributes);
				}
			} else {
				LOGGER.error(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
				throw new ApplicationException(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getCode(),
						StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
			}
		}
	}

	/**
	 * ODS Redesign - validate the co-relation from ods_wf_corelation_config with
	 * payload from workflow.
	 *
	 * @param requestObj
	 * @return JSONObject
	 * @throws ApplicationException
	 */
	public JSONObject validateAndBuildCorelationPayload(JSONObject requestObj, String requestKey)
			throws ApplicationException {
		LOGGER.info("Entering validateAndBuildCorelationPayload");
		JSONObject entityData = new JSONObject();

		try {
			/* Get correlation schema from App Param table */
			OdsParamConfig odsParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(requestKey,
					OdsParamConfigType.WORKFLOW_CORRELATION_PARAM.toString(), Constants.CORRELATION_SCHEMA);
			if (odsParam != null) {
				serviceUtils.populateJsonPayload(odsParam.getValue(), requestObj.toString(), entityData);
			}
		} catch (Exception e) {
			LOGGER.warn(StatusCode.ERROR_WF_CORELATION_NOTFOUND.getDesc() + ". " + e);
		}

		LOGGER.info("Correlation defined is :::" + entityData.toString());
		LOGGER.info("Exiting validateAndBuildCorelationPayload");

		return entityData;
	}

	/**
	 * API to do XML/JSON Transformation after all the validations and checks
	 *
	 * @param transformRequest
	 * @return String
	 * @throws ApplicationException
	 */
	public String doTransformation(TransformRequest transformRequest, String appKey, String requestKey)
			throws ApplicationException {
		LOGGER.info("Entering doTransformation");

		if (StringUtils.isEmpty(transformRequest.getTransformationType()))
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "transformationType is null or empty");
		if (StringUtils.isEmpty(transformRequest.getInputDocument()))
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "inputDocument is null or empty");
		if (StringUtils.isEmpty(transformRequest.getRequestSchema()))
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "requestSchema is null or empty");

		JSONObject inputJsonObject = new JSONObject(transformRequest.getInputDocument());

		/* Do Mandatory Attributes Validation */
		validateMandatoryAttributes(inputJsonObject, requestKey);

		/* Add Condtional Schema Defined Params in the Input DOC */
		serviceUtils.updateRequestJsonObjectWithConditionalDefinitions(inputJsonObject, transformRequest);
		/* Add Schema Defined Params in the Input DOC */
		serviceUtils.updateRequestJsonObjectWithSchemaDefinedParams(inputJsonObject, transformRequest);

		/* Add Application Params in the Input DOC */
		serviceUtils.updateRequestJsonObjectWithAppParams(appKey, inputJsonObject, transformRequest.getRequestSchema(),
				transformRequest.getTransformationType());
		LOGGER.info("Final JSON Object for transformation : " + inputJsonObject.toString(2));

		/* do transformation based on Transformation Type */
		String className = serviceUtils
				.getTransformerClass(Constants.TRANSFROMER_CLASS_KEY_PREFIX + transformRequest.getTransformationType());

		com.vz.uiam.onenet.ods.transformer.Transformer transformer = serviceUtils.getTransformerInstance(className);
		appcontext.getAutowireCapableBeanFactory().autowireBean(transformer);

		String transformedDoc = (String) transformer.doTransform(inputJsonObject, transformRequest.getRequestSchema());

		LOGGER.info("Exiting doTransformation");
		return transformedDoc;
	}

	/**
	 * Generic API to validate mandatory Attributes in manifest response document
	 *
	 * @param manifestDocument
	 * @param key
	 * @throws ApplicationException
	 */
	public void validateMandatoryAttributes(JSONObject manifestDocument, String key) throws ApplicationException {
		LOGGER.info(">>Entering validateMandatoryAttributes");

		// Get the mandatory attributes from the DB
		List<OdsMandatoryAttributes> mandatoryAttrbsList = odsMandatoryAttrsService.getMandatoryAttributeList(key);

		for (OdsMandatoryAttributes mandatoryAttribObj : mandatoryAttrbsList) {
			String jsonString = manifestDocument.toString();
			String jsonPath = mandatoryAttribObj.getJsonPath();
			Object objectValues = null;

			try {
				objectValues = serviceUtils.getJsonSchemaValue(jsonPath, jsonString);
			} catch (PathNotFoundException ex) {
				LOGGER.error("Exception occured while validating input JSON - ", ex);
				throw new ApplicationException(StatusCode.DATA_HANDLING_ERROR.getCode(),
						"Mandatory attribute path : " + jsonPath + " not found");
			}

			if (objectValues != null) {
				String stringValues = String.valueOf(objectValues);
				if (StringUtils.isEmpty(stringValues.trim())) {
					LOGGER.error("Mandatory Manifest Attributes value is null or empty - ");
					throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
							"Mandatory Attribute : " + jsonPath + " is null or empty");
				}
			} else {
				LOGGER.error("Exception occured while validating input JSON - ");
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
						"Mandatory Attributes : " + jsonPath + " is null or empty");
			}
		}

		LOGGER.info("<<Exiting validateMandatoryAttributes");
	}

	/**
	 * API to create ResponseConfigParams for OdsInterfaceRequest
	 *
	 * @param requestPayload
	 * @return
	 */
	public ResponseConfigParams createResponseConfigParam(OdsServiceRouterMapDetails routerDetails,
			JSONObject requestPayload, String appKey) {
		LOGGER.info("Entering createResponseConfigParam");
		ResponseConfigParams responseConfigParam = new ResponseConfigParams();

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.FLOW_PROCESS_NAME)))
			responseConfigParam.setFlowNodeProcessName(requestPayload.getString(Constants.FLOW_PROCESS_NAME));

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.FLOW_STEP_NAME)))
			responseConfigParam.setFlowNodeStepName(requestPayload.getString(Constants.FLOW_STEP_NAME));

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.ACTIVITY_INSTANCE_ID)))
			responseConfigParam.setActivityInstanceId(requestPayload.getString(Constants.ACTIVITY_INSTANCE_ID));

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.CASE_ID)))
			responseConfigParam.setCaseID(requestPayload.getString(Constants.CASE_ID));

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.PARENT_CASE_ID)))
			responseConfigParam.setParentCaseID(requestPayload.getString(Constants.PARENT_CASE_ID));

		if (StringUtils.isNotEmpty(requestPayload.optString(Constants.ROOT_CASE_ID)))
			responseConfigParam.setRootCaseID(requestPayload.getString(Constants.ROOT_CASE_ID));

		responseConfigParam.setResponseDocumentName(routerDetails.getResponseDocumentName());
		responseConfigParam.setTransformationType(routerDetails.getTransformationType());
		if (null == appKey) {
			responseConfigParam.setAppKey(routerDetails.getAppKey());
		} else {
			responseConfigParam.setAppKey(appKey);
		}
		if (StringUtils.isNotEmpty(routerDetails.getSendMilestoneFlag())
				&& "YES".equalsIgnoreCase(routerDetails.getSendMilestoneFlag()))
			responseConfigParam.setSendMilestone(true);
		else
			responseConfigParam.setSendMilestone(false);
		LOGGER.info("Exiting createResponseConfigParam");
		return responseConfigParam;
	}

	public ODSManifestResponse getManifestDocs(String request) throws ApplicationException {
		LOGGER.info("Entering getManifestDocs");
		// Convert input JSON string into JSON Object
		JSONObject workflowRequestJsonObj = new JSONObject(request);
		
		// Manifest Fetch Begins
		JSONObject manifestRequestPayload = buildManifestRequestPayload(workflowRequestJsonObj);

		JSONObject documentPayload = fetchManifestDocuments(manifestRequestPayload, workflowRequestJsonObj);
		// Manifest Fetch Ends

		return new ODSManifestResponse(documentPayload.toString());
	}
	
	/**
	 * API returns the list of OdsParamConfig with param_key = requestKeyand type = TRANSPORT_HEADER
	 * @param workflowRequest
	 * @return transportHeaders
	 */
	public TransportHeader getTransportHeaders(JSONObject workflowRequest) throws ApplicationException {
		LOGGER.info("Entering getTransportHeaders");

		String requestKey = serviceUtils.buildKey(workflowRequest.getString(Constants.FLOW_PROCESS_NAME),
				workflowRequest.getString(Constants.FLOW_STEP_NAME));

		List<OdsParamConfig> transportHeadersList = odsParamConfigService.findByParamKeyAndType(requestKey,
				Constants.TRANSPORT_HEADER);
		TransportHeader transportHeaders = new TransportHeader();
		transportHeaders.setTransportHeadersList(transportHeadersList);
		
		LOGGER.info("Exiting getTransportHeaders");
		return transportHeaders;
	}

}