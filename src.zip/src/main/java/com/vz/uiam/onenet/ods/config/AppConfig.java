package com.vz.uiam.onenet.ods.config;

import java.text.SimpleDateFormat;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.onenet.ods.mapper.ResourceMapper;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * @author Anand Badiger
 *
 */
@Configuration
@EnableTransactionManagement
//@EnableEurekaClient	
public class AppConfig {

    @Bean
    @ConfigurationProperties(prefix = "ods.datasource")
    public DataSource orderServiceDS() {
    	return DataSourceBuilder.create().build();
    }

    @Bean
    public Jackson2ObjectMapperBuilder jacksonBuilder() {
		Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
		builder.indentOutput(true).dateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		return builder;
    }

    @Bean
    MapperFacade mapperFacade() {

	MapperFactory factory = new DefaultMapperFactory.Builder().build();
		return factory.getMapperFacade();
    }

    @Bean
    public ResourceMapper resourceMapper() {
    	return new ResourceMapper();
    }
    
    @Bean
	public RestTemplate restTemplate() {
		return new RestTemplate(clientHttpRequestFactory());
	}
    
    /**
	 * @return
	 */
	private ClientHttpRequestFactory clientHttpRequestFactory() {
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		factory.setReadTimeout(2*60*1000);
		factory.setConnectTimeout(2*60*1000);
		return factory;
	}
}
