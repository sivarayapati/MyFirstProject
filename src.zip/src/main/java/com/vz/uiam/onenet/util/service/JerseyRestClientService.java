package com.vz.uiam.onenet.util.service;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.vz.uiam.onenet.util.constants.StatusCode;
import com.vz.uiam.onenet.util.exception.ApplicationException;
import com.vz.uiam.onenet.util.constants.Constants;

@Service
public class JerseyRestClientService {

	private static final Logger LOGGER = Logger.getLogger(JerseyRestClientService.class);

	public String routeWithJerseyClient(String request) throws ApplicationException {

		JSONObject requestJson = new JSONObject(request);
		String endPointUrl = requestJson.getString(Constants.JERSEY_CLIENT_ENDPOINT_URL_KEY);
		String contentType = requestJson.getString(Constants.JERSEY_CLIENT_CONTENT_TYPE_KEY);
		String accept = requestJson.getString(Constants.JERSEY_CLIENT_ACCEPT_KEY);
		String requestMethod = requestJson.getString(Constants.JERSEY_CLIENT_REQ_METHOD_KEY);
		String payload = requestJson.get(Constants.JERSEY_CLIENT_REQ_PAYLOAD_KEY).toString();
		JSONArray queryParams = requestJson.getJSONArray(Constants.JERSEY_CLIENT_QUERY_PARAM_KEY);
		
		if(queryParams!=null && queryParams.length()>0) {
			endPointUrl=endPointUrl+"?";
			for (int i = 0; i < queryParams.length(); i++) {
				JSONObject queryParam = queryParams.getJSONObject(i);
				String name = queryParam.getString("name");
				String value = queryParam.getString("value");
				endPointUrl=endPointUrl+name+"="+value;
				if(i < queryParams.length()-1)
					endPointUrl=endPointUrl+"&";
			}
		}
		LOGGER.info("Endpoint URL is: '" + endPointUrl + "'");
		LOGGER.info("contentType is: '" + contentType + "'");
		LOGGER.info("accept is: '" + accept + "'");
		LOGGER.info("requestMethod is: '" + requestMethod + "'");
		LOGGER.info("Payload is: '" + payload + "'");
		
		DefaultClientConfig clientConfig = new DefaultClientConfig();
		Client client;
		WebResource webResourceObj;
		ClientResponse clientResponse;
		client = Client.create(clientConfig);
		webResourceObj = client.resource(endPointUrl);
		
		if (Constants.JERSEY_CLIENT_REQ_METHOD_POST.equals(requestMethod)) {
			clientResponse = webResourceObj.accept(accept).type(contentType).post(ClientResponse.class, payload);
			if (clientResponse.getStatus() != 200) {
				LOGGER.info("There is an exception: " + clientResponse.getStatus());
			}
			ObjectMapper mapper = new ObjectMapper();
			JsonNode responseJson;

			try {
				responseJson = mapper.readTree(clientResponse.getEntity(String.class));
			} catch (JsonProcessingException jpe) {
				LOGGER.error("Error while calling the Service", jpe);
				throw new ApplicationException(StatusCode.ERROR_PROCESSING_JSON.getCode(), jpe.getMessage());
			} catch (ClientHandlerException che) {
				LOGGER.error("Error while calling the Service", che);
				throw new ApplicationException(StatusCode.ERROR_CONNECTION_REFUSED.getCode(), che.getMessage());
			} catch (UniformInterfaceException uie) {
				LOGGER.error("Error while calling the Service", uie);
				throw new ApplicationException(StatusCode.ERROR_INTERFACE_EXCEPTION.getCode(), uie.getMessage());
			} catch (IOException e) {
				LOGGER.error("Error while calling the Service", e);
				throw new ApplicationException(StatusCode.ERROR_IOEXCEPTION.getCode(), e.getMessage());
			}

			return responseJson.toString();
		} else
			return "Only POST supported for now";

	}

}
