package com.vz.uiam.onenet.ods.constants;

public enum StatusCode {

	SUCCESS("0", "Success"),
	FAILED("1", "Got Failure response"),
	REQUEST_SENT("2", "Request sent"),
	REQUEST_PENDING("4", "Request Pending"),
	IN_PROGRESS("3", "Request sent"),
	APP_ERROR("601", "Application Error"),
	BAD_REQUEST("400","Bad Request"),
	DATA_NOT_FOUND("604", "Data Not Found"),
	INTERNAL_ERROR("605","Internal Error"),
	DATA_HANDLING_ERROR("606", "Data Handling Error"),
	NOT_CREATED("607","Data Not Created"),
	NOT_UPDATED("608", "Data Not Updated"),
	DEFAULT_ODS_EROOR("DefaultODsError","Defalt ODS Error"),
	ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED("609", "Mandatory Manifest Attributes are not configured"),
	ERROR_MANDATORY_MANIFEST_ATTRIBS_NULL("610", "Mandatory Manifest Attributes value is null or empty"),
	ERROR_WF_CORELATION_NOTFOUND("611","Workflow Correltion configuration not found for given Key"),
	ERROR_TARGET_END_POINT_URL_NOTFOUND("612","Target End point URL is not configured in ODS config"),
	ERROR_REQUEST_DOCUMENT_NAME_NOTFOUND("613","Request Document Name is not configured in ODS config"),
	HTTP_ERROR("614", "HTTP Error"),
	ERROR_ODS_ROUTER_MAP_CONFIG_NOTCONFIGURED("615","ODS Router Map configuration not found"),
	ERROR_APPKEY_IS_NULL("616","Application Key is null or empty"),
	MANIFEST_GET_PROXY_URI_NOT_CONFIGURED("617","Manifest Get Proxy URL is not configured in App Param table"),
	MANIFEST_RESPONSE_IS_NULL("618","Manifest Document recieved is null"),
	ERROR_XML_TRANFORMATION("619","Error occured while tranforming the xslt"),
	TRANSFORMER_CLASS_NOTFOUND("620", "Transformer Class is not Found"),
	OBJECT_TO_JSON_CONVERSION_ERROR("621", "Error while do Object to JSON Conversion"),
	XML_TO_JSON_TRANSFORMATION_ERROR("622", "Error during XML to JSON Transformation"),
	JSON_UPDATE_ERROR("622", "Error during updating JSON data"),
	ERROR_WORKFLOW_FALLOUT_CONFIG_NOTFOUND("623","Workflow Fallout configration not found"),
	ERROR_WORKFLOW_NOTFOUND("624","Workflow Fallout  not found / has not been created"),
	ERROR_WHILE_CREATE_OR_UPDATE_WORKFLOW_PARAMS("625","Exception Occured while create/updating worflow Params"),
	ERROR_WHILE_CREATE_FALLOUT("627","Error while creating fallout"),
	TRANSACTION_ID_NOT_FOUND("628","Transaction ID not found in the response"),
	ERROR_WHILE_ODS_JSON_RESPONSE_PROCESSING("629","Exception Occured while processing the ODS JSON Response"),
	ERROR_WHILE_ODS_XML_RESPONSE_PROCESSING("630","Exception Occured while processing the ODS XML Response"),
	PWD_ENCODE_ERROR("631","Exception Occured while processing the ODS XML Response"),
	PWD_DECODE_ERROR("632","Exception Occured while processing the ODS XML Response"),
	ERROR_NOTES_NOTFOUND("633","Notes configuration not found for given Key"),
	TARGET_URL_IS_MALFORMED("634","The target url being configured is malfarmed"),
	ERROR_ODS_PARAM_CONFIG_NOTCONFIGURED("635","ODS Param configuration not found"),
	ERROR_WHILE_IS_RETRY_POSSIBLE("636","Error while checking retry possible"),
	ERROR_MANDATORY_ATTRIB_IN_RESPONSE_EMPTY("637","Mandatory value in response is empty"),
	ERROR_RESPONSE_STATUS_PARAM_FAILURE("638","Response Status param in response is not satisfied as configured"),
	TASK_TIMEOUT("650","Time out waiting for response from interface");


	private final String code;
	private final String desc;

	private StatusCode(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	/**
	 * Return the String value of this status code.
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Return the message of this status code.
	 */
	public String getDesc() {
		return this.desc;
	}
}
