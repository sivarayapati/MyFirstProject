package com.vz.uiam.onenet.ods.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsTransformerConfig;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsTransformerConfigDto;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsTransformerConfigResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformationResponse;
import com.vz.uiam.onenet.ods.service.OdsTransformerConfigService;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/oneDispatcher")
public class OdsTransformerConfigController {

	private static final Logger LOGGER = Logger.getLogger(OdsTransformerConfigController.class);

	@Autowired
	OdsTransformerConfigService odsTransformerConfigService;

	@Autowired
	ServiceUtils serviceUtils;

	/**
	 * @param request
	 * @return ResponseEntity<TransformationResponse>
	 */
	@RequestMapping(value = "/tranform", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Do Input Doc transformation based on the Transforamtion Type and schema", notes = "Do Input Doc transformation based on the Transforamtion Type and schema", response = TransformationResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully transformed the Input Document", response = TransformationResponse.class) })
	public ResponseEntity<TransformationResponse> transform(@RequestBody OdsTransformerConfigDto request) {
		LOGGER.info(">>transform()");
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		TransformationResponse response = new TransformationResponse();
		String transformedDocument = null;
		try {
			transformedDocument = odsTransformerConfigService.tranformDocument(request);
		} catch (ApplicationException e) {
			LOGGER.error(e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception exception) {
			LOGGER.error(exception);
			statusCode = StatusCode.APP_ERROR.getCode();
			statusMsg = exception.getMessage();
		}
		
		response = serviceUtils.handleTransformationResponse(statusCode, statusMsg, response, transformedDocument);
		LOGGER.info("<<transform()");
		if (statusCode == StatusCode.SUCCESS.getCode()) {
			HttpHeaders headers = new HttpHeaders();
			headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
			return new ResponseEntity<>(response, headers, HttpStatus.OK);
		} else {
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(response);
		}
	}
	
	
	@RequestMapping(value = "/odsTransformerConfig/createOrUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create or Update a record in OdsTransformerConfig", notes = "Create or Update a record in OdsTransformerConfig", response = OdsTransformerConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Created or Updated OdsTransformerConfig record", response = OdsTransformerConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "createOrUpdate OdsTransformerConfig Service is unavaialble") })
	public ResponseEntity<OdsTransformerConfigResponse> createOrUpdateOdsTransformerConfig(@RequestBody OdsTransformerConfig request)
														throws ApplicationException {
		
		LOGGER.info("Entering createOrUpdateOdsTransformerConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsTransformerConfigResponse response = new OdsTransformerConfigResponse();
		
		try {
			OdsTransformerConfig odsTransformerConfigResp = odsTransformerConfigService.createOrUpdateOdsTransformerConfig(request);
			
			if(null == odsTransformerConfigResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsTransformerConfig(odsTransformerConfigResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting createOrUpdateOdsTransformerConfig");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/odsTransformerConfig/get", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get OdsTransformerConfig Details", notes = "Get OdsTransformerConfig Details", response = OdsTransformerConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved OdsTransformerConfig record", response = OdsTransformerConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "get OdsTransformerConfig Service is unavaialble") })
	public ResponseEntity<OdsTransformerConfigResponse> getOdsTransformerConfig(@RequestBody OdsTransformerConfig request)
														throws ApplicationException {
		
		LOGGER.info("Entering getOdsTransformerConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsTransformerConfigResponse response = new OdsTransformerConfigResponse();
		
		try {
			OdsTransformerConfig odsTransformerConfigResp = odsTransformerConfigService.getOdsTransformerConfig(request.getTransformerKey());
			
			if(null == odsTransformerConfigResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsTransformerConfig(odsTransformerConfigResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting getOdsTransformerConfig");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/odsTransformerConfig/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Delete OdsTransformerConfig Details", notes = "Delete OdsTransformerConfig Details", response = OdsTransformerConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Delete OdsTransformerConfig record", response = OdsTransformerConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Delete OdsTransformerConfig Service is unavaialble") })
	public ResponseEntity<OdsTransformerConfigResponse> deleteOdsTransformerConfig(@RequestBody OdsTransformerConfig request)
														throws ApplicationException {
		
		LOGGER.info("Entering deleteOdsTransformerConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsTransformerConfigResponse response = new OdsTransformerConfigResponse();
		
		try {
			odsTransformerConfigService.deleteOdsTransformerConfigRecord(request);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting deleteOdsTransformerConfig");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

}