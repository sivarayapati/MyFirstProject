package com.vz.uiam.onenet.ods.transformer;

import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.exception.ApplicationException;

@Service
public interface Transformer {

	public Object doTransform(Object inputDocument, Object requestSchema) throws ApplicationException;
}
