/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.util.List;

/**
 * This class holds the key value pair retrieved from the targetend url as query string
 * @author Newt
 *
 */
public class QueryParam {
	
	private List<Param>  parameter;

	public QueryParam() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @return the param
	 */
	public List<Param> getParam() {
		return parameter;
	}

	/**
	 * @param param the param to set
	 */
	public void setParam(List<Param> param) {
		this.parameter = param;
	}

	/**
	 * @param param
	 */
	public QueryParam(List<Param> param) {
		this.parameter = param;
	}
	
	
	
}
