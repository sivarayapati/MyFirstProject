package com.vz.uiam.onenet.ods.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsMilestoneConfigResponse;
import com.vz.uiam.onenet.ods.service.OdsMilestoneConfigService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author Ashish Goyal
 *
 */
@RestController
@RequestMapping("/oneDispatcher/odsMilestoneConfig")
public class OdsMilestoneConfigController {

	private static final Logger LOGGER = Logger.getLogger(OdsMilestoneConfigController.class);
	
	@Autowired
	OdsMilestoneConfigService odsMilestoneConfigService;
	
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Delete Milestone configurations", notes = "Delete Milestone configurations", response = OdsMilestoneConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully deleted Milestone configurations", response = OdsMilestoneConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Delete Milestone config Service is unavaialble") })
	public ResponseEntity<OdsMilestoneConfigResponse> deleteOdsMilestoneConfig(@RequestBody List<OdsMilestoneConfig> request)
														throws ApplicationException {
		
		LOGGER.info("Entering deleteOdsMilestoneConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsMilestoneConfigResponse response = new OdsMilestoneConfigResponse();
		
		try {
			odsMilestoneConfigService.deleteOdsMilestoneConfigRecord(request);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = "Error while deleting Milestone Config. " + e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = StatusCode.APP_ERROR.getCode();
			statusMsg = "Error while deleting Milestone Config. " + e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting deleteOdsMilestoneConfig");

		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/createOrUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create or Update a record in Milestone configurations", notes = "Create or Update a record in Milestone configurations", response = OdsMilestoneConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Created or Updated OdsMilestoneConfig record", response = OdsMilestoneConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "createOrUpdate OdsMilestoneConfig Service is unavaialble") })
	public ResponseEntity<OdsMilestoneConfigResponse> createOrUpdateOdsMilestoneConfig(@RequestBody OdsMilestoneConfig request)
														throws ApplicationException {
		
		LOGGER.info("Entering createOrUpdateOdsMilestoneConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsMilestoneConfigResponse response = new OdsMilestoneConfigResponse();
		
		try {
			OdsMilestoneConfig odsMilestoneConfig =  odsMilestoneConfigService.createOrUpdateMilestoneConfig(request);
			
			if(null == odsMilestoneConfig) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsMilestoneConfig(odsMilestoneConfig);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting createOrUpdateOdsMilestoneConfig");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
		
	}

	
	@RequestMapping(value = "/get", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Milestone configurations", notes = "Get Milestone configurations", response = OdsMilestoneConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved Milestone configurations record", response = OdsMilestoneConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "get Milestone configuration is unavaialble") })
	public ResponseEntity<OdsMilestoneConfigResponse> getOdsMilestoneConfig(@RequestBody OdsMilestoneConfig request)
														throws ApplicationException {
		
		LOGGER.info("Entering getOdsMilestoneConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsMilestoneConfigResponse response = new OdsMilestoneConfigResponse();
		
		try {
			List<OdsMilestoneConfig> odsMilestoneConfigList =  odsMilestoneConfigService.getMilestoneConfig(request);
			
			if(null == odsMilestoneConfigList) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsMilestoneConfigList(odsMilestoneConfigList);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting getOdsMilestoneConfig");
			
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}


}