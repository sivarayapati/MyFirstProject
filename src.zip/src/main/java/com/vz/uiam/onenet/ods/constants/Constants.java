package com.vz.uiam.onenet.ods.constants;

public interface Constants {

	/**
	 * Constant holds ApplicationError
	 */
	String APPLICATION_ERROR = "Application Error. Data not found. Please verify the request.";
	/**
	 * Constant holds Content Type
	 */
	String CONTENT_TYPE = "Content-Type";
	/**
	 * Constant holds Manifest Name
	 */
	String MANIFEST_NAME_KEY_STR = "name";
	/**
	 * Constant holds Manifest Payload String
	 */
	String MANIFEST_PAYLOAD_STR = "manifest-payload";
	/**
	 * Constant holds ManifestKey value
	 */
	String MANIFEST_VALUE_KEY_STR = "value";
	/**
	 * Constant holds Manifest Attribute
	 */
	String MANIFEST_ATTRIBUTE_STR = "attribute";
	/**
	 * Constant holds Entity Attribute
	 */
	String MANIFEST_ENTITY_ATTRIBUTES_STR = "entity-attributes";
	/**
	 * Constant holds Manifest App Key
	 */
	String MANIFEST_APP_KEY_STR = "app-key";
	/**
	 * Constant holds Document Name
	 */
	String MANIFEST_DOCUMENT_NAME_STR = "document-name";
	/**
	 * Constant holds document payload
	 */
	String MANIFEST_DOCUMENT_PAYLOAD_STR = "document-payload";
	/**
	 * Constant holds String Split Literal
	 */
	String SPLIT_STRING_BY_PERIOD_EXPRESSION = "\\.";
	/**
	 * Constant holds rootProcess name
	 */
	String ROOT_FLOW_PROCESS_NAME = "rootProcessName";
	/**
	 * Constant holds process name
	 */
	String FLOW_PROCESS_NAME = "flowNodeProcessName";
	/**
	 * Constant holds step name
	 */
	String FLOW_STEP_NAME = "flowNodeStepName";
	/**
	 * Constant holds Task Id
	 */
	String ACTIVITY_INSTANCE_ID = "activityInstanceId";
	/**
	 * Constant holds Workflow ID/caseId
	 */
	String PROCESS_INSTANCE_ID = "processInstanceId";
	/**
	 * Constant holds Transaction ID
	 */
	String TRANSACTION_ID = "transactionId";
	/**
	 * Constant holds Seperator
	 */
	String KEYBUILDER_SEPERATOR = "_";
	/**
	 * Constant holds Target End point URL
	 */
	String SERVICE_URL = "targetEndPointURL";
	/**
	 * Constant holds Transaformation Type
	 */
	String TRANSFORMATION_TYPE = "transformationType";
	/**
	 * Constant holds Workflow ID/caseId
	 */
	String CASE_ID = "processInstanceId";
	/**
	 * Constant holds parent Workflow ID/caseId
	 */
	String PARENT_CASE_ID = "parentProcessInstanceId";
	/**
	 * Constant holds root Workflow ID/caseId
	 */
	String ROOT_CASE_ID = "rootProcessInstanceId";
	/**
	 * Constant holds Enity data
	 */
	String ENTITY_DATA_STR = "entity-data";
	/**
	 * Constant holds request Payload
	 */
	String REQUEST_PAYLOAD = "requestPayload";
	/**
	 * Constant holds Application Param
	 */
	String APP_PARAM_KEY = "ApplicationParam";
	/**
	 * Constant holds XML
	 */
	String TRANSFORMATION_XML_TYPE = "XML";
	/**
	 * Constant holds JSON
	 */
	String TRANSFORMATION_JSON_TYPE = "JSON";
	/**
	 * Constant holds One Dispatcher String
	 */
	String ONE_DISPATCHER_ROOT_TAG = "OneDispatcher";
	/**
	 * Constant holds manifest endpoint URL for build document
	 */
	String BUILD_MANIFEST_ENDPOINT_URL = "BUILD_MANIFEST_ENDPOINT_URL";
	/**
	 * Constant holds manifest endpoint URL for get document
	 */
	String GET_MANIFEST_ENDPOINT_URL = "GET_MANIFEST_ENDPOINT_URL";
	/**
	 * Constant holds URL for close Bonita Task
	 */
	String CLOSE_BONITA_TASK_URL = "CLOSE_BONITA_TASK_URL";
	/**
	 * Constant holds header extraction literal
	 */
	String HEADER_NODE_EXTRACTION ="//header/*";
	/**
	 * Constant holds body extraction literal
	 */
	String BODY_NODE_EXTRACTION ="//body/*";
	/**
	 * Constant holds Transform class splitter
	 */
	String TRANSFROMER_CLASS_KEY_PREFIX = "TRANSFROMER_CLASS_";
	/**
	 * Constant holds document payload
	 */
	String MANIFEST_DOCPAYLOAD_KEY = "document-payload";
	/**
	 * Constant holds document name
	 */
	String MANIFEST_DOCUMENT_NAME_KEY = "document-name";
	/**
	 * Constant holds manifest document
	 */
	String MANIFEST_DOC = "manifestDocument";
	/**
	 * Constant holds co-relation schema
	 */
	String CORRELATION_SCHEMA = "correlationSchema";
	/**
	 * Constant holds content schema
	 */
	String CONTENT_SCHEMA = "contentSchema";
	/**
	 * Constant holds contents literal
	 */
	String CONTENTS = "contents";
	/**
	 * Constant holds pending
	 */
	String STATUS_PENDING = "pending";
	/**
	 * Constant holds Create Task SLA Service
	 */
	String CREATE_TASK_SLA_URL = "CREATE_TASK_SLA_URL";
	/**
	 * Constant holds Failed
	 */
	String STATUS_FAILED ="FAILED";
	/**
	 * Constant holds sent status
	 */
	String STATUS_SENT="SENT";
	/**
	 * Constant holds default error code
	 */
	String GENERIC_ERROR_CODE = "DEFAULT_ERROR_CODE";
	/**
	 * Constant holds processed
	 */
	String PROCESSED = "processed";
	/**
	 * Constant holds routing protocol SOAP
	 */
	String ROUTING_PROTOCOL_SOAP = "SOAP";
	/**
	 * Constant holds routing protocol REST
	 */
	String ROUTING_PROTOCOL_REST = "REST";
	/**
	 * Constant holds routing protocol MQ
	 */
	String ROUTING_PROTOCOL_MQ = "MQ";
	/**
	 * Constant holds ODS
	 */
	String ODS_PARAM_KEY = "ODS";
	/**
	 * Constant holds Data Service Request
	 */
	String DATA_SERVICE_REQUEST_URL = "dataServiceRequestUrl";
	/**
	 * Constant holds seedInfo
	 */
	String SEED_INFO = "seedInfo";
	/**
	 * Constant holds socument name splitter
	 */
	String MANIFEST_DOCUMENT_NAME_SPLITTER = ",";
	/**
	 * Constant holds response Tranasaction Id
	 */
	String TRANSACTION_ID_RSP_KEY = "TRANSACTION_ID";
	/**
	 * Constant holds status code schema
	 */
	String STATUS_CODE_SCHEMA = "STATUS_CODE_SCHEMA";
	/**
	 * Constant holds success status code value
	 */
	String STATUS_CODE_SUCCESS_VAL = "STATUS_CODE_SUCCESS_VALUE";
	/**
	 * Constant holds status desc schema
	 */
	String STATUS_DESC_SCHEMA = "STATUS_DESC_SCHEMA";	
	/**
	 * Constant holds error code schema
	 */
	String FAILURE_CODE_SCHEMA = "FAILURE_CODE_SCHEMA";
	/**
	 * Constant holds error desc schema
	 */
	String FAILURE_DESC_SCHEMA = "FAILURE_DESC_SCHEMA";
	/**
	 * Constant holds ack status code schema
	 */
	String ACK_STATUS_CODE_SCHEMA = "ACK_STATUS_CODE_SCHEMA";
	/**
	 * Constant holds ack success status code value
	 */
	String ACK_STATUS_CODE_SUCCESS_VAL = "ACK_STATUS_CODE_SUCCESS_VALUE";
	/**
	 * Constant holds ack status desc schema
	 */
	String ACK_STATUS_DESC_SCHEMA = "ACK_STATUS_DESC_SCHEMA";
	/**
	 * Constant holds ack failure code schema
	 */
	String ACK_FAILURE_CODE_SCHEMA = "ACK_FAILURE_CODE_SCHEMA";
	/**
	 * Constant holds ack failure desc schema
	 */
	String ACK_FAILURE_DESC_SCHEMA = "ACK_FAILURE_DESC_SCHEMA";
	/**
	 * Constant holds success status
	 */
	String SUCCESS = "SUCCESS";
	/**
	 * Constant holds failure status
	 */
	String FAILURE = "FAILURE";
	/**
	 * Constant holds Application/Josn Type
	 */
	String APPLICATION_JSON = "application/json";
	/**
	 * Constant holds Notes Enabled Flag
	 */
	String NOTES_ENABLE_FLAG = "NOTES_ENABLE_FLAG";
	/**
	 * Constant holds Notes GET URL
	 */
	String NOTES_GET_URL = "NOTES_GET_URL";
	/**
	 * Constant holds Notes add or update URL
	 */
	String NOTES_ADD_OR_UPDATE_URL = "NOTES_ADD_OR_UPDATE_URL";
	/**
	 * Constant holds Note orderNumber
	 */
	String NOTES_ORDER_NUMBER = "orderNumber";
	/**
	 * Constant holds Notes Circuit ID
	 */
	String NOTES_CIRCUIT_ID = "circuitId";
	/**
	 * Constant holds Notes Region
	 */
	String NOTES_REGION = "region";
	/**
	 * Constant holds MILESTONE Request URL
	 */
	String MILESTONE_REQUEST_URL = "MILESTONE_REQUEST_URL";
	/**
	 * Constant holds MISTONE SUFFIX
	 */
	String MILESTONE_CONSTANT="_MILESTONE";
	/**
	 * Constant holds Default String
	 */
	String DEFAULT = "DEFAULT";
	/**
	 * Constant holds ODS Region
	 */
	String ODS_REGION="appRegion";
	/**
	 * Constant holds Create UTE Task URL
	 */
	String CREATE_UTE_TASK_URL="CREATE_UTE_TASK_URL";
	/**
	 * Constant holds Create UTE Task key
	 */
	String CREATE_UTE_TASK_KEY="CREATE_UTE_TASK";
	/**
	 * Constant holds Fallout Error Code
	 */
	String FALLOUT_ERROR_CODE="errorCode";
	/**
	 * Constant holds Fallout Error Desc
	 */
	String FALLOUT_ERROR_DESC="errorDesc";
	/**
	 * Constant holds workflow caseId
	 */
	String FALLOUT_CASE_ID="caseId";
	/**
	 * Constant holds UTE_SCHEMA_TRANSFORM_KEY Suffix literal.
	 */
	String UTE_SCHEMA_TRANSFORM_KEY_SUFFIX = "_UTE_SCHEMA_TRANSFORM_KEY";
	/**
	 * Constant holds Fallout Step Name
	 */
	String FALLOUT_STEP_NAME="falloutStepName";
	/**
	 * Constant holds Line Of Business
	 */
	String FALLOUT_LOB="lineOfBusiness";
	/**
	 * Constant holds Fallout Task Source
	 */
	String FALLOUT_TASK_SOURCE="taskSource";
	/**
	 * Constant holds Fallout Task name
	 */
	String FALLOUT_TASK_NAME="taskName";
	
	/**
	 * Constant holds Fallout Task Contract
	 */
	String FALLOUT_TASK_CONTRACT_VAR="taskContract";
	/**
	 * Constant holds isRetry flag
	 */
	String FALLOUT_ISRETRY_VAR="isRetry";
	/**
	 * Constant holds the retry interval
	 */
	String FALLOUT_RETRYINTERVAL_VAR="retryInterval";
	/**
	 * Constant holds the complete manual task 
	 */
	String COMPLETE_MANUAL_TASK_URL="COMPLETE_MANUAL_TASK_URL";
	String DEFAULT_REPROCESS_FLAG="YES";
	/**
	 * Holds the Notes payload 
	 */
	String NOTES_SCHEMA="NOTES_SCHEMA";
	/**
	 * Holds the Notes Param Schema
	 */
	String NOTES_PARAM_SCHEMA="NOTES_PARAM_SCHEMA";
	
	/*
	 * Holds the constant appended to app-key as transformer-key 
	 * for generating manifest payload for route-only invocations
	 */
	String UPDATE_RESPONSE_IN_MANIFEST = "UPDATE_RESPONSE_IN_MANIFEST";
	/**
	 * Constant holds Schema Defined Param
	 */
	String SCHEMA_DEFINED_PARAM_KEY = "SchemaDefinedParam";
	/**
	 * Constant holds Schema Defined Param
	 */
	String SCHEMA_DEFINED_LITERAL_KEY = "#define";
	/**
	 * Constant holds Schema Definitions Delimiter
	 */
	String SCHEMA_DEFINITIONS_DELIMITER = ";";
	/**
	 * Constant holds Schema Definitions Assignment Delimiter
	 */
	String SCHEMA_DEFINITIONS_ASSIGNMENT_DELIMITER = "=";
	
	/**
	 * Constant to denote the name of the Source System.
	 */
	String SOURCE_SYSTEM_NAME = "SOURCE_SYSTEM_NAME";
	
	/**
	 * Constant to denote the name of the Destination System.
	 */
	String DESTINATION_SYSTEM_NAME = "DESTINATION_SYSTEM_NAME";
	
	/**
	 * Constant to denote the application_key for the Admin document.
	 */
	String APPLICATION_KEY = "application_key";
	
	/**
	 * Constant to denote the type of data in the Admin document. 
	 */
	String DATA_TYPE = "data_type";
	
	/**
	 * Constant to denote the Metadata data type for the Admin document. 
	 */
	String METADATA = "META_DATA";
	
	/**
	 * Constant to denote the Metadata data type for the Admin document. 
	 */
	String METADATA_APP_KEY = "ZZZDE-ODS";
	
	/**
	 * Constant to denote the document_level entity attribute for the manifest payload.
	 */
	String DOCUMENT_LEVEL = "document_level";
	
	/**
	 * Constant to denote the GLOBAL value for document_level.
	 */
	String GLOBAL = "GLOBAL";
	
	/**
	 * Constant to denote the Metadata key in the request document name.
	 */
	String METADATA_KEY = "#Metadata.";
	
	/**
	 * Constant to denote the OMIT_XML_DECLARATION in the XmlTransformation Response .
	 */
	String OMIT_XML_DECLARATION = "omit-xml-declaration";
	
	/**
	 * Constant holds conditional Schema Definitions
	 */
	String SCHEMA_CONDITIONAL_DEFINED_LITERAL_KEY = "#if";
	
	/**
	 * Constant holds end conditional Schema Definitions
	 */
	String SCHEMA_END_CONDITIONAL_DEFINED_LITERAL_KEY = "#endif";
	
	/**
	 * Constant holds Schema Definitions
	 */
	String SCHEMA_THEN_CONDITIONAL_DEFINED_LITERAL_KEY = "#then";
	/**
	 * Constant holds Schema Definitions
	 */
	String SCHEMA_CONDITIONAL_EQUAL_OPERATOR = "==";
	/**
	 * NON_BLANK STATUS CODE VALUE
	 */
	String STATUS_CODE_NON_BLANK = "NON_BLANK";
	/**
	 * TITLE_LITERAL
	 */
	String TITLE_LITERAL = "TITLE";
	/**
	 * TITLE_VERSION_LITERAL
	 */
	String TITLE_VERSION_LITERAL = "TITLE_VERSION";
	/**
	 * AUTO_REFLOW_LITERAL
	 */
	String AUTO_REFLOW_LITERAL = "AUTO_REFLOW";
	/**
	 * AUTO_REFLOW_LITERAL
	 */
	String ODS_REQUEST_LOG_STATUS_PENDING = "PENDING";
	/**
	 * UTE_REQUEST_DOCUMENT_NAMES
	 */
	String UTE_REQUEST_DOCUMENT_NAMES = "UTE_REQUEST_DOCUMENT_NAMES";
	/**
	 * MANDATORY_RSP_PARAM_SUFFIX
	 */
	String MANDATORY_RSP_PARAM_SUFFIX = "_MANDATORY_RSP_PARAM";
	/**
	 * MANIFEST_DOC_NOT_FOUND
	 */
	String MANIFEST_DOC_NOT_FOUND_CODE="604";
	/**
	 * Contant holds the literal for notes message for request
	 */
	String REQUEST_SENT_SUCCESSFULLY="Request sent";
	/**
	 * Contant holds the literal for notes message for response
	 */
	String RESPONSE_RECEIVED_SUCCESSFULLY="Response received";
	
	/**
	 * Contant holds the literal for notes message for response
	 */
	String ACK_RECEIVED_SUCCESSFULLY="Acknowledement received";
	/**
	 * Contant holds the literal for notes message for request
	 */
	String EXCEPTION_OCCURRED="Received error";
	
	/**
	 * UTE_TASK_CREATION_STATUS_CODE
	 */
	String UTE_TASK_CREATION_STATUS_CODE = "statusCode";
	/**
	 * UTE_TASK_CREATION_STATUS_CODE_SUCCESS
	 */
	String UTE_TASK_CREATION_STATUS_CODE_SUCCESS = "SUCCESS";
	/**
	 * UTE_TASK_CREATION_STATUS_MSG
	 */
	String UTE_TASK_CREATION_STATUS_MSG = "statusMessage";
	/**
	 * UTE_TASK_CREATION_STTUS_MSG_SUCCESS
	 */
	String UTE_TASK_CREATION_STTUS_MSG_SUCCESS = "Task Initiated";
	/**
	 * EXTERNAL_TASK_ID_LITERAL
	 */
	String EXTERNAL_TASK_ID_LITERAL = "externalTaskId";
	/**
	 * TASK_SOURCE_LITERAL
	 */
	String TASK_SOURCE_LITERAL = "taskSource";
	/**
	 * USER_ID_LITERAL
	 */
	String USER_ID_LITERAL = "userId";
	/**
	 * CREATOR_LITERAL
	 */
	String CREATOR_LITERAL = "creator";
	/**
	 * STATUS_LITERAL
	 */
	String STATUS_LITERAL = "status";
	/**
	 * TASK_HEADER_LITERAL
	 */
	String TASK_HEADER_LITERAL = "taskHeader";
	/**
	 * STATUS_IN_PROGRESS_LITERAL
	 */
	String STATUS_IN_PROGRESS_LITERAL = "IN PROGRESS";
	/**
	 * STATUS_COMPLETED_LITERAL
	 */
	String STATUS_COMPLETED_LITERAL = "COMPLETED";
	/**
	 * UTE_TASK_LIST_DOC_NAME_LITERAL
	 */
	String UTE_TASK_LIST_DOC_NAME_LITERAL = "UTE_TASK_LIST_DOC_NAME";
	/**
	 * UTE_TASK_LIST_TRANSFORM_KEY_SUFFIX
	 */
	String UTE_TASK_LIST_TRANSFORM_KEY_SUFFIX = "_UPDATE_UTE_TASKLIST_IN_MANIFEST";
	/**
	 * EXTERNAL_TASK_ID_SEPARATOR
	 */
	String EXTERNAL_TASK_ID_SEPARATOR = "-";
	/**
	 * EXTERNAL_TASK_ID_PREFIX
	 */
	String EXTERNAL_TASK_ID_PREFIX = "1";
	/**
	 * Constant holds Complete UTE Task URL
	 */
	String COMPLETE_UTE_TASK_URL="COMPLETE_UTE_TASK_URL";
	/**
	 * Constant holds COMPLETE_UTE_SCHEMA_TRANSFORM_KEY Suffix literal.
	 */
	String COMPLETE_UTE_SCHEMA_TRANSFORM_KEY_SUFFIX = "_COMPLETE_UTE_SCHEMA_TRANSFORM_KEY";
	/**
	 * Constant holds Complete UTE Task URL
	 */
	String UPDATE_UTE_TASK_URL="UPDATE_UTE_TASK_URL";
	/**
	 * Constant holds COMPLETE_UTE_SCHEMA_TRANSFORM_KEY Suffix literal.
	 */
	String UPDATE_UTE_SCHEMA_TRANSFORM_KEY_SUFFIX = "_UPDATE_UTE_SCHEMA_TRANSFORM_KEY";
	/**
	 * Constant holds DEFAULT_TASK_TIME_OUT literal.
	 */
	String DEFAULT_TASK_TIME_OUT = "DEFAULT_TASK_TIME_OUT";
	/**
	 * Constant holds TIME_OUT Status.
	 */
	String STATUS_TIME_OUT = "TIME_OUT";
	/**
	 * Constant holds REQUEST_PENDING Status.
	 */
	String STATUS_REQUEST_PENDING = "REQUEST_PENDING";
	/**
	 * Constant holds ODS_SCHEDULER_SWITCH
	 */
	String ODS_SCHEDULER_SWITCH = "ODS_SCHEDULER_SWITCH";
	/**
	 * Constant holds value of ON
	 */
	String ODS_SCHEDULER_SWITCH_ON = "ON";
	/**
	 * Constant holds value of OFF
	 */
	String ODS_SCHEDULER_SWITCH_OFF = "OFF";
	/**
	 * Constant holds Task Id
	 */
	String WF_TASK_ID = "wfTaskId";
	
	/**
	 * Constant holds Scheduler lock key
	 */
	String ODS_RETRY_BONITA_TASK_COMPLETION_KEY = "RETRY_BONITA_TASK_COMPLETION";
	/**
	 * Constant holds Scheduler lock key
	 */
	String ODS_TASK_TIMER_KEY = "TASK_TIMER";
	
	/**
	 * Constant holds Scheduler lock key
	 */
	String ODS_RETRY_FAILED_TASK = "RETRY_TASK";
	
	/**
	 * Constant holds transport header value
	 */
	String TRANSPORT_HEADER = "TRANSPORT_HEADER";
	
	
	
}
