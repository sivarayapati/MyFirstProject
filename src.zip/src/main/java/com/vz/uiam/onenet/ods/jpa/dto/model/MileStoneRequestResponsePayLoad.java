package com.vz.uiam.onenet.ods.jpa.dto.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class MileStoneRequestResponsePayLoad {
	
	private static final long serialVersionUID = 1L;
	
	private TransformedResponsePayload payload;
	private String targetEndPointURL;
	private String routingProtocol;
	private String userNameAndPassword;
	
	
	public TransformedResponsePayload getPayload() {
		return payload;
	}
	
	public void setPayload(TransformedResponsePayload payload) {
		this.payload = payload;
	}
	
	public String getTargetEndPointURL() {
		return targetEndPointURL;
	}
	
	public void setTargetEndPointURL(String targetEndPointURL) {
		this.targetEndPointURL = targetEndPointURL;
	}
	
	public String getRoutingProtocol() {
		return routingProtocol;
	}
	
	public void setRoutingProtocol(String routingProtocol) {
		this.routingProtocol = routingProtocol;
	}
	public String getUserNameAndPassword() {
		return userNameAndPassword;
	}

	public void setUserNameAndPassword(String userNameAndPassword) {
		this.userNameAndPassword = userNameAndPassword;
	}

	
}
