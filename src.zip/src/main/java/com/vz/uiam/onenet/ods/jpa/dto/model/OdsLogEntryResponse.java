package com.vz.uiam.onenet.ods.jpa.dto.model;

public class OdsLogEntryResponse {
	
	private String title;	
	private String titleVersion;	
	private String wfTaskId;
	private String errorCode;
	private String errorMsg;
	private String statusCode;
	private String statusDesc;
	
	/**
	 * @param title
	 * @param titleVersion
	 * @param wfTaskId
	 */
	public OdsLogEntryResponse(String title, String titleVersion, String wfTaskId) {
		this.title = title;
		this.titleVersion = titleVersion;
		this.wfTaskId = wfTaskId;
	}

	/**
	 * 
	 */
	public OdsLogEntryResponse() {		
	
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the titleVersion
	 */
	public String getTitleVersion() {
		return titleVersion;
	}

	/**
	 * @param titleVersion the titleVersion to set
	 */
	public void setTitleVersion(String titleVersion) {
		this.titleVersion = titleVersion;
	}

	/**
	 * @return the wfTaskId
	 */
	public String getWfTaskId() {
		return wfTaskId;
	}

	/**
	 * @param wfTaskId the wfTaskId to set
	 */
	public void setWfTaskId(String wfTaskId) {
		this.wfTaskId = wfTaskId;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the statusDesc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * @param statusDesc the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	
	

}
