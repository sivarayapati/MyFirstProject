package com.vz.uiam.onenet.ods.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.jpa.impl.JPAQuery;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.QWorkflowFalloutConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFalloutConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.WorkflowFalloutConfigRepo;
import com.vz.uiam.onenet.ods.predicate.WorkFlowFalloutConfigSearchPredicate;


@Service
public class ODSWorkFlowFalloutConfigService {

	private static final Logger LOGGER = Logger.getLogger(ODSWorkFlowFalloutConfigService.class);
	
	@Autowired
	WorkflowFalloutConfigRepo workflowFalloutConfigRepo;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	
	/**
	 * @param inputWorkflowFalloutConfig
	 * @return WorkflowFalloutConfig
	 * @throws ApplicationException
	 * 
	 */
	public WorkflowFalloutConfig createOrUpdateWorkflowFalloutConfig(WorkflowFalloutConfig inputWorkflowFalloutConfig) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateWorkflowFalloutConfig");
		
		WorkflowFalloutConfig existingWorkflowFalloutConfig = null;
		
		if (inputWorkflowFalloutConfig != null && inputWorkflowFalloutConfig.getId()!=0 ) {
			existingWorkflowFalloutConfig = workflowFalloutConfigRepo.findOne(inputWorkflowFalloutConfig.getId());
			
			if (existingWorkflowFalloutConfig == null)
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "WorkflowFalloutConfig record not found for ID - " + inputWorkflowFalloutConfig.getId());
		} else if (inputWorkflowFalloutConfig != null && (!StringUtils.isEmpty(inputWorkflowFalloutConfig.getWorkFlowStepName()) && !StringUtils.isEmpty(inputWorkflowFalloutConfig.getWorkflowProcessName()))) {
			existingWorkflowFalloutConfig = workflowFalloutConfigRepo
					.findByWorkFlowStepNameAndWorkflowProcessNameAndWorkFlowFalloutErrorCode(inputWorkflowFalloutConfig.getWorkFlowStepName(),
									inputWorkflowFalloutConfig.getWorkflowProcessName(), inputWorkflowFalloutConfig.getWorkFlowFalloutErrorCode());
		}
		
		if (existingWorkflowFalloutConfig == null) {
			doWorkflowFalloutConfig(inputWorkflowFalloutConfig);
		}
		
		WorkflowFalloutConfig newWorkflowFalloutConfig = workflowFalloutConfigRepo.save(
				getUpdatedWorkflowFalloutConfigRecord(inputWorkflowFalloutConfig, existingWorkflowFalloutConfig));
		
		LOGGER.info("Exiting createOrUpdateWorkflowFalloutConfig");
		return newWorkflowFalloutConfig;
	}
	
	
	/**
	 * API to retrieve WorkflowFalloutConfig records
	 * 
	 * @param WorkflowFalloutConfig
	 * @return
	 * @throws ApplicationException
	 *
	 */
	public List<WorkflowFalloutConfig> getWorkflowFalloutConfig(WorkflowFalloutConfig workflowFalloutConfig) throws ApplicationException {
		LOGGER.info("Entering getWorkflowFalloutConfig");
		List<WorkflowFalloutConfig> workflowFalloutConfigRspList = null;
		
		QWorkflowFalloutConfig odsWorkflowFalloutConfigQdsl = QWorkflowFalloutConfig.workflowFalloutConfig;
		
		WorkFlowFalloutConfigSearchPredicate configSearchPredicate = new WorkFlowFalloutConfigSearchPredicate();
		
		JPAQuery query = getJPAQryInstance();
		
		try {
			workflowFalloutConfigRspList = query.from(odsWorkflowFalloutConfigQdsl)
					.where(configSearchPredicate.isWorkflowProcessNameEqualsIg(workflowFalloutConfig.getWorkflowProcessName()),
							configSearchPredicate.isWorkFlowStepNameEqualsIg(workflowFalloutConfig.getWorkFlowStepName()))
					.list(new QWorkflowFalloutConfig(odsWorkflowFalloutConfigQdsl));
		} catch (Exception e) {
			LOGGER.error("Error while getting WorkflowFalloutConfig records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while getting WorkflowFalloutConfig records. " + e.getMessage());
		}
		
		LOGGER.info("Exiting getWorkflowFalloutConfig");
		return workflowFalloutConfigRspList;
	}

	
	/**
	 * API to delete the WorkflowFalloutConfig records
	 * 
	 * @param workflowFalloutConfigList
	 * @throws ApplicationException
	 */
	public void deleteWorkflowFalloutConfigRecord(List<WorkflowFalloutConfig> workflowFalloutConfigList) throws ApplicationException {
		LOGGER.info("Entering deleteWorkflowFalloutConfigRecord");
		
		try {
			for (WorkflowFalloutConfig workflowFalloutConfig : workflowFalloutConfigList) {
				if (workflowFalloutConfig.getId() != 0) {
					workflowFalloutConfigRepo.delete(workflowFalloutConfig.getId());
				} else if (!StringUtils.isEmpty(workflowFalloutConfig.getWorkFlowStepName()) &&
							!StringUtils.isEmpty(workflowFalloutConfig.getWorkflowProcessName())) {
					
					WorkflowFalloutConfig existingWorkflowFalloutConfig = workflowFalloutConfigRepo
										.findByWorkFlowStepNameAndWorkflowProcessNameAndWorkFlowFalloutErrorCode(workflowFalloutConfig.getWorkFlowStepName(), 
												workflowFalloutConfig.getWorkflowProcessName() ,workflowFalloutConfig.getWorkFlowFalloutErrorCode());
					
					if (existingWorkflowFalloutConfig != null)
						workflowFalloutConfigRepo.delete(existingWorkflowFalloutConfig);
				} else {
					throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Provide either [id] or [WorkFlowStepName and WorkflowProcessName]");
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error while deleting WorkflowFalloutConfig records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while deleting WorkflowFalloutConfig records. " + e.getMessage());
		}
		
		LOGGER.info("Exiting deleteWorkflowFalloutConfigRecord");
	}
	
	/**
	 * API to update the input record with the exiting one 
	 * 
	 * @param inputWorkflowFalloutConfig
	 * @param existingWorkflowFalloutConfig
	 * @return
	 * 
	 */
	public WorkflowFalloutConfig getUpdatedWorkflowFalloutConfigRecord(WorkflowFalloutConfig inputWorkflowFalloutConfig,
			WorkflowFalloutConfig existingWorkflowFalloutConfig)  {
		LOGGER.info("Entering getUpdatedWorkflowFalloutConfigRecord");
		
		if (existingWorkflowFalloutConfig == null)
			return inputWorkflowFalloutConfig;
		
		if (!StringUtils.isEmpty(inputWorkflowFalloutConfig.getWorkFlowStepName()))
			existingWorkflowFalloutConfig.setWorkFlowStepName(inputWorkflowFalloutConfig.getWorkFlowStepName());
		
		if (!StringUtils.isEmpty(inputWorkflowFalloutConfig.getWorkflowProcessName()))
			existingWorkflowFalloutConfig.setWorkflowProcessName(inputWorkflowFalloutConfig.getWorkflowProcessName());
			
		if (!StringUtils.isEmpty(inputWorkflowFalloutConfig.getWorkFlowFalloutErrorCode()))
			existingWorkflowFalloutConfig.setWorkFlowFalloutErrorCode(inputWorkflowFalloutConfig.getWorkFlowFalloutErrorCode());
		
		if (!(inputWorkflowFalloutConfig.getMaxRetryCounter()<0))
			existingWorkflowFalloutConfig.setMaxRetryCounter(inputWorkflowFalloutConfig.getMaxRetryCounter());
		
		if (!(inputWorkflowFalloutConfig.getRetryInterval()<0))
			existingWorkflowFalloutConfig.setRetryInterval(inputWorkflowFalloutConfig.getRetryInterval());
		
		
		LOGGER.info("Exiting getUpdatedWorkflowFalloutConfigRecord");
		return existingWorkflowFalloutConfig;
	}
	
	
	/**
	 * API to do validation on input WorkflowFalloutConfig record
	 * 
	 * @param inputWorkflowFalloutConfig
	 * @throws ApplicationException
	 */
	public void doWorkflowFalloutConfig(WorkflowFalloutConfig inputWorkflowFalloutConfig) throws ApplicationException {
		LOGGER.info("Entering doWorkflowFalloutConfig");
		
		if (StringUtils.isEmpty(inputWorkflowFalloutConfig.getWorkFlowStepName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "WorkFlowStepName is null or empty");
		if (StringUtils.isEmpty(inputWorkflowFalloutConfig.getWorkflowProcessName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "WorkflowProcessName is null or empty");
		
		
		LOGGER.info("Exiting doWorkflowFalloutConfig");
	}
	
	public JPAQuery getJPAQryInstance() {
		return new JPAQuery(entityManager);
	}
	
}
