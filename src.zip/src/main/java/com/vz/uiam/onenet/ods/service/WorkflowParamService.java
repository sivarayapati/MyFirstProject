/**
 * 
 */
package com.vz.uiam.onenet.ods.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.OdsWorkflowParamsDAO;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsWorkflowParams;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsWorkflowParamsId;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsWorkflowParamsRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.WfParamRequestDTO;

/**
 * @author Anand Badiger
 *
 */
@Service
public class WorkflowParamService {

	private static final Logger LOGGER = Logger.getLogger(WorkflowParamService.class);
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	@Qualifier("odsWorkflowParamsDAO")
	OdsWorkflowParamsDAO odsWorkflowParamsDAO;
	
	@Autowired
	OdsWorkflowParamsRepository odsWorkflowParamsRepository;
	
	/**
	 * API to create or updated OdsWorkflowParams
	 * 
	 * @param respCfgParam
	 * @param paramName
	 * @param paramValue
	 * @return
	 * @throws ApplicationException
	 */
	public void createWorkflowParams(String rootCaseId, String paramName, String paramValue) throws ApplicationException {
		LOGGER.info("Entering createWorkflowParams");
		LOGGER.info("##########rootCaseId#######"+rootCaseId);
		OdsWorkflowParamsId pk = new OdsWorkflowParamsId(Integer.parseInt(rootCaseId),paramName);
		OdsWorkflowParams odsWfParam = new OdsWorkflowParams(pk, paramValue);
		try{
		odsWorkflowParamsRepository.save(odsWfParam);
		} catch (DataIntegrityViolationException se) {
			LOGGER.info("SQL Exception(DataIntegrityViolationException) while inserting"+ rootCaseId +" - "+paramName+". So, Re-trying to save Workflow Params :" + se);
			createWorkflowParams(rootCaseId, paramName, paramValue);
		} catch (ConstraintViolationException cve){
			LOGGER.info("SQL Exception(ConstraintViolationException) while inserting"+ rootCaseId +" - "+paramName+". So, Re-trying to save Workflow Params :" + cve);
			createWorkflowParams(rootCaseId, paramName, paramValue);
		} catch (Exception ex){
			LOGGER.info("Exception while inserting"+ rootCaseId +" - "+paramName+". So, Re-trying to save Workflow Params :" + ex);
			throw new ApplicationException(StatusCode.ERROR_WHILE_CREATE_OR_UPDATE_WORKFLOW_PARAMS.getCode(), StatusCode.ERROR_WHILE_CREATE_OR_UPDATE_WORKFLOW_PARAMS.getDesc());
		}
		LOGGER.info(odsWfParam);
		LOGGER.info("Exiting createWorkflowParams");
	}

	
	/**
	 * API to get Workflow Params
	 * 
	 * @param request
	 * @return
	 * @throws ApplicationException
	 */
	public Map<String, String> getWorkflowParams(WfParamRequestDTO request) throws ApplicationException {
		LOGGER.info("Entering getWorkflowParams");
		if (StringUtils.isEmpty(request.getRootCaseId())) {
			LOGGER.error("rootCaseId is missing in the request");
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "RootCaseId is missing in the request");
		}
		try {
			List<OdsWorkflowParams> params = odsWorkflowParamsDAO
					.findByRootCaseId(Integer.parseInt(request.getRootCaseId()));
			LOGGER.info("Exiting getWorkflowParams");
			return prepareWorkflowParamsResponse(params);
		} catch (Exception e) {
			LOGGER.error("Error while getting workflow params - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), e.getMessage() + request.toString());
		}

	}
	
	
	public Map<String, String> prepareWorkflowParamsResponse(List<OdsWorkflowParams> workFlowParamList) {
		LOGGER.info("Entering prepareWorkflowParamsResponse");
		Map<String, String> workFlowParamsMap = new HashMap<>();
		for (OdsWorkflowParams workflowParam : workFlowParamList) {
			workFlowParamsMap.put(workflowParam.getOdsWorkflowParamsId().getWfParamName(), workflowParam.getWfParamValue());
		}
		LOGGER.info(workFlowParamsMap);
		LOGGER.info("Entering prepareWorkflowParamsResponse");
		return workFlowParamsMap;
	}
}
