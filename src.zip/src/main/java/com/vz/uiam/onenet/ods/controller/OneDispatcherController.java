package com.vz.uiam.onenet.ods.controller;

import java.util.Date;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.service.NotesService;
import com.vz.uiam.onenet.ods.service.ODSJsonResponseHandler;
import com.vz.uiam.onenet.ods.service.ODSResponseHandler;
import com.vz.uiam.onenet.ods.service.ODSService;
import com.vz.uiam.onenet.ods.service.ODSXmlResponseHandler;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/oneDispatcher")
@PreAuthorize("hasAnyAuthority('ROLE:IVAPP_USER','ROLE:IVAPP_TESTER')")
public class OneDispatcherController {

	private static final Logger LOGGER = Logger.getLogger(OneDispatcherController.class);

	@Autowired
	ODSService odsService;

	@Autowired
	ServiceUtils serviceUtils;
	
	@Autowired
	ODSJsonResponseHandler odsJsonResponseHandler;
	
	@Autowired
	ODSXmlResponseHandler odsXmlResponseHandler;
	
	@Autowired
	ODSResponseHandler odsResponseHandler;
	
	@Autowired
	NotesService notesService;
	
	@Autowired 
	OdsRequestLogRepository odsRequestLogRepository;


	/**
	 * @param request
	 * @return ResponseEntity<ServiceRouterResponse>
	 */
	@RequestMapping(value = "/healthcheck", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "ServiceRouter Healthcheck page", notes = "ServiceRouter Healthcheck page", response = OdsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "ServiceRouter Service alive", response = OdsResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Service is unavaialble") })
	public ResponseEntity<OdsResponse> healthCheck() {
		LOGGER.debug(">>healthCheck()");
		OdsResponse response = new OdsResponse();
		String statusCode = StatusCode.SUCCESS.getCode();
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(statusCode);
		responseStatus.setDescription("ServiceRouter Service alive");
		response.setStatus(responseStatus);
		LOGGER.debug("<<healthCheck()");
		return ResponseEntity.ok(response);
	}
	
	/**
	 * @param request
	 * @return ResponseEntity<TransformationResponse>
	 */
	@RequestMapping(value = "/doRequestTransform", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Do Input Doc transformation based on the Transforamtion Type", notes = "Do Input Doc transformation based on the Transforamtion Type", response = OdsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully transformed the Input Document", response = OdsResponse.class) })
	public ResponseEntity<OdsResponse> doRequestTransform(@RequestBody String request) {
		LOGGER.info(">>doTransform()");
		Date requestTime = new Date();
		LOGGER.info("Request Payload being passed for ODS doTransform::::"+request);
		String statusCode = StatusCode.SUCCESS.getCode();
		 String statusMsg = StatusCode.SUCCESS.getDesc();
		OdsResponse response = null;
		try {
			response = odsService.handleOdsRequest(request);
			LOGGER.info("Response Recieved from ODS doTransform::::"+request);
		} catch (ApplicationException e) {
			LOGGER.error("############ Application Exception Occured while doTransform service #################"
												+ "ERROR CODE::::: " + e.getErrCode() + "ERROR DESCRIPTION IS::::: ", e);
			//add notes for exception
			notesService.addNotesForException(request, e);

			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception exception) {
			LOGGER.error("############ Exception Occured while doTransform service #################"
																			+ "ERROR DESCRIPTION IS::::: ", exception);
			//add notes for exception
			notesService.addNotesForException(request, exception);
			
			statusCode = StatusCode.APP_ERROR.getCode();
			statusMsg = exception.getMessage();
		}
		
		if (response == null)
			response = new OdsResponse();
		
		response = serviceUtils.handleOdsResponse(statusCode, statusMsg, response);
		Date responseTime = new Date();
		long seconds = responseTime.getTime()-requestTime.getTime();
		LOGGER.info("Time taken to respond in Milli seconds :"+seconds);
		LOGGER.info("<<doTransform()");
		if (statusCode == StatusCode.SUCCESS.getCode()) {
			HttpHeaders headers = new HttpHeaders();
			headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
			return new ResponseEntity<>(response, headers, HttpStatus.OK);
		} else {
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(response);
		}

	}


	/**
	 * @param request
	 * @return ResponseEntity<TransformationResponse>
	 */
	@RequestMapping(value = "/doTransform", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Do Input Doc transformation based on the Transforamtion Type", notes = "Do Input Doc transformation based on the Transforamtion Type", response = OdsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully transformed the Input Document", response = OdsResponse.class) })
	public ResponseEntity<OdsResponse> doTransform(@RequestBody String request) {
		LOGGER.info(">>doTransform()");
		Date requestTime = new Date();
		LOGGER.info("Request Payload being passed for ODS doTransform::::"+request);
		String statusCode = StatusCode.SUCCESS.getCode();
		 String statusMsg = StatusCode.SUCCESS.getDesc();
		OdsResponse response = null;
		try {
			response = odsService.getTransformedResponse(request);
			LOGGER.info("Response Recieved from ODS doTransform::::"+request);
		} catch (ApplicationException e) {
			LOGGER.error("############ Application Exception Occured while doTransform service #################"
												+ "ERROR CODE::::: " + e.getErrCode() + "ERROR DESCRIPTION IS::::: ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception exception) {
			LOGGER.error("############ Exception Occured while doTransform service #################"
																			+ "ERROR DESCRIPTION IS::::: ", exception);
			statusCode = StatusCode.APP_ERROR.getCode();
			statusMsg = exception.getMessage();
		}
		
		if (response == null)
			response = new OdsResponse();
		
		response = serviceUtils.handleOdsResponse(statusCode, statusMsg, response);
		Date responseTime = new Date();
		long seconds = responseTime.getTime()-requestTime.getTime();
		LOGGER.info("Time taken to respond in Milli seconds :"+seconds);
		LOGGER.info("<<doTransform()");
		if (statusCode == StatusCode.SUCCESS.getCode()) {
			HttpHeaders headers = new HttpHeaders();
			headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
			return new ResponseEntity<>(response, headers, HttpStatus.OK);
		} else {
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(response);
		}

	}
	
	
	/**
	 * @param request
	 * @return ResponseEntity<TransformationResponse>
	 * @throws ApplicationException 
	 */
	@RequestMapping(value = "/doXmlResponseTransform", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Do Input Response Doc processing based on the Transforamtion Type", notes = "Do Input Response Doc processing based on the Transforamtion Type", response = OdsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully parsed the Input Response Document", response = String.class) })
	public ResponseEntity<String> doXmlResponseTransform(@RequestBody String xmlResponse) {
		LOGGER.info("Entering doXmlResponseTransform");
		LOGGER.info("#################XML RESPONSE RECIVED FOR PROCESSING###########"+xmlResponse);
		Date requestTime = new Date();
		JSONObject originalResponse;
		String transactionId = null;
		OdsInterfaceRequest odsInterfaceReq  = null;
		try {
			
			
			transactionId = odsXmlResponseHandler.getTransactionIdFromRespTransIdMap(xmlResponse);
			// Get OdsInterfaceRequest record for the TransactionId
			odsInterfaceReq = odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(transactionId, StatusCode.REQUEST_PENDING.toString());
			
			originalResponse = odsXmlResponseHandler.doXMLResponseProcessing(xmlResponse,transactionId,odsInterfaceReq);
			
		} catch(ApplicationException applicationException) {
			LOGGER.error("############Application Exception Occured while processing the XML response#################"
					+ "ERROR CODE:::::"+applicationException.getErrCode()+"ERROR DESCRIPTION IS:::::", applicationException);
			ResponseStatus failureResponseStatus = new ResponseStatus(applicationException.getErrCode(), 
					applicationException.getMessage());
			

			originalResponse = new JSONObject();
			originalResponse.put("response", xmlResponse);
			
			odsXmlResponseHandler.handleException(originalResponse, failureResponseStatus, odsInterfaceReq);
		} catch(Exception exception) {
			LOGGER.error("############Exception Occured while processing the XML response#################"
					+ "ERROR DESCRIPTION IS:::::", exception);

			
			ResponseStatus failureResponseStatus = new ResponseStatus(StatusCode.APP_ERROR.getCode(), 
					StatusCode.APP_ERROR.getDesc());
			
			originalResponse = new JSONObject();
			originalResponse.put("response", xmlResponse);
			
			odsXmlResponseHandler.handleException(originalResponse, failureResponseStatus, odsInterfaceReq);
		}
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		
		Date responseTime = new Date();
		long seconds = responseTime.getTime()-requestTime.getTime();
		LOGGER.info("Time taken to respond in Milli seconds :"+seconds);
		
		LOGGER.info("#################AFTER PROCESSING THE XML RESPONSE###########" + originalResponse);
		return new ResponseEntity<>(originalResponse.toString(), headers, HttpStatus.OK);
	}
	

	
	
	/**
	 * @param request
	 * @return ResponseEntity<TransformationResponse>
	 * @throws ApplicationException 
	 */
	@RequestMapping(value = "/doRestSvcXmlResponseTransform", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Do REST Service - XML Response processing", notes = "Do REST Service - XML Response processing", response = String.class)
	@ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully processed the Input Response", response = String.class) })
	public ResponseEntity<String> doRestSvcXmlResponseTransform(@RequestBody String xmlResponse) {
		LOGGER.info("Entering doRestSvcXmlResponseTransform");
		LOGGER.info("#################REST SERVICE - XML RESPONSE RECIVED FOR PROCESSING###########" + xmlResponse);
		Date requestTime = new Date();
		JSONObject originalResponse;
		String transactionId = null;
		OdsInterfaceRequest odsInterfaceReq  = null;
		try {
			//JSONObject respJsonObj = new JSONObject(xmlResponse); respJsonObj.toString(), respJsonObj.optString(Constants.TRANSACTION_ID)
			// You always get an XML String here along with "transactionId". Extract the transactionId. If not present fail it.
			
			
			
			transactionId = odsXmlResponseHandler.getTransactionIdFromXmlNodeValue(xmlResponse);
			// Get OdsInterfaceRequest record for the TransactionId
			odsInterfaceReq = odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(transactionId, StatusCode.REQUEST_PENDING.toString());
						
			originalResponse = odsXmlResponseHandler.doXMLResponseProcessing(xmlResponse,transactionId, odsInterfaceReq);
		} catch(ApplicationException e) {
			LOGGER.error("############Application Exception Occured while processing the REST SERVICE - XML response#################"
					+ "ERROR CODE:::::"+e.getErrCode()+"ERROR DESCRIPTION IS:::::", e);
			

			
			ResponseStatus failureResponseStatus = new ResponseStatus(e.getErrCode(),e.getMessage());
			
			originalResponse = new JSONObject();
			originalResponse.put("response", xmlResponse);
			
			odsXmlResponseHandler.handleException(originalResponse, failureResponseStatus, odsInterfaceReq);
		} catch(Exception exception) {
			LOGGER.error("############Exception Occured while processing the REST SERVICE - XML response#################"
					+ "ERROR DESCRIPTION IS:::::", exception);
			

			
			ResponseStatus failureResponseStatus = new ResponseStatus(StatusCode.APP_ERROR.getCode(), StatusCode.APP_ERROR.getDesc());
			
			originalResponse = new JSONObject();
			originalResponse.put("response", xmlResponse);
			
			odsXmlResponseHandler.handleException(originalResponse, failureResponseStatus, odsInterfaceReq);
		}
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		
		Date responseTime = new Date();
		long seconds = responseTime.getTime()-requestTime.getTime();
		LOGGER.info("Time taken to respond in Milli seconds :"+seconds);
		
		LOGGER.info("#################AFTER PROCESSING THE REST SERVICE - XML RESPONSE###########" + originalResponse);
		return new ResponseEntity<>(originalResponse.toString(), headers, HttpStatus.OK);
	}
	
	


	/**
	 * @param request
	 * @return ResponseEntity<TransformationResponse>
	 * @throws ApplicationException
	 */
	@RequestMapping(value = "/doJsonResponseTransform", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Do Input Response Doc processing based on the Transforamtion Type", notes = "Do Input Response Doc processing based on the Transforamtion Type", response = OdsResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully parsed the Input Response Document", response = String.class) })
	public ResponseEntity<String> doJsonResponseTransform(@RequestBody String response) {
		LOGGER.info("Entering doJsonResponseTransform");
		LOGGER.info("#################JSON RESPONSE RECIVED FOR PROCESSING###########" + response);
		Date requestTime = new Date();
		
		JSONObject originalResponse = null;
		String transactionId=null;
		OdsInterfaceRequest odsInterfaceReq  = null;
		try {
						
				// Get Transaction ID 
				transactionId = odsJsonResponseHandler.getTransactionIdFromJsonResponse(response);
				// Get OdsInterfaceRequest record for the TransactionId
				odsInterfaceReq = odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(transactionId, StatusCode.REQUEST_PENDING.toString());
							
				originalResponse = odsJsonResponseHandler.handleJsonResponse(response, transactionId, odsInterfaceReq);	
			
			
		} catch(ApplicationException applicationException) {
			LOGGER.error("############Application Exception Occured while processing the JSON response#################"
					+ "ERROR CODE:::::"+applicationException.getErrCode()+"ERROR DESCRIPTION IS:::::", applicationException);
			ResponseStatus failureResponseStatus = new ResponseStatus(applicationException.getErrCode(), 
					applicationException.getMessage());

			
			originalResponse = new JSONObject(response);			
			odsJsonResponseHandler.handleException(originalResponse, failureResponseStatus, odsInterfaceReq);
		} catch(Exception exception) {
			LOGGER.error("############Exception Occured while processing the JSON response#################"
					+ "ERROR DESCRIPTION IS:::::", exception);
			

			ResponseStatus failureResponseStatus = new ResponseStatus(StatusCode.APP_ERROR.getCode(), 
					StatusCode.APP_ERROR.getDesc());
			originalResponse = new JSONObject(response);			
			odsJsonResponseHandler.handleException(originalResponse, failureResponseStatus, odsInterfaceReq);
		}
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		
		Date responseTime = new Date();
		long seconds = responseTime.getTime()-requestTime.getTime();
		LOGGER.info("Time taken to respond in Milli seconds :"+seconds);
		
		LOGGER.info("#################AFTER PROCESSING THE JSON RESPONSE###########" + originalResponse);
		return new ResponseEntity<>(originalResponse.toString(), headers, HttpStatus.OK);
	}
	


}