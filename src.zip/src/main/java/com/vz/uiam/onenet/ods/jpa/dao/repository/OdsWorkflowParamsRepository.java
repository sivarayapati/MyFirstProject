/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.stereotype.Repository;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsWorkflowParams;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsWorkflowParamsId;


/**
 * @author V130073
 *
 */

@Repository
public interface OdsWorkflowParamsRepository extends JpaRepository<OdsWorkflowParams, OdsWorkflowParamsId>, QueryDslPredicateExecutor<Object[]> {
	
	/**
	 * @param rootcaseid
	 * @return List<OdsWorkflowParams> 
	 */
	List<OdsWorkflowParams> findByOdsWorkflowParamsIdRootCaseId(Integer rootcaseid);
	/* (non-Javadoc)
	 * @see org.springframework.data.repository.CrudRepository#findOne(java.io.Serializable)
	 */
	OdsWorkflowParams findOne(OdsWorkflowParamsId id);
}
