package com.vz.uiam.onenet.ods.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsLogEntryResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsRequestLogResponse;
import com.vz.uiam.onenet.ods.service.OdsRequestLogService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/oneDispatcher/odsRequest")
public class OdsRequestLogController {
	
private static final Logger LOGGER = Logger.getLogger(OdsRequestLogController.class);
	
	@Autowired
	OdsRequestLogService odsRequestLogService;
	
	
	/**
	 * @param logEntryRequest
	 * @return ResponseEntity<OdsLogEntryResponse>
	 * @throws JSONException 
	 * @throws ApplicationException 
	 */
	@RequestMapping(value = "/requestDetailsByTaskId", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "odsLogEntryResponse", notes = "odsLogEntryResponse by TaskId", response = OdsLogEntryResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully parsed the Input Response Document", response = OdsLogEntryResponse.class) })
	public ResponseEntity<OdsLogEntryResponse> getOdsRequestLogEntryBywfTaskId(@RequestBody String logEntryRequest) throws JSONException, ApplicationException{
		LOGGER.info("Entering getOdsRequestLogEntryBywfTaskId");
		JSONObject odsLogEntryRequest = new JSONObject(logEntryRequest);
			
		LOGGER.info("#################logEntryRequest RECIVED FOR PROCESSING###########"+odsLogEntryRequest.getString("wfTaskId"));
		OdsLogEntryResponse odsLogEntryResponse = new OdsLogEntryResponse();
		if( odsLogEntryRequest.getString("wfTaskId").isEmpty() ){
			odsLogEntryResponse.setStatusCode(StatusCode.BAD_REQUEST.getCode());
			odsLogEntryResponse.setStatusDesc("TaskId is Empty or Null");			
		}else{
		odsLogEntryResponse = odsRequestLogService.getOdsRequestLogEntryBywfTaskId(odsLogEntryRequest);
		}
		LOGGER.info("Exiting getOdsRequestLogEntryBywfTaskId");
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(odsLogEntryResponse, headers, HttpStatus.OK);		
	}
	
	
	@RequestMapping(value = "/requestDetailsByTitleAndVersion", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "ODSRequestLogResponses", notes = "ODSRequestLogResponses by Title and TitleVersion", response = OdsRequestLogResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully retrieved the ods request log details", response = OdsRequestLogResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "RequestLog Service is unavailable") })
	public ResponseEntity<OdsRequestLogResponse> getOdsRequestLogEntriesByTitleAndVersion(
			@RequestBody String logEntryRequest) {
		LOGGER.info("Entering getOdsRequestLogEntriesByTitleAndVersion");
		JSONObject odsLogEntryRequest = new JSONObject(logEntryRequest);
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		OdsRequestLogResponse odsRequestLogResponse = new OdsRequestLogResponse();
		try {
			String title = odsLogEntryRequest.getString("title");
			String titleVersion = odsLogEntryRequest.getString("titleVersion");
			LOGGER.info("#################logEntryRequest RECIEVED FOR Retrieving ods request log entries with ########### "
							+ "title" + title + "And titleVersion" + titleVersion);
			if (StringUtils.isEmpty(title) || StringUtils.isEmpty(titleVersion)) {
				statusCode = StatusCode.BAD_REQUEST.getCode();
				statusMsg = "Title or TitleVersion  is Empty or Null";
			} else {
				List<OdsRequestLog> odsRequestLogDetails = odsRequestLogService
						.getOdsRequestLogEntryByTitleAndTitleVersion(title, titleVersion);
				if (odsRequestLogDetails == null || odsRequestLogDetails.isEmpty()) {
					statusCode = StatusCode.DATA_NOT_FOUND.getCode();
					statusMsg = StatusCode.DATA_NOT_FOUND.getDesc();
				}
				odsRequestLogResponse.setOdsRequestLogDetails(odsRequestLogDetails);
			}
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}
		LOGGER.info("Exiting getOdsRequestLogEntriesByTitleAndVersion");
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		odsRequestLogResponse.setStatusCode(statusCode);
		odsRequestLogResponse.setStatusDesc(statusMsg);
		return new ResponseEntity<>(odsRequestLogResponse, headers, HttpStatus.OK);
	}

}
