package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsTransformerConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFalloutConfig;


/**
 * @author Ashish Goyal
 *
 */
@JsonInclude(Include.NON_NULL)
public class ODSConfigPayload {

	private ODSKeyDetails keyDetails;
	private List<OdsServiceRouterMapDetails> serviceRouteMap;
	private List<OdsMandatoryAttributes> mandatoryAttrs;
	private List<OdsParamConfig> paramConfig;
	private OdsRequestTransactionIdMap odsRequestTransactionIdMap;
	private List<WorkflowFalloutConfig> workflowFalloutConfig;
	private OdsTransformerConfig odsTransformerConfig;
	private List<OdsMilestoneConfig> odsMilestoneConfig;
		
	public ODSKeyDetails getKeyDetails() {
		return keyDetails;
	}
	
	public void setKeyDetails(ODSKeyDetails keyDetails) {
		this.keyDetails = keyDetails;
	}
	
	public List<OdsServiceRouterMapDetails> getServiceRouteMap() {
		return serviceRouteMap;
	}

	public void setServiceRouteMap(List<OdsServiceRouterMapDetails> serviceRouteMap) {
		this.serviceRouteMap = serviceRouteMap;
	}

	public List<OdsMandatoryAttributes> getMandatoryAttrs() {
		return mandatoryAttrs;
	}
	
	public void setMandatoryAttrs(List<OdsMandatoryAttributes> mandatoryAttrs) {
		this.mandatoryAttrs = mandatoryAttrs;
	}
	
	public List<OdsParamConfig> getParamConfig() {
		return paramConfig;
	}
	
	public void setParamConfig(List<OdsParamConfig> paramConfig) {
		this.paramConfig = paramConfig;
	}
	
	
	public OdsRequestTransactionIdMap getOdsRequestTransactionIdMap() {
		return odsRequestTransactionIdMap;
	}

	public void setOdsRequestTransactionIdMap(OdsRequestTransactionIdMap odsRequestTransactionIdMap) {
		this.odsRequestTransactionIdMap = odsRequestTransactionIdMap;
	}

	public List<WorkflowFalloutConfig> getWorkflowFalloutConfig() {
		return workflowFalloutConfig;
	}

	public void setWorkflowFalloutConfig(List<WorkflowFalloutConfig> workflowFalloutConfig) {
		this.workflowFalloutConfig = workflowFalloutConfig;
	}

	public OdsTransformerConfig getOdsTransformerConfig() {
		return odsTransformerConfig;
	}

	public void setOdsTransformerConfig(OdsTransformerConfig odsTransformerConfig) {
		this.odsTransformerConfig = odsTransformerConfig;
	}

	/**
	 * @return the odsMilestoneConfig
	 */
	public List<OdsMilestoneConfig> getOdsMilestoneConfig() {
		return odsMilestoneConfig;
	}

	/**
	 * @param odsMilestoneConfig the odsMilestoneConfig to set
	 */
	public void setOdsMilestoneConfig(List<OdsMilestoneConfig> odsMilestoneConfig) {
		this.odsMilestoneConfig = odsMilestoneConfig;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
