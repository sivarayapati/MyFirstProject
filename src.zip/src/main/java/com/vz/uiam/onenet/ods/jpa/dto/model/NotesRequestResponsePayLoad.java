package com.vz.uiam.onenet.ods.jpa.dto.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class NotesRequestResponsePayLoad {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String region_s;
	private String[] notes;
	private String notes_date;
	private String workflow_step_s;
	private String[] response_message_t;
	private String order_number;
	private String[] request_message_t;
	private String circuit_id;
	private String user;
	private String notes_type;
	private Long _version_;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRegion_s() {
		return region_s;
	}
	public void setRegion_s(String region_s) {
		this.region_s = region_s;
	}
	public String getWorkflow_step_s() {
		return workflow_step_s;
	}
	public void setWorkflow_step_s(String workflow_step_s) {
		this.workflow_step_s = workflow_step_s;
	}
	public String getOrder_number() {
		return order_number;
	}
	public void setOrder_number(String order_number) {
		this.order_number = order_number;
	}
	public String getCircuit_id() {
		return circuit_id;
	}
	public void setCircuit_id(String circuit_id) {
		this.circuit_id = circuit_id;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getNotes_type() {
		return notes_type;
	}
	public void setNotes_type(String notes_type) {
		this.notes_type = notes_type;
	}
	
	public String getNotes_date() {
		return notes_date;
	}
	public void setNotes_date(String notes_date) {
		this.notes_date = notes_date;
	}
	public String[] getNotes() {
		return notes;
	}
	public void setNotes(String[] notes) {
		this.notes = notes;
	}
	public String[] getResponse_message_t() {
		return response_message_t;
	}
	public void setResponse_message_t(String[] response_message_t) {
		this.response_message_t = response_message_t;
	}
	public String[] getRequest_message_t() {
		return request_message_t;
	}
	public void setRequest_message_t(String[] request_message_t) {
		this.request_message_t = request_message_t;
	}
	public Long get_version_() {
		return _version_;
	}
	public void set_version_(Long _version_) {
		this._version_ = _version_;
	}
	
}
