package com.vz.uiam.onenet.ods.predicate;

import org.apache.commons.lang3.StringUtils;

import com.mysema.query.types.expr.BooleanExpression;
import com.vz.uiam.onenet.ods.jpa.dao.model.QOdsServiceRouterMapDetails;

/**
 * @author Ashish Goyal
 *
 */
public class ServiceRouteMapSearchPredicate {

	private static QOdsServiceRouterMapDetails odsServiceRouteMap = QOdsServiceRouterMapDetails.odsServiceRouterMapDetails;
	
	public ServiceRouteMapSearchPredicate() {
		super();
	}
	
	public BooleanExpression isAppKeyEqualsIg(String appKey) {
		return !StringUtils.isEmpty(appKey) ? odsServiceRouteMap.appKey.equalsIgnoreCase(appKey) : null;
	}
	
	public BooleanExpression isFlowNodeProcessNameEqualsIg(String flowNodeProcessName) {
		return !StringUtils.isEmpty(flowNodeProcessName) ? odsServiceRouteMap.flowNodeProcessName.equalsIgnoreCase(flowNodeProcessName) : null;
	}
	
	public BooleanExpression isFlowNodeStepNameEqualsIg(String flowNodeStepName) {
		return !StringUtils.isEmpty(flowNodeStepName) ? odsServiceRouteMap.flowNodeStepName.equalsIgnoreCase(flowNodeStepName) : null;
	}
	
	public BooleanExpression isRegionEqualsIg(String region){
		return !StringUtils.isEmpty(region) ? odsServiceRouteMap.region.equalsIgnoreCase(region) : null;
	}
}
