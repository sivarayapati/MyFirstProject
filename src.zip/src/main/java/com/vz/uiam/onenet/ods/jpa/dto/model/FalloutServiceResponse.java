/**
 *
 */
package com.vz.uiam.onenet.ods.jpa.dto.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author Anand
 *
 */
@JsonInclude(Include.NON_NULL)
public class FalloutServiceResponse {

	private Boolean isRetry;
	private Integer workFlowStepRetryFrequency;
	private String caseId;
	private String workFlowStepName;
	private String errorCode;
	private String errorMsg;
	private String statusCode;
	private String statusDesc;


	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return errorMsg;
	}

	/**
	 * @param errorMsg the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * @return the workFlowStepRetryFrequency
	 */
	public Integer getWorkFlowStepRetryFrequency() {
		return workFlowStepRetryFrequency;
	}

	/**
	 * @param workFlowStepRetryFrequency the workFlowStepRetryFrequency to set
	 */
	public void setWorkFlowStepRetryFrequency(Integer workFlowStepRetryFrequency) {
		this.workFlowStepRetryFrequency = workFlowStepRetryFrequency;
	}

	/**
	 * @return the workFlowStepName
	 */
	public String getWorkFlowStepName() {
		return workFlowStepName;
	}

	/**
	 * @param workFlowStepName the workFlowStepName to set
	 */
	public void setWorkFlowStepName(String workFlowStepName) {
		this.workFlowStepName = workFlowStepName;
	}

	/**
	 * @return the isRetry
	 */
	public Boolean getIsRetry() {
		return isRetry;
	}

	/**
	 * @param isRetry the isRetry to set
	 */
	public void setIsRetry(Boolean isRetry) {
		this.isRetry = isRetry;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	/**
	 * @param isRetry
	 * @param workFlowStepRetryFrequency
	 * @param workFlowStepName
	 * @param responseStatus
	 * @param errorCode
	 * @param errorMsg
	 */
	public FalloutServiceResponse(Boolean isRetry, Integer workFlowStepRetryFrequency, String caseId,
			String workFlowStepName, String errorCode, String errorMsg) {
		this.isRetry = isRetry;
		this.workFlowStepRetryFrequency = workFlowStepRetryFrequency;
		this.caseId = caseId;
		this.workFlowStepName = workFlowStepName;
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
	}

	public FalloutServiceResponse() {

	}

	public FalloutServiceResponse(Boolean isRetry, String caseId, String workFlowStepName, String errorCode) {
		this.isRetry = isRetry;
		this.caseId = caseId;
		this.workFlowStepName = workFlowStepName;
		this.errorCode = errorCode;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


}
