/**
 * 
 */
package com.vz.uiam.onenet.ods.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformRequest;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

/**
 * @author ODS.
 *
 */
@Service
public class ODSTransformationService {
	/**
	 * Logger object.
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSTransformationService.class);

	@Autowired
	OdsParamConfigRepository odsParamConfigRepo;

	@Autowired
	ServiceUtils serviceUtils;

	@Autowired
	ApplicationContext applicationContext;

	/**
	 * API to do XML/JSON Transformation after all the validations and checks
	 *
	 * @param transformRequest
	 * @return String
	 * @throws ApplicationException
	 */
	public String doTransformation(TransformRequest transformRequest) throws ApplicationException {
		LOGGER.info("Entering doTransformation");
		
		JSONObject inputJsonObject = new JSONObject(transformRequest.getInputDocument());
		
		/* Add Condtional Schema Defined Params in the Input DOC */
		updateRequestJsonObjectWithConditionalDefinitions(inputJsonObject, transformRequest);
		/* Add Schema Defined Params in the Input DOC */
		updateRequestJsonObjectWithSchemaDefinedParams(inputJsonObject, transformRequest);

		/* Add Application Params in the Input DOC */
		updateRequestJsonObjectWithAppParams(inputJsonObject,transformRequest);
		
		LOGGER.info("Final JSON Object for transformation : " + inputJsonObject.toString(2));

		/* do transformation based on Transformation Type */
		String className = serviceUtils
				.getTransformerClass(Constants.TRANSFROMER_CLASS_KEY_PREFIX + transformRequest.getTransformationType());

		com.vz.uiam.onenet.ods.transformer.Transformer transformer = serviceUtils.getTransformerInstance(className);
		applicationContext.getAutowireCapableBeanFactory().autowireBean(transformer);

		String transformedDoc = (String) transformer.doTransform(inputJsonObject,
				transformRequest.getRequestSchema());

		LOGGER.info("Exiting doTransformation");
		return transformedDoc;
	}

	/**
	 * API to add Application Params in the request JSON Object, if any
	 * 
	 * @param reqJsonDoc
	 * @param requestSchema
	 * @param transFormationType
	 * @throws ApplicationException
	 */
	public void updateRequestJsonObjectWithAppParams(JSONObject inputJsonObject, TransformRequest transformRequest) throws ApplicationException {
		LOGGER.info("Entering updateRequestJsonObjectWithAppParams");

		String[] appParamKeys = fetchApplicationParamKeys(transformRequest);
		if (appParamKeys == null || appParamKeys.length <= 0) {
			LOGGER.info("No Application Param Keys found in the request schema.");
			return;
		}

		String key = transformRequest.getKey();
		List<OdsParamConfig> odsAppParamList = odsParamConfigRepo.findByParamKeyAndTypeAndNameIn(key,
				OdsParamConfigType.APPLICATION_PARAM.toString(), Arrays.asList(appParamKeys));
		if (CollectionUtils.isEmpty(odsAppParamList) || appParamKeys.length > odsAppParamList.size()) {
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), serviceUtils.prepareOdsParamErrorMsg(
					key, OdsParamConfigType.APPLICATION_PARAM.toString(), null, Arrays.asList(appParamKeys)));
		}

		Map<String, String> appParamJsonMap = new HashMap<>();
		for (OdsParamConfig appParam : odsAppParamList) {
			appParamJsonMap.put(appParam.getName(), appParam.getValue());
		} /* end for */

		inputJsonObject.put(Constants.APP_PARAM_KEY, appParamJsonMap);

		LOGGER.info("Exiting updateRequestJsonObjectWithAppParams");
	}
	
	/**
	 * API to add Schema Defined Params in the request JSON Object, if any
	 * 
	 * @param reqJsonDoc
	 * @param requestSchema
	 * @param transFormationType
	 * @throws ApplicationException
	 */
	public void updateRequestJsonObjectWithSchemaDefinedParams(JSONObject reqJsonDoc, TransformRequest transformRequest)
			throws ApplicationException {
		LOGGER.info("Entering updateRequestJsonObjectWithSchemaDefinedParams");
		if (Constants.TRANSFORMATION_JSON_TYPE.equalsIgnoreCase(transformRequest.getTransformationType())) {
			if (!transformRequest.getRequestSchema().contains(Constants.SCHEMA_DEFINED_LITERAL_KEY)) {
				LOGGER.info("No Schema Defined Param Keys found in the request schema.");
				return;
			}
			String rawDefinitionsRows[] = transformRequest.getRequestSchema()
					.split(Constants.SCHEMA_DEFINED_LITERAL_KEY);
			for (int i = 0; i < rawDefinitionsRows.length; i++) {
				String rawDefnRow = rawDefinitionsRows[i];
				String rawDefnParamName = StringUtils.substringBefore(rawDefnRow,
						Constants.SCHEMA_DEFINITIONS_ASSIGNMENT_DELIMITER);

				if (StringUtils.isNotEmpty(rawDefnParamName)) {
					rawDefnParamName = rawDefnParamName.trim();
					String rawDefnParamSchema = StringUtils.substringBetween(rawDefnRow,
							Constants.SCHEMA_DEFINITIONS_ASSIGNMENT_DELIMITER, Constants.SCHEMA_DEFINITIONS_DELIMITER);
					if (StringUtils.isNotEmpty(rawDefnParamSchema)) {
						rawDefnParamSchema = rawDefnParamSchema.trim();
						JSONObject obj = new JSONObject();
						String schemaDefnJsonStr = "{" + rawDefnParamName + ":" + rawDefnParamSchema + "}";
						serviceUtils.populateJsonPayload(schemaDefnJsonStr, reqJsonDoc.toString(), obj);
						if (reqJsonDoc.has(Constants.SCHEMA_DEFINED_PARAM_KEY)) {
							((JSONObject) reqJsonDoc.get(Constants.SCHEMA_DEFINED_PARAM_KEY)).put(rawDefnParamName,
									obj.optString(rawDefnParamName));
						} else
							reqJsonDoc.put(Constants.SCHEMA_DEFINED_PARAM_KEY, obj);
					}
				}
			}
			String requestSchamaBySemiColan[] = transformRequest.getRequestSchema().split(";");
			String cleanRequestSchema = requestSchamaBySemiColan[requestSchamaBySemiColan.length - 1];
			LOGGER.info("Updated Input Document : " + reqJsonDoc);
			LOGGER.info("Request Schema after removing definitions : " + cleanRequestSchema);
			if (cleanRequestSchema != null && StringUtils.isNotEmpty(cleanRequestSchema))
				transformRequest.setRequestSchema(cleanRequestSchema);
			LOGGER.info("Exiting updateRequestJsonObjectWithSchemaDefinedParams");
		}
	}

	/**
	 * API to get Schema Defined Params and Schema
	 * 
	 * @param requestSchema
	 * @param reqJsonDoc
	 * @throws ApplicationException
	 */
	public void updateRequestJsonObjectWithConditionalDefinitions(JSONObject reqJsonDoc,
			TransformRequest transformRequest) throws ApplicationException {
		LOGGER.info("Entering updateRequestJsonObjectWithConditionalDefinitions");
		if (Constants.TRANSFORMATION_JSON_TYPE.equalsIgnoreCase(transformRequest.getTransformationType())) {

			if (!transformRequest.getRequestSchema().contains(Constants.SCHEMA_CONDITIONAL_DEFINED_LITERAL_KEY)) {
				LOGGER.info("No Coditional Schema Defined Param Keys found in the request schema.");
				return;
			}
			String schema = "";
			String schemaDefinition = "";
			/* split with #endif */
			String conditionalRows = StringUtils.substringBefore(transformRequest.getRequestSchema(),
					Constants.SCHEMA_END_CONDITIONAL_DEFINED_LITERAL_KEY);
			schema = StringUtils.substringAfter(transformRequest.getRequestSchema(),
					Constants.SCHEMA_END_CONDITIONAL_DEFINED_LITERAL_KEY);

			/* split with #if */
			String conditionAndDefnition[] = conditionalRows.split(Constants.SCHEMA_CONDITIONAL_DEFINED_LITERAL_KEY);
			for (int i = 0; i < conditionAndDefnition.length; i++) {
				if (StringUtils.isNotEmpty(conditionAndDefnition[i])) {
					StringBuilder condition = new StringBuilder(StringUtils.substringBefore(conditionAndDefnition[i],
							Constants.SCHEMA_THEN_CONDITIONAL_DEFINED_LITERAL_KEY));
					StringBuilder definition = new StringBuilder(StringUtils.substringAfter(conditionAndDefnition[i],
							Constants.SCHEMA_THEN_CONDITIONAL_DEFINED_LITERAL_KEY));
					StringBuilder conditionSchema = new StringBuilder(StringUtils.substringBefore(condition.toString(),
							Constants.SCHEMA_CONDITIONAL_EQUAL_OPERATOR));
					StringBuilder conditionValue = new StringBuilder(StringUtils.substringAfter(condition.toString(),
							Constants.SCHEMA_CONDITIONAL_EQUAL_OPERATOR));
					String value = (String) serviceUtils.getJsonSchemaValue(conditionSchema.toString().trim(),
							reqJsonDoc.toString());
					if (value.equalsIgnoreCase(conditionValue.toString().trim())) {
						schemaDefinition = schemaDefinition.concat(definition.toString());
					}
				}
			}

			String definitionAndSchema = schemaDefinition.concat(schema);
			if (definitionAndSchema != null && StringUtils.isNotEmpty(definitionAndSchema))
				transformRequest.setRequestSchema(definitionAndSchema);
		}
		LOGGER.info(
				"Exiting updateRequestJsonObjectWithConditionalDefinitions : " + transformRequest.getRequestSchema());

	}

	/**
	 * @param transformRequest
	 * @return
	 * @throws ApplicationException
	 */
	private String[] fetchApplicationParamKeys(TransformRequest transformRequest) throws ApplicationException {
		StringBuilder searchParam = new StringBuilder();
		String[] appParamKeys;
		String transformationType = transformRequest.getTransformationType();
		String requestSchema = transformRequest.getRequestSchema();
		if (Constants.TRANSFORMATION_XML_TYPE.equalsIgnoreCase(transformationType)) {
			searchParam.append("\"").append(Constants.APP_PARAM_KEY).append("/");
			appParamKeys = StringUtils.substringsBetween(requestSchema, searchParam.toString(), "\"");
		} else if (Constants.TRANSFORMATION_JSON_TYPE.equalsIgnoreCase(transformationType)) {
			searchParam.append("$.").append(Constants.APP_PARAM_KEY).append(".");
			JSONObject obj = new JSONObject(requestSchema);
			appParamKeys = StringUtils.substringsBetween(obj.toString(), searchParam.toString(), "\"");
		} else {
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "Invalid Transformation Type.");
		}
		return appParamKeys;
	}
}
