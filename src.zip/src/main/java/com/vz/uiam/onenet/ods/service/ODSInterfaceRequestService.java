/**
 * 
 */
package com.vz.uiam.onenet.ods.service;

import java.util.Calendar;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSInterfaceServiceRequest;

/**
 * @author ODS
 *
 */
@Service
public class ODSInterfaceRequestService {
	/**
	 * Logger object.
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSInterfaceRequestService.class);
	
	@Autowired
	OdsInterfaceRequestRepository odsInterfaceRequestRepo;

	public void createInterfaceServiceRecord(ODSInterfaceServiceRequest interfaceServiceRequest) {
		// SAVE the TRANSACTION BEFORE RETURNING
		String transactionId = interfaceServiceRequest.getTransactionId();
		OdsInterfaceRequest requestFromDb = odsInterfaceRequestRepo.findByTransactionIdAndStatus(transactionId,
				StatusCode.REQUEST_PENDING.toString());
		if (null == requestFromDb || StringUtils.isEmpty(requestFromDb.getRequest())) {
			requestFromDb = new OdsInterfaceRequest();
			requestFromDb.setTransactionId(transactionId);
		}
		requestFromDb.setTaskId(interfaceServiceRequest.getTaskId());
		requestFromDb.setRequest(interfaceServiceRequest.getRequestPayload());
		requestFromDb.setCoreleationPayload(interfaceServiceRequest.getCorelationPayload());
		requestFromDb.setManifestPayload(interfaceServiceRequest.getManifestPayload());
		requestFromDb.setStatus(StatusCode.REQUEST_PENDING.toString());
		requestFromDb.setRequestTime(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
		requestFromDb.setResponseConfigParam(interfaceServiceRequest.getResponseConfigParams());

		LOGGER.info("ODS INTERFACE REQUEST OBJECT NEEDS TO BE INSERTED IS : " + requestFromDb.toString());
		LOGGER.info("########CREATING THE TRANSACTION BEFORE SENDING IT TO TARGET#########");
		odsInterfaceRequestRepo.save(requestFromDb);
	}

}
