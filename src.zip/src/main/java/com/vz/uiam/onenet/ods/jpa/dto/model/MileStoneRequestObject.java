package com.vz.uiam.onenet.ods.jpa.dto.model;

public class MileStoneRequestObject {

	private String flowNodeProcessName;
	private String flowNodeStepName;
	private String manifestPayload;
	private String rootCaseID;
	private String appKey;

	/**
	 * @return the flowNodeProcessName
	 */
	public String getFlowNodeProcessName() {
		return flowNodeProcessName;
	}

	/**
	 * @param flowNodeProcessName
	 *            the flowNodeProcessName to set
	 */
	public void setFlowNodeProcessName(String flowNodeProcessName) {
		this.flowNodeProcessName = flowNodeProcessName;
	}

	/**
	 * @return the flowNodeStepName
	 */
	public String getFlowNodeStepName() {
		return flowNodeStepName;
	}

	/**
	 * @param flowNodeStepName
	 *            the flowNodeStepName to set
	 */
	public void setFlowNodeStepName(String flowNodeStepName) {
		this.flowNodeStepName = flowNodeStepName;
	}

	/**
	 * @return the manifestPayload
	 */
	public String getManifestPayload() {
		return manifestPayload;
	}

	/**
	 * @param manifestPayload
	 *            the manifestPayload to set
	 */
	public void setManifestPayload(String manifestPayload) {
		this.manifestPayload = manifestPayload;
	}

	/**
	 * @return the rootCaseID
	 */
	public String getRootCaseID() {
		return rootCaseID;
	}

	/**
	 * @param rootCaseID
	 *            the rootCaseID to set
	 */
	public void setRootCaseID(String rootCaseID) {
		this.rootCaseID = rootCaseID;
	}
	
	/**
	 * @return the appKey
	 */
	public String getAppKey() {
		return appKey;
	}

	/**
	 * @param appKey the appKey to set
	 */
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	/**
	 * @param flowNodeProcessName
	 * @param flowNodeStepName
	 * @param manifestPayload
	 * @param rootCaseID
	 */
	public MileStoneRequestObject(String flowNodeProcessName, String flowNodeStepName, String manifestPayload,
			String rootCaseID, String appKey) {
		super();
		this.flowNodeProcessName = flowNodeProcessName;
		this.flowNodeStepName = flowNodeStepName;
		this.manifestPayload = manifestPayload;
		this.rootCaseID = rootCaseID;
		this.appKey = appKey;
	}

	public MileStoneRequestObject() {
		// TODO Auto-generated constructor stub
	}

}
