package com.vz.uiam.onenet.ods.service;

import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsLogEntryResponse;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@Service
public class OdsRequestLogService {

	private static final Logger LOGGER = Logger.getLogger(OdsRequestLogService.class);

	@Autowired
	OdsRequestLogRepository odsRequestLogRepository;

	@Autowired
	OdsParamConfigRepository odsParamConfigRepository;

	@Autowired
	ServiceUtils serviceUtils;

	public OdsRequestLog createOdsRequestLogEntry(JSONObject workflowRequest, String title, String titleVersion)
			throws JSONException, ApplicationException {

		LOGGER.info("Entering createOdsRequestLogEntry");

		OdsRequestLog odsRequestLog = odsRequestLogRepository
				.findByWfTaskId(workflowRequest.getString(Constants.ACTIVITY_INSTANCE_ID));

		Timestamp currentTime = serviceUtils.getCurrentTimestamp();
		if (odsRequestLog == null) {
			odsRequestLog = new OdsRequestLog();
			odsRequestLog.setTitle(title);
			odsRequestLog.setTitleVersion(titleVersion);
			odsRequestLog.setWfTaskId(workflowRequest.getString(Constants.ACTIVITY_INSTANCE_ID));
			odsRequestLog.setWfTaskName(workflowRequest.getString(Constants.FLOW_STEP_NAME));
			odsRequestLog.setWfRequestPayload(workflowRequest.toString());
			odsRequestLog.setCreatedTime(currentTime);
		}

		if (!(Constants.SUCCESS.equals(odsRequestLog.getWfTaskStatus()))) {
			odsRequestLog.setWfTaskStatus(Constants.ODS_REQUEST_LOG_STATUS_PENDING);
		}

		odsRequestLog.setExpiryTime(getRequestLogExpiryTime(currentTime));
		odsRequestLog.setResponseStatus(Constants.ODS_REQUEST_LOG_STATUS_PENDING);
		odsRequestLog = odsRequestLogRepository.save(odsRequestLog);
		LOGGER.info("Exiting createOdsRequestLogEntry");
		return odsRequestLog;
	}

	public Timestamp getRequestLogExpiryTime(Timestamp currentTime) {

		LOGGER.info("Entering getRequestLogExpiryTime");
		OdsParamConfig odsParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(Constants.ODS_PARAM_KEY,
				OdsParamConfigType.ODS_PARAM.toString(), Constants.DEFAULT_TASK_TIME_OUT);
		Timestamp expiryTime =  serviceUtils.addBufferInMinutesToTime(currentTime, Integer.parseInt(odsParam.getValue()));
		LOGGER.info("Exiting getRequestLogExpiryTime");
		return expiryTime;
	}
	

	public OdsLogEntryResponse getOdsRequestLogEntryBywfTaskId(JSONObject logEntryRequest)
			throws JSONException, ApplicationException {
		LOGGER.info("Entering getOdsRequestLogEntryBywfTaskId");
		OdsRequestLog odsRequestLog = odsRequestLogRepository
				.findByWfTaskId(logEntryRequest.getString(Constants.WF_TASK_ID));
		OdsLogEntryResponse odsLogEntryResponse = new OdsLogEntryResponse();
		if (odsRequestLog == null) {
			odsLogEntryResponse.setStatusCode(StatusCode.DATA_NOT_FOUND.getCode());
			odsLogEntryResponse.setStatusDesc(
					"No DataFoud for the given TaskID" + logEntryRequest.getString(Constants.WF_TASK_ID));
		} else {
			odsLogEntryResponse.setTitle(odsRequestLog.getTitle());
			odsLogEntryResponse.setTitleVersion(odsRequestLog.getTitleVersion());
			odsLogEntryResponse.setWfTaskId(odsRequestLog.getWfTaskId());
			odsLogEntryResponse.setStatusCode(StatusCode.SUCCESS.getCode());
			odsLogEntryResponse.setStatusDesc("Success");
		}
		LOGGER.info("Exiting getOdsRequestLogEntryBywfTaskId");
		return odsLogEntryResponse;
	}
	
	public List<OdsRequestLog> getOdsRequestLogEntryByTitleAndTitleVersion(String title,String titleVersion){
		List<OdsRequestLog> odsRequestLogList = odsRequestLogRepository.findByTitleAndTitleVersion(title,titleVersion);	
		return odsRequestLogList;
	}

}
