/**
 *
 */
package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Request Model class
 *
 * @author Anand
 *
 */
public class WorkflowFalloutRequest implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	public String caseId;
	public String wfTaskId;
	public String workFlowStepName;
	public String workFlowFalloutErrorCode;
	public String workFlowFalloutErrorDesc;
	public String workFlowProcessName;
	public String rootCaseId;
	

	/**
	 * @return the workFlowStepName
	 */
	public String getWorkFlowStepName() {
		return workFlowStepName;
	}

	/**
	 * @param workFlowStepName
	 *            the workFlowStepName to set
	 */
	public void setWorkFlowStepName(String workFlowStepName) {
		this.workFlowStepName = workFlowStepName;
	}

	/**
	 * @return the caseId
	 */
	public String getCaseId() {
		return caseId;
	}

	
	/**
	 * @return the rootCaseId
	 */
	public String getRootCaseId() {
		return rootCaseId;
	}
	
	/**
	 * @return the wfTaskId
	 */
	public String getWfTaskId() {
		return wfTaskId;
	}

	/**
	 * @param wfTaskId the wfTaskId to set
	 */
	public void setWfTaskId(String wfTaskId) {
		this.wfTaskId = wfTaskId;
	}

	/**
	 * @param rootCaseId the rootCaseId to set
	 */
	public void setRootCaseId(String rootCaseId) {
		this.rootCaseId = rootCaseId;
	}

	/**
	 * @param caseId
	 *            the caseId to set
	 */
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return the workFlowFalloutErrorCode
	 */
	public String getWorkFlowFalloutErrorCode() {
		return workFlowFalloutErrorCode;
	}

	/**
	 * @param workFlowFalloutErrorCode
	 *            the workFlowFalloutErrorCode to set
	 */
	public void setWorkFlowFalloutErrorCode(String workFlowFalloutErrorCode) {
		this.workFlowFalloutErrorCode = workFlowFalloutErrorCode;
	}

	/**
	 * @return the workFlowFalloutErrorDes
	 */
	public String getWorkFlowFalloutErrorDesc() {
		return workFlowFalloutErrorDesc;
	}

	/**
	 * @param workFlowFalloutErrorDes
	 *            the workFlowFalloutErrorDes to set
	 */
	public void setWorkFlowFalloutErrorDesc(String workFlowFalloutErrorDes) {
		this.workFlowFalloutErrorDesc = workFlowFalloutErrorDes;
	}

	/**
	 * @return the workFlowProcessName
	 */
	public String getWorkFlowProcessName() {
		return workFlowProcessName;
	}

	/**
	 * @param workFlowProcessName
	 *            the workFlowProcessName to set
	 */
	public void setWorkFlowProcessName(String workFlowProcessName) {
		this.workFlowProcessName = workFlowProcessName;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @param caseId
	 * @param workFlowStepName
	 * @param workFlowStepRetryCounter
	 * @param status
	 * @param workFlowFalloutErrorCode
	 * @param workFlowFalloutErrorDes
	 */
	public WorkflowFalloutRequest(String caseId,String workFlowProcessName, String workFlowStepName,
			String workFlowFalloutErrorCode, String workFlowFalloutErrorDes) {
		this.caseId = caseId;
		this.workFlowStepName = workFlowStepName;
		this.workFlowProcessName=workFlowProcessName;
		this.workFlowFalloutErrorCode = workFlowFalloutErrorCode;
		this.workFlowFalloutErrorDesc = workFlowFalloutErrorDes;
	}

	/**
	 * @param workFlowStepName
	 * @param workFlowFalloutErrorCode
	 */
	public WorkflowFalloutRequest(String workFlowProcessName,String workFlowStepName,
			String workFlowFalloutErrorCode) {
		this.workFlowProcessName=workFlowProcessName;
		this.workFlowStepName = workFlowStepName;
		this.workFlowFalloutErrorCode = workFlowFalloutErrorCode;
	}

	public WorkflowFalloutRequest() {
		// TODO Auto-generated constructor stub
	}

	public WorkflowFalloutRequest(String caseId, String workFlowStepName, String workFlowFalloutErrorCode, String workFlowFalloutErrorDes) {
		this.caseId = caseId;
		this.workFlowStepName = workFlowStepName;
		this.workFlowFalloutErrorCode = workFlowFalloutErrorCode;
		this.workFlowFalloutErrorDesc = workFlowFalloutErrorDes;

	}

	/**
	 * @param caseID
	 * @param flowNodeProcessName
	 * @param flowNodeStepName
	 * @param code
	 * @param description
	 * @param rootCaseID
	 */
	public WorkflowFalloutRequest(String caseID, String flowNodeProcessName, String flowNodeStepName, String code,
			String description, String rootCaseID) {
		this.caseId = caseID;
		this.workFlowStepName = flowNodeStepName;
		this.workFlowProcessName=flowNodeProcessName;
		this.workFlowFalloutErrorCode = code;
		this.workFlowFalloutErrorDesc = description;
		this.rootCaseId = rootCaseID;
	}
	
	/**
	 * @param caseID
	 * @param wfTaskId
	 * @param flowNodeProcessName
	 * @param flowNodeStepName
	 * @param code
	 * @param description
	 * @param rootCaseID
	 */
	public WorkflowFalloutRequest(String caseID, String wfTaskId, String flowNodeProcessName, String flowNodeStepName, String code,
			String description, String rootCaseID) {
		this.caseId = caseID;
		this.wfTaskId = wfTaskId;
		this.workFlowStepName = flowNodeStepName;
		this.workFlowProcessName=flowNodeProcessName;
		this.workFlowFalloutErrorCode = code;
		this.workFlowFalloutErrorDesc = description;
		this.rootCaseId = rootCaseID;
	}

}
