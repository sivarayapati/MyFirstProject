package com.vz.uiam.onenet.ods.service;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneTransaction;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsMilestoneConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsMilestoneTansactionRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsServiceRouterMapRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.MileStoneRequestObject;
import com.vz.uiam.onenet.ods.jpa.dto.model.MileStoneRequestResponsePayLoad;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsMilestoneTransactionRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformedResponsePayload;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@Service
@Transactional(readOnly = false, rollbackFor = Exception.class)
public class MilestoneService {

	private static final Logger LOGGER = Logger.getLogger(MilestoneService.class);

	@Autowired
	OdsServiceRouterMapRepository odsServiceRouterMapRepository;

	@Autowired
	ServiceUtils serviceUtils;
	
	

	@Autowired
	ApplicationContext appcontext;

	@Autowired
	OdsParamConfigRepository odsParamConfigRepo;
	
	@Autowired
	ODSService odsService;

	@Autowired
	OdsMilestoneTansactionRepository odsMilestoneTansactionRepo;

	@Autowired
	OdsMilestoneConfigRepository odsMilestoneConfigRepository;

	/**
	 * API to Send mileStone
	 *
	 * @param responseConfigParam
	 * @param odsInterfaceRequest
	 * @param response
	 * @return
	 * @throws ApplicationException
	 */
	@Async
	public void sendMilestone(MileStoneRequestObject mileStoneRequestObject) throws ApplicationException {
		LOGGER.info("Entering sendMilestone");
		OdsMilestoneTransaction odsMilestoneTransaction = null;
			List<OdsMilestoneConfig> milestoneConfigs = getMilestoneConfigDetails(mileStoneRequestObject);
			if (CollectionUtils.isEmpty(milestoneConfigs)) {

				LOGGER.info("Milestone / Notifications is NOT Configured for ProcessName :: "
						+ mileStoneRequestObject.getFlowNodeProcessName() + " and StepName :: "
						+ mileStoneRequestObject.getFlowNodeStepName());
				return;
			}

			for (OdsMilestoneConfig odsMilestoneConfig : milestoneConfigs) {
				LOGGER.info(odsMilestoneConfig);				
				
				if (!StringUtils.isEmpty(odsMilestoneConfig.getSendMilestone())
						&& "YES".equalsIgnoreCase(odsMilestoneConfig.getSendMilestone()) ) {
					LOGGER.info("Sending Milestone to this service is enabled !!");
					try
					{
						odsMilestoneTransaction = saveMilestoneTransaction(odsMilestoneConfig, mileStoneRequestObject);
						sendMilestoneOrNotification(odsMilestoneConfig, mileStoneRequestObject, odsMilestoneTransaction,
								Constants.DEFAULT_REPROCESS_FLAG);
					}catch(ApplicationException e){
						if(odsMilestoneTransaction != null)
						{
							odsMilestoneTransaction.setStatus(Constants.STATUS_FAILED);
							odsMilestoneTransaction.setStatusDesc(e.getMessage());
							odsMilestoneTansactionRepo.save(odsMilestoneTransaction);
						}
						LOGGER.error("Save the milestone transaction and existing from sendMileston" + e);
					}
				}
				else{
					LOGGER.info("Sending Milestone to this service is disabled !!");
				}
				
			}

		LOGGER.info("Exiting sendMilestone");
	}

	/**
	 * API to getMilestoneConfigDetails
	 * 
	 * @param responseConfigParam
	 * @throws ApplicationException
	 */
	public List<OdsMilestoneConfig> getMilestoneConfigDetails(MileStoneRequestObject mileStoneRequestObject) {
		LOGGER.info("Entering getMilestoneConfigDetails");
		List<OdsMilestoneConfig> milestoneConfigs = odsMilestoneConfigRepository
				.findByFlowNodeProcessNameAndFlowNodeStepName(mileStoneRequestObject.getFlowNodeProcessName(),
						mileStoneRequestObject.getFlowNodeStepName());
		LOGGER.info("Exiting getMilestoneConfigDetails");
		return milestoneConfigs;
	}

	/**
	 * API to send milestone or notifications
	 *
	 * @param odsMilestoneConfig
	 * @param manifestReqPayload
	 * @throws ApplicationException
	 */
	public void sendMilestoneOrNotification(OdsMilestoneConfig odsMilestoneConfig,
			MileStoneRequestObject mileStoneRequestObject, OdsMilestoneTransaction odsMilestoneTranc,
			String reProcessFlag) throws ApplicationException {
		LOGGER.info("Entering sendMilestoneOrNotification");
		
		String appKey = mileStoneRequestObject.getAppKey();
		String requestKey = serviceUtils.buildKey(mileStoneRequestObject.getFlowNodeProcessName(),
				mileStoneRequestObject.getFlowNodeStepName());
		LOGGER.info("Request Key : " + requestKey);
		LOGGER.info("App Key : " + appKey);
		// Validate Milestone configurations
		validateMileStoneConfigs(odsMilestoneConfig);
		MileStoneRequestResponsePayLoad mReqPayLaod = null;
		String tranformedDocument;
		JSONObject finalDocument = new JSONObject();
		if (("YES").equalsIgnoreCase(reProcessFlag) || StringUtils.isEmpty(odsMilestoneTranc.getRequestPayload())) {
			// Get Manifest document
			String manifestReqPayload = mileStoneRequestObject.getManifestPayload();
			String documentPayload = serviceUtils.buildManifestDocument(manifestReqPayload,
					odsMilestoneConfig.getRequestDocumentName());
			finalDocument = new JSONObject(documentPayload);

			TransformRequest tranformReq = new TransformRequest(odsMilestoneConfig.getTransformationType(),
					finalDocument.toString(), odsMilestoneConfig.getRequestSchema());

			LOGGER.info("Required Transformation Type is::: " + odsMilestoneConfig.getTransformationType());
			// Do Transformation
			String tranformedDocumentStr = odsService.doTransformation(tranformReq,appKey,requestKey);
			if (odsMilestoneConfig.getTransformationType().equalsIgnoreCase(Constants.TRANSFORMATION_XML_TYPE)) {
				tranformedDocument = StringEscapeUtils.unescapeXml(tranformedDocumentStr);
			} else {
				tranformedDocument = tranformedDocumentStr;
			}
			odsMilestoneTranc.setRequestPayload(tranformedDocument);
			LOGGER.info("Transformed milsetone Document is ::: \n" + tranformedDocument);
			mReqPayLaod = prepareMilestonePayload(odsMilestoneConfig, tranformedDocument,finalDocument);

		} else {
			tranformedDocument = odsMilestoneTranc.getRequestPayload();
			mReqPayLaod = prepareMilestonePayload(odsMilestoneConfig, tranformedDocument,finalDocument);

		}
		// Call Milestone Proxy Service
		boolean sentMilestoneFalg = callMilestoneProxyService(mReqPayLaod);
		saveMilestoneTranasactinStatus(odsMilestoneTranc, sentMilestoneFalg);
		LOGGER.info("Exiting sendMilestoneOrNotification");
	}

	/**
	 * @param odsMilestoneTranc
	 * @param sentMilestoneFalg
	 */
	public void saveMilestoneTranasactinStatus(OdsMilestoneTransaction odsMilestoneTranc, boolean sentMilestoneFalg) {
		LOGGER.info("Entering saveMilestoneTranasactinStatus");
		if (sentMilestoneFalg) {
			odsMilestoneTranc.setStatus(Constants.STATUS_SENT);
			odsMilestoneTranc.setStatusDesc(StatusCode.SUCCESS.getDesc());
		} else {
			odsMilestoneTranc.setStatus(Constants.STATUS_FAILED);
			odsMilestoneTranc.setStatusDesc(StatusCode.FAILED.getDesc());
		}
		odsMilestoneTansactionRepo.save(odsMilestoneTranc);
		LOGGER.info("Exiting saveMilestoneTranasactinStatus");
	}

	/**
	 * API to prepare Milestone Payload
	 * 
	 * @param odsMilestoneConfig
	 * @param mReqPayLaod
	 * @param tranformedDocument
	 * @throws ApplicationException
	 */
	public MileStoneRequestResponsePayLoad prepareMilestonePayload(OdsMilestoneConfig odsMilestoneConfig,String tranformedDocument, JSONObject document) throws ApplicationException {
		LOGGER.info("Entering prepareMilestonePayload");
		// Prepare milestone payload
		MileStoneRequestResponsePayLoad mReqPayLaod = new MileStoneRequestResponsePayLoad();
		TransformedResponsePayload payload = null;
		payload = serviceUtils.getTransformationPayload(payload, tranformedDocument,
				odsMilestoneConfig.getRouteProtocol());
		mReqPayLaod.setPayload(payload);
		mReqPayLaod.setRoutingProtocol(odsMilestoneConfig.getRouteProtocol());
		//preparing targetEndpoint dynamically
		String targetEndPointUrl = serviceUtils.generateDynamicTargetEndPointUrl(document,odsMilestoneConfig.getTargetEndpointUrl(),odsMilestoneConfig.getFlowNodeProcessName());
		mReqPayLaod.setTargetEndPointURL(targetEndPointUrl);
		// encoding UsernamePassword
		String encodeCredentials = "";
		if (!(StringUtils.isEmpty(odsMilestoneConfig.getUserName())
				&& StringUtils.isEmpty(odsMilestoneConfig.getPassword()))) {
			encodeCredentials = serviceUtils.userNamePasswordEncoder(odsMilestoneConfig.getUserName(),
					odsMilestoneConfig.getPassword());
			mReqPayLaod.setUserNameAndPassword(encodeCredentials);
		}
		LOGGER.info("Exiting prepareMilestonePayload");
		return mReqPayLaod;

	}

	/**
	 * API to prepare save Milestone details in transaction table
	 * 
	 * @param odsMilestoneConfig
	 * @param odsInterfaceRequest
	 * @param responseConfigParam
	 * @throws ApplicationException
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = { ApplicationException.class, Exception.class,
			RuntimeException.class })
	private OdsMilestoneTransaction saveMilestoneTransaction(OdsMilestoneConfig odsMilestoneConfig,
			MileStoneRequestObject mileStoneRequestObject) throws ApplicationException {
		LOGGER.info("Entering saveMilestoneTransc");
		OdsMilestoneTransaction odsMilestoneTrans = odsMilestoneTansactionRepo
				.findByRootCaseIdAndProcessNameAndStepNameAndOdsMilestoneConfig(mileStoneRequestObject.getRootCaseID(),
						mileStoneRequestObject.getFlowNodeProcessName(), mileStoneRequestObject.getFlowNodeStepName(),
						odsMilestoneConfig);
		if (odsMilestoneTrans == null) {
			odsMilestoneTrans = new OdsMilestoneTransaction(mileStoneRequestObject.getRootCaseID(),
					mileStoneRequestObject.getFlowNodeProcessName(), mileStoneRequestObject.getFlowNodeStepName());
		}
		odsMilestoneTrans.setOdsMilestoneConfig(odsMilestoneConfig);
		odsMilestoneTrans.setStatus(Constants.STATUS_PENDING);
		odsMilestoneTrans.setManifestPayload(mileStoneRequestObject.getManifestPayload());
		odsMilestoneTrans.setRootCaseId(mileStoneRequestObject.getRootCaseID());
		odsMilestoneTansactionRepo.save(odsMilestoneTrans);
		LOGGER.info("Exiting saveMilestoneTransc");
		return odsMilestoneTrans;
	}

	/**
	 * API to validate Milestone config
	 * 
	 * @param odsMilestoneConfig
	 * @param odsInterfaceRequest
	 * @param responseConfigParam
	 * @throws ApplicationException
	 */
	private void validateMileStoneConfigs(OdsMilestoneConfig odsMilestoneConfig) throws ApplicationException {
		LOGGER.info("Entering validateMileStoneConfigs");

		if (StringUtils.isEmpty(odsMilestoneConfig.getTargetEndpointUrl())
				|| StringUtils.isEmpty(odsMilestoneConfig.getRequestSchema())
				|| StringUtils.isEmpty(odsMilestoneConfig.getRequestDocumentName())
				|| StringUtils.isEmpty(odsMilestoneConfig.getTransformationType())
				|| StringUtils.isEmpty(odsMilestoneConfig.getRouteProtocol())) {
			LOGGER.error("One or more Milestone configuration is NULL or EMPTY.");
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					"One or more Milestone configuration is NULL or EMPTY.");
		}

		LOGGER.info("Exiting validateMileStoneConfigs");
	}


	/**
	 * API to post Milestone data on proxy service
	 * 
	 * @param mileStonePayLoad
	 * @throws ApplicationException
	 */
	public boolean callMilestoneProxyService(MileStoneRequestResponsePayLoad mileStonePayLoad) throws ApplicationException {
		LOGGER.info("Entering callMilestoneProxyService");
		boolean sentMilestoneFalg = false;
		/* Get MileStone Proxy URL from Param table */
		OdsParamConfig odsAppParam = getMilestoneProxyURL();
		String mileStoneJsonObj = serviceUtils.convertObjectToJsonString(mileStonePayLoad);
		LOGGER.info("MileStone Request :\n" + mileStoneJsonObj);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(mileStoneJsonObj, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = serviceUtils.callService(odsAppParam, httpEntity);

		String response = null;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			response = responseEntity.getBody();
			sentMilestoneFalg = true;
		}
		LOGGER.info("Milestone service Response ::: " + response);
		LOGGER.info("Exiting callMilestoneProxyService");
		return sentMilestoneFalg;
	}

	/**
	 * @return
	 * @throws ApplicationException
	 */
	public OdsParamConfig getMilestoneProxyURL() throws ApplicationException {
		OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.MILESTONE_REQUEST_URL);
		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(),
							OdsParamConfigType.ODS_PARAM.toString(), Constants.MILESTONE_REQUEST_URL, null));

		LOGGER.info("MileStone Request URL : " + odsAppParam.getValue());
		return odsAppParam;
	}

	/**
	 * API to get All milestone transaction for given rootCase Id
	 * 
	 * @param rootCaseId
	 * @return odsMilestoneTransactionList
	 * @throws ApplicationException
	 */
	public List<OdsMilestoneTransaction> getMilestoneTransctionDetails(String rootCaseId) throws ApplicationException {

		LOGGER.debug(">>Entering getMilestoneTransctionDetails");

		List<OdsMilestoneTransaction> odsMilestoneTransactionList = odsMilestoneTansactionRepo
				.findByRootCaseId(rootCaseId);

		for (OdsMilestoneTransaction odsMilestoneTransaction : odsMilestoneTransactionList) {
			odsMilestoneTransaction.setOdsMilestoneConfig(odsMilestoneTransaction.getOdsMilestoneConfig());
		}
		LOGGER.debug(">>Exiting getMilestoneTransctionDetails");
		return odsMilestoneTransactionList;
	}

	/**
	 * API to retry or reprocess the failed Milestone transaction
	 * 
	 * @param retryRequest
	 * @return odsMilestoneTransaction
	 * @throws ApplicationException
	 */
	public OdsMilestoneTransaction retryMilestoneTransaction(OdsMilestoneTransactionRequest retryRequest)
			throws ApplicationException {
		LOGGER.info("Entering retryMilestoneTransaction");

		MileStoneRequestObject mileStoneRequestObject = new MileStoneRequestObject();
		OdsMilestoneTransaction odsMilestoneTransaction;
		if (retryRequest.getOdsMilestoneTransactionId() == 0)
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "MilestoneTransactionId is 0");
		if (StringUtils.isEmpty(retryRequest.getReProcessFlag()))
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "reProcess Flag is null or empty");

		// Find the transaction details from transaction ID

		odsMilestoneTransaction = odsMilestoneTansactionRepo
				.findByOdsMilestoneTransactionId(retryRequest.getOdsMilestoneTransactionId());
		OdsMilestoneConfig milestoneConfig = odsMilestoneTransaction.getOdsMilestoneConfig();
		mileStoneRequestObject.setFlowNodeProcessName(odsMilestoneTransaction.getProcessName());
		mileStoneRequestObject.setFlowNodeStepName(odsMilestoneTransaction.getStepName());
		mileStoneRequestObject.setManifestPayload(odsMilestoneTransaction.getManifestPayload());
		mileStoneRequestObject.setRootCaseID(odsMilestoneTransaction.getRootCaseId());

		sendMilestoneOrNotification(milestoneConfig, mileStoneRequestObject, odsMilestoneTransaction,
				retryRequest.getReProcessFlag());
		LOGGER.info("Exiting retryMilestoneTransaction");
		return odsMilestoneTransaction;
	}

}
