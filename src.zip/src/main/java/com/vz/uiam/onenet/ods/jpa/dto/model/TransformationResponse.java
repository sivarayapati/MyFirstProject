/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dto.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRawValue;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * @author Anand Badiger
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(Include.NON_NULL)
public class TransformationResponse {

	private ResponseStatus status;
	@JsonRawValue
	@XmlElement(name = "responsePayload")
	@JsonProperty("responsePayload")
	@XStreamAlias("responsePayload")
	private String responsePayload;
	

	/**
	 * @return the responsePayload
	 */
	public String getResponsePayload() {
		return responsePayload;
	}

	/**
	 * @param responsePayload the responsePayload to set
	 */
	public void setResponsePayload(String responsePayload) {
		this.responsePayload = responsePayload;
	}

	/**
	 * @return the status
	 */
	public ResponseStatus getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	
}
