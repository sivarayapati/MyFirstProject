/**
 * 
 */
package com.vz.uiam.onenet.ods.service;

import java.util.Calendar;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsTransformerConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

/**
 * @author Ashish Goyal
 *
 */
@Service
public class ODSXmlResponseHandler {

	private static final Logger LOGGER = Logger.getLogger(ODSXmlResponseHandler.class);

	private static final String TRANFORMER_CONFIG_RSP_SCHEMA_SUFFIX = "_RSP_SCHEMA";
	
	@Autowired
	ServiceUtils serviceUtils;
	
	@Autowired
	ODSResponseHandler odsResponseHandler;
	
	
	@Autowired
	OdsTransformerConfigService odsTransformerConfigService;
	
	@Autowired
	OdsRequestLogRepository odsRequestLogRepository;
	
	@Autowired
	NotesService notesService;
	
	/**
	 * 
	 * @param response
	 * @param transactionId
	 * @param odsInterfaceReq
	 * @return
	 * @throws ApplicationException
	 */
	public JSONObject doXMLResponseProcessing(String response, String transactionId, OdsInterfaceRequest odsInterfaceReq) throws ApplicationException {
		LOGGER.info("Entering doXMLResponseProcessing");
		ResponseConfigParams responseConfigParam = null;

		String actualResponse = response;
		JSONObject respObj = new JSONObject();
		// Convert XML to JSON for processing
		JSONObject responseXmlJsonObj = serviceUtils.convertXmlToJson(response);
		LOGGER.info("transactionId : " + transactionId);
		if(!odsResponseHandler.checkForAckInResponse(responseXmlJsonObj.toString(),odsInterfaceReq)) { 			//Proceed further only if Ack not found in response.
		// convert Response Config Param JSON String to Object
		responseConfigParam = (ResponseConfigParams) serviceUtils.
								convertJsonStringToObject(odsInterfaceReq.getResponseConfigParam(), ResponseConfigParams.class);
		String requestKey = serviceUtils.buildKey(responseConfigParam.getFlowNodeProcessName(), responseConfigParam.getFlowNodeStepName());
			
		//Get ODS_Request_log table entry
		OdsRequestLog odsRequestLog = odsRequestLogRepository.findByWfTaskId(odsInterfaceReq.getTaskId());
		
		if (odsRequestLog != null) {
			// Prepare notes payload JSON for transformation
			JSONObject notesJsonForTransformation = notesService.prepareNotesPayload(odsRequestLog.getTitle(),
					odsRequestLog.getTitleVersion(), Constants.RESPONSE_RECEIVED_SUCCESSFULLY, response,
					responseConfigParam.getFlowNodeStepName(), responseConfigParam.getDestinationSystemName(),
					responseConfigParam.getSourceSystemName());

			// Add Notes for the Response
			notesService.addNotes(notesJsonForTransformation, requestKey);
		}
		// Update the response in OdsInterfaceRequest
		odsInterfaceReq.setResponse(response);
		odsInterfaceReq.setResponseTime(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
		
		//Transform Response if configured
		response = transformResponse(response, requestKey);
		LOGGER.info("Response after transformation of the response" + response);
		
		// Remove cdata from XML
		response = serviceUtils.removeCdataFromXml(response);
				
		responseXmlJsonObj = serviceUtils.convertXmlToJson(response);
		response = responseXmlJsonObj.toString();
		
		ResponseStatus responseStatus = odsResponseHandler.processResponse(response, odsInterfaceReq, responseConfigParam, requestKey);
		LOGGER.info("XML RESPONSE STATUS IS ::::::"+ responseStatus);
		
		
		respObj.put("response", responseXmlJsonObj);
		
		respObj = addStatusToResponseObj(responseStatus, respObj);
		
		LOGGER.info("Exiting doXMLResponseProcessing");
		//Only difference is when we return the xml response back though its success or failure we dont read it in Bonita side but for JSON we might.
		}
		return respObj;
	}
	
	/**
	 * 
	 * @param response
	 * @return transactionId
	 * @throws ApplicationException
	 */
	public String getTransactionIdFromRespTransIdMap(String response) throws ApplicationException {
		LOGGER.info("Entering doXMLResponseProcessing");

		// Get the root tag of the response XML
		String rootTagName = serviceUtils.getRootTagFromXml(response);
		LOGGER.info("rootTagName : " + rootTagName);
		
		// Get transactionIdKey using the rootTagName
		String transactionIdKey = odsResponseHandler.getTransIdKeyFromOdsRespTransIdMap(rootTagName);
		LOGGER.info("transactionIdKey : " + transactionIdKey);
		
		// Get the TransactionId from the response
		String transactionId  = getTransactionIdFromResponseUsingTransactionIdKey(response, transactionIdKey);
		
		return transactionId;
	}
	
	/**
	 * @param xmlResponse
	 * @return transactionId
	 * @throws ApplicationException
	 */
	public String getTransactionIdFromXmlNodeValue(String xmlResponse) throws ApplicationException {
				String transactionId  = serviceUtils.getNodeValueFromXml(xmlResponse,Constants.TRANSACTION_ID);
		if (StringUtils.isEmpty(transactionId))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "TransactionId not found in the response");
		return transactionId;
	}

	
	/**
	 * 
	 * @param response
	 * @return
	 * @throws ApplicationException
	 */
	public JSONObject doXMLResponseProcessing(String response) throws ApplicationException {
		LOGGER.info("Entering doXMLResponseProcessing");

		// Get the root tag of the response XML
		String rootTagName = serviceUtils.getRootTagFromXml(response);
		LOGGER.info("rootTagName : " + rootTagName);
		
		// Get transactionIdKey using the rootTagName
		String transactionIdKey = odsResponseHandler.getTransIdKeyFromOdsRespTransIdMap(rootTagName);
		LOGGER.info("transactionIdKey : " + transactionIdKey);
		
		// Get the TransactionId from the response
		String transactionId  = getTransactionIdFromResponseUsingTransactionIdKey(response, transactionIdKey);
		
		return doXMLResponseProcessing(response, transactionId);
	}
	
	/**
	 * 
	 * @param response
	 * @param transactionId
	 * @return
	 * @throws ApplicationException
	 */
	public JSONObject doXMLResponseProcessing(String response, String transactionId) throws ApplicationException {
		LOGGER.info("Entering doXMLResponseProcessing");
		ResponseConfigParams responseConfigParam = null;
		String actualResponse = response;
		OdsInterfaceRequest odsInterfaceReq  = null;
		
		LOGGER.info("transactionId : " + transactionId);
		
		// Get OdsInterfaceRequest record for the TransactionId
		odsInterfaceReq = odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(transactionId, StatusCode.REQUEST_PENDING.toString());
		
		// Update the response in OdsInterfaceRequest
		odsInterfaceReq.setResponse(response);
		odsInterfaceReq.setResponseTime(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
		
		// convert Response Config Param JSON String to Object
		responseConfigParam = (ResponseConfigParams) serviceUtils.
								convertJsonStringToObject(odsInterfaceReq.getResponseConfigParam(), ResponseConfigParams.class);
		String requestKey = serviceUtils.buildKey(responseConfigParam.getFlowNodeProcessName(), responseConfigParam.getFlowNodeStepName());
				
		
		response = transformResponse(response, requestKey);
		LOGGER.info("Response after transformation of the response" + response);
		
		// Remove cdata from XML
		response = serviceUtils.removeCdataFromXml(response);
				
		// Convert XML to JOSN for processing
		JSONObject responseXmlJsonObj = serviceUtils.convertXmlToJson(response);
		response = responseXmlJsonObj.toString();
		
		// call the Notes AddOrUpdate Service
		odsResponseHandler.updateResponseInNotes(transactionId, actualResponse, requestKey);
		
		ResponseStatus responseStatus = odsResponseHandler.processResponse(response, odsInterfaceReq);
		LOGGER.info("XML RESPONSE STATUS IS ::::::"+ responseStatus);
		
		JSONObject respObj = new JSONObject();
		respObj.put("response", responseXmlJsonObj);
		
		respObj = addStatusToResponseObj(responseStatus, respObj);
		
		LOGGER.info("Exiting doXMLResponseProcessing");
		//Only difference is when we return the xml response back though its succes or failure we dont read it in Bonita side but for JSON we might.
		return respObj;
	}
	
	/**
	 * Method to transform the response.
	 * 
	 * @param String response
	 * @param String requestKey
	 * @return
	 * @throws ApplicationException 
	 */
	private String transformResponse(String response, String requestKey) throws ApplicationException {
		String transformerKey = requestKey + ODSXmlResponseHandler.TRANFORMER_CONFIG_RSP_SCHEMA_SUFFIX;
		OdsTransformerConfig odsTranformerConfig = odsTransformerConfigService.getOdsTransformerConfig(transformerKey);

		response = response.replaceAll("&lt;([^.]*?)&gt;", "<$1>");
		if(odsTranformerConfig != null) {
			return odsTransformerConfigService.doTransform(response, odsTranformerConfig.getTransformerType(),
				odsTranformerConfig.getTransformerSchema());
		} else {
			return response;
		}
	}
	
	/**
	 * @param response
	 * @param transactionIdKey
	 * @return String
	 * @throws ApplicationException
	 */
	public String getTransactionIdFromResponseUsingTransactionIdKey(String response, String transactionIdKey) throws ApplicationException {
		LOGGER.info("Entering getTransactionIdFromResponseUsingTransactionIdKey");
		
		String transactionId;
		
		//Checking Cdata Contains XML Tag, if exists remove that tag
		String finalResponse=serviceUtils.validateXml(response);
		if(transactionIdKey.equalsIgnoreCase(Constants.DEFAULT)) {
			transactionId = serviceUtils.getNodeValueFromXml(finalResponse,
					Constants.TRANSACTION_ID_RSP_KEY);
		} else {
			String[] transactionIdKeyArry = transactionIdKey.split("\\|");
			
			transactionId = "";
			for (String key : transactionIdKeyArry) {
				transactionId += serviceUtils.getNodeValueFromXml(finalResponse, key);
				transactionId += "|";
			}
			transactionId = transactionId.substring(0, transactionId.length()-1);
		}
		
		if (StringUtils.isEmpty(transactionId))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "TransactionId not found in the response");
		
		LOGGER.info("Exiting getTransactionIdFromResponseUsingTransactionIdKey");
		return transactionId;
	}
	
	/**
	 * 
	 * @param respStatus
	 * @param respObj
	 * @return
	 */
	public JSONObject addStatusToResponseObj(ResponseStatus respStatus, JSONObject respObj) {
		JSONObject statusOb =  new JSONObject();
		statusOb.put("code", respStatus.getCode());
		statusOb.put("description", respStatus.getDescription());
		
		respObj.put("status", statusOb);
		return respObj;
	}

	
	/**
	 * Handle exceptions occured during XML Response processing
	 * 
	 * @param originalResponse
	 * @param failureResponseStatus
	 */
	public void handleException(JSONObject originalResponse, ResponseStatus failureResponseStatus, OdsInterfaceRequest odsInterfaceReq) {
		
		LOGGER.info("Entering handleException");
		
		odsResponseHandler.addOrUpdateStatus(originalResponse, failureResponseStatus);
		
		notesService.addNotesForException(odsInterfaceReq, originalResponse.toString(), failureResponseStatus );
		if (odsInterfaceReq != null) {
		
			ResponseConfigParams responseConfigParam;
			try {
				responseConfigParam = (ResponseConfigParams) serviceUtils
						.convertJsonStringToObject(odsInterfaceReq.getResponseConfigParam(), ResponseConfigParams.class);
				if (responseConfigParam != null)
				{
					OdsRequestLog odsRequestLog = odsRequestLogRepository.findByWfTaskId(odsInterfaceReq.getTaskId());
					if (!(Constants.SUCCESS.equals(odsRequestLog.getResponseStatus()))) {
						odsResponseHandler.createFallout(responseConfigParam, failureResponseStatus);
						odsResponseHandler.handleFallout(failureResponseStatus, responseConfigParam, odsRequestLog);
					}
				}
			} catch (Exception e) {
				LOGGER.error("############Exception occured while creating fallout for the exception occurred during XML response processing#################"
						+ "ERROR DESCRIPTION IS:::::", e);
			}
		}
		
		LOGGER.info("Exiting handleException");
	}
	/**
	 * @param xmlResponse
	 * @return JSONObject
	 * @throws ApplicationException
	 */
	public JSONObject doSvcXMLResponseProcessing(String xmlResponse) throws ApplicationException {
		//JSONObject respJsonObj = new JSONObject(xmlResponse); respJsonObj.toString(), respJsonObj.optString(Constants.TRANSACTION_ID)
		// You always get an XML String here along with "transactionId". Extract the transactionId. If not present fail it.
		
		String transactionId  = serviceUtils.getNodeValueFromXml(xmlResponse,Constants.TRANSACTION_ID);
		if (StringUtils.isEmpty(transactionId))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "TransactionId not found in the response");
		return doXMLResponseProcessing(xmlResponse, transactionId);
	}

}
