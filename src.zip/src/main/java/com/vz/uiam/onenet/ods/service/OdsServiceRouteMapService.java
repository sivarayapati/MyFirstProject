package com.vz.uiam.onenet.ods.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.jpa.impl.JPAQuery;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dao.model.QOdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsServiceRouterMapRepository;
import com.vz.uiam.onenet.ods.predicate.ServiceRouteMapSearchPredicate;


/**
 * @author Ashish Goyal
 *
 */
@Service
@Transactional(rollbackOn = { ApplicationException.class, Exception.class, RuntimeException.class })
public class OdsServiceRouteMapService {

	private static final Logger LOGGER = Logger.getLogger(OdsServiceRouteMapService.class);
	
	@Autowired
	OdsServiceRouterMapRepository odsServicRouteMapRepo;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	/**
	 * @param inputServiceRouteMap
	 * @return OdsServiceRouterMapDetails
	 * @throws ApplicationException
	 */
	public OdsServiceRouterMapDetails createOrUpdateServiceRouteMap(OdsServiceRouterMapDetails inputServiceRouteMap) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateServiceRouteMap");
		
		OdsServiceRouterMapDetails existingServiceRouteMap = null;
		
		if (inputServiceRouteMap.getId() != null) {
			existingServiceRouteMap = odsServicRouteMapRepo.findOne(inputServiceRouteMap.getId());
			
			if (existingServiceRouteMap == null)
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Service Route Map record not found for ID - " + inputServiceRouteMap.getId());
		} else if (!StringUtils.isEmpty(inputServiceRouteMap.getAppKey()) &&
						!StringUtils.isEmpty(inputServiceRouteMap.getFlowNodeProcessName()) &&
						!StringUtils.isEmpty(inputServiceRouteMap.getFlowNodeStepName())) {
			existingServiceRouteMap = odsServicRouteMapRepo.findByAppKeyAndFlowNodeProcessNameAndFlowNodeStepName(inputServiceRouteMap.getAppKey(),
							inputServiceRouteMap.getFlowNodeProcessName(), inputServiceRouteMap.getFlowNodeStepName());
		}
		
		if (existingServiceRouteMap == null) {
			doServiceRouteMapValidation(inputServiceRouteMap);
		}
		
		OdsServiceRouterMapDetails newServiceRoueteMap = getUpdatedServiceRouteMapRecord(inputServiceRouteMap, existingServiceRouteMap);
		newServiceRoueteMap = odsServicRouteMapRepo.save(newServiceRoueteMap);
		
		LOGGER.info("Exiting createOrUpdateServiceRouteMap");
		return newServiceRoueteMap;
	}
	
	
	/**
	 * API to retrieve Service Route Map records
	 * 
	 * @param serviceRouteMap
	 * @return
	 * @throws ApplicationException
	 */
	public List<OdsServiceRouterMapDetails> getServiceRouteMapRecords(OdsServiceRouterMapDetails serviceRouteMap) throws ApplicationException {
		LOGGER.info("Entering getServiceRouteMapRecords");
		
		if (StringUtils.isEmpty(serviceRouteMap.getAppKey()) && StringUtils.isEmpty(serviceRouteMap.getFlowNodeProcessName()) &&
																			StringUtils.isEmpty(serviceRouteMap.getFlowNodeStepName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Please provide either appKey or flowNodeProcessName or flowNodeStepName");
		
		List<OdsServiceRouterMapDetails> serviceRouteMapRspList = null;
		QOdsServiceRouterMapDetails odsServiceRouteMap = QOdsServiceRouterMapDetails.odsServiceRouterMapDetails;
		
		ServiceRouteMapSearchPredicate serviceRouteMapSearchPredicate = new ServiceRouteMapSearchPredicate();
		
		JPAQuery query = getJPAQryInstance();
		
		try {
			serviceRouteMapRspList = query.from(odsServiceRouteMap)
					.where(serviceRouteMapSearchPredicate.isAppKeyEqualsIg(serviceRouteMap.getAppKey()),
							serviceRouteMapSearchPredicate.isFlowNodeProcessNameEqualsIg(serviceRouteMap.getFlowNodeProcessName()),
							serviceRouteMapSearchPredicate.isFlowNodeStepNameEqualsIg(serviceRouteMap.getFlowNodeStepName()),
							serviceRouteMapSearchPredicate.isRegionEqualsIg(serviceRouteMap.getRegion()))
							.list(new QOdsServiceRouterMapDetails(odsServiceRouteMap));
		} catch (Exception e) {
			LOGGER.error("Error while getting Service Route Map records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while getting Service Route Map records. " + e.getMessage());
		}
		
		LOGGER.info("Exiting getServiceRouteMapRecords");
		return serviceRouteMapRspList;
	}

	
	/**
	 * API to delete the Service Route Map records
	 * 
	 * @param serviceRouteMapList
	 * @throws ApplicationException
	 */
	public void deleteServiceRouteMapRecord(List<OdsServiceRouterMapDetails> serviceRouteMapList) throws ApplicationException {
		LOGGER.info("Entering deleteServiceRouteMapRecord");
		
		try {
			for (OdsServiceRouterMapDetails odsServiceRouterMapDetails : serviceRouteMapList) {
				if (odsServiceRouterMapDetails.getId() != null) {
					odsServicRouteMapRepo.delete(odsServiceRouterMapDetails.getId());
				} else if (!StringUtils.isEmpty(odsServiceRouterMapDetails.getAppKey()) &&
							!StringUtils.isEmpty(odsServiceRouterMapDetails.getFlowNodeProcessName()) &&
							!StringUtils.isEmpty(odsServiceRouterMapDetails.getFlowNodeStepName())) {
					
					OdsServiceRouterMapDetails existingServiceRouteMap = odsServicRouteMapRepo.findByAppKeyAndFlowNodeProcessNameAndFlowNodeStepName(
							odsServiceRouterMapDetails.getAppKey(), odsServiceRouterMapDetails.getFlowNodeProcessName(), odsServiceRouterMapDetails.getFlowNodeStepName());
					
					if (existingServiceRouteMap != null)
						odsServicRouteMapRepo.delete(existingServiceRouteMap);
					else
						if(!(odsServiceRouterMapDetails.getFlowNodeProcessName().contains(Constants.MILESTONE_CONSTANT) && odsServiceRouterMapDetails.getFlowNodeStepName().contains(Constants.MILESTONE_CONSTANT) ))
						throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Record not found for the given input. appKey[" + odsServiceRouterMapDetails.getAppKey()
								+ "] flowNodeProcessName[" + odsServiceRouterMapDetails.getFlowNodeProcessName() + "] and flowNodeStepName[" + odsServiceRouterMapDetails.getFlowNodeStepName() + "]");
				} else {
					throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Provide either [id] or [flowNodeProcessName and flowNodeStepName]");
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error while deleting Service Route Map records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while deleting Service Route Map records. " + e.getMessage());
		}
		
		LOGGER.info("Exiting deleteServiceRouteMapRecord");
	}
	
	/**
	 * API to update the input record with the exiting one 
	 * 
	 * @param inputServiceRouteMap
	 * @param existingServiceRouteMap
	 * @return
	 * @throws ApplicationException 
	 */
	public OdsServiceRouterMapDetails getUpdatedServiceRouteMapRecord(OdsServiceRouterMapDetails inputServiceRouteMap,
												OdsServiceRouterMapDetails existingServiceRouteMap) throws ApplicationException {
		LOGGER.info("Entering getUpdatedServiceRouteMapRecord");
		
		if (existingServiceRouteMap == null)
			return inputServiceRouteMap;
		
		if (!StringUtils.isEmpty(inputServiceRouteMap.getAppKey()))
			existingServiceRouteMap.setAppKey(inputServiceRouteMap.getAppKey());
		
		if (!StringUtils.isEmpty(inputServiceRouteMap.getFlowNodeProcessName()))
			existingServiceRouteMap.setFlowNodeProcessName(inputServiceRouteMap.getFlowNodeProcessName());
		
		if (!StringUtils.isEmpty(inputServiceRouteMap.getFlowNodeStepName()))
			existingServiceRouteMap.setFlowNodeStepName(inputServiceRouteMap.getFlowNodeStepName());
		
		if (!StringUtils.isEmpty(inputServiceRouteMap.getTargetEndPointUrl()))
			existingServiceRouteMap.setTargetEndPointUrl(inputServiceRouteMap.getTargetEndPointUrl());
		
		if (!StringUtils.isEmpty(inputServiceRouteMap.getRouterProtocol()))
			existingServiceRouteMap.setRouterProtocol(inputServiceRouteMap.getRouterProtocol());
		
		existingServiceRouteMap.setRequestDocumentName(inputServiceRouteMap.getRequestDocumentName());		
		existingServiceRouteMap.setRequestSchema(inputServiceRouteMap.getRequestSchema());
		existingServiceRouteMap.setResponseDocumentName(inputServiceRouteMap.getResponseDocumentName());
		existingServiceRouteMap.setTransformationType(inputServiceRouteMap.getTransformationType());
		existingServiceRouteMap.setUserName(inputServiceRouteMap.getUserName());
		existingServiceRouteMap.setPassword(inputServiceRouteMap.getPassword());
		if (!StringUtils.isEmpty(inputServiceRouteMap.getSendMilestoneFlag()))
			existingServiceRouteMap.setSendMilestoneFlag(inputServiceRouteMap.getSendMilestoneFlag().toUpperCase());
		else
			existingServiceRouteMap.setSendMilestoneFlag("NO");
		existingServiceRouteMap.setReplyToQueueName(inputServiceRouteMap.getReplyToQueueName());
		existingServiceRouteMap.setRequestMethod(inputServiceRouteMap.getRequestMethod());
		
		LOGGER.info("Exiting getUpdatedServiceRouteMapRecord");
		return existingServiceRouteMap;
	}
	
	/**
	 * API to do validation on input ServiceRouteMap record
	 * 
	 * @param inputServiceRouteMap
	 * @throws ApplicationException
	 */
	public void doServiceRouteMapValidation(OdsServiceRouterMapDetails inputServiceRouteMap) throws ApplicationException {
		LOGGER.info("Entering doServiceRouteMapValidation");
		
		if (StringUtils.isEmpty(inputServiceRouteMap.getAppKey()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "appKey is null or empty");
		if (StringUtils.isEmpty(inputServiceRouteMap.getFlowNodeProcessName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "flowNodeProcessName is null or empty");
		if (StringUtils.isEmpty(inputServiceRouteMap.getFlowNodeStepName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "flowNodeStepName is null or empty");
		
		if (!StringUtils.isEmpty(inputServiceRouteMap.getTargetEndPointUrl()) &&
				!StringUtils.isEmpty(inputServiceRouteMap.getRouterProtocol())){
			
		if (StringUtils.isEmpty(inputServiceRouteMap.getTargetEndPointUrl()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "targetEndPointUrl is null or empty");
		if (StringUtils.isEmpty(inputServiceRouteMap.getRouterProtocol()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "routerProtocol is null or empty");
		
		String sendMilestone = inputServiceRouteMap.getSendMilestoneFlag();
		if (StringUtils.isNotEmpty(sendMilestone) && !"YES".equalsIgnoreCase(sendMilestone) && !"NO".equalsIgnoreCase(sendMilestone)) {
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "sendMilestoneFlag value should be either [YES or NO]");
		} else if (StringUtils.isEmpty(sendMilestone))
			inputServiceRouteMap.setSendMilestoneFlag("NO");
		}
    	LOGGER.info("Exiting doServiceRouteMapValidation");
	}
	
	
	/**
	 * @param processName
	 * @param stepName
	 * @param region
	 * @return OdsServiceRouterMapDetails
	 * @throws ApplicationException
	 */	
	public OdsServiceRouterMapDetails getServiceRouterMapDetails(String processName, String stepName, String region)
			throws ApplicationException {
		LOGGER.info("Entering getServiceRouterMapDetails");
		OdsServiceRouterMapDetails details =null;
		
		if(StringUtils.isEmpty(region)) {
			LOGGER.info("CacheKey :"+processName+"|"+stepName);
			details = odsServicRouteMapRepo.findByFlowNodeProcessNameAndFlowNodeStepName(processName, stepName);
		}			
		else {
			LOGGER.info("CacheKey :"+processName+"|"+stepName+"|"+region);
			details = odsServicRouteMapRepo.findByFlowNodeProcessNameAndFlowNodeStepNameAndRegion(processName, stepName, region);
		}
			
		if (null == details) {
			LOGGER.error("ODS Service router configuration not found");
			throw new ApplicationException(StatusCode.ERROR_ODS_ROUTER_MAP_CONFIG_NOTCONFIGURED.getCode(),
					StatusCode.ERROR_ODS_ROUTER_MAP_CONFIG_NOTCONFIGURED.getDesc());
		}
		LOGGER.info("Exiting getServiceRouterMapDetails");
		return details;
	}
	
	public JPAQuery getJPAQryInstance() {
		return new JPAQuery(entityManager);
	}
}
