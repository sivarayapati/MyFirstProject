package com.vz.uiam.onenet.util.constants;

public interface Constants {

	/**
	 * Constant holds Jersey Client Utility Keys
	 */
	String JERSEY_CLIENT_REQ_PAYLOAD_KEY = "payload";
	
	/**
	 * Constant holds Jersey Client Utility Keys
	 */
	String JERSEY_CLIENT_ENDPOINT_URL_KEY = "endpointUrl";
	
	/**
	 * Constant holds Jersey Client Utility Keys
	 */
	String JERSEY_CLIENT_CONTENT_TYPE_KEY = "contentType";
	
	/**
	 * Constant holds Jersey Client Utility Keys
	 */
	String JERSEY_CLIENT_REQ_METHOD_KEY ="requestMethod";
	
	/**
	 * Constant holds Jersey Client Utility Keys
	 */
	String JERSEY_CLIENT_ACCEPT_KEY ="accept";
	
	/**
	 * Constant holds Jersey Client Utility Keys
	 */
	String JERSEY_CLIENT_QUERY_PARAM_KEY ="queryParams";
	
	/**
	 * Constant holds Jersey Client Request Method Type
	 */
	String JERSEY_CLIENT_REQ_METHOD_POST = "POST";
	
	/**
	 * Constant holds Jersey Client Request Method Type
	 */
	String APPLICATION_JSON = "application/json";
}