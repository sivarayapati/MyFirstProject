package com.vz.uiam.onenet.ods.config;

import static com.google.common.base.Predicates.or;
import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.google.common.base.Predicate;

import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@ComponentScan(basePackages = {"com.vz.uiam.onenet.ods","com.vz.uiam.onenet.util"})
public class SwaggerConfig {
    @Bean
    public Docket restfulApi() {
	return new Docket(DocumentationType.SWAGGER_2).groupName("one-dispatcher-api").select().paths(paths()).build()
		.apiInfo(apiInfo());
    }

    private Predicate<String> paths() {
    	return or(regex("/oneDispatcher/.*"),
    						regex("/manifest/.*"),
    						regex("/oneDispatcher/fallout/.*"),
    						regex("/oneDispatcher/serviceRouteMap/.*"),
    						regex("/oneDispatcher/odsParamConfig/.*"),
    						regex("/oneDispatcher/odsMandatoryAttrs/.*"),
    						regex("/oneDispatcher/odsMilestoneConfig/.*"),
    						regex("/oneDispatcher/odsConfig/.*"),
    						regex("/sla/.*"),
    						regex("/restClient/.*"));
    }

    private ApiInfo apiInfo() {
	return new ApiInfo("OneDispatcher", "OneDispatcher service details ", "1.0",
		"https://oneconfluence.verizon.com/display/NGPON/One-Dispather+Architecture", "ODS", "Confluence",
		"https://oneconfluence.verizon.com/display/NGPON/One-Dispather+Architecture");

    }
}