package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;


@Entity
@Table(name = "ods_param_config")
public class OdsParamConfig implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "param_id")
	private Integer paramId;

	@Column(name = "param_key")
	private String paramKey;

	@Column(name = "type")
	private String type;

	@Column(name = "name")
	private String name;

	@Column(name = "value")
	private String value;

	
	public Integer getParamId() {
		return paramId;
	}

	public void setParamId(Integer paramId) {
		this.paramId = paramId;
	}

	public String getParamKey() {
		return paramKey;
	}

	public void setParamKey(String paramKey) {
		this.paramKey = paramKey;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	
	public OdsParamConfig() {
		super();
	}

	public OdsParamConfig(String paramKey) {
		super();
		this.paramKey = paramKey;
	}
	

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
