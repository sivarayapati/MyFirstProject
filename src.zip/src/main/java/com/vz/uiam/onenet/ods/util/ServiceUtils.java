package com.vz.uiam.onenet.ods.util;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.JsonPath;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.Param;
import com.vz.uiam.onenet.ods.jpa.dto.model.QueryParam;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformationResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformedResponsePayload;
import com.vz.uiam.onenet.ods.service.OdsParamConfigService;

/**
 * This class provides helper functionalities for VPS Interfaces Utils.
 * 
 * @author Anand Badiger
 *
 */
@Component
public class ServiceUtils {

	private static final Logger LOGGER = Logger.getLogger(ServiceUtils.class);
	
	@Autowired
	OdsParamConfigRepository odsParamConfigRepository;
	
	@Autowired
	OdsParamConfigService odsParamConfigService;
	
	@Autowired
	RestTemplate restTemplate;

	/**
	 * Method returns the Transformation response generated after transformation
	 * done using request schema defined in the one dispatcher related tables
	 * @param statusCode
	 * @param statusMsg
	 * @param response
	 * @param transformedDocument
	 * @return
	 */
	public TransformationResponse handleTransformationResponse(String statusCode, String statusMsg,
			TransformationResponse response, String transformedDocument) {
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(statusCode);
		responseStatus.setDescription(statusMsg);
		response.setStatus(responseStatus);
		response.setResponsePayload(transformedDocument);
		return response;
	}
	
	/**
	 * Method returns the Transformation response generated after transformation
	 * done using request schema defined in the one dispatcher related tables
	 * 
	 * @param statusCode
	 * @param statusMsg
	 * @param transformedDoc
	 * @return TransformationResponse
	 */
	public OdsResponse handleOdsResponse(String statusCode, String statusMsg,
			OdsResponse resp) {
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode(statusCode);
		responseStatus.setDescription(statusMsg);
		resp.setStatus(responseStatus);
		return resp;
	}

	/**
	 * @param jsonSchema
	 * @param actualJson
	 * @param outputJsonObject
	 * @throws ApplicationException 
	 */
	public  void populateJsonPayload(String jsonSchemaStr, String actualJson, JSONObject outputJsonObject) throws ApplicationException {
		LOGGER.info("Entering populateJsonPayload");
		LOGGER.info("SCHEMA FOR TRANSFER IS:::"+jsonSchemaStr);
		LOGGER.info("ACTUAL JSON DOCUMENT IS:::"+actualJson);
		String schemaKey;
		JSONObject jsonSchemObj;
		jsonSchemObj = new JSONObject(jsonSchemaStr);
		Iterator<String> schemaKeys = jsonSchemObj.keys();
		
		// Iterating through top most object loop
		while (schemaKeys.hasNext()) {
			schemaKey = schemaKeys.next();
			Object obj = jsonSchemObj.get(schemaKey);
			if (obj instanceof String) {
				// If the value is being string then replace $ with proper value
				// from actual Json
				populateValues(schemaKey, (String) obj, actualJson, outputJsonObject);
			} else if (obj instanceof JSONArray) {
				// If the Json Value is object of JSON Array then handle the
				// Json Array
				handleJsonArray(outputJsonObject, schemaKey,obj,
						actualJson);
			} else if (obj instanceof JSONObject) {
				// If the value is JSONObject then handle complex Json Object
				JSONObject subJsonObj = new JSONObject();
				outputJsonObject.put(schemaKey, subJsonObj);
				populateJsonPayload(obj.toString(), actualJson, subJsonObj);
			}else{
				outputJsonObject.put(schemaKey, obj);
			}
		}
		
		LOGGER.info("Exiting populateJsonPayload");
	}

	
	/**
	 * 
	 * @param outputJsonObject
	 * @param schemaKey
	 * @param obj
	 * @param jsonString
	 * @throws ApplicationException
	 */
	private void handleJsonArray(JSONObject outputJsonObject, String schemaKey,
			Object obj, String jsonString) throws ApplicationException {
		LOGGER.info("Entering handleJsonArray");
		JSONArray arrayObj = (JSONArray) obj;
		JSONArray outputJsonArray = new JSONArray();
		for (int i = 0; i < arrayObj.length(); i++) {
			JSONObject eachObjInArray = arrayObj.getJSONObject(i);
			Iterator<String> keys = eachObjInArray.keys();
			JSONObject innerJsonObj = new JSONObject();
			while (keys.hasNext()) {
				Object key = keys.next();
				Object innerObj = eachObjInArray.get((String) key);
				// Here Array can have multiple complex elements
				if (innerObj instanceof JSONObject) {
					// Need to handle when an Array has complex Json Structure
					JSONObject subJsonObj = new JSONObject();
					outputJsonObject.put(schemaKey, subJsonObj);
					populateJsonPayload(innerObj.toString(), jsonString, subJsonObj);
					innerJsonObj.put((String) key, subJsonObj);
				}else if (innerObj instanceof JSONArray) {
					handleJsonArray(innerJsonObj,String.valueOf(key),innerObj,jsonString);
				}else {
					populateValues((String) key, innerObj, jsonString, innerJsonObj);
				}
			}
			outputJsonArray.put(innerJsonObj);
		}
		outputJsonObject.put(schemaKey, outputJsonArray);
		LOGGER.info("Exiting handleJsonArray");
	}

	/**
	 * @param schemaKey
	 * @param schemaVal
	 * @param requestJsonStr
	 * @param outputJsonObject
	 * @throws ApplicationException 
	 */
	public void populateValues(String schemaKey, Object schemaVal, String requestJsonStr,
											JSONObject outputJsonObject) throws ApplicationException {
		LOGGER.info("Entering populateValues");
		if(schemaVal instanceof String ){
			String schemaValStr = (String) schemaVal;
			if (schemaValStr.contains("fn-transformXML")) {
				String finalValue = handleXMLTransform(schemaValStr, requestJsonStr);
				outputJsonObject.put(schemaKey, finalValue);
			} else if (schemaValStr.contains("fn-concat")) {
				String finalValue = handleJsonConcat(schemaValStr, requestJsonStr);
				outputJsonObject.put(schemaKey, finalValue);
			}  else if (schemaValStr.contains("fn-substring-before")) {
				String finalValue = handleJsonSubStringBefore(schemaValStr, requestJsonStr);
				outputJsonObject.put(schemaKey, finalValue);
			} else if (schemaValStr.contains("fn-substring-after")) {
				String finalValue = handleJsonSubStringAfter(schemaValStr, requestJsonStr);
				outputJsonObject.put(schemaKey, finalValue);
			} else if (schemaValStr.contains("fn-substring")) {
				String finalValue = handleJsonSubString(schemaValStr, requestJsonStr);
				outputJsonObject.put(schemaKey, finalValue);
			}  else if (schemaValStr.contains("fn-formatdate")) {
				String finalValue = handleJsonFormatDate(schemaValStr, requestJsonStr);
				outputJsonObject.put(schemaKey, finalValue);
			} else if (schemaValStr.contains("fn-sysdate-epoch")) {
				String finalValue = handleJsonSysDateEpoch();
				outputJsonObject.put(schemaKey, finalValue);
			} else if (schemaValStr.contains("fn-date-epoch")) {
				String finalValue = handleJsonDateEpoch(schemaValStr);
				outputJsonObject.put(schemaKey, finalValue);
			} else if (schemaValStr.contains("fn-sysdate")) {
				String finalValue = handleJsonSysDate(schemaValStr);
				outputJsonObject.put(schemaKey, finalValue);
			} else if (schemaValStr.contains("$")) {
				outputJsonObject.put(schemaKey, getJsonSchemaValue(schemaValStr, requestJsonStr));
			} else{
				outputJsonObject.put(schemaKey, schemaValStr);
			}
		} else {
			outputJsonObject.put(schemaKey, schemaVal);
		}
		
		LOGGER.info("Final translated value: " + outputJsonObject);
		LOGGER.info("Exiting populateValues");
	}
	
	
	/**
	 * 
	 * @param xmlSchema
	 * @param reqJson
	 * @return
	 * @throws ApplicationException
	 */
	private String handleXMLTransform(String xmlSchema, String reqJsonStr) throws ApplicationException {
		LOGGER.info("Entering handleXMLTransform");
		
		String newXmlSchema = xmlSchema.substring(xmlSchema.indexOf("(") + 1, xmlSchema.length() - 1);
		JSONObject reqJsonObj = new JSONObject(reqJsonStr);
		
		String appKey = reqJsonObj.getJSONObject(Constants.REQUEST_PAYLOAD).getString(Constants.MANIFEST_APP_KEY_STR);
		updateRequestJsonObjectWithAppParams(appKey, reqJsonObj, xmlSchema, Constants.TRANSFORMATION_XML_TYPE);
		
		String className = getTransformerClass(Constants.TRANSFROMER_CLASS_KEY_PREFIX + Constants.TRANSFORMATION_XML_TYPE);
		com.vz.uiam.onenet.ods.transformer.Transformer transformer = getTransformerInstance(className);

		String transformedDoc = (String) transformer.doTransform(reqJsonObj, newXmlSchema);
		
		LOGGER.info("Exiting handleXMLTransform");
		return transformedDoc;
	}

	/**
	 * @param schemaVal
	 * @return
	 */
	private String handleJsonSysDate(String schemaVal) {
		LOGGER.info("Entering handleJsonSysDate");
		String systemDate = "";
		try {
			String newSchemaVal = schemaVal.substring(schemaVal.indexOf("(") + 1, schemaVal.length() - 1);
			String[] tokens = newSchemaVal.split("\\,");
			DateFormat formatter = null;
			if (tokens.length == 0) {
				formatter = new SimpleDateFormat("MM-DD-YYYY");
			} else if (tokens.length == 1) {
				formatter = new SimpleDateFormat(tokens[0].trim());
			}
			if (tokens.length == 2) {
				formatter = new SimpleDateFormat(tokens[0].trim());
				formatter.setTimeZone(TimeZone.getTimeZone(tokens[1].trim()));
			}
			Date sysDate = Calendar.getInstance().getTime();
			if (formatter != null)
				systemDate = formatter.format(sysDate);
		} catch (Exception e) {
			LOGGER.error("Exception while executing fn-sysdate. Returning blank date."+e);
		}

		LOGGER.info("Exiting handleJsonSysDate with " + systemDate);
		return systemDate;
	}
	
	/**
	 * @param schemaVal
	 * @return
	 */
	private String handleJsonFormatDate(String schemaVal, String requestJsonStr) {
		LOGGER.info("Entering handleJsonFormatDate");

		String formattedDate = "";
		try {
			String newSchemaVal = schemaVal.substring(schemaVal.indexOf("(") + 1, schemaVal.length() - 1);
			String[] tokens = newSchemaVal.split("\\,");
	
			DateFormat df = new SimpleDateFormat(tokens[2].trim());
			if (tokens.length == 4) {
				df.setTimeZone(TimeZone.getTimeZone(tokens[3].trim()));
			}
			formattedDate = df.format(
					new SimpleDateFormat(tokens[1].trim()).parse((String)getJsonSchemaValue(tokens[0].trim(), requestJsonStr)));
		} catch (ParseException e) {
			LOGGER.info("Exception while formating the date. Returning blank date.");
		}
		LOGGER.info("Exiting handleJsonFormatDate with " + formattedDate);
		return formattedDate;
	}

	/**
	 * @param schemaVal
	 * @return
	 */
	private String handleJsonSysDateEpoch() {
		LOGGER.info("Entering handleJsonSysDateEpoch");
		
		long epochTime = Instant.now().toEpochMilli();

		LOGGER.info("Exiting handleJsonSysDateEpoch with " + epochTime);
		return Long.toString(epochTime);
	}
	
	/**
	 * @param schemaVal
	 * @return
	 */
	private String handleJsonDateEpoch(String schemaVal) {
		LOGGER.info("Entering handleJsonDateEpoch");
		Long epochInMillis = 0L;
		try {
			String newSchemaVal = schemaVal.substring(schemaVal.indexOf("(") + 1, schemaVal.length() - 1);
			String[] tokens = newSchemaVal.split("\\,");
		
			epochInMillis = new SimpleDateFormat(tokens[0].trim()).parse(tokens[1].trim()).getTime();
		} catch (ParseException e) {
			LOGGER.error("Exception while converting date to epoch. Returning zero value.");
		}
		
		LOGGER.info("Exiting handleJsonDateEpoch with " + epochInMillis);
		return Long.toString(epochInMillis);
	}

	/**
	 * @param schemaVal
	 * @param requestJsonStr
	 * @return
	 */
	private String handleJsonSubString(String schemaVal, String requestJsonStr) {
		LOGGER.info("Entering handleJsonSubString");
		String newSchemaVal = schemaVal.substring(schemaVal.indexOf("(") + 1, schemaVal.length() - 1);
		String[] s = newSchemaVal.split("\\,");
		String finalValue = "";
		if (s.length == 1) {
			LOGGER.info("Insufficient parameters to the fn-substring method. Returning blank string");
			return finalValue;
		}

		String valFromSchema = (String)getJsonSchemaValue(s[0].trim(), requestJsonStr);
		if (s.length == 2) {
			finalValue = valFromSchema.substring(Integer.parseInt(s[1].trim()));
		} else if (s.length == 3) {
			finalValue = valFromSchema.substring(Integer.parseInt(s[1].trim()), Integer.parseInt(s[2].trim()));
		}
		LOGGER.info("Exiting handleJsonSubString with " + finalValue);
		return finalValue;
	}
	
	/**
	 * @param schemaVal
	 * @param requestJsonStr
	 * @return
	 */
	private String handleJsonSubStringBefore(String schemaVal, String requestJsonStr) {
		LOGGER.info("Entering handleJsonSubStringBefore");
		String newSchemaVal = schemaVal.substring(schemaVal.indexOf("(") + 1, schemaVal.length() - 1);
		String[] s = newSchemaVal.split("\\,");
		String finalValue = "";
		if (s.length == 1) {
			LOGGER.info("Insufficient parameters to the fn-substring-before method. Returning blank string");
			return finalValue;
		}

		String valFromSchema = (String)getJsonSchemaValue(s[0].trim(), requestJsonStr);
		if (s.length == 2) {
			String delimiter = StringUtils.substringBetween(s[1], "'");
			LOGGER.info("delimiter: " + delimiter);
			finalValue = StringUtils.substringBefore(valFromSchema, delimiter);
		}
		LOGGER.info("Exiting handleJsonSubStringBefore with " + finalValue);
		return finalValue;
	}
	/**
	 * @param schemaVal
	 * @param requestJsonStr
	 * @return
	 */
	private String handleJsonSubStringAfter(String schemaVal, String requestJsonStr) {
		LOGGER.info("Entering handleJsonSubStringAfter");
		String newSchemaVal = schemaVal.substring(schemaVal.indexOf("(") + 1, schemaVal.length() - 1);
		String[] s = newSchemaVal.split("\\,");
		String finalValue = "";
		if (s.length == 1) {
			LOGGER.info("Insufficient parameters to the fn-substring-after method. Returning blank string");
			return finalValue;
		}

		String valFromSchema = (String)getJsonSchemaValue(s[0].trim(), requestJsonStr);
		if (s.length == 2) {
			String delimiter = StringUtils.substringBetween(s[1], "'");
			LOGGER.info("delimiter: " + delimiter);
			finalValue = StringUtils.substringAfter(valFromSchema, delimiter);
		}
		LOGGER.info("Exiting handleJsonSubStringAfter with " + finalValue);
		return finalValue;
	}

	/**
	 * @param schemaKey
	 * @param schemaVal
	 * @param requestJsonStr
	 * @return
	 */
	private String handleJsonConcat(String schemaVal, String requestJsonStr) {
		LOGGER.info("Entering handleJsonConcat");
		String[] parts = schemaVal.split("[\\(\\)]");
		for (String part : parts) {
			LOGGER.info(part);
		}
		String delimiter=StringUtils.substringBeforeLast(StringUtils.substringAfter(parts[1], "'<"),">'");
		LOGGER.info("delimiter: " + delimiter);
		
		if(delimiter==null) {
			LOGGER.info("Delimiter is null, returning emtpy string");
			return "";
		}
		
		
		String newSchemaVal = schemaVal.substring(schemaVal.indexOf("(") + 1, schemaVal.length() - 1);
		newSchemaVal = StringUtils.substringAfterLast(newSchemaVal, ">'");
		String[] s = newSchemaVal.split("\\,");
		StringBuilder finalValue = new StringBuilder();
		for (int i = 1; i < s.length; i++) {
			String valFrmSchema=(String)getJsonSchemaValue(s[i].trim(), requestJsonStr);
			if (i < s.length - 1) {
				if(!StringUtils.isEmpty(valFrmSchema))
					finalValue.append(valFrmSchema.concat(delimiter));
			} else {
				if(!StringUtils.isEmpty(valFrmSchema))
					finalValue.append(valFrmSchema);
			}
		}
		
		LOGGER.info("Exiting handleJsonConcat");
		return finalValue.toString();
	}

	/**
	 * 
	 * @param schemaVal
	 * @param requestJsonStr
	 * @return
	 */
	public Object getJsonSchemaValue(String schemaVal, String requestJsonStr) {		
		if(schemaVal != null && schemaVal.startsWith("$.")) {
			String[] schemaValTokens = schemaVal.split("\\.(?![^\\[\\]]*\\])");		
			return evaluateSchemaValTokens(schemaValTokens, new JSONObject(requestJsonStr));
		} else {
			return schemaVal;
		}
	}
	
	private Object evaluateSchemaValTokens(String[] schemaValueTokens, JSONObject requestJSONObject) {
		String orginalRequestJSONObject = requestJSONObject.toString();

		for (int i = 0; i < schemaValueTokens.length; i++) {
			if ("$".equals(schemaValueTokens[i].trim())) {
				continue;
			}
			JSONArray jsonArray = null;
			if (isSchemaValueTokenAnArray(schemaValueTokens[i].trim())) {
				Object schemaValueTokenObject;
				try {
					schemaValueTokenObject = requestJSONObject
							.get(schemaValueTokens[i].trim().substring(0, schemaValueTokens[i].trim().indexOf("[")));
				} catch (JSONException e) {
					LOGGER.error("JSONException while getting "
							+ schemaValueTokens[i].trim().substring(0, schemaValueTokens[i].trim().indexOf("["))
							+ ". Defaulting to empty string. " + e);
					return "";
				}
				if (schemaValueTokenObject instanceof JSONArray) {
					LOGGER.info("JSONArray found.");
					jsonArray = (JSONArray) schemaValueTokenObject;
					String arrayKey = retrieveSchemaValueArrayKey(schemaValueTokens[i].trim());
					if (StringUtils.isNumeric(arrayKey)) {
						int index = Integer.parseInt(arrayKey);
						if (index > (jsonArray.length() - 1)) {
							LOGGER.info("Array index is out of bounds " + index);
							return "";
						}
						requestJSONObject = jsonArray.getJSONObject(index);
					} else {
						String[] tokens = arrayKey.split("\\=");
						String schemaKeyValue = null;
						if (tokens[1].trim().startsWith("$")) {
							try {
								schemaKeyValue = readValueFromJson(orginalRequestJSONObject, tokens[1].trim());
							} catch (ApplicationException ae) {
								LOGGER.info("Exception while reading schema " + tokens[1].trim()+"::::"+ ae);
								return "";
							}
						} else {
							schemaKeyValue = tokens[1].trim().substring(1, tokens[1].trim().length() - 1);
						}
						for (int j = 0; j < jsonArray.length(); j++) {
							JSONObject eachObjInArray = jsonArray.getJSONObject(j);
							String keyValue = String.valueOf(eachObjInArray.get(tokens[0].trim()));
							if (keyValue.equals(schemaKeyValue)) {
								requestJSONObject = eachObjInArray;
								break;
							}
						}
					}
				} else if (schemaValueTokenObject instanceof JSONObject) {
					LOGGER.info("Only one JSONObject present instead of JSONArray.");
					requestJSONObject = (JSONObject) schemaValueTokenObject;
				}
			} else {
				Object obj = null;
				try {
					obj = requestJSONObject.get(schemaValueTokens[i].trim());
				} catch (JSONException jsonex) {
					LOGGER.error("JSONException while getting " + schemaValueTokens[i].trim()
							+ ". Defaulting to empty string. " + jsonex);
					return "";
				}
				if (obj != null) {
					if (obj instanceof JSONObject) {
						requestJSONObject = (JSONObject) obj;
					} else if (obj instanceof JSONArray) {
						return obj;
					} else {
						return String.valueOf(obj);
					}
				}
			}
		}
		return requestJSONObject;
	}
	
	private boolean isSchemaValueTokenAnArray(String schemaTokenValue) {
		Pattern p = Pattern.compile("\\[(.*?)\\]");
		Matcher m = p.matcher(schemaTokenValue);

		while(m.find()) {
			return true;
		}
		return false;
	}
	
	private String retrieveSchemaValueArrayKey(String schemaTokenValue) {
		Pattern p = Pattern.compile("\\[(.*?)\\]");
		Matcher m = p.matcher(schemaTokenValue);

		while(m.find()) {
			return m.group(1);
		}
		return null;
	}

	
	/**
	 * API to get the Transformer class from APP PARAM table
	 * 
	 * @param key
	 * @return
	 * @throws ApplicationException
	 */
	public String getTransformerClass(String name) throws ApplicationException {
		LOGGER.info("Entering getTransformerClass");

		OdsParamConfig odsAppParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), name);
		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), prepareOdsParamErrorMsg(
					OdsParamConfigType.ODS.toString(), OdsParamConfigType.ODS_PARAM.toString(), name, null));
		LOGGER.info("Transformer class for [ " + name + " ] is " + odsAppParam.getValue());

		LOGGER.info("Exiting getTransformerClass");
		return odsAppParam.getValue();
	}
	
	/**
	 * API to add Application Params in the request JSON Object, if any
	 * 
	 * @param reqJsonDoc
	 * @param requestSchema
	 * @param transFormationType
	 * @throws ApplicationException
	 */
	public void updateRequestJsonObjectWithAppParams(String key, JSONObject reqJsonDoc, String requestSchema,
										String transFormationType) throws ApplicationException {
		LOGGER.info("Entering updateRequestJsonObjectWithAppParams");

		StringBuilder searchParam = new StringBuilder();
		String[] appParamKeys;
		if (Constants.TRANSFORMATION_XML_TYPE.equalsIgnoreCase(transFormationType)) {
			searchParam.append("\"").append(Constants.APP_PARAM_KEY).append("/");
			appParamKeys = StringUtils.substringsBetween(requestSchema, searchParam.toString(), "\"");
		} else if (Constants.TRANSFORMATION_JSON_TYPE.equalsIgnoreCase(transFormationType)) {
			searchParam.append("$.").append(Constants.APP_PARAM_KEY).append(".");
			JSONObject obj = new JSONObject(requestSchema);
			appParamKeys = StringUtils.substringsBetween(obj.toString(),
					searchParam.toString(), "\"");
		} else {
			LOGGER.error("Invalid Transformation Type.");
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "Invalid Transformation Type.");
		}

		if (appParamKeys == null || appParamKeys.length <= 0) {
			LOGGER.info("No Application Param Keys found in the request schema.");
			return;
		}

		List<OdsParamConfig> odsAppParamList = odsParamConfigService.getOdsParamConfigByParamKeyAndTypeAndNameIn(key,
				OdsParamConfigType.APPLICATION_PARAM.toString(), Arrays.asList(appParamKeys));
		if (CollectionUtils.isEmpty(odsAppParamList) || appParamKeys.length > odsAppParamList.size()) {
			LOGGER.error("Data Not Found");
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), prepareOdsParamErrorMsg(key,
					OdsParamConfigType.APPLICATION_PARAM.toString(), null, Arrays.asList(appParamKeys)));
		}

		Map<String, String> appParamJsonMap = new HashMap<>();
		for (OdsParamConfig appParam : odsAppParamList) {
			appParamJsonMap.put(appParam.getName(), appParam.getValue());
		} /* end for */

		reqJsonDoc.put(Constants.APP_PARAM_KEY, appParamJsonMap);

		LOGGER.info("Exiting updateRequestJsonObjectWithAppParams");
	}
	
	/**
	 * API to add Schema Defined Params in the request JSON Object, if any
	 * 
	 * @param reqJsonDoc
	 * @param requestSchema
	 * @param transFormationType
	 * @throws ApplicationException
	 */
	public void updateRequestJsonObjectWithSchemaDefinedParams(JSONObject reqJsonDoc, TransformRequest transformRequest)
			throws ApplicationException {
		LOGGER.info("Entering updateRequestJsonObjectWithSchemaDefinedParams");
		if (Constants.TRANSFORMATION_JSON_TYPE.equalsIgnoreCase(transformRequest.getTransformationType())) {
			if (!transformRequest.getRequestSchema().contains(Constants.SCHEMA_DEFINED_LITERAL_KEY)) {
				LOGGER.info("No Schema Defined Param Keys found in the request schema.");
				return;
			}
			String rawDefinitionsRows[] = transformRequest.getRequestSchema()
					.split(Constants.SCHEMA_DEFINED_LITERAL_KEY);
			for (int i = 0; i < rawDefinitionsRows.length; i++) {
				String rawDefnRow = rawDefinitionsRows[i];
				String rawDefnParamName = StringUtils.substringBefore(rawDefnRow,
						Constants.SCHEMA_DEFINITIONS_ASSIGNMENT_DELIMITER);

				if (StringUtils.isNotEmpty(rawDefnParamName)) {
					rawDefnParamName = rawDefnParamName.trim();
					String rawDefnParamSchema = StringUtils.substringBetween(rawDefnRow,
							Constants.SCHEMA_DEFINITIONS_ASSIGNMENT_DELIMITER, Constants.SCHEMA_DEFINITIONS_DELIMITER);
					if (StringUtils.isNotEmpty(rawDefnParamSchema)) {
						rawDefnParamSchema = rawDefnParamSchema.trim();
						JSONObject obj = new JSONObject();
						String schemaDefnJsonStr = "{" + rawDefnParamName + ":" + rawDefnParamSchema + "}";
						populateJsonPayload(schemaDefnJsonStr, reqJsonDoc.toString(), obj);
						if (reqJsonDoc.has(Constants.SCHEMA_DEFINED_PARAM_KEY)) {
							((JSONObject) reqJsonDoc.get(Constants.SCHEMA_DEFINED_PARAM_KEY)).put(rawDefnParamName,
									obj.optString(rawDefnParamName));
						} else
							reqJsonDoc.put(Constants.SCHEMA_DEFINED_PARAM_KEY, obj);
					}
				}
			}
			String requestSchamaBySemiColan[] = transformRequest.getRequestSchema().split(";");
			String cleanRequestSchema = requestSchamaBySemiColan[requestSchamaBySemiColan.length - 1];
			LOGGER.info("Updated Input Document : " + reqJsonDoc);
			LOGGER.info("Request Schema after removing definitions : " + cleanRequestSchema);
			if (cleanRequestSchema != null && StringUtils.isNotEmpty(cleanRequestSchema))
				transformRequest.setRequestSchema(cleanRequestSchema);
			LOGGER.info("Exiting updateRequestJsonObjectWithSchemaDefinedParams");
		}
	}

	/**
	 * API to get Schema Defined Params and Schema
	 * 
	 * @param requestSchema
	 * @param reqJsonDoc
	 * @throws ApplicationException
	 */
	public void updateRequestJsonObjectWithConditionalDefinitions(JSONObject reqJsonDoc,
			TransformRequest transformRequest) throws ApplicationException {
		LOGGER.info("Entering updateRequestJsonObjectWithConditionalDefinitions");
		if (Constants.TRANSFORMATION_JSON_TYPE.equalsIgnoreCase(transformRequest.getTransformationType())) {

			if (!transformRequest.getRequestSchema().contains(Constants.SCHEMA_CONDITIONAL_DEFINED_LITERAL_KEY)) {
				LOGGER.info("No Coditional Schema Defined Param Keys found in the request schema.");
				return;
			}
			String schema = "";
			String schemaDefinition = "";
			/* split with #endif */
			String conditionalRows = StringUtils.substringBefore(transformRequest.getRequestSchema(),
					Constants.SCHEMA_END_CONDITIONAL_DEFINED_LITERAL_KEY);
			schema = StringUtils.substringAfter(transformRequest.getRequestSchema(),
					Constants.SCHEMA_END_CONDITIONAL_DEFINED_LITERAL_KEY);

			/* split with #if */
			String conditionAndDefnition[] = conditionalRows.split(Constants.SCHEMA_CONDITIONAL_DEFINED_LITERAL_KEY);
			for (int i = 0; i < conditionAndDefnition.length; i++) {
				if (StringUtils.isNotEmpty(conditionAndDefnition[i])) {
					StringBuilder condition = new StringBuilder(StringUtils.substringBefore(conditionAndDefnition[i],
							Constants.SCHEMA_THEN_CONDITIONAL_DEFINED_LITERAL_KEY));
					StringBuilder definition = new StringBuilder(StringUtils.substringAfter(conditionAndDefnition[i],
							Constants.SCHEMA_THEN_CONDITIONAL_DEFINED_LITERAL_KEY));
					StringBuilder conditionSchema = new StringBuilder(StringUtils.substringBefore(condition.toString(),
							Constants.SCHEMA_CONDITIONAL_EQUAL_OPERATOR));
					StringBuilder conditionValue = new StringBuilder(StringUtils.substringAfter(condition.toString(),
							Constants.SCHEMA_CONDITIONAL_EQUAL_OPERATOR));
					String value = (String) getJsonSchemaValue(conditionSchema.toString().trim(),
							reqJsonDoc.toString());
					if (value.equalsIgnoreCase(conditionValue.toString().trim())) {
						schemaDefinition = schemaDefinition.concat(definition.toString());
					}
				}
			}

			String definitionAndSchema = schemaDefinition.concat(schema);
			if (definitionAndSchema != null && StringUtils.isNotEmpty(definitionAndSchema))
				transformRequest.setRequestSchema(definitionAndSchema);
		}
		LOGGER.info(
				"Exiting updateRequestJsonObjectWithConditionalDefinitions : " + transformRequest.getRequestSchema());

	}
	
	/**
	 * API to convert input Object to JSON String
	 * 
	 * @param object
	 * @return
	 * @throws ApplicationException
	 */
	public String convertObjectToJsonString(Object object) throws ApplicationException {
		LOGGER.info("Entering convertObjectToJsonString");

		String jsonInString = "";

		try {
			ObjectMapper mapper = new ObjectMapper();
			jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
		} catch (JsonProcessingException e) {
			LOGGER.error("Error while converting Object to JSON - ", e);
			throw new ApplicationException(StatusCode.OBJECT_TO_JSON_CONVERSION_ERROR.getCode(),
					StatusCode.OBJECT_TO_JSON_CONVERSION_ERROR.getDesc());
		}

		LOGGER.info("Exiting convertObjectToJsonString");
		return jsonInString;
	}

	/**
	 * API to convert input JSON String to Object
	 * 
	 * @param jsonString
	 * @return
	 * @throws ApplicationException
	 */
	public <T> Object convertJsonStringToObject(String jsonString, Class<T> cls) throws ApplicationException {
		LOGGER.info("Entering convertJsonStringToObject");

		T object = null;

		try {
			ObjectMapper mapper = new ObjectMapper();
			object = mapper.readValue(jsonString, cls);
		} catch (IOException e) {
			LOGGER.error("Error while converting Object to Java - ", e);
			throw new ApplicationException(StatusCode.OBJECT_TO_JSON_CONVERSION_ERROR.getCode(),
					StatusCode.OBJECT_TO_JSON_CONVERSION_ERROR.getDesc());
		}

		LOGGER.info("Exiting convertJsonStringToObject");
		return object;
	}

	/**
	 * API to convert XML to JSONObject
	 * 
	 * @param xml
	 * @return
	 * @throws ApplicationException
	 */
	public JSONObject convertXmlToJson(String xml) throws ApplicationException {
		LOGGER.info("Entering convertXmlToJson");
		JSONObject xmlJSONObj = null;

		try {
			xmlJSONObj = XML.toJSONObject(xml);
		} catch (Exception e) {
			LOGGER.error("Error while converting response XML to JSON - ", e);
			throw new ApplicationException(StatusCode.XML_TO_JSON_TRANSFORMATION_ERROR.getCode(),
					StatusCode.XML_TO_JSON_TRANSFORMATION_ERROR.getDesc());
		}

		LOGGER.info("Exiting convertXmlToJson");
		return xmlJSONObj;
	}

	/**
	 * API to the get the value from JSON
	 * 
	 * @param jsonString
	 * @param jsonPath
	 * @return
	 * @throws ApplicationException
	 */
	public String readValueFromJson(String jsonString, String jsonPath) throws ApplicationException {
		LOGGER.info("Entering readValueFromJson");
		String value = null;		
		try {
			Object val = JsonPath.read(jsonString, jsonPath);
			
			if (val != null && val instanceof Map) {
				String newJsonPath = jsonPath + ".content";
				val = JsonPath.read(jsonString, newJsonPath);
			} else if (val != null && val instanceof net.minidev.json.JSONArray) {
				
				net.minidev.json.JSONArray reslutArry = (net.minidev.json.JSONArray) val;
				
				if (!reslutArry.isEmpty()) {
					JSONArray jsonArry = new JSONArray(reslutArry.toJSONString());
					List<Object> arrayObj = jsonArry.toList();
					val = arrayObj;
				}
			}

			if (val != null)
				value = String.valueOf(val);
			else{
				LOGGER.info("jsonPath: " + jsonPath + " not found. Returning empty string");
				value = "";
			}			

		} catch (Exception e) {
			LOGGER.error("Error while getting value from JSON,Returning empty string : ", e);
			value = "";
		}

		LOGGER.info("Path [ " + jsonPath + " ], value [" + value + "]");
		LOGGER.info("Exiting readValueFromJson");
		
		return value;
	}

	/**
	 * API to Add or Update a property in JSON with the given value
	 * 
	 * @param jsonString
	 * @param jsonPath
	 * @param value
	 * @throws ApplicationException
	 */
	public void addOrUpdateJsonProperty(JSONObject parentJSONObject, String jsonPath, String value)
			throws ApplicationException {
		LOGGER.info("Entering addOrUpdateJsonProperty");

		String[] documentParamTokens = jsonPath.split("\\.");

		int tokensLength = documentParamTokens.length;
		try {
			for (int i = 1; i < tokensLength; i++) {
				boolean isArray = false;
				Integer arrIndex = null;
				String token = documentParamTokens[i];

				if (token.contains("[")) {
					isArray = true;
					String arrIndexStr = StringUtils.substringBetween(token, "[", "]");
					if (!StringUtils.isEmpty(arrIndexStr))
						arrIndex = Integer.parseInt(arrIndexStr);

					token = StringUtils.substringBefore(token, "[");
				}

				JSONObject childJSONObject;

				if (parentJSONObject.has(token)) {
					if (parentJSONObject.get(token) instanceof java.lang.String) {
						parentJSONObject.put(token, value);
						return;
					} else if (parentJSONObject.get(token) instanceof JSONArray) {
						int arryLength = parentJSONObject.getJSONArray(token).length();
						if (arrIndex == null) {
							parentJSONObject.getJSONArray(token).put(new JSONObject());
							arrIndex = parentJSONObject.getJSONArray(token).length() - 1;
						} else if (arrIndex > arryLength - 1) {
							parentJSONObject.getJSONArray(token).put(arrIndex, new JSONObject());
						}
						childJSONObject = parentJSONObject.getJSONArray(token).getJSONObject(arrIndex);
					} else {
						childJSONObject = parentJSONObject.getJSONObject(token);
					}

					if (childJSONObject.length() != 0) {
						parentJSONObject = childJSONObject;
					} else {
						if (i < tokensLength - 1) {
							childJSONObject.put(documentParamTokens[i + 1], new JSONObject());
						} else {
							parentJSONObject.put(documentParamTokens[i], value);
						}
						parentJSONObject = childJSONObject;
					}
				} else {
					if (i < tokensLength - 1) {
						if (isArray) {
							parentJSONObject.put(token, new JSONArray().put(arrIndex, new JSONObject()));
							parentJSONObject = parentJSONObject.getJSONArray(token).getJSONObject(arrIndex);
						} else {
							parentJSONObject.put(token, new JSONObject());
							parentJSONObject = parentJSONObject.getJSONObject(token);
						}

					} else {
						parentJSONObject.put(documentParamTokens[i], value);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error while adding/updating the JSON - ", e);
			throw new ApplicationException(StatusCode.JSON_UPDATE_ERROR.getCode(),
					"Error while adding/updating [" + jsonPath + "]");
		}

		LOGGER.info("Exiting addOrUpdateJsonProperty");
	}
	
	
	/**
	 * @param className
	 * @return Transformer
	 * @throws ApplicationException
	 */
	public com.vz.uiam.onenet.ods.transformer.Transformer getTransformerInstance(String className)
			throws ApplicationException {
		com.vz.uiam.onenet.ods.transformer.Transformer transformer = null;
		try {
			transformer = (com.vz.uiam.onenet.ods.transformer.Transformer) Class.forName(className).newInstance();
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			LOGGER.error("Exception occuerd - ", e);
			throw new ApplicationException(StatusCode.TRANSFORMER_CLASS_NOTFOUND.getCode(),
					"Class - " + className + " - NOT FOUND");
		}
		return transformer;
	}
	
	
	/**
	 * API to merge two JSONObjects
	 * 
	 * @param json1
	 * @param json2
	 * @return
	 * @throws ApplicationException 
	 */
	public JSONObject mergeJSONObjects(JSONObject json1, JSONObject json2) throws ApplicationException {
		JSONObject mergedJSON = new JSONObject();
		try {
			mergedJSON = new JSONObject(json1, JSONObject.getNames(json1));
			for (String crunchifyKey : JSONObject.getNames(json2)) {
				mergedJSON.put(crunchifyKey, json2.get(crunchifyKey));
			}
 
		} catch (JSONException e) {
			LOGGER.error(e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while merging JSON Objects. " + e.getMessage());
		}
		return mergedJSON;
	}
	
	/**
	 * API to remove the cdata from xml
	 * 
	 * @param xml
	 * @return
	 */
	public String removeCdataFromXml(String xml) {
		
		xml = xml.replaceAll("(?i)<!\\[CDATA\\[", "");
		
		while(xml.contains("]]>"))
		 xml = xml.replaceAll("\\]\\]>", "");
		 
		 return xml;
	}
	
	
	/**
	 * API to get the XML root tag
	 * 
	 * @param xml
	 * @return
	 * @throws ApplicationException
	 */
	public String getRootTagFromXml(String xml) throws ApplicationException {
		LOGGER.info("Entering getRootTagFromXml");
		
		String rootTag = null;
		
		try {
			InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(xml));
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			org.w3c.dom.Document document = builder.parse(is);
			
			Element root = document.getDocumentElement();
			rootTag = root.getNodeName();
			
		} catch (ParserConfigurationException | SAXException | IOException te) {
			LOGGER.error("Exception occured while scanning the XML for root tag", te);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(),
								"Error while scanning the XML for root tag. " + te.getMessage());
		}
		
		LOGGER.info("Exiting getRootTagFromXml with rootTag - " + rootTag);
		return rootTag;
	}
	
	
	/**
	 * API to get the root tag of JSON
	 * 
	 * @param json
	 * @return
	 * @throws ApplicationException
	 */
	public String getRootTagFromJson(String json) throws ApplicationException {
		LOGGER.info("Entering getRootTagFromXml");
		
		String rootTag = null;
		
		try {
			JSONObject jsonObj = new JSONObject(json);
			
			Iterator<String> keys = jsonObj.keys();
			rootTag = keys.next();
		} catch (Exception te) {
			LOGGER.error("Exception occured while scanning the JSON for root tag", te);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(),
								"Error while scanning the JSON for root tag. " + te.getMessage());
		}
		
		LOGGER.info("Exiting getRootTagFromXml with rootTag - " + rootTag);
		return rootTag;
	}
	
	
	/**
	 * API to get the node value from the XML for the given key
	 * 
	 * @param xml
	 * @param key
	 * @return
	 * @throws ApplicationException
	 */
	public String getNodeValueFromXml(String xml, String key) throws ApplicationException  {
		LOGGER.info("Entering getNodeValueFromXml");
		
		String value = null;
		
		try {
			InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(xml));
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			org.w3c.dom.Document document = builder.parse(is);
			
			 // Create XPathFactory object
            XPathFactory xpathFactory = XPathFactory.newInstance();
            
            // Create XPath object
            XPath xpath = xpathFactory.newXPath();
            
            String xPathQry = "//*/" + key + "/text()"; 
            
            XPathExpression expr = xpath.compile(xPathQry);
            value = (String) expr.evaluate(document, XPathConstants.STRING);
            
            // If there is no node present with "key" as name then look for node whose attribute value is same as "key"
            if (StringUtils.isEmpty(value)) {
            	xPathQry = "//*[@*='" + key + "']/text()"; 
                
                expr = xpath.compile(xPathQry);
                value = (String) expr.evaluate(document, XPathConstants.STRING);
            }
            
		} catch (ParserConfigurationException | SAXException | IOException | XPathExpressionException te) {
			LOGGER.error("Exception occured while retreiving the key from XML", te);
			throw new ApplicationException(StatusCode.ERROR_XML_TRANFORMATION.getCode(),
								"Error occured while retreiving the key[ " + key + "] from XML. " + te.getMessage());
		}
		
		LOGGER.info("xml key[" + key + "] value[" + value + "]");
		LOGGER.info("Exiting getNodeValueFromXml");
		return value;
	}
	
	
	/**
	 * API to get the JSON value for the given JSON Key from a JSON string
	 * 
	 * @param json
	 * @param jsonKey 
	 * @return String
	 * @throws ApplicationException 
	 */
	public String getValueFromJson(String json, String jsonKey) throws ApplicationException {
		LOGGER.info("Entering getValueFromJson");
		String jsonValue = null;
		
		try {
			net.minidev.json.JSONArray jsonValueArry = JsonPath.read(json, "$.." + jsonKey);
			LOGGER.info(jsonValueArry);
		
			if (!jsonValueArry.isEmpty()) {
				jsonValue = (String) jsonValueArry.get(0);
			}
		} catch(Exception e) {
			LOGGER.error("Error while getting value of jsonKey[" + jsonKey + "] from the JSON - ", e);
			throw new ApplicationException(StatusCode.INTERNAL_ERROR.getCode(),
							"Error while getting value of jsonKey[" + jsonKey + "] from the JSON. " + e.getMessage());
		}
		
		LOGGER.info("json key[" + jsonKey + "] value[" + jsonValue + "]");
		LOGGER.info("Exiting getValueFromJson");
		return jsonValue;
	}
	
	/**
	 * API to get the TRANSACTION_ID from JSON Response 
	 * 
	 * @param response
	 * @param transactionIdRspKey 
	 * @return Integer
	 * @throws ApplicationException 
	 */
	public String generateTransactionIdUsingTransactionIdKey(String response, String transactionIdRspKey) throws ApplicationException {
		LOGGER.info("Entering generateTransactionIdUsingTransactionIdKey");
		String transactionId = null;
		JSONObject obj = new JSONObject();
		try {
			populateValues("transactionId", transactionIdRspKey, response, obj);
			transactionId = obj.getString("transactionId");
		} catch(Exception e) {
			LOGGER.error("Error while getting TRANSACTION_ID from the JSON response - ", e);
			throw new ApplicationException(StatusCode.INTERNAL_ERROR.getCode(),
							"Error while getting TRANSACTION_ID from the JSON response. " + e.getMessage());
		}
		
		if (transactionId == null)
			throw new ApplicationException(StatusCode.TRANSACTION_ID_NOT_FOUND.getCode(), StatusCode.TRANSACTION_ID_NOT_FOUND.getDesc());
		
		LOGGER.info("Exiting generateTransactionIdUsingTransactionIdKey");
		return transactionId;
	}
	
	
	/**
	 * API to prepare error message, if OdsParamConfig is not found
	 * 
	 * @param key
	 * @param type
	 * @param name
	 * @param names
	 * @return
	 */
	public String prepareOdsParamErrorMsg(String key, String type, String name, List<String> names) {
		StringBuilder msg = new StringBuilder("OdsParamConfig not configured for ");

		if (!StringUtils.isEmpty(key))
			msg.append("key [" + key + "] ");
		if (!StringUtils.isEmpty(type))
			msg.append("type [" + type + "] ");
		if (!StringUtils.isEmpty(name))
			msg.append(" name [" + name + "] ");
		if (!CollectionUtils.isEmpty(names))
			msg.append(" names " + names + " ");

		return msg.toString();
	}

	/**
	 * @param response
	 * @return String
	 */
	public String getTransactionIdFromResponse(String response) {
		JSONObject responseJsonObj = new JSONObject(response);
		return responseJsonObj.optString(Constants.TRANSACTION_ID);
	}
	
	/**
	 * Method to 
	 *
	 * @param appKey
	 * @throws ApplicationException
	 */
	private String buildManifestPayloadForAdminDocuments(String manifestReqPayload)
			throws ApplicationException {
		JSONObject manifestReqPayloadJSON = new JSONObject(manifestReqPayload);
		JSONObject entityDataJSONObject = manifestReqPayloadJSON.getJSONObject(Constants.ENTITY_DATA_STR);
		String appKey = entityDataJSONObject.getString(Constants.MANIFEST_APP_KEY_STR);
		
		JSONArray manifestAttributesArray = new JSONArray();
		JSONObject attributes = new JSONObject();
		attributes.put(Constants.MANIFEST_NAME_KEY_STR, Constants.APPLICATION_KEY);
		attributes.put(Constants.MANIFEST_VALUE_KEY_STR, appKey);
		manifestAttributesArray.put(attributes);
		attributes = new JSONObject();
		attributes.put(Constants.MANIFEST_NAME_KEY_STR, Constants.DATA_TYPE);
		attributes.put(Constants.MANIFEST_VALUE_KEY_STR, Constants.METADATA);
		manifestAttributesArray.put(attributes);
		attributes = new JSONObject();
		attributes.put(Constants.MANIFEST_NAME_KEY_STR, Constants.DOCUMENT_LEVEL);
		attributes.put(Constants.MANIFEST_VALUE_KEY_STR, Constants.GLOBAL);
		manifestAttributesArray.put(attributes);
			
		// Prepare Manifest Get Request
		String entityData = buildManifestPayload(Constants.METADATA_APP_KEY, manifestAttributesArray);

		return entityData;
	}
	
	/**
	 * @param appKey
	 * @param manifestAttributesArray
	 * @return JSONObject
	 * @throws JSONException
	 */
	public String buildManifestPayload(String appKey, JSONArray manifestAttributesArray) throws JSONException {
		JSONObject entityData = new JSONObject();
		JSONObject valueMap = new JSONObject();
		JSONObject attributesMap = new JSONObject();

		attributesMap.put(Constants.MANIFEST_ATTRIBUTE_STR, manifestAttributesArray);
		valueMap.put(Constants.MANIFEST_ENTITY_ATTRIBUTES_STR, attributesMap);
		valueMap.put(Constants.MANIFEST_APP_KEY_STR, appKey);
		entityData.put(Constants.ENTITY_DATA_STR, valueMap);

		return entityData.toString();
	}
	
	/**
	 * API to get the manifest document, after updating the document name in the getManifest payload
	 * 
	 * @param manifestReqPayload
	 * @param manifestDocumentNames
	 * @return String
	 * @throws ApplicationException
	 */
	public String buildManifestDocument(String manifestReqPayload, String manifestDocumentNames)
			throws ApplicationException {
		LOGGER.info("Entering buildManifestDocument");

		JSONObject manfiestDoc = new JSONObject();

		String[] manifestDocumentNameArry = manifestDocumentNames.split(Constants.MANIFEST_DOCUMENT_NAME_SPLITTER);
		for (String manifestDocumentName : manifestDocumentNameArry) {
			LOGGER.info("Getting Manifest document for : " + manifestDocumentName);
			JSONObject documentPayload = new JSONObject();
			JSONObject manfiestPayload = null;
			if (manifestDocumentName.startsWith(Constants.METADATA_KEY)) {
				manfiestPayload = new JSONObject(buildManifestPayloadForAdminDocuments(manifestReqPayload));
				String[] tokens = manifestDocumentName.split("\\.");
				manifestDocumentName = tokens[1];
			} else {
				manfiestPayload = new JSONObject(manifestReqPayload);
			}
			String populatedDocPayloadStr = populateDocumentNameAndGetManifest(manfiestPayload, manifestDocumentName);
			documentPayload = new JSONObject(populatedDocPayloadStr);
			manfiestDoc.put(manifestDocumentName, documentPayload);
		}

		LOGGER.info("Exiting buildManifestDocument");

		return manfiestDoc.toString();
	}
	
	/**
	 * @param manfiestPayload
	 * @param manifestDocumentName
	 * @return
	 * @throws ApplicationException
	 */
	private String populateDocumentNameAndGetManifest(JSONObject manfiestPayload, String manifestDocumentName)
			throws ApplicationException {
		manfiestPayload.getJSONObject(Constants.ENTITY_DATA_STR).put(Constants.MANIFEST_DOCUMENT_NAME_STR,
				manifestDocumentName);

		String manifestResp = getManifestDocument(manfiestPayload.toString());
		JSONObject manfiestRespJson = new JSONObject(manifestResp);
		JSONObject documentPayload = new JSONObject();
		documentPayload.put(Constants.MANIFEST_DOCUMENT_PAYLOAD_STR,
				manfiestRespJson.getJSONObject(Constants.MANIFEST_DOCUMENT_PAYLOAD_STR));
		
		return documentPayload.toString();
	}
	
	/**
	 * API to get the manifest document
	 * 
	 * @param manifestReqPayload
	 * @return String
	 * @throws ApplicationException
	 */
	public String getManifestDocument(String manifestReqPayload) throws ApplicationException {
		LOGGER.info("Entering getManifestDocument");

		/* Get MANIFEST_GET_SERVICE_URL from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.GET_MANIFEST_ENDPOINT_URL);
		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(), OdsParamConfigType.ODS_PARAM.toString(),
							Constants.GET_MANIFEST_ENDPOINT_URL, null));
		LOGGER.info("Manifest GET URL : " + odsAppParam.getValue());

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(manifestReqPayload, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(odsAppParam.getValue(), HttpMethod.POST, httpEntity, String.class);
		} catch (Exception e) {
			LOGGER.error("Error while calling Manifest GET Service", e);
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Error while calling Manifest GET Service. ");
		}

		String manifestResponse;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			manifestResponse = responseEntity.getBody();
			if (StringUtils.isEmpty(manifestResponse)) {
				LOGGER.error(StatusCode.MANIFEST_RESPONSE_IS_NULL.getDesc());
				throw new ApplicationException(StatusCode.MANIFEST_RESPONSE_IS_NULL.getCode(),
						StatusCode.MANIFEST_RESPONSE_IS_NULL.getDesc());
			}
			else{
				JSONObject responseJson = new JSONObject(manifestResponse);
				if(Constants.MANIFEST_DOC_NOT_FOUND_CODE.equals(((JSONObject) responseJson.get("status")).get("code"))){
					LOGGER.error("Document not found in Manifest");
					responseJson.put("document-payload", new JSONObject());
					return responseJson.toString();
				}
			}
		} else {
			LOGGER.error("Error Received failure response from Manifest GET Service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from Manifest GET Service");
		}
		LOGGER.info("Exiting getManifestDocument");
		return manifestResponse;
	}

	/**
	 * @param payload
	 * @param tranformedDocument
	 * @return TransformedResponsePayload
	 * @throws ApplicationException
	 */
	public TransformedResponsePayload getTransformationPayload(TransformedResponsePayload payload,
			String tranformedDocument, String routingProtocol) throws ApplicationException {
		LOGGER.info("Entering getTransformationPayload");

		if (Constants.ROUTING_PROTOCOL_SOAP.equalsIgnoreCase(routingProtocol)) {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder;
			try {
				builder = factory.newDocumentBuilder();
				org.w3c.dom.Document document = builder.parse(new InputSource(new StringReader(tranformedDocument)));
				LOGGER.info(" Document is :::" + document);
				XPath xPath = XPathFactory.newInstance().newXPath();
				Node headerNode = (Node) xPath.evaluate(Constants.HEADER_NODE_EXTRACTION, document,
						XPathConstants.NODE);
				Node body = (Node) xPath.evaluate(Constants.BODY_NODE_EXTRACTION, document, XPathConstants.NODE);
				payload = new TransformedResponsePayload(nodeToString(body), nodeToString(headerNode));
			} catch (TransformerException | ParserConfigurationException | SAXException | IOException
					| XPathExpressionException te) {
				LOGGER.error("ODS Service router configuration not found", te);
				throw new ApplicationException(StatusCode.ERROR_XML_TRANFORMATION.getCode(),
						StatusCode.ERROR_XML_TRANFORMATION.getDesc());
			}
		} else if (Constants.ROUTING_PROTOCOL_REST.equalsIgnoreCase(routingProtocol)
				|| Constants.ROUTING_PROTOCOL_MQ.equalsIgnoreCase(routingProtocol)) {
			payload = new TransformedResponsePayload(tranformedDocument, "");
		}
		LOGGER.info("Exiting getTransformationPayload");
		return payload;
	}

	/**
	 * @param node
	 * @return
	 * @throws TransformerException
	 */
	private String nodeToString(Node node) throws TransformerException {
		if(node == null) 
			return "";
		StringWriter buf = new StringWriter();
		Transformer xform = TransformerFactory.newInstance().newTransformer();
		xform.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		xform.transform(new DOMSource(node), new StreamResult(buf));
		return buf.toString();
	}
	
	/**
	 * @param odsAppParam
	 * @param httpEntity
	 * @return ResponseEntity<String>
	 * @throws ApplicationException
	 */
	public ResponseEntity<String> callService(OdsParamConfig odsAppParam, HttpEntity<String> httpEntity)
			throws ApplicationException {
		ResponseEntity<String> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(odsAppParam.getValue(), HttpMethod.POST, httpEntity, String.class);
		} catch (Exception e) {
			LOGGER.error("Error while calling the Service", e);
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(), "Error while calling the Service. " + e.getMessage());
		}
		return responseEntity;
	}
	
	/**
	 * API to do Base64 encoding 
	 * 
	 * @param str
	 * @return
	 * @throws ApplicationException 
	 */
	public static String base64Encode(String str) throws ApplicationException {
		try {
			return Base64.getEncoder().encodeToString(str.getBytes("utf-8"));
		} catch (Exception e) {
			LOGGER.error("Error while encoding the service password", e);
			throw new ApplicationException(StatusCode.PWD_ENCODE_ERROR.getCode(), "Error while encoding the service password");
		}
	}

	/**
	 *  API to do Base64 decoding 
	 * 
	 * @param str
	 * @return
	 * @throws ApplicationException 
	 */
	public static String base64Decode(String str) throws ApplicationException {
		try {
			return new String(Base64.getDecoder().decode(str), "utf-8");
		} catch (Exception e) {
			LOGGER.error("Error while decoding the service password", e);
			throw new ApplicationException(StatusCode.PWD_DECODE_ERROR.getCode(), "Error while decoding the service password");
		}
	}
	

	public String getResponseStatusAndBody(ResponseEntity<String> responseEntity) {
		return "StatusCode [" + responseEntity.getStatusCode() + "] Response Body [" + responseEntity.getBody() + "]";
	}
	
	/**
	 * 
	 * @param userName
	 * @param password
	 * @return
	 * @throws ApplicationException
	 */
	public String userNamePasswordEncoder(String userName, String password) throws ApplicationException {
		LOGGER.info("Entering userNamePasswordEncoder");
		String encodedCredentials = "";
		// Encoding string
		String decodeUsernNamePassword = userName + ":" + password;
		encodedCredentials = ServiceUtils.base64Encode(decodeUsernNamePassword);
		LOGGER.info("Exiting userNamePasswordEncoder");
		return encodedCredentials;
	}
	
	
	/*
	 * @param targetEndPointUrl
	 * return List<NameValuePair>
	 * @throws URISyntaxException
	 */
	private List<NameValuePair> getQueryParamsInUrl(String targetEndPointUrl) throws URISyntaxException{
		URI targetURL = new URI(targetEndPointUrl);
		@SuppressWarnings("deprecation")
		List<NameValuePair> result =URLEncodedUtils.parse(targetURL, "UTF-8");
		return result;
	}

	/**
	 * @param targetEndPointUrl
	 * @return Map<String, String>
	 * @throws ApplicationException
	 */
	public QueryParam extractQueryParameters(String targetEndPointUrl , JSONObject jsonDocument) throws ApplicationException {
		List<Param> params = new ArrayList<Param>();
		try {
			List<NameValuePair> result = getQueryParamsInUrl(targetEndPointUrl);
		    for (NameValuePair nvp : result) {
				String paramValue = null;
				paramValue = (String)getJsonSchemaValue(nvp.getValue(), jsonDocument.toString());
				params.add(new Param(nvp.getName(), paramValue));
		    }
		} catch (URISyntaxException e) {
			LOGGER.info("The target url being configured is malfarmed"+e);
			throw new ApplicationException(StatusCode.TARGET_URL_IS_MALFORMED.getCode(), "The target url being configured is malfarmed");
		}catch (Exception e) {
			LOGGER.info("Exception occured while extracting the query parameters from the target URL:::"+e);
			throw new ApplicationException(StatusCode.TARGET_URL_IS_MALFORMED.getCode(), "The target url being configured is malfarmed");
		}
		return new QueryParam(params);
	}

	/**
	 * @param sourceDocument
	 * @param documentToBeMerged
	 * @param subDocumentName
	 * @return String
	 */
	public String mergeDocumentByName(JSONObject sourceDocument, JSONObject documentToBeMerged, String subDocumentName) {
		return sourceDocument.put(subDocumentName, documentToBeMerged).toString();
	}
	
	/**
	 * API to prepare  TargetEndPoint Dynamically
	 *
	 * @param jsonDocument
	 * @param targetEndpointUrl
	 * @return
	 * @throws ApplicationException 
	 */
	public String generateDynamicTargetEndPointUrl(JSONObject jsonDocument, String targetEndpointUrl,String paramKey) throws ApplicationException {
		LOGGER.info("Entering generateDynamicTragetEndPointUrl");
		LOGGER.info("targetEndpointUrl before hostname transformation : " + targetEndpointUrl);
		
		String transformedTargetUrl = targetEndpointUrl;
		if (!(StringUtils.isEmpty(targetEndpointUrl)) && (targetEndpointUrl.startsWith("$"))) {
			String[] dynamicUrlAry = targetEndpointUrl.split("/");
			String jsonSchema = dynamicUrlAry[0];
			String[] jsonSchemaAry = jsonSchema.split("\\.");
			
			String transformedValue = null;
			
			if (!(ArrayUtils.isEmpty(jsonSchemaAry)) && (jsonSchemaAry[1].equalsIgnoreCase(Constants.APP_PARAM_KEY))) {
				OdsParamConfig odsParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(paramKey,
		    								OdsParamConfigType.APPLICATION_PARAM.toString(), jsonSchemaAry[2]);
				
				if (odsParam == null)
					throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Application Param not configured for [" 
															+ jsonSchemaAry[2] + "] for creating the target end point URL dynamically.");
				
				transformedValue = odsParam.getValue();
			} else {
				JSONObject obj = new JSONObject();
				populateValues("targetEndpointUrl", jsonSchema, jsonDocument.toString(), obj);
				transformedValue = obj.optString("targetEndpointUrl");
			}
			
			if (StringUtils.isEmpty(transformedValue) || "null".equalsIgnoreCase(transformedValue))
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Could not found value for [" 
						+ jsonSchema + "] while creating the target end point URL dynamically.");
			
			dynamicUrlAry[0] = transformedValue;
			transformedTargetUrl = String.join("/", dynamicUrlAry);
		}
		
		
		transformedTargetUrl = updateTargetEndPointUrlWithManifestSchemaMapping(jsonDocument, transformedTargetUrl);
		transformedTargetUrl = updateTargetEndPointUrlQueryParamsWithManifestSchemaMapping(jsonDocument, transformedTargetUrl);
		LOGGER.info("Exiting generateDynamicTragetEndPointUrl");
		return transformedTargetUrl;
	}
	
	/**
	 * Method to apply manifest document schema to the Target Endpoint URL.
	 * 
	 * @param jsonDocument
	 * @param transformedTargetUrl
	 * @return
	 */
	private String updateTargetEndPointUrlWithManifestSchemaMapping(JSONObject jsonDocument,
			String endpointURL) {
		String[] urlTokens = endpointURL.split("/");
		for(int i = 0; i < urlTokens.length; i++) {
			if(urlTokens[i].startsWith("$.")) {
				urlTokens[i] = (String)getJsonSchemaValue(urlTokens[i], jsonDocument.toString()); 
			}
		}
		return String.join("/", urlTokens);
	}
	
	/**
	 * ODS Redesign - Build a key based on workflow process name and task name
	 * to store the co-relation for the given step.
	 *
	 * @param requestObj
	 * @return String
	 */
	public String buildKey(String flowNodeProcessName, String flowNodeStepName) {
		return new StringBuffer(flowNodeProcessName).append(Constants.KEYBUILDER_SEPERATOR).append(flowNodeStepName)
				.toString();
	}
	
	/**
	 * ODS Redesign - Build External Task ID of UTE based on workflow process instance id and activity instance id
	 *
	 * @param requestObj
	 * @return String
	 */
	public String buildExternalTaskId(String rootCaseId, String activityInstanceId) {
		return new StringBuffer(Constants.EXTERNAL_TASK_ID_PREFIX).append(Constants.EXTERNAL_TASK_ID_SEPARATOR).append(rootCaseId).append(Constants.EXTERNAL_TASK_ID_SEPARATOR).append(activityInstanceId)
				.toString();
	}
	
	/**
	 * Method to apply manifest document schema to the queryParameters in theTarget Endpoint URL.
	 * 
	 * @param jsonDocument
	 * @param transformedTargetUrl
	 * @return
	 * @throws ApplicationException 
	 */
	private String updateTargetEndPointUrlQueryParamsWithManifestSchemaMapping(JSONObject jsonDocument,
			String targetEndPointUrl) throws ApplicationException  {
		try {
			List<NameValuePair> result = getQueryParamsInUrl(targetEndPointUrl);
			for (NameValuePair nvp : result) {
				String value = (String)getJsonSchemaValue(nvp.getValue(), jsonDocument.toString());
				value = URLEncoder.encode(value, "UTF-8") ;
				LOGGER.info("Encodedvalue::::"+value);
				targetEndPointUrl = targetEndPointUrl.replace(nvp.getValue(), value);
			}
		} catch (URISyntaxException e) {
			LOGGER.info("The target url being configured is malfarmed" + e);
			throw new ApplicationException(StatusCode.TARGET_URL_IS_MALFORMED.getCode(),
					"The target url being configured is malfarmed");
		} catch (UnsupportedEncodingException e) {
			LOGGER.info("Error while encoding query Parameter" + e);
			throw new ApplicationException(StatusCode.TARGET_URL_IS_MALFORMED.getCode(),
					"Error while encoding query Parameter");
		}
		return targetEndPointUrl;
	}
	
	public Timestamp getCurrentTimestamp() {
		return new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
	}
	
	/**
	 * Method to Check the CDATA Response contains xml Tag if exists remove that
	 * tag.
	 * 
	 * @param response
	 * @return
	 * 
	 */
	public String validateXml(String response) {
		LOGGER.info("Entering validateXml");
		String cdataResponse = StringUtils.substringAfter(response, "<![CDATA[");
		String finalResponse = "";
		if (cdataResponse.contains("<?xml")) {
			LOGGER.info("cdataResponse" + cdataResponse);

			String removeXmlTag = cdataResponse.substring(cdataResponse.indexOf("<?xml"),
					cdataResponse.indexOf("?>") + 2);
			LOGGER.info("removeXmlTag" + removeXmlTag);
			finalResponse = StringUtils.substringBefore(response, "<![CDATA[")
					.concat(cdataResponse.replace(removeXmlTag, ""));

		}
		LOGGER.info("Exiting validateXml");
		if (StringUtils.isNotEmpty(finalResponse)) {
			return removeCdataFromXml(finalResponse);
		} else {
			return removeCdataFromXml(response);
		}
	}	
	/**
	 * @param Timestamp
	 * @param buffer
	 * @return expiryTime
	 */
	public Timestamp addBufferInMinutesToTime(Timestamp time, int buffer) {
		LOGGER.info("Entering getExpiryTime");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(time);
		calendar.add(Calendar.MINUTE, buffer);
		Timestamp expiryTime = new Timestamp(calendar.getTimeInMillis());
		LOGGER.info("Exiting getExpiryTime");
		return expiryTime;

	}
	

	/**
	 * @param paramKey
	 * @param type
	 * @param name
	 * @param payload
	 * @throws ApplicationException
	 */
	public void callService(String paramKey, String type, String name, String payload)
			throws ApplicationException {
		/* Get service URL from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(paramKey,type, name);

		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue())) {
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(),
							OdsParamConfigType.APPLICATION_PARAM.toString(), name, null));
		}

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(payload, httpHeaders);
		callService(odsAppParam, httpEntity);

	}
	

}