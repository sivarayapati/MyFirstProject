/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dto.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author ODS.
 *
 */
public class ODSInterfaceServiceRequest {
	String transactionId;
	String taskId;
	String requestPayload;
	String manifestPayload;
	String corelationPayload;
	String responseConfigParams;
	
	public ODSInterfaceServiceRequest(String transactionId, String requestPayload, String manifestPayload, String corelationPayload, String responseConfigParams) {
		this.transactionId = transactionId;
		this.requestPayload = requestPayload;
		this.manifestPayload = manifestPayload;
		this.corelationPayload = corelationPayload;
		this.responseConfigParams = responseConfigParams;
	}
	
	public ODSInterfaceServiceRequest(String transactionId, String taskId, String requestPayload, String manifestPayload, String corelationPayload, String responseConfigParams) {
		this.transactionId = transactionId;
		this.taskId = taskId;
		this.requestPayload = requestPayload;
		this.manifestPayload = manifestPayload;
		this.corelationPayload = corelationPayload;
		this.responseConfigParams = responseConfigParams;
	}

	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}



	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}



	/**
	 * @return the taskId
	 */
	public String getTaskId() {
		return taskId;
	}

	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	/**
	 * @return the requestPayload
	 */
	public String getRequestPayload() {
		return requestPayload;
	}



	/**
	 * @param requestPayload the requestPayload to set
	 */
	public void setRequestPayload(String requestPayload) {
		this.requestPayload = requestPayload;
	}



	/**
	 * @return the manifestPayload
	 */
	public String getManifestPayload() {
		return manifestPayload;
	}



	/**
	 * @param manifestPayload the manifestPayload to set
	 */
	public void setManifestPayload(String manifestPayload) {
		this.manifestPayload = manifestPayload;
	}



	/**
	 * @return the corelationPayload
	 */
	public String getCorelationPayload() {
		return corelationPayload;
	}



	/**
	 * @param corelationPayload the corelationPayload to set
	 */
	public void setCorelationPayload(String corelationPayload) {
		this.corelationPayload = corelationPayload;
	}



	/**
	 * @return the responseConfigParams
	 */
	public String getResponseConfigParams() {
		return responseConfigParams;
	}



	/**
	 * @param responseConfigParams the responseConfigParams to set
	 */
	public void setResponseConfigParams(String responseConfigParams) {
		this.responseConfigParams = responseConfigParams;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
