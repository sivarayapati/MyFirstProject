package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

@Entity
@Table(name = "ods_milestone_config")
public class OdsMilestoneConfig implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ods_milestone_config_Id")
	private Integer odsMilestoneConfigId;

	@Column(name = "milestone_name")
	private String milestoneName;

	@Column(name = "flow_node_process_name")
	private String flowNodeProcessName;

	@Column(name = "flow_node_step_name")
	private String flowNodeStepName;

	@Column(name = "destination_app_name")
	private String destinationAppName;

	@Column(name = "target_end_point_url")
	private String targetEndpointUrl;

	@Column(name = "request_schema")
	private String requestSchema;

	@Column(name = "request_document_name")
	private String requestDocumentName;

	@Column(name = "transformation_type")
	private String transformationType;

	@Column(name = "route_protocol")
	private String routeProtocol;

	@Column(name = "send_milestone")
	private String sendMilestone;

	@Column(name = "send_fallout_notification")
	private String sendFalloutNotification;

	@Column(name = "username")
	private String userName;

	@Column(name = "password")
	private String password;

	/**
	 * @return the odsMilestoneConfigId
	 */
	public Integer getOdsMilestoneConfigId() {
		return odsMilestoneConfigId;
	}

	/**
	 * @param odsMilestoneConfigId
	 *            the odsMilestoneConfigId to set
	 */
	public void setOdsMilestoneConfigId(Integer odsMilestoneConfigId) {
		this.odsMilestoneConfigId = odsMilestoneConfigId;
	}

	/**
	 * @return the milestoneName
	 */
	public String getMilestoneName() {
		return milestoneName;
	}

	/**
	 * @param milestoneName
	 *            the milestoneName to set
	 */
	public void setMilestoneName(String milestoneName) {
		this.milestoneName = milestoneName;
	}

	/**
	 * @return the flowNodeProcessName
	 */
	public String getFlowNodeProcessName() {
		return flowNodeProcessName;
	}

	/**
	 * @param flowNodeProcessName
	 *            the flowNodeProcessName to set
	 */
	public void setFlowNodeProcessName(String flowNodeProcessName) {
		this.flowNodeProcessName = flowNodeProcessName;
	}

	/**
	 * @return the flowNodeStepName
	 */
	public String getFlowNodeStepName() {
		return flowNodeStepName;
	}

	/**
	 * @param flowNodeStepName
	 *            the flowNodeStepName to set
	 */
	public void setFlowNodeStepName(String flowNodeStepName) {
		this.flowNodeStepName = flowNodeStepName;
	}

	/**
	 * @return the destinationAppName
	 */
	public String getDestinationAppName() {
		return destinationAppName;
	}

	/**
	 * @param destinationAppName
	 *            the destinationAppName to set
	 */
	public void setDestinationAppName(String destinationAppName) {
		this.destinationAppName = destinationAppName;
	}

	/**
	 * @return the targetEndpointUrl
	 */
	public String getTargetEndpointUrl() {
		return targetEndpointUrl;
	}

	/**
	 * @param targetEndpointUrl
	 *            the targetEndpointUrl to set
	 */
	public void setTargetEndpointUrl(String targetEndpointUrl) {
		this.targetEndpointUrl = targetEndpointUrl;
	}

	/**
	 * @return the requestSchema
	 */
	public String getRequestSchema() {
		return requestSchema;
	}

	/**
	 * @param requestSchema
	 *            the requestSchema to set
	 */
	public void setRequestSchema(String requestSchema) {
		this.requestSchema = requestSchema;
	}

	/**
	 * @return the requestDocumentName
	 */
	public String getRequestDocumentName() {
		return requestDocumentName;
	}

	/**
	 * @param requestDocumentName
	 *            the requestDocumentName to set
	 */
	public void setRequestDocumentName(String requestDocumentName) {
		this.requestDocumentName = requestDocumentName;
	}

	/**
	 * @return the transformationType
	 */
	public String getTransformationType() {
		return transformationType;
	}

	/**
	 * @param transformationType
	 *            the transformationType to set
	 */
	public void setTransformationType(String transformationType) {
		this.transformationType = transformationType;
	}

	/**
	 * @return the routeProtocol
	 */
	public String getRouteProtocol() {
		return routeProtocol;
	}

	/**
	 * @param routeProtocol
	 *            the routeProtocol to set
	 */
	public void setRouteProtocol(String routeProtocol) {
		this.routeProtocol = routeProtocol;
	}

	/**
	 * @return the sendMilestone
	 */
	public String getSendMilestone() {
		return sendMilestone;
	}

	/**
	 * @param sendMilestone
	 *            the sendMilestone to set
	 */
	public void setSendMilestone(String sendMilestone) {
		this.sendMilestone = sendMilestone;
	}

	/**
	 * @return the sendFalloutNotification
	 */
	public String getSendFalloutNotification() {
		return sendFalloutNotification;
	}

	/**
	 * @param sendFalloutNotification
	 *            the sendFalloutNotification to set
	 */
	public void setSendFalloutNotification(String sendFalloutNotification) {
		this.sendFalloutNotification = sendFalloutNotification;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @param flowNodeProcessName
	 * @param flowNodeStepName
	 */
	public OdsMilestoneConfig(String flowNodeProcessName, String flowNodeStepName) {
		super();
		this.flowNodeProcessName = flowNodeProcessName;
		this.flowNodeStepName = flowNodeStepName;
	}

	/**
	 * 
	 */
	public OdsMilestoneConfig() {
		super();
	}

}
