/**
 * 
 */
package com.vz.uiam.onenet.ods.service;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsTransformerConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsTransformerConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsTransformerConfigDto;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformRequest;
import com.vz.uiam.onenet.ods.transformer.TranformerFactory;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

/**
 * @author Anand
 *
 */
@Service("odsTransformerConfigService")
@Transactional(readOnly = false, rollbackFor=Exception.class)
public class OdsTransformerConfigService {

	private static final Logger LOGGER = Logger.getLogger(OdsTransformerConfigService.class);

	@Autowired
	OdsTransformerConfigRepository odsTransformerConfigRepository;

	@Autowired
	ApplicationContext appcontext;
	
	@Autowired
	ServiceUtils serviceUtils;
	
	/**
	 * @param requestDto
	 * @return transformerDocument
	 * @throws ApplicationException
	 */
	public String tranformDocument(OdsTransformerConfigDto requestDto) throws ApplicationException {
		LOGGER.info(">>tranformDocument()");
		String transformerDoc;
		OdsTransformerConfig odsTransformerConfig = odsTransformerConfigRepository
				.findByTransformerKey(requestDto.getTransformerKey());

		if (odsTransformerConfig != null) {
			TransformRequest transformRequest = new TransformRequest();
			transformRequest.setRequestSchema(odsTransformerConfig.getTransformerSchema());
			transformRequest.setTransformationType(odsTransformerConfig.getTransformerType());
			String inputDocumentStr = requestDto.getRequestDocument();
			if(Constants.TRANSFORMATION_JSON_TYPE.equals(odsTransformerConfig.getTransformerType())){
				JSONObject inputJsonObject = new JSONObject(inputDocumentStr);
				serviceUtils.updateRequestJsonObjectWithSchemaDefinedParams(inputJsonObject, transformRequest);
				inputDocumentStr= inputJsonObject.toString();
			}
			transformerDoc = doTransform(inputDocumentStr, transformRequest.getTransformationType(),
					transformRequest.getRequestSchema());
		} else {
			throw new ApplicationException("", "");
		}

		LOGGER.info("<<tranformDocument()");
		return transformerDoc;
	}

	/**
	 * @param requestDto
	 * @param odsTransformerConfig
	 * @return
	 * @throws ApplicationException
	 */
	public String doTransform(String requestDocument, String transformerType, String transformerSchema)
			throws ApplicationException {
		String transformerDoc;
		com.vz.uiam.onenet.ods.transformer.Transformer transformer = TranformerFactory.getTransformerInstance(transformerType);
		appcontext.getAutowireCapableBeanFactory().autowireBean(transformer);
		transformerDoc = (String) transformer.doTransform(requestDocument, transformerSchema);
		return transformerDoc;
	}

	/**
	 * API to create or Update a record in OdsTransformerConfig table
	 * 
	 * @param inputOdsTransformerConfig
	 * @return
	 * @throws ApplicationException
	 */
	public OdsTransformerConfig createOrUpdateOdsTransformerConfig(OdsTransformerConfig inputOdsTransformerConfig) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateOdsTransformerConfig");
		
		OdsTransformerConfig existingOdsTransformerConfig = null;
		
		if (inputOdsTransformerConfig.getOdsTransformerId() != null) {
			existingOdsTransformerConfig = odsTransformerConfigRepository.findOne(inputOdsTransformerConfig.getOdsTransformerId());
			
			if (existingOdsTransformerConfig == null)
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "OdsTransformerConfig record not found for ID - " + inputOdsTransformerConfig.getOdsTransformerId());
		}
		
		if (existingOdsTransformerConfig == null) {
			existingOdsTransformerConfig = odsTransformerConfigRepository.findByTransformerKey(inputOdsTransformerConfig.getTransformerKey());
			if (existingOdsTransformerConfig != null)
				throw new ApplicationException(StatusCode.DATA_HANDLING_ERROR.getCode(), "OdsTransformerConfig record already exists for the input data. " + existingOdsTransformerConfig);
			 else {
				 doOdsTransformerConfigValidation(inputOdsTransformerConfig);
				}
		} else {
			doOdsTransformerConfigValidation(inputOdsTransformerConfig);
		}
		
		OdsTransformerConfig newOdsTransformerConfig = odsTransformerConfigRepository.save(
							getUpdatedOdsTransformerConfigRecord(inputOdsTransformerConfig, existingOdsTransformerConfig));
		
		LOGGER.info("Exiting createOrUpdateOdsTransformerConfig");
		return newOdsTransformerConfig;
	}
	
	
	/**
	 * @param transformerKey
	 * @return OdsTransformerConfig
	 */
	public OdsTransformerConfig getOdsTransformerConfig(String transformerKey) throws ApplicationException {
		LOGGER.info("Entering getOdsTransformerConfig");
		return odsTransformerConfigRepository.findByTransformerKey(transformerKey);
	}

	
	/**
	 * API to delete the OdsTransformerConfig records
	 * 
	 * @param odsTransformerConfig
	 * @throws ApplicationException
	 */
	public void deleteOdsTransformerConfigRecord(OdsTransformerConfig odsTransformerConfig) throws ApplicationException {
		LOGGER.info("Entering deleteOdsTransformerConfigRecord");
		
		try {
			if (odsTransformerConfig.getOdsTransformerId() != null) {
				odsTransformerConfigRepository.delete(odsTransformerConfig.getOdsTransformerId());
			} else if (!StringUtils.isEmpty(odsTransformerConfig.getTransformerKey())) {
				
				OdsTransformerConfig existingOdsTransformerConfig = odsTransformerConfigRepository.findByTransformerKey(odsTransformerConfig.getTransformerKey());
		
				if (existingOdsTransformerConfig != null) {
					odsTransformerConfigRepository.delete(existingOdsTransformerConfig);
				} else
					throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Record not found for the given input."
							+ " transformerKey[" + odsTransformerConfig.getTransformerKey() + "]");
			} else {
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Provide either [odsTransformerId] or [transformerKey]");
			}
		} catch (Exception e) {
			LOGGER.error("Error while deleting OdsTransformerConfig records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while deleting OdsTransformerConfig records. " + e.getMessage());
		}
		
		LOGGER.info("Exiting deleteOdsTransformerConfigRecord");
	}
	
	
	/**
	 * API to update the input OdsTransformerConfig record with the exiting one 
	 * 
	 * @param inputOdsTransformerConfig
	 * @param existingOdsTransformerConfig
	 * @return
	 * @throws ApplicationException 
	 */
	public OdsTransformerConfig getUpdatedOdsTransformerConfigRecord(OdsTransformerConfig inputOdsTransformerConfig,
												OdsTransformerConfig existingOdsTransformerConfig) throws ApplicationException {
		LOGGER.info("Entering getUpdatedOdsTransformerConfigRecord");
		
		if (existingOdsTransformerConfig == null)
			return inputOdsTransformerConfig;
		
		if (!StringUtils.isEmpty(inputOdsTransformerConfig.getTransformerKey()))
			existingOdsTransformerConfig.setTransformerKey(inputOdsTransformerConfig.getTransformerKey());
		
		if (!StringUtils.isEmpty(inputOdsTransformerConfig.getTransformerType()))
			existingOdsTransformerConfig.setTransformerType(inputOdsTransformerConfig.getTransformerType());
		
		if (!StringUtils.isEmpty(inputOdsTransformerConfig.getTransformerSchema()))
			existingOdsTransformerConfig.setTransformerSchema(inputOdsTransformerConfig.getTransformerSchema());
		
		LOGGER.info("Exiting getUpdatedOdsTransformerConfigRecord");
		return existingOdsTransformerConfig;
	}
	
	
	/**
	 * API to do validation on input OdsTransformerConfig record
	 * 
	 * @param odsTransformerConfig
	 * @throws ApplicationException
	 */
	public void doOdsTransformerConfigValidation(OdsTransformerConfig odsTransformerConfig) throws ApplicationException {
		LOGGER.info("Entering doOdsTransformerConfigValidation");
		
		if (StringUtils.isEmpty(odsTransformerConfig.getTransformerKey()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "transformerKey is null or empty");
		if (StringUtils.isEmpty(odsTransformerConfig.getTransformerType()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "transformerType is null or empty");
		if (StringUtils.isEmpty(odsTransformerConfig.getTransformerSchema()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "transformerSchema is null or empty");
		
		LOGGER.info("Exiting doOdsTransformerConfigValidation");
	}
}
