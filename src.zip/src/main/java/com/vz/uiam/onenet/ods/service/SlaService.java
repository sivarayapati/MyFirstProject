package com.vz.uiam.onenet.ods.service;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

/**
 * @author ODS
 *
 */
@Service
public class SlaService {
	private static final Logger LOGGER = Logger.getLogger(SlaService.class);

	
	@Autowired
	OdsInterfaceRequestRepository odsRequestRepo;

	@Autowired
	OdsParamConfigRepository odsParamConfigRepository;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired 
	ServiceUtils serviceUtils;
	

	
	/**
	 * This method calls the SLA service to make an entry in SLA table
	 * @param slaUrl
	 * @param slaPayload
	 * @return String
	 * @throws ApplicationException
	 */
	public String createPayloadtoCloseBonitaTask(String request) throws ApplicationException {
		LOGGER.info("Entering createPayloadtoCloseBonitaTask");

		// Convert input JSON string into JSON Object
		JSONObject reqJson = new JSONObject(request);
		
		String transactionId = reqJson.get("id").toString();
		OdsInterfaceRequest requestFromDb = odsRequestRepo.findByTransactionIdAndStatus(transactionId, StatusCode.REQUEST_PENDING.toString());
		if (requestFromDb == null)
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					"No Pending record found in OdsInterfaceRequest for transactionId - " + transactionId);
		String correlationPayload = requestFromDb.getCoreleationPayload();
		JSONObject bonitaPayload = new JSONObject(correlationPayload);
		String paramKey = bonitaPayload.get("bonitaProcessName")+"_"+bonitaPayload.get("bonitaFlowNodeName");
		try {
			/* Get content schema from param config table */
			OdsParamConfig odsParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(paramKey,
					OdsParamConfigType.WORKFLOW_CORRELATION_PARAM.toString(), Constants.CONTENT_SCHEMA);
			JSONObject contentSchema = new JSONObject();
			JSONObject responseStatus = new JSONObject();
			responseStatus.put("code", "TIMEOUT");
			responseStatus.put("description", "SLA has been breached");
			if (odsParam != null) {
				serviceUtils.populateJsonPayload(odsParam.getValue(), responseStatus.toString(), contentSchema);
			}
			bonitaPayload.put("contents", contentSchema.get("contents"));
			
		} catch (Exception e) {
			LOGGER.warn(StatusCode.ERROR_ODS_PARAM_CONFIG_NOTCONFIGURED.getDesc() + ". " + e);
		}
		
		LOGGER.info("Exiting createPayloadtoCloseBonitaTask");
		return bonitaPayload.toString();
	}
	

	/**
	 * This method calls the SLA service to make an entry in SLA table
	 * @param slaUrl
	 * @param slaPayload
	 * @return String
	 * @throws ApplicationException
	 */
	@Async
	public String createSLAEntry(String slaPayload) throws ApplicationException {
		LOGGER.info("Entering createSLAEntry");
		
		JSONObject slaPayloadJSON = new JSONObject(slaPayload);
		String paramKey = serviceUtils.buildKey(slaPayloadJSON.getString(Constants.FLOW_PROCESS_NAME),
				slaPayloadJSON.getString(Constants.FLOW_STEP_NAME));
		OdsParamConfig odsParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(paramKey,
				OdsParamConfigType.WORKFLOW_CORRELATION_PARAM.toString(), Constants.CORRELATION_SCHEMA);
		if(odsParam == null) {
			return null;
		}
		/* Get Create Task SLA Service URL from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.APPLICATION_PARAM.toString(), Constants.CREATE_TASK_SLA_URL);
		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(), OdsParamConfigType.APPLICATION_PARAM.toString(),
							Constants.CREATE_TASK_SLA_URL, null));
		LOGGER.info("Create Task SLA Service URL : " + odsAppParam.getValue());
		
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(slaPayload, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(odsAppParam.getValue(), HttpMethod.POST, httpEntity, String.class);
		} catch (Exception e) {
			LOGGER.error("Error while calling SLA Service", e);
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Error while calling SLA Service. " + e.getMessage());
		}

		String slaCreateResponse;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			slaCreateResponse = responseEntity.getBody();
			if (StringUtils.isEmpty(slaCreateResponse)) {
				LOGGER.error("SLA create service response is Empty");
			}
		} else {
			LOGGER.error("Error Received failure response from SLA create Service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from SLA create Service");
		}

		LOGGER.info("SLA create service response is:::" + slaCreateResponse);
		LOGGER.info("Exiting createSLAEntry");
		return slaCreateResponse;
	}
	

	
}