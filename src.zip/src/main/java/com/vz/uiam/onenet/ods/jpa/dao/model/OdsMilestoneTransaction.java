package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

@Entity
@Table(name = "ods_milestone_transaction")
public class OdsMilestoneTransaction implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ods_milestone_transaction_id")
	private Integer odsMilestoneTransactionId;

	@Column(name = "root_case_id")
	private String rootCaseId;

	@Column(name = "process_name")
	private String processName;

	@Column(name = "step_name")
	private String stepName;

	@ManyToOne
	@JoinColumn(name = "ods_milestone_config_Id")
	private OdsMilestoneConfig odsMilestoneConfig;

	@Column(name = "manifest_payload")
	private String manifestPayload;

	@Column(name = "request_payload")
	private String requestPayload;

	@Column(name = "last_modified_ts")
	private Timestamp lastModifiedTs;

	@Column(name = "status")
	private String status;

	@Column(name = "status_desc")
	private String statusDesc;

	/**
	 * @return the odsMilestoneTransactionId
	 */
	public Integer getOdsMilestoneTransactionId() {
		return odsMilestoneTransactionId;
	}

	/**
	 * @param odsMilestoneTransactionId
	 *            the odsMilestoneTransactionId to set
	 */
	public void setOdsMilestoneTransactionId(Integer odsMilestoneTransactionId) {
		this.odsMilestoneTransactionId = odsMilestoneTransactionId;
	}

	/**
	 * @return the rootCaseId
	 */
	public String getRootCaseId() {
		return rootCaseId;
	}

	/**
	 * @param rootCaseId
	 *            the rootCaseId to set
	 */
	public void setRootCaseId(String rootCaseId) {
		this.rootCaseId = rootCaseId;
	}

	/**
	 * @return the processName
	 */
	public String getProcessName() {
		return processName;
	}

	/**
	 * @param processName
	 *            the processName to set
	 */
	public void setProcessName(String processName) {
		this.processName = processName;
	}

	/**
	 * @return the stepName
	 */
	public String getStepName() {
		return stepName;
	}

	/**
	 * @param stepName
	 *            the stepName to set
	 */
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}

	/**
	 * @return the odsMilestoneConfig
	 */
	public OdsMilestoneConfig getOdsMilestoneConfig() {
		return odsMilestoneConfig;
	}

	/**
	 * @param odsMilestoneConfig
	 *            the odsMilestoneConfig to set
	 */
	public void setOdsMilestoneConfig(OdsMilestoneConfig odsMilestoneConfig) {
		this.odsMilestoneConfig = odsMilestoneConfig;
	}

	/**
	 * @return the manifestPayload
	 */
	public String getManifestPayload() {
		return manifestPayload;
	}

	/**
	 * @param manifestPayload
	 *            the manifestPayload to set
	 */
	public void setManifestPayload(String manifestPayload) {
		this.manifestPayload = manifestPayload;
	}

	/**
	 * @return the requestPayload
	 */
	public String getRequestPayload() {
		return requestPayload;
	}

	/**
	 * @param requestPayload
	 *            the requestPayload to set
	 */
	public void setRequestPayload(String requestPayload) {
		this.requestPayload = requestPayload;
	}

   /**
	 * @return the lastModifiedTs
	 */
	public Timestamp getLastModifiedTs() {
		return lastModifiedTs;
	}

	/**
	 * @param lastModifiedTs the lastModifiedTs to set
	 */
	public void setLastModifiedTs(Timestamp lastModifiedTs) {
		this.lastModifiedTs = lastModifiedTs;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the statusDesc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * @param statusDesc
	 *            the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public OdsMilestoneTransaction(String rootCaseID2, String flowNodeProcessName, String flowNodeStepName) {
		super();
		this.rootCaseId = rootCaseID2;
		this.stepName = flowNodeStepName;
		this.processName = flowNodeProcessName;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public OdsMilestoneTransaction() {

	}

}
