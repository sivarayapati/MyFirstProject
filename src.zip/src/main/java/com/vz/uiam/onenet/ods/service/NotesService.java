package com.vz.uiam.onenet.ods.service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.jayway.jsonpath.JsonPath;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.util.ServiceUtils;


@Service
@Transactional(readOnly = false, rollbackFor=Exception.class)
public class NotesService {

	private static final Logger LOGGER = Logger.getLogger(ODSService.class);
	
	@Autowired
	OdsParamConfigRepository odsParamConfigRepository;
	
	@Autowired
	ServiceUtils serviceUtils;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	ODSService odsService;
	
	@Autowired
	OdsRequestLogRepository odsRequestLogRepository;
	
	
	/**
	 * API to store the request in Notes Service
	 *
	 * @param request
	 * 
	 * @return void
	 * 
	 */
	@Async
	public void addNotesForException(String request, Exception e) {
		LOGGER.info("Entering addNotesForException");
		
		JSONObject workflowRequest = new JSONObject(request);
		//Get title and title version
		JSONObject titleJsonObject = odsService.getTitleAndTitleVersion(workflowRequest);
		
		// Prepare notes payload JSON for transformation
		JSONObject notesJsonForTransformation = prepareNotesPayload(titleJsonObject.get("title").toString(),
				titleJsonObject.get("titleVersion").toString(), Constants.EXCEPTION_OCCURRED, e.toString(),
				workflowRequest.get("flowNodeStepName").toString());
		
		//Build Request Key
		String requestKey = serviceUtils.buildKey(workflowRequest.get("flowNodeProcessName").toString(),
				workflowRequest.get("flowNodeStepName").toString());
		
		// Add Notes for the Response
		addNotes(notesJsonForTransformation, requestKey);
		
		LOGGER.info("Exiting addNotesForException");
		
	}
	
	/**
	 * API to store the request in Notes Service
	 *
	 * @param OdsInterfaceRequest
	 * 				odsInterfaceReq
	 * @return void
	 * 
	 */
	@Async
	public void addNotesForException(OdsInterfaceRequest odsInterfaceReq, String originalResponse, ResponseStatus responseStatus) {
		LOGGER.info("Entering addNotesForException");
		
		OdsRequestLog odsRequestLog = odsRequestLogRepository.findByWfTaskId(odsInterfaceReq.getTaskId());
	
		//Get ResponseConfigParams record
		ResponseConfigParams responseConfigParam = null;
		try {
			responseConfigParam = (ResponseConfigParams) serviceUtils
					.convertJsonStringToObject(odsInterfaceReq.getResponseConfigParam(), ResponseConfigParams.class);
		} catch (ApplicationException e) {
			LOGGER.error("############Exception Occured while processing the retrieving ReponseConfigParam from odsInterfaceRequest#################"
					+ "ERROR DESCRIPTION IS:::::", e);
		}
		
		String notesText = Constants.EXCEPTION_OCCURRED+ ": "+ responseStatus.getCode()+", "+responseStatus.getDescription();
		// Prepare notes payload JSON for transformation
		JSONObject notesJsonForTransformation = prepareNotesPayload(odsRequestLog.getTitle(),
				odsRequestLog.getTitleVersion(), notesText, originalResponse,
				odsRequestLog.getWfTaskName(),responseConfigParam.getDestinationSystemName(), responseConfigParam.getSourceSystemName());
		
		//Get Workflow Request Payload to read process name
		JSONObject wfRequestJson = new JSONObject(odsRequestLog.getWfRequestPayload());
		
		//Build Request Key
		String requestKey = serviceUtils.buildKey(wfRequestJson.get("flowNodeProcessName").toString(),
				wfRequestJson.get("flowNodeStepName").toString());
		
		// Add Notes for the Response
		addNotes(notesJsonForTransformation, requestKey);
		
		LOGGER.info("Exiting addNotesForException");
		
	}
	
	
	/**
	 * API to store the request in Notes Service
	 *
	 * @param orderNumber
	 * @param orderVersion
	 * @param notesMsg
	 * @param payload
	 * @param stepName
	 * @param sourceSystem
	 * @param destinationSystem
	 * 
	 * @return notesJsonForTransformation
	 * @throws JSONException 
	 */
	public JSONObject prepareNotesPayload(String orderNumber, String orderVersion, String notesMsg, String payload, String stepName, String sourceSystem, String destinationSystem ) {
		LOGGER.info("Entering prepareNotesPayload");
		
		JSONObject notesJsonForTransformation = new JSONObject();
		notesJsonForTransformation.put("orderNumber", orderNumber);
		notesJsonForTransformation.put("orderVersion", orderVersion);
		notesJsonForTransformation.put("sourceSystem", sourceSystem);
		notesJsonForTransformation.put("destinationSystem", destinationSystem);
		notesJsonForTransformation.put("notesMsg", notesMsg);
		notesJsonForTransformation.put("request", payload);
		notesJsonForTransformation.put("flowStepName", stepName);
		
		LOGGER.debug("Prepared Notes Payload: " + notesJsonForTransformation.toString());
		LOGGER.info("Exiting prepareNotesPayload");
		
		return notesJsonForTransformation;
	}
	
	/**
	 * API to store the request in Notes Service
	 *
	 * @param orderNumber
	 * @param orderVersion
	 * @param notesMsg
	 * @param payload
	 * @param stepName
	 * 
	 * @return notesJsonForTransformation
	 * @throws JSONException 
	 */
	public JSONObject prepareNotesPayload(String orderNumber, String orderVersion, String notesMsg, String payload, String stepName) {
		LOGGER.info("Entering prepareNotesPayload");
		
		JSONObject notesJsonForTransformation = new JSONObject();
		notesJsonForTransformation.put("orderNumber", orderNumber);
		notesJsonForTransformation.put("orderVersion", orderVersion);
		notesJsonForTransformation.put("sourceSystem", "");
		notesJsonForTransformation.put("destinationSystem", "");
		notesJsonForTransformation.put("notesMsg", notesMsg);
		notesJsonForTransformation.put("request", payload);
		notesJsonForTransformation.put("flowStepName", stepName);

		LOGGER.debug("Prepared Notes Payload: " + notesJsonForTransformation.toString());
		LOGGER.info("Exiting prepareNotesPayload");
		
		return notesJsonForTransformation;
	}
	
	
	/**
	 * API to store the request in Notes Service
	 *
	 * @param requestKey 
	 * @param reqDocument 
	 * @throws JSONException 
	 */
	@Async
	public void addNotes(JSONObject reqDocument, String requestKey) {
		LOGGER.info("Entering addNotes");
		try {
			
			// Check if ODS Notes is enabled
			OdsParamConfig odsNotesToggleFlag = odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
					OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ENABLE_FLAG);
	
			if (odsNotesToggleFlag == null || !"TRUE".equalsIgnoreCase(odsNotesToggleFlag.getValue())) {
				LOGGER.info("ODS Notes is disabled. Hence not saving the notes !!");
				return;
			}
	
			Instant instant = Instant.now();
			
			String id = reqDocument.optString("orderNumber") + "|" + reqDocument.optString("orderVersion") + "|"
					+ System.currentTimeMillis();

			reqDocument.put("id", id);
			reqDocument.put("dateTime", instant.toString());

			JSONObject notePayLoad = validateAndBuildNotesPayload(reqDocument);
	        
			String notesPayLoad = notePayLoad.toString();
			
			// call the Notes AddOrUpdate Service
			addOrUpdateNotesPayLoad(notesPayLoad);
			
		} catch(Exception e) {
			LOGGER.error("Exception occurred while saving request in Notes Service - ", e);
		}

		LOGGER.info("Exiting addNotes");
	}
	
	/**
	 * API to store the request in Notes Service
	 *
	 * @param request
	 * @param transactionId
	 * @param flowStepName
	 * @throws JSONException
	 */
	@Async
	public void addRequestInNotesService(String request, String transactionId, String flowStepName, JSONObject reqDocument, String requestKey) {
		LOGGER.info("Entering addRequestInNotesService");
		try {
			// Check if ODS Notes is enabled
			OdsParamConfig odsNotesToggleFlag = odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
					OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ENABLE_FLAG);
	
			if (odsNotesToggleFlag == null || !"TRUE".equalsIgnoreCase(odsNotesToggleFlag.getValue())) {
				LOGGER.info("ODS Notes is disabled. Hence not saving the notes !!");
				return;
			}
	
			List<OdsParamConfig> paramConfigForNoteIdentifiers = odsParamConfigRepository.findByParamKeyAndType(requestKey,
					OdsParamConfigType.NOTES_PARAM.toString());
			if (paramConfigForNoteIdentifiers == null || CollectionUtils.isEmpty(paramConfigForNoteIdentifiers)) {
				LOGGER.info("ODS Notes Identifier is not configured. Hence not saving the notes !!");
				return;
			}
			
			JSONObject odsNotesIdentifiers = new JSONObject();
			for (OdsParamConfig paramConfigForNotesIdentifier : paramConfigForNoteIdentifiers) {
				odsNotesIdentifiers.put(paramConfigForNotesIdentifier.getName(), serviceUtils
						.readValueFromJson(reqDocument.toString(), paramConfigForNotesIdentifier.getValue()));
			}
			
			Instant instant = Instant.now();
			
			JSONObject noteRequestObj = new JSONObject();
			noteRequestObj.put("id", transactionId);
			noteRequestObj.put("notesMsg", "Successfully Sent - " + flowStepName + " request.");
			noteRequestObj.put("dateTime", instant.toString());
			noteRequestObj.put("request", request);
			noteRequestObj.put("odsNotesIdentifiers", odsNotesIdentifiers);
			noteRequestObj.put("flowStepName", flowStepName);
			String sourceSystemName = reqDocument.getString(Constants.SOURCE_SYSTEM_NAME); 
			noteRequestObj.put("sourceSystem", sourceSystemName != null ? sourceSystemName : "");
			String destinationSystemName = reqDocument.getString(Constants.DESTINATION_SYSTEM_NAME);
			noteRequestObj.put("destinationSystem", destinationSystemName != null ? destinationSystemName : "");
			
			JSONObject notePayLoad = new JSONObject();
	        notePayLoad=validateAndBuildNotesPayload(noteRequestObj);
			String notesPayLoad = notePayLoad.toString();
			// call the Notes AddOrUpdate Service
			addOrUpdateNotesPayLoad(notesPayLoad);
		} catch(Exception e) {
			LOGGER.error("Exception occurred while saving request in Notes Service - ", e);
		}

		LOGGER.info("Exiting addRequestInNotesService");
	}
	
	/**
	 * @param Notes Response payload
	 * @param response
	 * @param transactionId
	 * @return string notesPaload
	 */
	@Async
	public void updateResponseInNotes(String transactionId, String response, String requestKey) {
		LOGGER.info("NotesService - Entering updateResponseInNotes");
		try {
			String notesPayLoad;
	
			// Check if ODS Notes is enabled
			OdsParamConfig odsNotesToggleFlag = odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
					OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ENABLE_FLAG);
	
			if (odsNotesToggleFlag == null || !"TRUE".equalsIgnoreCase(odsNotesToggleFlag.getValue())) {
				LOGGER.info("ODS Notes is disabled. Hence not saving the notes !!");
				return;
			}
	
			List<OdsParamConfig> odsNotesIdentifiers = odsParamConfigRepository.findByParamKeyAndType(requestKey,
					OdsParamConfigType.NOTES_PARAM.toString());
			if (odsNotesIdentifiers == null || CollectionUtils.isEmpty(odsNotesIdentifiers)) {
				LOGGER.info("ODS Notes Identifier is not configured. Hence not saving the notes !!");
				return;
			}
	
			JSONObject notesGetPayLoadObject =  getNotesInfoById(transactionId);
			notesGetPayLoadObject.put("responseMessage", response );
			notesGetPayLoadObject.put("response_date_time_t", Instant.now().toString());
			JSONObject notesPayLoadObject =  new JSONObject();		
			notesPayLoadObject.put("doc", notesGetPayLoadObject);
			JSONObject notePayLoadfinal = new JSONObject();
			notePayLoadfinal.put("add", notesPayLoadObject);
			notesPayLoad = notePayLoadfinal.toString();
			
			// call the Notes AddOrUpdate Service
			addOrUpdateNotesPayLoad(notesPayLoad);
		} catch(Exception e) {
			LOGGER.error("Exception occurred while saving response in Notes Service - ", e);
		}

		LOGGER.info("NotesService - Exiting updateResponseInNotes");
	}
	
	/**
	 * API to Get the Notes info By ID
	 * @param id
	 * @throws ApplicationException
	 */
	public JSONObject getNotesInfoById(String id) throws ApplicationException {
		LOGGER.info("Entering getNotesInfoById");

		JSONObject jsonData = new JSONObject();
		jsonData.put("id", id);
		String finalData = jsonData.toString();
		/* Get NOTES_GET_URL from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_GET_URL);
		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(), OdsParamConfigType.ODS_PARAM.toString(),
							Constants.NOTES_GET_URL, null));
		LOGGER.info("Notes Get URL : " + odsAppParam.getValue());

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(finalData, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(odsAppParam.getValue(), HttpMethod.POST, httpEntity, String.class);
		} catch (Exception e) {
			LOGGER.error("Error while getting Notes GET INFO - ", e);
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Error while getting Notes GET INFO. " + e.getMessage());
		}

		String response;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			response = responseEntity.getBody();
		} else {
			LOGGER.error("Received failure response from Notes GET service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from Notes GET service");
		}


		JSONObject jsonResponse = new JSONObject(response);
		JSONObject responseJson = (JSONObject) jsonResponse.get("response");
		
		JSONObject docsObject;
		if (responseJson.getJSONArray("docs").opt(0) != null){
			JSONArray responseArr = responseJson.getJSONArray("docs");
			docsObject = (JSONObject) responseArr.get(0);
		} else {
			docsObject = new JSONObject();
		}
		LOGGER.info("Exiting getNotesInfoById");
		return docsObject;
	}
	
	/**
	 * API to addOrUpdate NotesPayLoad
	 * @param notesPayload
	 * @throws ApplicationException
	 */
	public void addOrUpdateNotesPayLoad(String notesPayload) throws ApplicationException {
		LOGGER.info("Entering addOrUpdateNotesPayLoad");

		/* Get NOTES_ADD_OR_UPDATE_URL from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ADD_OR_UPDATE_URL);
		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(), OdsParamConfigType.ODS_PARAM.toString(),
							Constants.NOTES_ADD_OR_UPDATE_URL, null));
		LOGGER.info("Notes AddOrUpdate URL : " + odsAppParam.getValue());

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(notesPayload, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(odsAppParam.getValue(), HttpMethod.POST, httpEntity, String.class);
		} catch (Exception e) {
			LOGGER.error("Error while getting Notes AddOrUpdate - ", e);
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Error while getting Notes AddOrUpdate. " + e.getMessage());
		}

		String response;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			response = responseEntity.getBody();
		} else {
			LOGGER.error("Received failure response from Notes AddOrUpdate service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from Notes AddOrUpdate service");
		}

		LOGGER.info("Exiting addOrUpdateNotesPayLoad");
	}
	/**
	 *validateAndBuildNotesPayload
	 *
	 * @param requestObj
	 * @return JSONObject
	 * @throws ApplicationException
	 */
	public JSONObject validateAndBuildNotesPayload(JSONObject requestObj) throws ApplicationException {
		LOGGER.info("Entering validateAndBuildNotesPayload");
		JSONObject notesPayload = new JSONObject();

		try {
			/* Get notes schema from App Param table */
			OdsParamConfig odsParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
					OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_SCHEMA);
			if (odsParam != null) {
				serviceUtils.populateJsonPayload(odsParam.getValue(), requestObj.toString(), notesPayload);
			}
		} catch (Exception e) {
			LOGGER.warn(StatusCode.ERROR_NOTES_NOTFOUND.getDesc() + ". " + e);
		}

		LOGGER.info("Exiting validateAndBuildNotesPayload");

		return notesPayload;
	}




}