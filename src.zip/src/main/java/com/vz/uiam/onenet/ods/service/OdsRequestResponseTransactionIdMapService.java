package com.vz.uiam.onenet.ods.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.jpa.impl.JPAQuery;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsResponseTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.QOdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.QOdsResponseTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestTransactionIdMapRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsResponseTransactionIdMapRepository;
import com.vz.uiam.onenet.ods.predicate.OdsTransactionIdMapSearchPredicate;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@Service
@Transactional(rollbackOn = { ApplicationException.class, Exception.class, RuntimeException.class })
public class OdsRequestResponseTransactionIdMapService {

	private static final Logger LOGGER = Logger.getLogger(OdsRequestResponseTransactionIdMapService.class);
	
	/**
	 * Transaction Id literal constant.
	 */
	private static final String TRANSACTION_ID_LITERAL = "transactionId";
	
	@Autowired
	OdsRequestTransactionIdMapRepository odsRequestRepo;
	
	@Autowired
	OdsResponseTransactionIdMapRepository odsResponseRepo;
	
	@Autowired
	ServiceUtils serviceUtils;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	/**
	 * API to create or Update a record in OdsRequestTransactionIdMap table
	 * 
	 * @param inputOdsRequest
	 * @return
	 * @throws ApplicationException
	 */
	public OdsRequestTransactionIdMap createOrUpdateOdsRequestTransIdMap(OdsRequestTransactionIdMap inputOdsRequest) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateOdsRequestTransIdMap");

		OdsRequestTransactionIdMap existingOdsRequest = null;
		
		if (inputOdsRequest.getId() != null) {
			existingOdsRequest = odsRequestRepo.findOne(inputOdsRequest.getId());

			if (existingOdsRequest == null)
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
						"OdsRequestTransactionIdMap record not found for ID - " + inputOdsRequest.getId());
			
			} else if (!StringUtils.isEmpty(inputOdsRequest.getFlowNodeProcessName())
				&& !StringUtils.isEmpty(inputOdsRequest.getFlowNodeStepName())) {
			existingOdsRequest = odsRequestRepo.findByFlowNodeProcessNameAndFlowNodeStepName(
					inputOdsRequest.getFlowNodeProcessName(), inputOdsRequest.getFlowNodeStepName());
			
		}
		
	   if (existingOdsRequest == null) {
			doOdsRequestTIdMapValidation(inputOdsRequest);
		}
		OdsRequestTransactionIdMap odsRequestTransactionIdMap = getUpdatedOdsRequestTransactionIdMapRecord(
																			inputOdsRequest, existingOdsRequest);
		OdsRequestTransactionIdMap newOdsRequestTransactionIdMap = odsRequestRepo.save(odsRequestTransactionIdMap);

		LOGGER.info("Exiting createOrUpdateOdsRequestTransIdMap");
		return newOdsRequestTransactionIdMap;
	}
	
	/**
	 * API to retrieve OdsRequestTransactionIdMap records
	 * 
	 * @param odsRequestTransactionIdMap
	 * @return
	 * @throws ApplicationException
	 */
	public List<OdsRequestTransactionIdMap> getOdsRequestTransIdMapRecords(OdsRequestTransactionIdMap odsRequestTransactionIdMap) throws ApplicationException {
		LOGGER.info("Entering getOdsRequestTransIdMapRecords");
		
		if (StringUtils.isEmpty(odsRequestTransactionIdMap.getFlowNodeProcessName()) && StringUtils.isEmpty(odsRequestTransactionIdMap.getFlowNodeStepName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Please provide either flowNodeProcessName or flowNodeStepName");
		
		List<OdsRequestTransactionIdMap> odsRequestTIdMapRspList = null;
		QOdsRequestTransactionIdMap odsRequestTransIDMapQdsl= QOdsRequestTransactionIdMap.odsRequestTransactionIdMap;
		OdsTransactionIdMapSearchPredicate searchPredicate= new OdsTransactionIdMapSearchPredicate();
		
		JPAQuery query = getJPAQryInstance();
		
		try {
			odsRequestTIdMapRspList = query.from(odsRequestTransIDMapQdsl)
					.where(searchPredicate.isTransactionIdKey(odsRequestTransactionIdMap.getTransactionIdKey()),
							searchPredicate.isFlowNodeProcessNameLike(odsRequestTransactionIdMap.getFlowNodeProcessName()),
							searchPredicate.isFlowNodeStepNameLike(odsRequestTransactionIdMap.getFlowNodeStepName()))
					.list(new QOdsRequestTransactionIdMap(odsRequestTransIDMapQdsl));
		} catch (Exception e) {
			LOGGER.error("Error while getting OdsRequestTransactionIdMap - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while getting OdsRequestTransactionIdMap. " + e.getMessage());
		}
		
		LOGGER.info("Exiting getOdsRequestTransIdMapRecords");
		return odsRequestTIdMapRspList;
	}

	
	/**
	 * API to delete the OdsRequestTransactionIdMap records
	 * 
	 * @param odsRequestTransIdMapList
	 * @throws ApplicationException
	 */
	public void deleteOdsRequestTransIdMapRecord(List<OdsRequestTransactionIdMap> odsRequestTransIdMapList) throws ApplicationException {
		LOGGER.info("Entering deleteOdsRequestTransIdMapRecord");
		
		try {
			for (OdsRequestTransactionIdMap odsRequestTIdMap : odsRequestTransIdMapList) {
				if (odsRequestTIdMap.getId() != null) {
					odsRequestRepo.delete(odsRequestTIdMap.getId());
				} else if (!StringUtils.isEmpty(odsRequestTIdMap.getFlowNodeProcessName()) &&
						!StringUtils.isEmpty(odsRequestTIdMap.getFlowNodeStepName())) {
					
					OdsRequestTransactionIdMap existingOdsRequestTIdMap = odsRequestRepo.findByFlowNodeProcessNameAndFlowNodeStepName(
							odsRequestTIdMap.getFlowNodeProcessName(), odsRequestTIdMap.getFlowNodeStepName());
					
					if (existingOdsRequestTIdMap != null)
						odsRequestRepo.delete(existingOdsRequestTIdMap);
					else
						throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Record not found for the given input."
								+ " flowNodeProcessName[" + odsRequestTIdMap.getFlowNodeProcessName() + "]" + ", flowNodeStepName[" + odsRequestTIdMap.getFlowNodeStepName() + "]" );
				}else {
					throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Provide either [Id] or [flowNodeProcessName, flowNodeStepName and transactionIdKey]");
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error while deleting OdsRequestTransactionIdMap records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while deleting OdsRequestTransactionIdMap records. " + e.getMessage());
		}
		
		LOGGER.info("Exiting deleteOdsRequestTransIdMapRecord");
	}
	
	/**
	 * API to update the input OdsRequestTransactionIdMap record with the exiting one 
	 * 
	 * @param inputOdsRequest
	 * @param existingOdsRequest
	 * @return
	 * @throws ApplicationException 
	 */
	public OdsRequestTransactionIdMap getUpdatedOdsRequestTransactionIdMapRecord(OdsRequestTransactionIdMap inputOdsRequest,
			OdsRequestTransactionIdMap existingOdsRequest) throws ApplicationException {
		LOGGER.info("Entering getUpdatedOdsRequestTransactionIdMapRecord");
		
		if (existingOdsRequest == null)
			return inputOdsRequest;
		
		if (!StringUtils.isEmpty(inputOdsRequest.getFlowNodeProcessName()))
			existingOdsRequest.setFlowNodeProcessName(inputOdsRequest.getFlowNodeProcessName());
		
		if (!StringUtils.isEmpty(inputOdsRequest.getFlowNodeStepName()))
			existingOdsRequest.setFlowNodeStepName(inputOdsRequest.getFlowNodeStepName());
		
		if (!StringUtils.isEmpty(inputOdsRequest.getTransactionIdKey()))
			existingOdsRequest.setTransactionIdKey(inputOdsRequest.getTransactionIdKey());
			
		LOGGER.info("Exiting getUpdatedOdsRequestTransactionIdMapRecord");
		return existingOdsRequest;
	}
	
	
	/**
	 * API to do validation on input OdsRequestTransactionIdMap record
	 * 
	 * @param odsRequestTransactionIdMap
	 * @throws ApplicationException
	 */
	public void doOdsRequestTIdMapValidation(OdsRequestTransactionIdMap odsRequestTransactionIdMap) throws ApplicationException {
		LOGGER.info("Entering doOdsRequestTIdMapValidation");
		
		if (StringUtils.isEmpty(odsRequestTransactionIdMap.getFlowNodeProcessName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "FlowNodeProcessName is null or empty");
		if (StringUtils.isEmpty(odsRequestTransactionIdMap.getFlowNodeStepName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "FlowNodeStepName is null or empty");
		if (StringUtils.isEmpty(odsRequestTransactionIdMap.getTransactionIdKey()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "TransactionIdKey is null or empty");
			
		LOGGER.info("Exiting doOdsRequestTIdMapValidation");
	}
	/**
	 * API to create or Update a record in OdsRequestTransactionIdMap table
	 * 
	 * @param inputOdsRequest
	 * @return
	 * @throws ApplicationException
	 */
	public OdsResponseTransactionIdMap createOrUpdateOdsResponseTransIdMap(OdsResponseTransactionIdMap inputOdsResponse) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateOdsRequestTransIdMap");
		
		OdsResponseTransactionIdMap existingOdsResponse = null;
		
		if (inputOdsResponse.getId()!= null) {
			existingOdsResponse = odsResponseRepo.findOne(inputOdsResponse.getId());
			
			if (existingOdsResponse == null)
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "OdsResponseTransactionIdMap record not found for ID - " + inputOdsResponse.getId());
		} else if (!StringUtils.isEmpty(inputOdsResponse.getRootTagName())) {
			existingOdsResponse = odsResponseRepo.findByRootTagName(inputOdsResponse.getRootTagName());
		}
		
		if (existingOdsResponse == null) {
			doOdsResponseTIdMapValidation(inputOdsResponse);
		}
		
		OdsResponseTransactionIdMap newOdsResponseTransactionIdMap = odsResponseRepo.save(getUpdatedOdsResponseTransactionIdMapRecord(inputOdsResponse, existingOdsResponse));
		
		LOGGER.info("Exiting createOrUpdateOdsRequestTransIdMap");
		return newOdsResponseTransactionIdMap;
	}
	
	/**
	 * API to get the TRANSACTION_ID from JSON Response
	 * 
	 * @param response
	 * @param transactionIdRspKey
	 * @return Integer
	 * @throws ApplicationException
	 */
	public String generateTransactionIdUsingTransactionIdKey(String response, String transactionIdRspKey)
			throws ApplicationException {
		LOGGER.info("Entering generateTransactionIdUsingTransactionIdKey");
		String transactionId = null;
		JSONObject obj = new JSONObject();
		try {
			serviceUtils.populateValues(OdsRequestResponseTransactionIdMapService.TRANSACTION_ID_LITERAL,
					transactionIdRspKey, response, obj);
			transactionId = obj.getString(OdsRequestResponseTransactionIdMapService.TRANSACTION_ID_LITERAL);
		} catch (Exception e) {
			LOGGER.error("Error while getting TRANSACTION_ID from the JSON response - ", e);
			throw new ApplicationException(StatusCode.INTERNAL_ERROR.getCode(),
					"Error while getting TRANSACTION_ID from the JSON response. " + e.getMessage());
		}

		if (transactionId == null)
			throw new ApplicationException(StatusCode.TRANSACTION_ID_NOT_FOUND.getCode(),
					StatusCode.TRANSACTION_ID_NOT_FOUND.getDesc());

		LOGGER.info("Exiting generateTransactionIdUsingTransactionIdKey");
		return transactionId;
	}
	
	/**
	 * API to retrieve OdsResponseTransactionIdMap records
	 * 
	 * @param odsResponseTransactionIdMap
	 * @return
	 * @throws ApplicationException
	 */
	public List<OdsResponseTransactionIdMap> getOdsResponseTransIdMapRecords(OdsResponseTransactionIdMap odsResponseTransactionIdMap) throws ApplicationException {
		LOGGER.info("Entering getOdsResponseTransIdMapRecords");
		
		List<OdsResponseTransactionIdMap> odsResponseTIdMapRspList = null;
		QOdsResponseTransactionIdMap odsResponseTransIDMapQdsl= QOdsResponseTransactionIdMap.odsResponseTransactionIdMap;
		OdsTransactionIdMapSearchPredicate searchPredicate= new OdsTransactionIdMapSearchPredicate();
		
		JPAQuery query = getJPAQryInstance();
		
		try {
			odsResponseTIdMapRspList = query.from(odsResponseTransIDMapQdsl)
					.where(searchPredicate.isResTransactionIdKey(odsResponseTransactionIdMap.getTransactionIdKey()),
							searchPredicate.isRootTagNameLike(odsResponseTransactionIdMap.getRootTagName()))
					.list(new QOdsResponseTransactionIdMap(odsResponseTransIDMapQdsl));
		} catch (Exception e) {
			LOGGER.error("Error while getting QOdsResponseTransactionIdMap - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while getting QOdsResponseTransactionIdMap. " + e.getMessage());
		}
		
		LOGGER.info("Exiting getOdsRequestTransIdMapRecords");
		return odsResponseTIdMapRspList;
	}
	
	/**
	 * API to delete the OdsRequestTransactionIdMap records
	 * 
	 * @param odsRequestTransIdMapList
	 * @throws ApplicationException
	 */
	public void deleteOdsResponseTransIdMapRecord(List<OdsResponseTransactionIdMap> odsResponseTransIdMapList) throws ApplicationException {
		LOGGER.info("Entering deleteOdsResponseTransIdMapRecord");
		
		try {
			for (OdsResponseTransactionIdMap odsResponseTIdMap : odsResponseTransIdMapList) {
				if (odsResponseTIdMap.getId() != null) {
					odsResponseRepo.delete(odsResponseTIdMap.getId());
				} else if (!StringUtils.isEmpty(odsResponseTIdMap.getRootTagName())) {
					
					OdsResponseTransactionIdMap existingOdsResponseTIdMap = odsResponseRepo.findByRootTagName(odsResponseTIdMap.getRootTagName());
					
					if (existingOdsResponseTIdMap != null)
						odsResponseRepo.delete(existingOdsResponseTIdMap);
					else
						throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Record not found for the given input."
								+ " RootTagName[" +odsResponseTIdMap.getRootTagName() + "]");
				}else {
					throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Provide either [Id] or [RootTagName]");
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error while deleting OdsResponseTransactionIdMap records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while deleting OdsResponseTransactionIdMap records. " + e.getMessage());
		}
		
		LOGGER.info("Exiting deleteOdsResponseTransIdMapRecord");
	}
	
	/**
	 * API to update the input OdsResponseTransactionIdMap record with the exiting one 
	 * 
	 * @param inputOdsResponse
	 * @param existingOdsResponse
	 * @return
	 * @throws ApplicationException 
	 */
	public OdsResponseTransactionIdMap getUpdatedOdsResponseTransactionIdMapRecord(OdsResponseTransactionIdMap inputOdsResponse,
			OdsResponseTransactionIdMap existingOdsResponse) throws ApplicationException {
		LOGGER.info("Entering getUpdatedOdsResponseTransactionIdMapRecord");
		
		if (existingOdsResponse == null)
			return inputOdsResponse;
		
		if (!StringUtils.isEmpty(inputOdsResponse.getRootTagName()))
			existingOdsResponse.setRootTagName(inputOdsResponse.getRootTagName());
		
		if (!StringUtils.isEmpty(inputOdsResponse.getTransactionIdKey()))
			existingOdsResponse.setTransactionIdKey(inputOdsResponse.getTransactionIdKey());
			
		LOGGER.info("Exiting getUpdatedOdsResponseTransactionIdMapRecord");
		return existingOdsResponse;
	}
	
	
	/**
	 * API to do validation on input OdsResponseTransactionIdMap record
	 * 
	 * @param odsResponseTransactionIdMap
	 * @throws ApplicationException
	 */
	public void doOdsResponseTIdMapValidation(OdsResponseTransactionIdMap odsResponseTransactionIdMap) throws ApplicationException {
		LOGGER.info("Entering doOdsResponseTIdMapValidation");
		
		if (StringUtils.isEmpty(odsResponseTransactionIdMap.getRootTagName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "rootTagName is null or empty");
		if (StringUtils.isEmpty(odsResponseTransactionIdMap.getTransactionIdKey()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "transactionIdKey is null or empty");
				
		LOGGER.info("Exiting doOdsResponseTIdMapValidation");
	}
	
	/**
	 * @param flowNodeProcessName
	 * @param flowNodeStepName
	 * @return
	 * @throws ODSRequestValidationException
	 */
	public OdsRequestTransactionIdMap findByFlowNodeProcessNameAndFlowNodeStepName(String flowNodeProcessName,
			String flowNodeStepName) {
		return odsRequestRepo.findByFlowNodeProcessNameAndFlowNodeStepName(flowNodeProcessName, flowNodeStepName);
	}
	
	public JPAQuery getJPAQryInstance() {
		return new JPAQuery(entityManager);
	}
}
