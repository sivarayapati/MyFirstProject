/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The Data Model class for WF_DECISION_PARAMS
 * @author v130073
 *
 */
@Entity
@Table(name = "tbl_wf_decision_params")
public class OdsWorkflowParams implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	OdsWorkflowParamsId odsWorkflowParamsId;

	@Column(name = "wf_param_value")
	private String wfParamValue;

	
	public OdsWorkflowParams() {
		
	}
	
	
	/**
	 * @param rootCaseId
	 * @param wfParamName
	 * @param wfParamValue
	 */
	public OdsWorkflowParams(Integer rootCaseId, String wfParamName, String wfParamValue) {
		this.odsWorkflowParamsId = new OdsWorkflowParamsId();
		this.odsWorkflowParamsId.setRootCaseId(rootCaseId);
		this.odsWorkflowParamsId.setWfParamName(wfParamName);
		this.wfParamValue = wfParamValue;
	}
	
	/**
	 * 
	 * @return odsWorkflowParamsId
	 */
	public OdsWorkflowParamsId getOdsWorkflowParamsId() {
		return odsWorkflowParamsId;
	}

	/**
	 * 
	 * @param odsWorkflowParamsId
	 */
	public void setOdsWorkflowParamsId(OdsWorkflowParamsId odsWorkflowParamsId) {
		this.odsWorkflowParamsId = odsWorkflowParamsId;
	}

	/**
	 * @return wfParamValue
	 */
	public String getWfParamValue() {
		return wfParamValue;
	}

	/**
	 * @param wfParamValue
	 */
	public void setWfParamValue(String wfParamValue) {
		this.wfParamValue = wfParamValue;
	}

	
	
	/**
	 * @param odsWorkflowParamsId
	 * @param wfParamValue
	 */
	public OdsWorkflowParams(OdsWorkflowParamsId odsWorkflowParamsId, String wfParamValue) {
		this.odsWorkflowParamsId = odsWorkflowParamsId;
		this.wfParamValue = wfParamValue;
	}


	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
