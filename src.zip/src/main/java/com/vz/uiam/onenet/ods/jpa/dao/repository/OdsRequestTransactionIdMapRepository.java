package com.vz.uiam.onenet.ods.jpa.dao.repository;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;



/**
 * @author Anand
 *
 */
@Transactional
@Repository
public interface OdsRequestTransactionIdMapRepository extends JpaRepository<OdsRequestTransactionIdMap, Integer> {

	/**
	 * @param processName
	 * @param stepName
	 * @return OdsRequestTransactionIdMap
	 */
	@Cacheable(value="odsRequestTransactionIdMap", key="#p0.concat('|').concat(#p1)", unless="#result == null", condition="#p0!=null && #p1!=null")
	public OdsRequestTransactionIdMap findByFlowNodeProcessNameAndFlowNodeStepName(String processName,String stepName);
	
	@CacheEvict(value = "odsRequestTransactionIdMap", key="#p0.flowNodeProcessName.concat('|').concat(#p0.flowNodeStepName)",condition="#p0.flowNodeProcessName!=null && #p0.flowNodeStepName!=null")
	public OdsRequestTransactionIdMap save(OdsRequestTransactionIdMap odsRequestTransactionIdMap);

}