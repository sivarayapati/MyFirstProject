package com.vz.uiam.onenet.ods.jpa.dto.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class OdsMilestoneTransactionRequest {

    private String rootCaseId;
    private Integer odsMilestoneTransactionId;
    private String reProcessFlag;

    public String getRootCaseId() {
	return rootCaseId;
    }

    public void setRootCaseId(String rootCaseId) {
	this.rootCaseId = rootCaseId;
    }

   
    public Integer getOdsMilestoneTransactionId() {
        return odsMilestoneTransactionId;
    }

    public void setOdsMilestoneTransactionId(Integer odsMilestoneTransactionId) {
        this.odsMilestoneTransactionId = odsMilestoneTransactionId;
    }

    public String getReProcessFlag() {
	return reProcessFlag;
    }

    public void setReProcessFlag(String reProcessFlag) {
	this.reProcessFlag = reProcessFlag;
    }

    @Override
    public String toString() {
	return ToStringBuilder.reflectionToString(this);
    }
}
