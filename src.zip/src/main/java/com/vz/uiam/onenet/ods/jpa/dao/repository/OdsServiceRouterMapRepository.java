/**
 *
 */
package com.vz.uiam.onenet.ods.jpa.dao.repository;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;


/**
 * @author Anand
 *
 */
@Transactional
@Repository
public interface OdsServiceRouterMapRepository extends JpaRepository<OdsServiceRouterMapDetails, Integer> {
	
	@Cacheable(value="odsServiceRoute", key="#p0.concat('|').concat(#p1)", unless="#result == null", condition="#p0!=null && #p1!=null")
	public OdsServiceRouterMapDetails findByFlowNodeProcessNameAndFlowNodeStepName(String flowNodeProcessName, String flowNodeStepName);

	@Cacheable(value="odsServiceRoute", key="#p0.concat('|').concat(#p1).concat('|').concat(#p2)", unless="#result == null", condition="#p0!=null && #p1!=null && #p2!=null")
	public OdsServiceRouterMapDetails findByFlowNodeProcessNameAndFlowNodeStepNameAndRegion(String flowNodeProcessName, String flowNodeStepName, String region);

	public OdsServiceRouterMapDetails findByAppKeyAndFlowNodeProcessNameAndFlowNodeStepName(String appKey, String flowNodeProcessName, String flowNodeStepName);
	
	@Caching(evict = {
			  @CacheEvict(value = "odsServiceRoute", key="#p0.flowNodeProcessName.concat('|').concat(#p0.flowNodeStepName)",condition="#p0.flowNodeProcessName!=null && #p0.flowNodeStepName!=null"),
			  @CacheEvict(value = "odsServiceRoute", key="#p0.flowNodeProcessName.concat('|').concat(#p0.flowNodeStepName).concat('|').concat(#p0.region)",condition="#p0.flowNodeProcessName!=null && #p0.flowNodeStepName!=null && #p0.region!=null")
			})
	public OdsServiceRouterMapDetails save(OdsServiceRouterMapDetails orsServiceRouterMap);
	
}