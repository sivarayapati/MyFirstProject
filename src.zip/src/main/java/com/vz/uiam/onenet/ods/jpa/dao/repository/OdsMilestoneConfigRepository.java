package com.vz.uiam.onenet.ods.jpa.dao.repository;

import java.util.List;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;

/**
 * @author Ashish
 *
 */
@Transactional
@Repository
public interface OdsMilestoneConfigRepository extends JpaRepository<OdsMilestoneConfig, Integer> {

	@Cacheable(value="milestoneConfig", key="#p0.concat('|').concat(#p1)", unless="#result == null", condition="#p0!=null && #p1!=null")
	List<OdsMilestoneConfig> findByFlowNodeProcessNameAndFlowNodeStepName(String flowNodeProcessName,String flowNodeStepName);
	
	@Cacheable(value="milestoneConfig", key="#p0.concat('|').concat(#p1).concat('|').concat(#p2)", unless="#result == null", condition="#p0!=null && #p1!=null && #p2!=null")
	public OdsMilestoneConfig findByFlowNodeStepNameAndFlowNodeProcessNameAndMilestoneName(String flowNodeStepName,String flowNodeProcessName, String milestoneName);
	
	
	@Caching(evict = {
			  @CacheEvict(value = "milestoneConfig", key="#p0.flowNodeProcessName.concat('|').concat(#p0.flowNodeStepName)",condition="#p0.flowNodeProcessName!=null && #p0.flowNodeStepName!=null"),
			  @CacheEvict(value = "milestoneConfig", key="#p0.flowNodeStepName.concat('|').concat(#p0.flowNodeProcessName).concat('|').concat(#p0.milestoneName)",condition="#p0.flowNodeProcessName!=null && #p0.flowNodeStepName!=null && #p0.milestoneName!=null")
			})
	public OdsMilestoneConfig save(OdsMilestoneConfig odsMilestoneConfig);
	
}