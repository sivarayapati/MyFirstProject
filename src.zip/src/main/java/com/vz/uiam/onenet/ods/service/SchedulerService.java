package com.vz.uiam.onenet.ods.service;


import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsSchedulerLock;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFallout;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsSchedulerLockRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.WorkflowFalloutRepo;
import com.vz.uiam.onenet.ods.util.ServiceUtils;



/**
 * @author ODS
 *
 */
@Service("schedulerService")
public class SchedulerService {

	private static final Logger LOGGER = Logger.getLogger(SchedulerService.class);

	@Autowired
	OdsRequestLogRepository odsRequestLogRepository;

	@Autowired
	ODSResponseHandler odsResponseHandler;

	@Autowired
	OdsInterfaceRequestRepository odsInterfaceRequestRepository;

	@Autowired
	ServiceUtils serviceUtils;

	@Autowired
	FalloutService falloutService;

	@Autowired
	OdsRequestLogService odsRequestLogService;

	@Autowired
	OdsSchedulerLockRepository odsSchedulerLockRepository;

	@Autowired
	BonitaService bonitaService;
	
	@Autowired
	WorkflowFalloutRepo fallOutRepo;
	
	@Autowired
	OdsParamConfigRepository odsParamConfigRepo;

	@Scheduled(initialDelay=60000*5, fixedDelay = 60000*1)
	public void monitorPendingTasks() {

		LOGGER.info("Entering monitorPendingTasks");

		try {
			OdsSchedulerLock odsSchdulerLock = odsSchedulerLockRepository
					.findByLockKeyAndLockValue(Constants.ODS_TASK_TIMER_KEY, Constants.ODS_SCHEDULER_SWITCH_OFF);

			if (odsSchdulerLock != null) {
				odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_ON);
				odsSchedulerLockRepository.save(odsSchdulerLock);
				LOGGER.info("Marking the Scheduler Switch ON and start monitoring task time out");

				// LOGIC EXCECUTION BEGINS
				// Get list of expired entries
				List<OdsRequestLog> expiredEntries = odsRequestLogRepository
						.findByWfTaskStatusAndResponseStatusAndExpiryTimeBefore(
								Constants.ODS_REQUEST_LOG_STATUS_PENDING, Constants.ODS_REQUEST_LOG_STATUS_PENDING,
								serviceUtils.getCurrentTimestamp());

				for (OdsRequestLog expiredEntry : expiredEntries) {
					try {
						List<OdsInterfaceRequest> odsInterfaceRequests = odsInterfaceRequestRepository
								.findByTaskIdAndStatus(expiredEntry.getWfTaskId(), Constants.STATUS_REQUEST_PENDING);

						if (odsInterfaceRequests != null && !odsInterfaceRequests.isEmpty()) {
							LOGGER.info("Expired Entry with Task ID : " + expiredEntry.getWfTaskId());
							// Create or Update UTE Task BEGINS
							JSONObject handleFalloutReqJson = new JSONObject(expiredEntry.getWfRequestPayload());
							handleFalloutReqJson.put(Constants.FALLOUT_ERROR_CODE, StatusCode.TASK_TIMEOUT.getCode());
							handleFalloutReqJson.put(Constants.FALLOUT_STEP_NAME, expiredEntry.getWfTaskName());
							JSONObject uteTaskListDocumentPayload = falloutService
									.getUteTaskListdocument(handleFalloutReqJson);
							falloutService.createOrUpdateUTETaskForFallout(handleFalloutReqJson,
									uteTaskListDocumentPayload);
							// Create or Update UTE Task ENDS

							// Save status as TIME_OUT BEGINS
							expiredEntry.setResponseStatus(Constants.STATUS_TIME_OUT);
							expiredEntry.setLastModifiedTime(serviceUtils.getCurrentTimestamp());
							odsRequestLogRepository.save(expiredEntry);

							for (OdsInterfaceRequest odsInterfaceRequest : odsInterfaceRequests) {
								odsInterfaceRequest.setStatus(Constants.STATUS_TIME_OUT);
								odsInterfaceRequestRepository.save(odsInterfaceRequest);
							}
							// Save status as TIME_OUT ENDS
						}
					} catch (ApplicationException ae) {
						LOGGER.error(
								"Application Exception while creating/updating UTE task for timedout task : " + ae);
						expiredEntry
								.setExpiryTime(odsRequestLogService.getRequestLogExpiryTime(serviceUtils.getCurrentTimestamp()));
						odsRequestLogRepository.save(expiredEntry);
					} catch (Exception e) {
						LOGGER.error("Exception while creating/updating UTE task for timedout task : " + e);
						expiredEntry
								.setExpiryTime(odsRequestLogService.getRequestLogExpiryTime(serviceUtils.getCurrentTimestamp()));
						odsRequestLogRepository.save(expiredEntry);
					}
				}
				// LOGIC EXCECUTION ENDS

				odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_OFF);
				odsSchedulerLockRepository.save(odsSchdulerLock);
				LOGGER.info("Completed monitoring task time out. Marking the Scheduler Switch OFF");
			} else {
				LOGGER.info("Sheduler Switch is ON. So skipping monitoring");
			}

		} catch (Exception e) {
			LOGGER.error("Exception while monitoring task for time out : " + e);
			OdsSchedulerLock odsSchdulerLock = odsSchedulerLockRepository
					.findByLockKeyAndLockValue(Constants.ODS_TASK_TIMER_KEY, Constants.ODS_SCHEDULER_SWITCH_ON);
			if (odsSchdulerLock != null) {
				odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_OFF);
				odsSchedulerLockRepository.save(odsSchdulerLock);
			}
		}

		LOGGER.info("Exiting monitorPendingTasks");
	}

	@Scheduled(initialDelay=60000*1/2, fixedDelay = 60000*1)
	public void retryBonitaTaskCompletion() {

		LOGGER.info("Entering retryBonitaTaskCompletion");
		try {
			// Get Scheduler Lock
			OdsSchedulerLock odsSchdulerLock = odsSchedulerLockRepository.findByLockKeyAndLockValue(
					Constants.ODS_RETRY_BONITA_TASK_COMPLETION_KEY, Constants.ODS_SCHEDULER_SWITCH_OFF);

			// if Get Scheduler Lock is OFF, turn it ON and perform core logic
			if (odsSchdulerLock != null) {
				odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_ON);
				odsSchedulerLockRepository.save(odsSchdulerLock);
				LOGGER.info("Marking the Scheduler Switch ON and start retrying bonita task completion");

				// LOGIC EXCECUTION BEGINS
				// Get list of failed task status whose response status is success
				List<OdsRequestLog> failedEntries = odsRequestLogRepository
						.findByWfTaskStatusAndResponseStatus(Constants.FAILURE, Constants.SUCCESS);
				for (OdsRequestLog failedEntry : failedEntries) {
					falloutService.closeBonitaTask(failedEntry);
				}
				// LOGIC EXCECUTION ENDS

				// Turn OFF the lock and exit
				odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_OFF);
				odsSchedulerLockRepository.save(odsSchdulerLock);
				LOGGER.info("Completed retrying bonita task completion. Marking the Scheduler Switch OFF");

			} else {
				LOGGER.info("Scheduler Switch is ON. So skipping retry bonita task completion");
			}

		} catch (Exception e) {
			LOGGER.error("Exception while retrying bonita task completion : " + e);
			OdsSchedulerLock odsSchdulerLock = odsSchedulerLockRepository.findByLockKeyAndLockValue(
					Constants.ODS_RETRY_BONITA_TASK_COMPLETION_KEY, Constants.ODS_SCHEDULER_SWITCH_ON);
			if (odsSchdulerLock != null) {
				odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_OFF);
				odsSchedulerLockRepository.save(odsSchdulerLock);
			}

		}
		LOGGER.info("Exiting retryBonitaTaskCompletion");
	}

	
	@Scheduled(initialDelay=60000*1/2, fixedDelay = 60000*1)
	public void retryFailedTasks() {

		LOGGER.info("Entering retryFailedTasks");
		try {
			// Get Scheduler Lock
			OdsSchedulerLock odsSchdulerLock = odsSchedulerLockRepository
					.findByLockKeyAndLockValue(Constants.ODS_RETRY_FAILED_TASK, Constants.ODS_SCHEDULER_SWITCH_OFF);

			// if Get Scheduler Lock is OFF, turn it ON and perform core logic
			if (odsSchdulerLock != null) {
				odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_ON);
				odsSchedulerLockRepository.save(odsSchdulerLock);
				LOGGER.info("Marking the Scheduler Switch ON and start retrying faild tasks");

				// LOGIC EXCECUTION BEGINS
				// Get list of expired pending fallouts
				List<WorkflowFallout> expiredPendingFallouts = fallOutRepo
						.getByStatusAndExpiryTimeBefore(Constants.STATUS_PENDING, serviceUtils.getCurrentTimestamp());
				for (WorkflowFallout fallout : expiredPendingFallouts) {
					OdsRequestLog odsRequestLog = odsRequestLogRepository
							.findByWfTaskIdAndResponseStatus(fallout.getWfTaskId(), Constants.FAILURE);
					if (odsRequestLog != null) {
						fallout.setWorkFlowStepRetryCounter(fallout.getWorkFlowStepRetryCounter() + 1);
						fallout.setExpiryTime(null);
						fallOutRepo.save(fallout);
						serviceUtils.callService(OdsParamConfigType.ODS.toString(),
								OdsParamConfigType.APPLICATION_PARAM.toString(), "asyncOdsRequestProxy",
								odsRequestLog.getWfRequestPayload());
					}
				}
				// LOGIC EXCECUTION ENDS

				// Turn OFF the lock and exit
				odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_OFF);
				odsSchedulerLockRepository.save(odsSchdulerLock);
				LOGGER.info("Completed retrying failed tasks. Marking the Scheduler Switch OFF");
			} else {
				LOGGER.info("Scheduler Switch is ON. So skipping retry failed tasks");
			}

		} catch (Exception e) {
			LOGGER.error("Exception while retrying failed tasks : " + e);
			OdsSchedulerLock odsSchdulerLock = odsSchedulerLockRepository
					.findByLockKeyAndLockValue(Constants.ODS_RETRY_FAILED_TASK, Constants.ODS_SCHEDULER_SWITCH_ON);
			if (odsSchdulerLock != null) {
				odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_OFF);
				odsSchedulerLockRepository.save(odsSchdulerLock);
			}

		}
		LOGGER.info("Exiting retryFailedTasks");
	}


}
