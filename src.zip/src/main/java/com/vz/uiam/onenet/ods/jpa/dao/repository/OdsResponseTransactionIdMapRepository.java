package com.vz.uiam.onenet.ods.jpa.dao.repository;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsResponseTransactionIdMap;



/**
 * @author Anand
 *
 */
@Transactional
@Repository
public interface OdsResponseTransactionIdMapRepository extends JpaRepository<OdsResponseTransactionIdMap, Integer> {
	
	/**
	 * @param roottagname
	 * @return OdsResponseTransactionIdMap
	 */
	@Cacheable(value="odsResponseTransactionIdMap", key="#p0", unless="#result == null", condition="#p0!=null")
	public OdsResponseTransactionIdMap  findByRootTagName(String rootTagName);
	
	@CacheEvict(value="odsResponseTransactionIdMap", key="#p0.rootTagName", condition="#p0.rootTagName!=null")
	public OdsResponseTransactionIdMap save(OdsResponseTransactionIdMap odsResponseTransactionIdMap);
	
}