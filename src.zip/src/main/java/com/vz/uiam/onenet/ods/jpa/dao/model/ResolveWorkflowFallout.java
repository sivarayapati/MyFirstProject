/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The Data Model class for SERVICE_ROUTE_MAP_TABLE
 * @author Kiran
 *
 */
@Entity
@Table(name = "ods_workflow_fallout")
public class ResolveWorkflowFallout implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "case_id",unique=true)
	private String caseId;
	
	@Column(name = "workflow_step_name")
	private String workFlowStepName;

	@Column(name = "workflow_retry_counter")
	private int workFlowStepRetryCounter;
	
	@Column(name="workflow_process_name")
	private String workFlowProcessName;

	@Column(name = "status")
	private String status;

	@Column(name = "workflow_fallout_error_code")
	private String workFlowFalloutErrorCode;
	
	@Column(name = "workflow_fallout_error_desc")
	private String workFlowFalloutErrorDesc;
	
	@Column(name = "workflow_fallout_error_category")
	private String workFlowFalloutErrorCategory;
	
	@Column(name = "root_case_id")
	private String rootCaseId;

	public String getWorkFlowFalloutErrorCategory() {
		return workFlowFalloutErrorCategory;
	}

	public void setWorkFlowFalloutErrorCategory(String workFlowFalloutErrorCategory) {
		this.workFlowFalloutErrorCategory = workFlowFalloutErrorCategory;
	}

	public String getRootCaseId() {
		return rootCaseId;
	}

	public void setRootCaseId(String rootCaseId) {
		this.rootCaseId = rootCaseId;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the caseId
	 */
	public String getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId the caseId to set
	 */
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return the workFlowStepName
	 */
	public String getWorkFlowStepName() {
		return workFlowStepName;
	}

	/**
	 * @param workFlowStepName the workFlowStepName to set
	 */
	public void setWorkFlowStepName(String workFlowStepName) {
		this.workFlowStepName = workFlowStepName;
	}

	public String getWorkFlowProcessName() {
		return workFlowProcessName;
	}

	public void setWorkFlowProcessName(String workFlowProcessName) {
		this.workFlowProcessName = workFlowProcessName;
	}

	/**
	 * @return the workFlowStepRetryCounter
	 */
	public int getWorkFlowStepRetryCounter() {
		return workFlowStepRetryCounter;
	}

	/**
	 * @param workFlowStepRetryCounter the workFlowStepRetryCounter to set
	 */
	public void setWorkFlowStepRetryCounter(int workFlowStepRetryCounter) {
		this.workFlowStepRetryCounter = workFlowStepRetryCounter;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the workFlowFalloutErrorCode
	 */
	public String getWorkFlowFalloutErrorCode() {
		return workFlowFalloutErrorCode;
	}

	/**
	 * @param workFlowFalloutErrorCode the workFlowFalloutErrorCode to set
	 */
	public void setWorkFlowFalloutErrorCode(String workFlowFalloutErrorCode) {
		this.workFlowFalloutErrorCode = workFlowFalloutErrorCode;
	}

	/**
	 * @return the workFlowFalloutErrorDesc
	 */
	public String getWorkFlowFalloutErrorDesc() {
		return workFlowFalloutErrorDesc;
	}

	/**
	 * @param workFlowFalloutErrorDesc the workFlowFalloutErrorDesc to set
	 */
	public void setWorkFlowFalloutErrorDesc(String workFlowFalloutErrorDesc) {
		this.workFlowFalloutErrorDesc = workFlowFalloutErrorDesc;
	}
	
	public ResolveWorkflowFallout() {
		// TODO Auto-generated constructor stub
	}
	
	
	/**
	 * @param id
	 * @param caseId
	 * @param workFlowStepName
	 * @param workFlowStepRetryCounter
	 * @param status
	 * @param workFlowFalloutErrorCode
	 * @param workFlowFalloutErrorDesc
	 */
	public ResolveWorkflowFallout(String caseId, String workFlowStepName,
			int workFlowStepRetryCounter, String status, String workFlowFalloutErrorCode,
			String workFlowFalloutErrorDesc) {
		this.caseId = caseId;
		this.workFlowStepName = workFlowStepName;
		this.workFlowStepRetryCounter = workFlowStepRetryCounter;
		this.status = status;
		this.workFlowFalloutErrorCode = workFlowFalloutErrorCode;
		this.workFlowFalloutErrorDesc = workFlowFalloutErrorDesc;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}