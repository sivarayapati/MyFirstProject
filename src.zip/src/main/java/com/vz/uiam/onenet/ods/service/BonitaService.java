package com.vz.uiam.onenet.ods.service;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

/**
 * @author ODS
 *
 */
@Service
public class BonitaService {
	private static final Logger LOGGER = Logger.getLogger(BonitaService.class);

	
	@Autowired
	OdsInterfaceRequestRepository odsRequestRepo;

	@Autowired
	OdsParamConfigRepository odsParamConfigRepository;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired 
	ServiceUtils serviceUtils;
	

	

	/**
	 * API to close the task in Bonita
	 *
	 * @param correlationData
	 * @param contentData
	 * @throws ApplicationException
	 */
	public void completeBonitaReceiveTask(String correlationData) throws ApplicationException {
		LOGGER.info("Entering closeTaskInBonita");

		
		LOGGER.info("Bonita payload - " + correlationData);

		/* Get CLOSE_BONITA_TASK_URL from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.CLOSE_BONITA_TASK_URL);
		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(), OdsParamConfigType.ODS_PARAM.toString(),
							Constants.CLOSE_BONITA_TASK_URL, null));
		LOGGER.info("Bonita close task URL : " + odsAppParam.getValue());

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(correlationData, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = serviceUtils.callService(odsAppParam, httpEntity);

		String response;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			response = responseEntity.getBody();
		} else {
			LOGGER.error("Received failure response from close bonita task service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from close bonita task service");
		}

		LOGGER.info("Response :::" + response);
		LOGGER.info("Exiting closeTaskInBonita");
	}

	
}