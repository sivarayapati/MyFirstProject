package com.vz.uiam.onenet.ods.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneTransaction;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dto.model.MileStoneRequestObject;
import com.vz.uiam.onenet.ods.jpa.dto.model.MileStoneResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsMilestoneTransactionRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsMilestoneTransactionResponse;
import com.vz.uiam.onenet.ods.service.MilestoneService;
import com.vz.uiam.onenet.ods.service.ODSService;
import com.vz.uiam.onenet.ods.service.OdsServiceRouteMapService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/oneDispatcher/odsMilestoneTransaction")
public class OdsMilestoneTrasctionController {
    
    private static final Logger LOGGER = Logger.getLogger(OdsMilestoneConfigController.class);
	
	@Autowired
	MilestoneService milestoneService;
	
	@Autowired
	OdsServiceRouteMapService odsServiceRouteMapService;

	@Autowired
	@Lazy(value=true)
	ODSService odsService;
	
	@RequestMapping(value = "/get", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get MilestoneTransaction Details", notes = "Get MilestoneTransaction Details", response = OdsMilestoneTransactionResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved MilestoneTransaction Details", response = OdsMilestoneTransactionResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = " getOdsMilestoneTransactions Service is unavaialble") })
	public ResponseEntity<OdsMilestoneTransactionResponse> getOdsMilestoneTransactions(@RequestBody OdsMilestoneTransactionRequest request )
														throws ApplicationException {
		
		LOGGER.info("Entering getOdsMilestoneTransactions");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsMilestoneTransactionResponse response = new OdsMilestoneTransactionResponse();
		
		try {
			List<OdsMilestoneTransaction> odsMilestoneTransctionDetails =  milestoneService.getMilestoneTransctionDetails(request.getRootCaseId());
			
			if(null == odsMilestoneTransctionDetails) {
				statusCode = StatusCode.DATA_NOT_FOUND.getCode();
				statusMsg = StatusCode.DATA_NOT_FOUND.getDesc();
			}
			
			response.setOdsMilestoneTransactionList(odsMilestoneTransctionDetails);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting getOdsMilestoneTransactions");

		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/retry", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get retry status for Milestone Transaction", notes = "Get retry status for Milestone Transaction", response = OdsMilestoneTransactionResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retried  MilestoneTransaction", response = OdsMilestoneTransactionResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "get retryOdsMilestoneTransactions Service is unavaialble") })
	public ResponseEntity<OdsMilestoneTransactionResponse> retryOdsMilestoneTransactions(@RequestBody OdsMilestoneTransactionRequest request )
														throws ApplicationException {
		
		LOGGER.info("Entering retryOdsMilestoneTransactions");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsMilestoneTransactionResponse response = new OdsMilestoneTransactionResponse();
		
		try {
			OdsMilestoneTransaction odsMilestoneTransctionDetails =  milestoneService.retryMilestoneTransaction(request);
			
			if(null == odsMilestoneTransctionDetails) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsMilestoneTransaction(odsMilestoneTransctionDetails);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}
		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting retryOdsMilestoneTransactions");

		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/sendMilestone", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Send Milestone or Notifications", notes = "Send Milestone or Notifications", response = MileStoneRequestObject.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Send Milestone", response = MileStoneRequestObject.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = " sendMilestone Service is unavaialble") })
	public ResponseEntity<MileStoneResponse> sendMilestone(@RequestBody String request) throws ApplicationException {

		LOGGER.info("Entering sendMilestone");

		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();

		MileStoneResponse response = new MileStoneResponse();

		try {
			JSONObject requestJson = new JSONObject(request);
			MileStoneRequestObject mileStoneRequestObject = new MileStoneRequestObject();
			mileStoneRequestObject.setFlowNodeProcessName(requestJson.getString(Constants.FLOW_PROCESS_NAME));
			mileStoneRequestObject.setFlowNodeStepName(requestJson.getString(Constants.FLOW_STEP_NAME));
			mileStoneRequestObject.setAppKey(requestJson.getString(Constants.MANIFEST_APP_KEY_STR));
			mileStoneRequestObject.setRootCaseID(requestJson.getString(Constants.ROOT_CASE_ID));
			// Get the ODS Service Router Map Details
			OdsServiceRouterMapDetails details = odsServiceRouteMapService.getServiceRouterMapDetails(
					requestJson.getString(Constants.FLOW_PROCESS_NAME), requestJson.getString(Constants.FLOW_STEP_NAME),
					requestJson.optString(Constants.ODS_REGION));
			String manifestPayload = odsService.validateAndBuildManifestPayload(requestJson, details);
			mileStoneRequestObject.setManifestPayload(manifestPayload);
			milestoneService.sendMilestone(mileStoneRequestObject);

			response.setStatusCode(statusCode);
			response.setStatusDesc(statusMsg);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);

		LOGGER.info("Exiting sendMilestone");

		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
}
