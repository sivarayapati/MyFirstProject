/**
 * 
 */
package com.vz.uiam.onenet.ods.transformer;

import com.vz.uiam.onenet.ods.constants.Constants;

/**
 * @author Anand Badiger
 *
 */
public class TranformerFactory {

	/**
	 * @param tranformerType
	 * @return Transformer
	 */
	public static Transformer getTransformerInstance(String tranformerType){
		if(Constants.TRANSFORMATION_XML_TYPE.equalsIgnoreCase(tranformerType)){
			return new XMLTransformer();
		}else if(Constants.TRANSFORMATION_JSON_TYPE.equalsIgnoreCase(tranformerType)){
			return new JSONTransformer();
			
		}
		return null;
	}
	
	/**
	 * 
	 */
	private TranformerFactory() {
		//no-arg constructor
	}
}
