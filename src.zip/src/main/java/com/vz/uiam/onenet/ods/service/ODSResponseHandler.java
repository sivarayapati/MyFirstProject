/**
 *
 */
package com.vz.uiam.onenet.ods.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsResponseTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFallout;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsResponseTransactionIdMapRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.WorkflowFalloutRepo;
import com.vz.uiam.onenet.ods.jpa.dto.model.MileStoneRequestObject;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsTransformerConfigDto;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.jpa.dto.model.WorkflowFalloutRequest;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

/**
 * @author Ashish Goyal
 *
 */
@Service
public class ODSResponseHandler {

	private static final Logger LOGGER = Logger.getLogger(ODSResponseHandler.class);

	@Autowired
	ServiceUtils serviceUtils;

	@Autowired
	WorkflowParamService workflowParamService;

	@Autowired
	FalloutService falloutService;

	@Autowired
	OdsParamConfigRepository odsParamConfigRespository;

	@Autowired
	OdsInterfaceRequestRepository odsRequestRepo;

	@Autowired
	OdsResponseTransactionIdMapRepository odsResponseTransactionIdMapRepository;
	
	@Autowired
	NotesService notesService;
	
	@Autowired
	MilestoneService milestoneService;
	
	@Autowired
	OdsTransformerConfigService odsTransformerConfigService;
	
	@Autowired
	ManifestService manifestService;
	
	@Autowired 
	OdsRequestLogRepository odsRequestLogRepository;
	
	@Autowired
	BonitaService bonitaService;
	
	@Autowired
	OdsMandatoryAttrsService odsMandatoryAttrsService;
	
	@Autowired
	WorkflowFalloutRepo fallOutRepo;
	
	/**
	 * API to process the response document
	 *
	 * @param response
	 * @param odsInterfaceRequest
	 * @throws ApplicationException
	 */
	public ResponseStatus processResponse(String response, OdsInterfaceRequest odsInterfaceRequest, ResponseConfigParams responseConfigParam, String requestKey) throws ApplicationException {
		LOGGER.info("Entering processResponse");

		String appKey = responseConfigParam.getAppKey();
		
		//Get ODS_Request_log table entry
		OdsRequestLog odsRequestLog = odsRequestLogRepository.findByWfTaskId(odsInterfaceRequest.getTaskId());
		
		// Get status from the response
		ResponseStatus status = parseStatusFromResponse(response, requestKey);
		LOGGER.info("Response status : " + status);

		if(status.isSuccess())
			status = checkMandatoryAttributesInResponse(response, requestKey, status);
		
		if (status.isSuccess()) {
			// Update the status in OdsInterfaceRequest
						odsInterfaceRequest.setStatus(StatusCode.SUCCESS.toString());
						odsRequestRepo.save(odsInterfaceRequest);
						if(odsRequestLog !=null) {
							falloutService.updateStatusAndExpiryTimeByWfTaskIdAndStatus(Constants.STATUS_PENDING,odsRequestLog.getWfTaskId());
						}

			// Create or update the manifest payload with the configured
			// response params in Params table / schema in transfomer config
			parseResponseParamsAndUpdateManifestDoc(odsInterfaceRequest, response, requestKey);

			// Create of update Workflow Params
			createOrUpdateWorkflowParams(responseConfigParam, response, appKey);

			if (odsRequestLog != null) {
				// Close UTE task if any
				JSONObject workflowRequest = new JSONObject(odsRequestLog.getWfRequestPayload());
				falloutService.closePendingUteTasks(workflowRequest);

				// Update Response_Status to 'SUCCESS' in ods_request_log table
				odsRequestLog.setResponseStatus(Constants.SUCCESS);
				odsRequestLog.setExpiryTime(null);
				odsRequestLog.setLastModifiedTime(serviceUtils.getCurrentTimestamp());
				odsRequestLogRepository.save(odsRequestLog);

				// Do not proceed further if Wf_task_status is SUCCESS
				if (Constants.SUCCESS.equals(odsRequestLog.getWfTaskStatus())) {
					LOGGER.info("Wf_task_status is already SUCCESS. So, exiting processResponse");
					return status;
				}
			}

			// Transform content schema
			String correlationSchema = odsInterfaceRequest.getCoreleationPayload();
			String finalCorrelationData = null;
			if (StringUtils.isNotEmpty(correlationSchema)) {

				String correlationContent = prepareCorrelationContent(status, response, requestKey);

				JSONObject finalCorrelationJsonData = serviceUtils.mergeJSONObjects(new JSONObject(correlationSchema),
						new JSONObject(correlationContent));
				finalCorrelationData = finalCorrelationJsonData.toString();
				LOGGER.info("Bonita payload - " + finalCorrelationData);
			}

			// Update ods_request_log WF_Task_Completion_Payload with merged correlations
			// and contents
			if (odsRequestLog != null) {
				odsRequestLog.setWfTaskCompletionPayload(finalCorrelationData);
				odsRequestLogRepository.save(odsRequestLog);
			}

			// Complete WF Receive Task
			if (StringUtils.isNotEmpty(correlationSchema)) {
				try {
					bonitaService.completeBonitaReceiveTask(finalCorrelationData);

					// Update WF_Task_Status to 'SUCCESS' in ods_request_log table
					if (odsRequestLog != null) {
						odsRequestLog.setWfTaskStatus(Constants.SUCCESS);
						Timestamp currentTimestamp = serviceUtils.getCurrentTimestamp();
						odsRequestLog.setLastModifiedTime(currentTimestamp);
						odsRequestLog.setCompletionTime(currentTimestamp);
						odsRequestLogRepository.save(odsRequestLog);
					}

				} catch (Exception ex) {
					LOGGER.error("Exception while completing Bonita task : " + ex);
					// Update WF_Task_Status to 'FAILURE' in ods_request_log table
					if (odsRequestLog != null) {
						odsRequestLog.setWfTaskStatus(Constants.FAILURE);
						odsRequestLog.setLastModifiedTime(serviceUtils.getCurrentTimestamp());
						odsRequestLogRepository.save(odsRequestLog);
					}

					throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
							"Failure while closing Bonita task");
				}
			}

			validateAndSendMilestone(odsInterfaceRequest);
		} else {
			
			LOGGER.info("Failure response identified");
			// Update the status in OdsInterfaceRequest
			odsInterfaceRequest.setStatus(StatusCode.FAILED.toString());
			odsRequestRepo.save(odsInterfaceRequest);
			// Update Response_Status to 'FAILURE' in ods_request_log table
			if(odsRequestLog!=null) {
				odsRequestLog.setResponseStatus(Constants.FAILURE);	
				odsRequestLog.setLastModifiedTime(serviceUtils.getCurrentTimestamp());
				odsRequestLogRepository.save(odsRequestLog);
				LOGGER.info("Failure response identified");
			}
			
			JSONObject statusObjectJson = new JSONObject(status);
			
			//add notes as we are creating fallout
			notesService.addNotesForException(odsInterfaceRequest, statusObjectJson.toString(), status);
			
			// create fallout
			createFallout(responseConfigParam, status);
			
			if(odsRequestLog!=null)
				handleFallout(status, responseConfigParam, odsRequestLog);
		}
		LOGGER.info("Exiting processResponse");
		return status;
	}
	
	
	
	public void handleFallout(ResponseStatus status, ResponseConfigParams responseConfigParam, OdsRequestLog odsRequestLog) {
		JSONObject handleFalloutReqJson = new JSONObject(odsRequestLog.getWfRequestPayload());
		handleFalloutReqJson.put(Constants.FALLOUT_ERROR_CODE, status.getCode());
		handleFalloutReqJson.put(Constants.FALLOUT_STEP_NAME, responseConfigParam.getFlowNodeStepName());
		String handleFalloutReq = handleFalloutReqJson.toString();
		falloutService.handleFallout(handleFalloutReq, odsRequestLog);
	}
	
	/**
	 * API to process the response document
	 *
	 * @param response
	 * @param odsInterfaceRequest
	 * @throws ApplicationException
	 */
	public ResponseStatus processResponse(String response, OdsInterfaceRequest odsInterfaceRequest) throws ApplicationException {
		LOGGER.info("Entering processResponse");

		ResponseConfigParams responseConfigParam = null;
		// convert Response Config Param JSON String to Object
		responseConfigParam = (ResponseConfigParams) serviceUtils
						.convertJsonStringToObject(odsInterfaceRequest.getResponseConfigParam(), ResponseConfigParams.class);
		LOGGER.info("######responseConfigParam retrived in response processing########: " + responseConfigParam);
		// Prepare the request key
		String requestKey = buildKey(responseConfigParam.getFlowNodeProcessName(), responseConfigParam.getFlowNodeStepName());
		String appKey = responseConfigParam.getAppKey();

		LOGGER.info("Request Key : " + requestKey);
		LOGGER.info("App Key : " + appKey);

		// Get status from the response
		ResponseStatus status = parseStatusFromResponse(response, requestKey);
		LOGGER.info("Response status : " + status);

		if (status.isSuccess()) {
			// Update the status in OdsInterfaceRequest
			odsInterfaceRequest.setStatus(StatusCode.SUCCESS.toString());

			// Create or update the manifest payload with the configured
			// response params in Params table / schema in transfomer config
			parseResponseParamsAndUpdateManifestDoc(odsInterfaceRequest, response, requestKey);

			// Create of update Workflow Params
			createOrUpdateWorkflowParams(responseConfigParam, response, appKey);

			validateAndSendMilestone(odsInterfaceRequest);
		} else {
			// Update the status in OdsInterfaceRequest
			odsInterfaceRequest.setStatus(StatusCode.FAILED.toString());
						
			// create fallout
			createFallout(responseConfigParam, status);
		}

		String correlationSchema = odsInterfaceRequest.getCoreleationPayload();
		if (StringUtils.isNotEmpty(correlationSchema)) {

			String correlationContent = prepareCorrelationContent(status, response, requestKey);
			if (StringUtils.isNotEmpty(correlationContent)) {
				// Complete Bonita waitActivity
				closeTaskInBonita(correlationSchema, correlationContent);
			}
		}


		LOGGER.info("Exiting processResponse");
		return status;
	}

	/**
	 * API to check whether Milestone need to be send or not.
	 *
	 * @param responseConfigParam
	 * @param odsInterfaceRequest
	 * @return
	 * @throws ApplicationException
	 */
	public void validateAndSendMilestone(OdsInterfaceRequest odsInterfaceRequest) throws ApplicationException {
		LOGGER.info("Entering validateAndSendMilestone");
		ResponseConfigParams responseConfigParam = null;
		// convert Response Config Param JSON String to Object
		responseConfigParam = (ResponseConfigParams) serviceUtils
				.convertJsonStringToObject(odsInterfaceRequest.getResponseConfigParam(), ResponseConfigParams.class);
		LOGGER.info("######responseConfigParam retrived in response processing########: " + responseConfigParam);

		if (responseConfigParam.isSendMilestone() == null || !responseConfigParam.isSendMilestone()) {
			LOGGER.info("Milestone is NOT Enabled for ProcessName :: " + responseConfigParam.getFlowNodeProcessName()
					+ " and StepName :: " + responseConfigParam.getFlowNodeStepName());
			return;
		}
		// Prepatre MilestoneRequest object and send milestone.
		// Send Milestone if configured
		
		MileStoneRequestObject mileStoneRequestObject= new MileStoneRequestObject(responseConfigParam.getFlowNodeProcessName(), 
				responseConfigParam.getFlowNodeStepName(),odsInterfaceRequest.getManifestPayload(),responseConfigParam.getRootCaseID(), responseConfigParam.getAppKey());
		milestoneService.sendMilestone(mileStoneRequestObject);

		LOGGER.info("Exiting validateAndSendMilestone");
	}


	/**
	 * API to get the TransactionId Key from the OdsResponseTransactionIdMap
	 * for the give rootTagName
	 *
	 * @param rootTagName
	 * @return
	 * @throws ApplicationException
	 */
	public String getTransIdKeyFromOdsRespTransIdMap(String rootTagName) throws ApplicationException {
		LOGGER.info("Entering getTransIdKeyFromOdsRespTransIdMap");

		OdsResponseTransactionIdMap odsResponseTransactionIdMap = odsResponseTransactionIdMapRepository.findByRootTagName(rootTagName);

		if (odsResponseTransactionIdMap == null || StringUtils.isEmpty(odsResponseTransactionIdMap.getTransactionIdKey()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					"TransactionId key is not configured in OdsResponseTransactionIdMap for root tag - " + rootTagName);

		LOGGER.info("Exiting getTransIdKeyFromOdsRespTransIdMap");
		return odsResponseTransactionIdMap.getTransactionIdKey();
	}


	/**
	 * API to get the get OdsInterfaceRequest record for the input transactionId and status
	 *
	 * @param transactionId
	 * @param status
	 * @return
	 * @throws ApplicationException
	 */
	public OdsInterfaceRequest getOdsInterfaceRequestByTransactionIdAndStatus(String transactionId, String status) throws ApplicationException {
		LOGGER.info("Entering getOdsInterfaceRequestByTransactionIdAndStatus");

		OdsInterfaceRequest odsInterfaceRequest = odsRequestRepo.findByTransactionIdAndStatus(transactionId, status);

		if (odsInterfaceRequest == null)
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					"No Pending record found in OdsInterfaceRequest for transactionId - " + transactionId);

		LOGGER.info("Exiting getOdsInterfaceRequestByTransactionIdAndStatus");
		return odsInterfaceRequest;
	}


	/**
	 * ODS Redesign - Build a key based on workflow process name and task name
	 * to store the co-relation for the given step.
	 *
	 * @param requestObj
	 * @return String
	 */
	private String buildKey(String flowNodeProcessName, String flowNodeStepName) {
		return new StringBuffer(flowNodeProcessName).append(Constants.KEYBUILDER_SEPERATOR).append(flowNodeStepName)
				.toString();
	}
	
	
	private ResponseStatus checkMandatoryAttributesInResponse(String response, String requestKey, ResponseStatus status) throws ApplicationException {
		LOGGER.info("Entering checkMandatoryAttributesInResponse");

		ResponseStatus respStatus = new ResponseStatus();
		String statusCode = status.getCode();
		String statusDesc = status.getDescription();
		boolean isSuccess = status.isSuccess();

		/* Get Status code schema from App Param table */
		List<OdsMandatoryAttributes> odsMandatoryAttributes = getMandatoryResponseAttributes(requestKey);
		for(OdsMandatoryAttributes mandatoryAttribute : odsMandatoryAttributes) {
			String value = serviceUtils.readValueFromJson(response, mandatoryAttribute.getJsonPath());
			if(value == null || StringUtils.isEmpty(value)) {
				statusCode = StatusCode.ERROR_MANDATORY_ATTRIB_IN_RESPONSE_EMPTY.getCode();
				statusDesc = StatusCode.ERROR_MANDATORY_ATTRIB_IN_RESPONSE_EMPTY.getDesc();
				isSuccess = false;
				break;
			}
		}
		respStatus.setCode(statusCode);
		respStatus.setDescription(statusDesc);
		respStatus.setSuccess(isSuccess);

		LOGGER.info("Exiting checkMandatoryAttributesInResponse");
		return respStatus;
	}



	/**
	 * API to parse the response from response
	 *
	 * @param response
	 * @return
	 * @throws ApplicationException
	 */
	private ResponseStatus parseStatusFromResponse(String response, String requestKey) throws ApplicationException {
		LOGGER.info("Entering parseStatusFromResponse");

		OdsParamConfig odsStatusCodeParam = getOdsParamConfigFromRequestKey(requestKey,Constants.STATUS_CODE_SCHEMA);
		OdsParamConfig odsSuccessStatusCodeParam =  getOdsParamConfigFromRequestKey(requestKey,Constants.STATUS_CODE_SUCCESS_VAL);
		OdsParamConfig odsStatusDescParam =  getOdsParamConfigFromRequestKey(requestKey,Constants.STATUS_DESC_SCHEMA);
		OdsParamConfig odsFailureCodeParam =  getOdsParamConfigFromRequestKey(requestKey,Constants.FAILURE_CODE_SCHEMA);
		OdsParamConfig odsFailureDescParam = getOdsParamConfigFromRequestKey(requestKey,Constants.FAILURE_DESC_SCHEMA);
		                                       
		ResponseStatus respStatus = setResponseStatus(response,odsStatusCodeParam,odsStatusDescParam,odsSuccessStatusCodeParam,odsFailureCodeParam,odsFailureDescParam);
		
		LOGGER.info("Exiting parseStatusFromResponse");
		return respStatus;
	}
	
	/**
	 * @return
	 * @throws ApplicationException
	 */
	public List<OdsMandatoryAttributes> getMandatoryResponseAttributes(String requestKey) throws ApplicationException {
		String attrKey = requestKey + Constants.MANDATORY_RSP_PARAM_SUFFIX;
		List<OdsMandatoryAttributes> odsMandatoryAtttributes = odsMandatoryAttrsService.getMandatoryAttributeList(attrKey);
		return odsMandatoryAtttributes;
	}

	/**
	 * @return
	 * @throws ApplicationException
	 */
	
	public OdsParamConfig getOdsParamConfigFromRequestKey(String requestKey,String constant) throws ApplicationException {
		OdsParamConfig odsParam = odsParamConfigRespository.findByParamKeyAndTypeAndName(requestKey,
				OdsParamConfigType.RESPONSE_STATUS_PARAM.toString(),constant);
		return odsParam;
	}
	
	public ResponseConfigParams getResponseConfigParams(OdsInterfaceRequest odsInterfaceReq) throws ApplicationException{
		//Get ResponseConfigParams record
		ResponseConfigParams responseConfigParam = (ResponseConfigParams) serviceUtils
				.convertJsonStringToObject(odsInterfaceReq.getResponseConfigParam(), ResponseConfigParams.class);
		
		return responseConfigParam;
	}
	
	public String buildRequestKey(ResponseConfigParams responseConfigParam) {
		//Build Request Key
		String requestKey = serviceUtils.buildKey(responseConfigParam.getFlowNodeProcessName(),
				responseConfigParam.getFlowNodeStepName());
		
		return requestKey;
	}
	
	public void prepareNotesPayloadAddNotes(OdsRequestLog odsRequestLog, String message,String response,ResponseConfigParams responseConfigParam,String requestKey)  {
		// Prepare notes payload JSON for transformation
		JSONObject notesJsonForTransformation = notesService.prepareNotesPayload(odsRequestLog.getTitle(),
				odsRequestLog.getTitleVersion(),message, response,
				responseConfigParam.getFlowNodeStepName(), responseConfigParam.getDestinationSystemName(),
				responseConfigParam.getSourceSystemName());

		// Add Notes for the Response
		notesService.addNotes(notesJsonForTransformation, requestKey);
	}
		
	
	public ResponseStatus setResponseStatus(String response,OdsParamConfig odsStatusCodeParam, OdsParamConfig odsStatusDescParam,OdsParamConfig odsSuccessStatusCodeParam,OdsParamConfig odsFailureCodeParam,OdsParamConfig odsFailureDescParam) throws ApplicationException {
		LOGGER.info("Entering setResponseStatus method");
		String statusCode = "";
		String statusDesc = "";
		boolean isSuccess = false;
		ResponseStatus respStatus = new ResponseStatus();
		/* Get Status code schema from App Param table */
		if (null == odsStatusCodeParam || StringUtils.isEmpty(odsStatusCodeParam.getValue())) {
			statusCode = StatusCode.SUCCESS.getCode();
		} else {
			try {
				statusCode = serviceUtils.readValueFromJson(response, odsStatusCodeParam.getValue());
			} catch (ApplicationException ae) {
				LOGGER.error("JSON Path not found - ", ae);
				if(StringUtils.isEmpty(statusCode)) {
					statusCode = StatusCode.FAILED.getCode();
				}
			}
		}
		
		/* Get Status Description schema from App Param table */
		if (null == odsStatusDescParam || StringUtils.isEmpty(odsStatusDescParam.getValue())) {
			statusDesc = StatusCode.SUCCESS.getDesc();
		} else {
			try {
				statusDesc = serviceUtils.readValueFromJson(response, odsStatusDescParam.getValue());
			} catch (ApplicationException ae) {
				LOGGER.error("JSON Path not found - ", ae);
			}
		}
		
		
		/* Get Success value of Status code from App Param table */
		if (null == odsSuccessStatusCodeParam || statusCode.equalsIgnoreCase(odsSuccessStatusCodeParam.getValue()))
			isSuccess = true;
		else if (odsSuccessStatusCodeParam != null
				&& Constants.STATUS_CODE_NON_BLANK.equals(odsSuccessStatusCodeParam.getValue())
				&& StringUtils.isNotEmpty(statusCode)) {
			isSuccess = true;
			statusCode = StatusCode.SUCCESS.getCode();
			statusDesc = StatusCode.SUCCESS.getDesc();
		} else if (odsSuccessStatusCodeParam != null && StringUtils.isNotEmpty(odsSuccessStatusCodeParam.getValue())
				&& StringUtils.isEmpty(statusCode)) {
			statusCode = StatusCode.ERROR_RESPONSE_STATUS_PARAM_FAILURE.getCode();
			statusDesc = StatusCode.ERROR_RESPONSE_STATUS_PARAM_FAILURE.getDesc();
			
			/* Get Failure code schema from App Param table */
			if(odsFailureCodeParam !=null && StringUtils.isNotEmpty(odsFailureCodeParam.getValue())) {
				try {
					statusCode = serviceUtils.readValueFromJson(response, odsFailureCodeParam.getValue());
				} catch (ApplicationException ae) {
					LOGGER.error("JSON Path not found - ", ae);
					if (StringUtils.isEmpty(statusCode)) {
						statusCode = StatusCode.ERROR_RESPONSE_STATUS_PARAM_FAILURE.getCode();
					}
				}
			}

			/* Get Failure Description schema from App Param table */
			if (odsFailureDescParam !=null && StringUtils.isNotEmpty(odsFailureDescParam.getValue())) {
				try {
					statusDesc = serviceUtils.readValueFromJson(response, odsFailureDescParam.getValue());
				} catch (ApplicationException ae) {
					LOGGER.error("JSON Path not found - ", ae);
					statusDesc = StatusCode.ERROR_RESPONSE_STATUS_PARAM_FAILURE.getDesc();
				}
			}
			
		} else if (odsSuccessStatusCodeParam != null
				&& (!statusCode.equalsIgnoreCase(odsSuccessStatusCodeParam.getValue()))) {	
			/* Get Failure Description schema from App Param table */
			if (odsFailureDescParam !=null && StringUtils.isNotEmpty(odsFailureDescParam.getValue())) {
				try {
					statusDesc = serviceUtils.readValueFromJson(response, odsFailureDescParam.getValue());
				} catch (ApplicationException ae) {
					LOGGER.error("JSON Path not found - ", ae);
					statusDesc = StatusCode.ERROR_RESPONSE_STATUS_PARAM_FAILURE.getDesc();
				}
			}
		
	} else {
		    statusCode = StatusCode.FAILED.getCode();
		    statusDesc = StatusCode.FAILED.getDesc();
		}
		
		respStatus.setCode(statusCode);
		respStatus.setDescription(statusDesc);
		respStatus.setSuccess(isSuccess);

		LOGGER.info("Exiting setResponseStatus method");
		return respStatus;
				
	}
	
	public boolean checkForAckInResponse(String response,OdsInterfaceRequest odsInterfaceReq)throws ApplicationException {
		LOGGER.info("Entering checkForAckInResponse");		
		JSONObject originalResponse =  new JSONObject(response);
		if(originalResponse.has("acknowledgement")) {
			LOGGER.info("Ack found. Exiting checkForAckInResponse with Original Response");
			originalResponse =  new JSONObject(response);
			ResponseConfigParams responseConfigParam   = getResponseConfigParams(odsInterfaceReq);
			String requestKey = buildRequestKey(responseConfigParam);
			
			OdsParamConfig odsAckStatusCodeParam = getOdsParamConfigFromRequestKey(requestKey,Constants.ACK_STATUS_CODE_SCHEMA);
			OdsParamConfig odsAckSuccessStatusCodeParam = getOdsParamConfigFromRequestKey(requestKey,Constants.ACK_STATUS_CODE_SUCCESS_VAL);
			OdsParamConfig odsAckStatusDescParam = getOdsParamConfigFromRequestKey(requestKey,Constants.ACK_STATUS_DESC_SCHEMA);
			OdsParamConfig odsAckFailureCodeParam =  getOdsParamConfigFromRequestKey(requestKey,Constants.ACK_FAILURE_CODE_SCHEMA);
			OdsParamConfig odsAckFailureDescParam = getOdsParamConfigFromRequestKey(requestKey,Constants.ACK_FAILURE_DESC_SCHEMA);
			
			ResponseStatus	respStatus = setResponseStatus(response,odsAckStatusCodeParam,odsAckStatusDescParam,odsAckSuccessStatusCodeParam,odsAckFailureCodeParam,odsAckFailureDescParam);
			
			if (respStatus.isSuccess()) {
				//Get ODS_Request_log table entry
				OdsRequestLog odsRequestLog = odsRequestLogRepository.findByWfTaskId(odsInterfaceReq.getTaskId());
				if(odsRequestLog != null){
					prepareNotesPayloadAddNotes(odsRequestLog,Constants.ACK_RECEIVED_SUCCESSFULLY,response,responseConfigParam,requestKey);		
				}
				
			}else {
				throw new ApplicationException(respStatus.getCode(),respStatus.getDescription());
			}
			
		 return true;
		}	
		LOGGER.info("No Ack found. Exiting checkForAckInResponse with null");
		return false;
	}

	/**
	 * @param response
	 * @return String
	 * @throws ApplicationException
	 */
	public String prepareCorrelationContent(ResponseStatus status, String response, String requestKey) throws ApplicationException {
		LOGGER.info("Entering prepareCorrelationContent");

		OdsParamConfig odsParam = odsParamConfigRespository.findByParamKeyAndTypeAndName(requestKey,
				OdsParamConfigType.WORKFLOW_CORRELATION_PARAM.toString(), Constants.CONTENT_SCHEMA);
		if (odsParam == null) {
			LOGGER.info("No Content Schema configured.");
			return "{\"contents\":{}}";
		}
		
		String statusJsonStr = serviceUtils.convertObjectToJsonString(status);
		String finalJsonData = statusJsonStr;
		
		if (StringUtils.isNotEmpty(response)) {
			JSONObject finalJsonDataObj = serviceUtils.mergeJSONObjects(new JSONObject(statusJsonStr), new JSONObject(response));
			finalJsonData = finalJsonDataObj.toString();
		}

		JSONObject correlationJsonObj = new JSONObject();
		serviceUtils.populateJsonPayload(odsParam.getValue(), finalJsonData, correlationJsonObj);
		
		JSONObject contentsJsonObject = (JSONObject) correlationJsonObj.get(Constants.CONTENTS);
		for(Object key: contentsJsonObject.keySet()){
			if(contentsJsonObject.getString(key.toString()) == null || "".equals(contentsJsonObject.getString(key.toString()))){
				contentsJsonObject.put(key.toString(), " ");
			}
		}

		LOGGER.info("correlationContent : " + correlationJsonObj.toString(2));
		LOGGER.info("Exiting prepareCorrelationContent");

		return correlationJsonObj.toString();
	}


	/**
	 *
	 * @param odsInterfaceRequest
	 * @param response
	 * @param responseConfigParam
	 * @throws ApplicationException
	 */
	public void parseResponseParamsAndUpdateManifestDoc(OdsInterfaceRequest odsInterfaceRequest, String response, String requestKey) throws ApplicationException {
		LOGGER.info("Entering parseResponseParamsAndUpdateManifestDoc");
		ResponseConfigParams responseConfigParam = null;
		// convert Response Config Param JSON String to Object
		responseConfigParam = (ResponseConfigParams) serviceUtils
						.convertJsonStringToObject(odsInterfaceRequest.getResponseConfigParam(), ResponseConfigParams.class);
		LOGGER.info("######responseConfigParam retrived in response processing########: " + responseConfigParam);
		if(StringUtils.isEmpty(responseConfigParam.getResponseDocumentName())) {//RETURN if ResponseDocumentName is empty
			return;
		}
		
		String manifestPayload = odsInterfaceRequest.getManifestPayload();
		/*
		 * if Manifest Payload is empty and ResponseDocumentName is configured,
		 * Prepare Manifest Payload with configuration from TransformerConfig
		 */
		if(manifestPayload == null || StringUtils.isEmpty(manifestPayload) || "{}".equals(manifestPayload)) {
			LOGGER.info("MANIFEST Payload is empty. Building it with Transformer Config");
			String bonitaRequest = odsInterfaceRequest.getRequest();
			JSONObject bonitaReqJson = new JSONObject(bonitaRequest);
			if(bonitaReqJson.has("app-key") && bonitaReqJson.has("seedInfo")) {
				String appKey = responseConfigParam.getAppKey();
				String transformerKey = serviceUtils.buildKey(appKey,Constants.UPDATE_RESPONSE_IN_MANIFEST);
				OdsTransformerConfigDto transformRequest = new OdsTransformerConfigDto(transformerKey, odsInterfaceRequest.getRequest());
				manifestPayload = odsTransformerConfigService.tranformDocument(transformRequest);
				LOGGER.info("MANIFEST Payload built with Transformer Config : "+manifestPayload);
			}
			else {
				/*
				 * app-key and seendinfo are neded to construct a payload with transformer config.
				 * Skipping update manifest without any of these value
				 */
				LOGGER.info(
						"app-key or seedinfo is empty in the request payload from bonita. app-key and seedinfo needed to build manifest payload with transformer config. Skipping manifest update gracefully.");
				return;
			}
			
		}
		
		// Get Response Params from Params config table
		List<OdsParamConfig> odsParamConfigList = odsParamConfigRespository.findByParamKeyAndType(requestKey,
				OdsParamConfigType.RESPONSE_PARAM.toString());		
		
		String respManifestDocNames = responseConfigParam.getResponseDocumentName();
		String[] manifestDocumentNameArry = respManifestDocNames.split(Constants.MANIFEST_DOCUMENT_NAME_SPLITTER);
		
		//Creating a map of <DocumentName, List of ODS_PARAMS - RESPONSE_PARAMS for the Given document name. 
		Map<String,List<OdsParamConfig>> odsRespParamsPerDoc = new HashMap<>();
		for (String manifestDocumentName : manifestDocumentNameArry) {
			List<OdsParamConfig> odsRespParams = new ArrayList<>();
			for (OdsParamConfig odsParam : odsParamConfigList) {				
				if(odsParam.getValue().contains(manifestDocumentName))
				{									
					odsRespParams.add(odsParam);					
				}
			}			
			odsRespParamsPerDoc.put(manifestDocumentName, odsRespParams);
		}
		
		for (String manifestDocumentName : manifestDocumentNameArry) {
			JSONObject manifestPayloadJson = buildPayloadToUpdateManifest(manifestDocumentName, response,manifestPayload,odsRespParamsPerDoc.get(manifestDocumentName));
			manifestService.createOrUpdateManifestDoc(manifestPayloadJson.toString());
		}
		LOGGER.info("Exiting parseResponseParamsAndUpdateManifestDoc");
	}
	
	
	public JSONObject buildPayloadToUpdateManifest(String manifestDocumentName, String response, String manifestPayload, List<OdsParamConfig> odsParamsRespParams) throws ApplicationException
	{
		LOGGER.info("Entering buildPayloadToUpdateManifest");
		String manifestDocument;
		JSONObject manifestDocumentJson;
		JSONObject manifestPayloadJson = new JSONObject(manifestPayload);
		
		if(CollectionUtils.isEmpty(odsParamsRespParams)){
			manifestDocumentJson = new JSONObject(response);
			manifestPayloadJson.put(Constants.MANIFEST_DOCPAYLOAD_KEY,manifestDocumentJson);
		}else{
			// Update the Response Document Name in the GET manifest payload
			try {
				JSONObject getManfiestPayloadJson = new JSONObject(manifestPayload);
				getManfiestPayloadJson.getJSONObject(Constants.ENTITY_DATA_STR).put(Constants.MANIFEST_DOCUMENT_NAME_STR, manifestDocumentName);				
				LOGGER.info("Payload to get Manifest Doc : "+getManfiestPayloadJson.toString());
				manifestDocument = manifestService.getManifestDocument(getManfiestPayloadJson.toString());
				manifestDocumentJson = new JSONObject(manifestDocument);
			} catch (ApplicationException e) {
				LOGGER.info("Manifest Document not found. So creating a new one." + e);
				manifestDocumentJson = new JSONObject();
			}
						
			for (OdsParamConfig odsParam : odsParamsRespParams) {
				String newValue = "";
				String paramConfigValue = "";
				if(odsParam.getValue().contains(manifestDocumentName))
				{	
					//THE ATTRIBUTE KEY THAT SHOULD GO IN THE MANIFEST PAYLOAD
					String[] odsParamConfigValueArr =  odsParam.getValue().split(manifestDocumentName.concat("."));						
					for (String paramValue : odsParamConfigValueArr) {							
						paramConfigValue+=paramValue;								
					}	
					
					//VALUE OF THE ATTRIBUTE KEY - CAN BE FROM RESPONSE OR A LITERAL VALUE.
					if(odsParam.getName().startsWith("$")) { //FETCH VALUE FROM THE GIVEN PATH IN RESPONE										
						newValue = serviceUtils.readValueFromJson(response, odsParam.getName());						
					}
					else {//LITERAL CASE - Value is a LITERAL
						newValue = odsParam.getName();	
					}					
				}												
				serviceUtils.addOrUpdateJsonProperty(manifestDocumentJson, paramConfigValue, newValue);
			}			
			manifestPayloadJson.put(Constants.MANIFEST_DOCPAYLOAD_KEY, manifestDocumentJson.get(Constants.MANIFEST_DOCPAYLOAD_KEY));
		}
		manifestPayloadJson.getJSONObject(Constants.ENTITY_DATA_STR).put(Constants.MANIFEST_DOCUMENT_NAME_STR,manifestDocumentName);
		LOGGER.info("Payload Built to Update Manifest :"+manifestPayloadJson.toString()); 		
		LOGGER.info("Exiting buildPayloadToUpdateManifest");
		return manifestPayloadJson;
	}



	/**
	 *
	 * @param responseConfigParam
	 * @throws ApplicationException
	 */
	public void createOrUpdateWorkflowParams(ResponseConfigParams responseConfigParam, String response, String appKey)
			throws ApplicationException {
		LOGGER.info("Entering createOrUpdateWorkflowParams");

		JSONObject respJsonObj = new JSONObject(response);
		if(respJsonObj.has("workflowParameters")){
			JSONObject workflowParameterObj = respJsonObj.optJSONObject("workflowParameters");
			JSONArray workFlowParamArry = workflowParameterObj.optJSONArray("workflowParams");
			String paramValue;
			if (workFlowParamArry != null && workFlowParamArry.length()> 0) {
				for (int i=0; i<workFlowParamArry.length(); i++) {
					JSONObject workflowParams = workFlowParamArry.getJSONObject(i);
					LOGGER.info("creating workflow params for:" + workflowParams);
					if (null == workflowParams.get("paramValue")) {
						paramValue = "null";
					} else {
						paramValue = workflowParams.get("paramValue").toString();
					}
					workflowParamService.createWorkflowParams(responseConfigParam.getRootCaseID(),
							workflowParams.getString("paramName"), paramValue);
				}

			}
		}

		// Get Workflow Params from Params config table
		List<OdsParamConfig> odsParamConfigList = odsParamConfigRespository.findByParamKeyAndType(appKey,
				OdsParamConfigType.WORKFLOW_PARAM.toString());
		if (CollectionUtils.isEmpty(odsParamConfigList)) {
			LOGGER.info("No workflow params are configured in Param table for key - " + appKey);
			return;
		}

		String paramValue;
		for (OdsParamConfig odsParam : odsParamConfigList) {
			paramValue = serviceUtils.readValueFromJson(response, odsParam.getValue());
			workflowParamService.createWorkflowParams(responseConfigParam.getRootCaseID(), odsParam.getName(), paramValue);
		}

		LOGGER.info("Exiting createOrUpdateWorkflowParams");
	}


	/**
	 * API to close the task in Bonita
	 *
	 * @param correlationData
	 * @param contentData
	 * @throws ApplicationException
	 */
	public void closeTaskInBonita(String correlationData, String contentData) throws ApplicationException {
		LOGGER.info("Entering closeTaskInBonita");

		JSONObject finalCorrelationJsonData = serviceUtils.mergeJSONObjects(new JSONObject(correlationData), new JSONObject(contentData));
		String finalCorrelationData = finalCorrelationJsonData.toString();
		LOGGER.info("Bonita payload - " + finalCorrelationData);

		/* Get CLOSE_BONITA_TASK_URL from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRespository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.CLOSE_BONITA_TASK_URL);
		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(), OdsParamConfigType.ODS_PARAM.toString(),
							Constants.CLOSE_BONITA_TASK_URL, null));
		LOGGER.info("Bonita close task URL : " + odsAppParam.getValue());

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(finalCorrelationData, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = serviceUtils.callService(odsAppParam, httpEntity);

		String response;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			response = responseEntity.getBody();
		} else {
			LOGGER.error("Received failure response from close bonita task service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from close bonita task service");
		}

		LOGGER.info("Response :::" + response);
		LOGGER.info("Exiting closeTaskInBonita");
	}


	/**
	 * @param Notes Response payload
	 * @param response
	 * @param transactionId
	 * @return string notesPaload
	 * @throws ApplicationException
	 */
	public void updateResponseInNotes(String transactionId, String response, String requestKey) {
		LOGGER.info("Entering updateResponseInNotes");
		
		notesService.updateResponseInNotes(transactionId, response, requestKey);

		LOGGER.info("Exiting updateResponseInNotes");
	}


	/**
	 * @param odsInterfaceReq
	 * @param failureResponseStatus
	 */
	public void closeTaskInBonita(OdsInterfaceRequest odsInterfaceReq, ResponseStatus failureResponseStatus, String requestKey) {
		LOGGER.info("Entering closeTaskInBonita");
		
		try {
			String correlationSchema = odsInterfaceReq.getCoreleationPayload();
			String correlationContent = prepareCorrelationContent(failureResponseStatus, null, requestKey);
			if (StringUtils.isNotEmpty(correlationSchema) && StringUtils.isNotEmpty(correlationContent)) {
				closeTaskInBonita(correlationSchema, correlationContent);
			}

		} catch (Exception e) {
			LOGGER.error("Exception occured while closing the bonita task - ", e);
			//Create UTE Task
		}
		LOGGER.info("Exiting closeTaskInBonita");
	}

	/**
	 * @param responseConfigParam
	 * @param failureResponseStatus
	 */
	public void createFallout(ResponseConfigParams responseConfigParam, ResponseStatus failureResponseStatus) {
		LOGGER.info("Entering createFallout");

		WorkflowFalloutRequest falloutReq = new WorkflowFalloutRequest(responseConfigParam.getCaseID(),
				responseConfigParam.getActivityInstanceId(), responseConfigParam.getFlowNodeProcessName(),
				responseConfigParam.getFlowNodeStepName(), failureResponseStatus.getCode(),
				failureResponseStatus.getDescription(), responseConfigParam.getRootCaseID());

		try {
			falloutService.createFallout(falloutReq);
		} catch (Exception e) {
			LOGGER.error("Exception occured while creating fallout - ", e);
			// Create UTE TASK
		}
		LOGGER.info("Exiting createFallout");
	}

	/**
	 * @param originalResponse
	 * @param responseStatus
	 */
	public void addOrUpdateStatus(JSONObject originalResponse, ResponseStatus responseStatus) {
		LOGGER.info("Entering addOrUpdateStatus");
		
		if (null != originalResponse && originalResponse.optJSONObject("status") != null) {
			JSONObject statusOb =  originalResponse.getJSONObject("status");
			statusOb.put("code", responseStatus.getCode());
			statusOb.put("description", responseStatus.getDescription());
			originalResponse.put("status", statusOb);
		} else {
			if (null == originalResponse)
				originalResponse = new JSONObject();
			//Add New Status section yo original response and send it back
			JSONObject statusOb =  new JSONObject();
			statusOb.put("code", responseStatus.getCode());
			statusOb.put("description", responseStatus.getDescription());
			originalResponse.put("status", statusOb);
		}
		
		LOGGER.info("Exiting addOrUpdateStatus");
	}

}