/**
 * 
 */
package com.vz.uiam.onenet.ods.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.ResolveWorkflowFallout;
import com.vz.uiam.onenet.ods.jpa.dao.model.ResolveWorkflowFalloutConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.ResolveWorkflowFalloutConfigRepo;
import com.vz.uiam.onenet.ods.jpa.dao.repository.ResolveWorkflowFalloutRepo;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveFalloutServiceResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveHandleFalloutRequest;

import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveWorkflowFalloutRequest;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

import ma.glasnost.orika.MapperFacade;

/**
 * @author Kiran
 *
 */
@Service("resolveFalloutService")
public class ResolveFalloutService {

	private static final Logger LOGGER = Logger.getLogger(FalloutService.class);

	@Autowired
	ResolveWorkflowFalloutConfigRepo configRepo;

	@Autowired
	ResolveWorkflowFalloutRepo fallOutRepo;

	@Autowired
	ServiceUtils utils;

	@Autowired
	MapperFacade mapper;

	/**
	 * @param request
	 * @return WorkflowFalloutConfig
	 * @throws ApplicationException
	 */
	public ResolveWorkflowFalloutConfig getFalloutConfig(ResolveWorkflowFalloutRequest request) throws ApplicationException {
		return configRepo.findByWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndWorkFlowProcessName(request.getWorkFlowStepName(), request.getWorkFlowFalloutErrorCode(), request.getWorkFlowProcessName());
	}

	/**
	 * @param request
	 * @return WorkflowFalloutConfig
	 * @throws ApplicationException
	 */
	public void createFallout(ResolveWorkflowFalloutRequest request) throws ApplicationException {
		ResolveWorkflowFallout fallout = fallOutRepo.getByCaseIdAndWorkFlowStepName(
				request.getCaseId(), request.getWorkFlowStepName());
		
		
		if(null != fallout){
			fallout.setRootCaseId(request.getRootCaseId());
			fallout.setWorkFlowFalloutErrorCode(request.getWorkFlowFalloutErrorCode());
			fallout.setWorkFlowFalloutErrorDesc(request.getWorkFlowFalloutErrorDesc());
			fallout.setWorkFlowProcessName(request.getWorkFlowProcessName());
			fallout.setStatus(Constants.STATUS_PENDING);
			fallOutRepo.save(fallout);
		}else{
			
			createNewFallout(request);
		}
		
	}

	/**
     *
	 * @param request
	 */
	private void createNewFallout(ResolveWorkflowFalloutRequest request) {
		
		if (request.getWorkFlowFalloutErrorCode()==null || "".equalsIgnoreCase(request.getWorkFlowFalloutErrorCode()))
		{
			request.setWorkFlowFalloutErrorCode("DEFAULT_ERROR_CODE");	
		}
		ResolveWorkflowFallout newFallout = mapper.map(request, ResolveWorkflowFallout.class);
		newFallout.setWorkFlowStepRetryCounter(0);
		newFallout.setStatus(Constants.STATUS_PENDING);
		fallOutRepo.save(newFallout);
	}

	/**
	 * 
	 * @param handleFalloutReq
	 * @return ResolveFalloutServiceResponse
	 * @throws ApplicationException
	 */
	public  ResolveFalloutServiceResponse handleFallout(ResolveHandleFalloutRequest handleFalloutReq) throws ApplicationException {
		LOGGER.info("Entering handleFallout");
		
		Boolean retryFlag = false;
		
		ResolveWorkflowFallout fallout = checkFallout(handleFalloutReq);
		ResolveWorkflowFalloutConfig config = null;
		if(fallout == null) {
			config = configRepo.findByWorkFlowStepNameAndWorkFlowFalloutErrorCode(handleFalloutReq.getStepName(),
					"DEFAULT_ERROR_CODE");
			if (config != null) {
			   fallout = new ResolveWorkflowFallout();
				
				fallout.setWorkFlowFalloutErrorCode(config.getWorkFlowFalloutErrorCode());
				fallout.setWorkFlowFalloutErrorCategory(config.getWorkFlowFalloutErrorCategory());
				
				fallout.setWorkFlowFalloutErrorDesc("Default error description");
				
				fallout.setWorkFlowStepName(handleFalloutReq.getStepName());
				fallout.setWorkFlowProcessName(handleFalloutReq.getProcessName());
				fallout.setCaseId(handleFalloutReq.getCaseId());
				fallout.setRootCaseId(handleFalloutReq.getRootCaseId());
				
				fallout.setWorkFlowStepRetryCounter(0);
				fallout.setStatus(Constants.STATUS_PENDING);
			}else {
              fallout = new ResolveWorkflowFallout();
				
				 fallout.setWorkFlowFalloutErrorCode("Default_Error_Code");
				 fallout.setWorkFlowFalloutErrorCategory("System_Error");
				
				fallout.setWorkFlowFalloutErrorDesc("Default error description");
				fallout.setRootCaseId(handleFalloutReq.getRootCaseId());
				fallout.setWorkFlowStepName(handleFalloutReq.getStepName());
				fallout.setWorkFlowProcessName(handleFalloutReq.getProcessName());
				fallout.setCaseId(handleFalloutReq.getCaseId());
				
				fallout.setWorkFlowStepRetryCounter(0);
				fallout.setStatus(Constants.STATUS_PENDING);
				fallOutRepo.save(fallout);
			}
		}
	
		 checkFallout(fallout);
		
		if (config == null) {
			
			 ResolveWorkflowFalloutRequest falloutConfigReq = new ResolveWorkflowFalloutRequest(fallout.getWorkFlowStepName(),
					 fallout.getWorkFlowFalloutErrorCode(),fallout.getWorkFlowProcessName());
		
			   config = getFalloutConfig(falloutConfigReq);
			   
		}
		// Compare the fallout with config
		 if (config!=null && fallout.getWorkFlowStepRetryCounter() < config.getMaxRetryCounter()) {
			// set retry flag == true and update status = P
			retryFlag = true;
			fallout.setRootCaseId(handleFalloutReq.getRootCaseId());
			fallout.setWorkFlowStepRetryCounter(fallout.getWorkFlowStepRetryCounter() + 1);
			fallout.setWorkFlowFalloutErrorCategory(config.getWorkFlowFalloutErrorCategory());
			fallOutRepo.save(fallout);
		} else {
			retryFlag = false;
			fallout.setRootCaseId(handleFalloutReq.getRootCaseId());
			fallout.setStatus(Constants.PROCESSED);
			if(config!=null){
			fallout.setWorkFlowFalloutErrorCategory(config.getWorkFlowFalloutErrorCategory());
			}
			fallOutRepo.save(fallout);
		}
		
		ResolveFalloutServiceResponse response = new ResolveFalloutServiceResponse(retryFlag, config!=null?config.getRetryInterval():fallout.getWorkFlowStepRetryCounter(), fallout.getCaseId(), fallout.getWorkFlowStepName(),
												fallout.getWorkFlowFalloutErrorCode(), fallout.getWorkFlowFalloutErrorDesc(), fallout.getWorkFlowFalloutErrorCategory());
		
		LOGGER.info("Exiting handleFallout");
		return response;
	}
	

	/**
	 * @param fallout
	 * @throws ApplicationException
	 */
	private void checkFallout(ResolveWorkflowFallout fallout) throws ApplicationException {
		if (null == fallout) {
			LOGGER.error(StatusCode.ERROR_WORKFLOW_NOTFOUND.getDesc());
			throw new ApplicationException(StatusCode.ERROR_WORKFLOW_NOTFOUND.getCode(),
					StatusCode.ERROR_WORKFLOW_NOTFOUND.getDesc());
		}
	}
	
	/**
	 * @param handleFalloutReq
	 * @return ResolveWorkflowFallout
	 */ 
	private ResolveWorkflowFallout checkFallout(ResolveHandleFalloutRequest handleFalloutReq) {
		return fallOutRepo.getByCaseIdAndWorkFlowStepName(
				handleFalloutReq.getCaseId(),handleFalloutReq.getStepName());
	}

	
}
