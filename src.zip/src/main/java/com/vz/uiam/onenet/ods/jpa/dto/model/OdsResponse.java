package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.io.Serializable;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class OdsResponse implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private TransformedResponsePayload payload;
	private String targetEndPointURL;
	private String routingProtocol;
	private ResponseStatus status;
	private String transactionId;
	private String userNameAndPassword;
	private String transformationType;
	QueryParam queryParameters;
	private String replyToQueueName;
	private String requestMethod;
	private String serviceMode;
	TransportHeader transportHeader;
	
	public OdsResponse() {
		
	}
	
	/**
	 * @param payload
	 * @param serviceURI
	 * @param routingProtocol
	 * @param notesPayLoad
	 * @param transactionId
	 */
	public OdsResponse(TransformedResponsePayload payload, String targetEndPointURL, String routingProtocol,
															String transactionId, String userNameAndPassword) {
		this.payload = payload;
		this.targetEndPointURL = targetEndPointURL;
		this.routingProtocol = routingProtocol;
		this.transactionId=transactionId;
		this.userNameAndPassword=userNameAndPassword;
	}
	
	/**
	 * 
	 * @param payload
	 * @param targetEndPointURL
	 * @param routingProtocol
	 * @param transactionId
	 * @param userNameAndPassword
	 * @param transformationType
	 */
	public OdsResponse(TransformedResponsePayload payload, String targetEndPointURL, String routingProtocol,
								String transactionId, String userNameAndPassword, String transformationType) {
		this.payload = payload;
		this.targetEndPointURL = targetEndPointURL;
		this.routingProtocol = routingProtocol;
		this.transactionId = transactionId;
		this.userNameAndPassword = userNameAndPassword;
		this.transformationType = transformationType;
	}
	
	
	
	/**
	 * @param payload
	 * @param targetEndPointURL
	 * @param routingProtocol
	 * @param transactionId
	 * @param userNameAndPassword
	 * @param transformationType
	 * @param queryParams
	 * @param replyToQueueName
	 * @param requestMethod
	 */
	public OdsResponse(TransformedResponsePayload payload, String targetEndPointURL, String routingProtocol,
			String transactionId, String userNameAndPassword, String transformationType,
			QueryParam queryParams, String replyToQueueName, String requestMethod) {
		this.payload = payload;
		this.targetEndPointURL = targetEndPointURL;
		this.routingProtocol = routingProtocol;
		this.transactionId = transactionId;
		this.userNameAndPassword = userNameAndPassword;
		this.transformationType = transformationType;
		this.queryParameters = queryParams;
		this.replyToQueueName = replyToQueueName;
		this.requestMethod = requestMethod;
	}

	/**
	 * @param payload
	 * @param targetEndPointURL
	 * @param routingProtocol
	 * @param status
	 * @param transactionId
	 * @param userNameAndPassword
	 * @param transformationType
	 * @param queryParameters
	 * @param replyToQueueName
	 * @param requestMethod
	 */
	public OdsResponse(TransformedResponsePayload payload, String targetEndPointURL, String routingProtocol,
			ResponseStatus status, String transactionId, String userNameAndPassword, String transformationType,
			QueryParam queryParameters, String replyToQueueName, String requestMethod) {
		this.payload = payload;
		this.targetEndPointURL = targetEndPointURL;
		this.routingProtocol = routingProtocol;
		this.status = status;
		this.transactionId = transactionId;
		this.userNameAndPassword = userNameAndPassword;
		this.transformationType = transformationType;
		this.queryParameters = queryParameters;
		this.replyToQueueName = replyToQueueName;
		this.requestMethod = requestMethod;
	}
	/**
	 * @param payload
	 * @param targetEndPointURL
	 * @param routingProtocol
	 * @param transactionId
	 * @param userNameAndPassword
	 * @param transformationType
	 * @param queryParams
	 * @param replyToQueueName
	 * @param requestMethod
	 * @param serviceMode
	 * @param transportHeader 
	 */

	public OdsResponse(TransformedResponsePayload payload, String targetEndPointURL, String routingProtocol,
			String transactionId, String userNameAndPassword, String transformationType,
			QueryParam queryParams, String replyToQueueName, String requestMethod,String serviceMode,TransportHeader transportHeader) {
		this.payload = payload;
		this.targetEndPointURL = targetEndPointURL;
		this.routingProtocol = routingProtocol;
		this.transactionId = transactionId;
		this.userNameAndPassword = userNameAndPassword;
		this.transformationType = transformationType;
		this.queryParameters = queryParams;
		this.replyToQueueName = replyToQueueName;
		this.requestMethod = requestMethod;
		this.serviceMode = serviceMode;
		this.transportHeader=transportHeader;
	}

	/**
	 * @return the status
	 */
	public ResponseStatus getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	
	/**
	 * @return the payload
	 */
	public TransformedResponsePayload getPayload() {
		return payload;
	}

	/**
	 * @param payload the payload to set
	 */
	public void setPayload(TransformedResponsePayload payload) {
		this.payload = payload;
	}

	/**
	 * @return the targetEndPointURL
	 */
	public String getTargetEndPointURL() {
		return targetEndPointURL;
	}

	/**
	 * @param targetEndPointURL the targetEndPointURL to set
	 */
	public void setTargetEndPointURL(String targetEndPointURL) {
		this.targetEndPointURL = targetEndPointURL;
	}

	/**
	 * @return the routingProtocol
	 */
	public String getRoutingProtocol() {
		return routingProtocol;
	}

	/**
	 * @param routingProtocol the routingProtocol to set
	 */
	public void setRoutingProtocol(String routingProtocol) {
		this.routingProtocol = routingProtocol;
	}

	/**
	 * 
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * 
	 * @param transactionId
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * 
	 * @return the userNameAndPassword
	 */
	public String getUserNameAndPassword() {
		return userNameAndPassword;
	}

	/**
	 * 
	 * @param userNameAndPassword
	 */
	public void setUserNameAndPassword(String userNameAndPassword) {
		this.userNameAndPassword = userNameAndPassword;
	}
	
	/**
	 * 
	 * @return the transformationType
	 */
	public String getTransformationType() {
		return transformationType;
	}

	/**
	 * 
	 * @param transformationType
	 */
	public void setTransformationType(String transformationType) {
		this.transformationType = transformationType;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}

	/**
	 * @return the queryParameters
	 */
	public QueryParam getQueryParameters() {
		return queryParameters;
	}

	/**
	 * @param queryParameters the queryParameters to set
	 */
	public void setQueryParameters(QueryParam queryParameters) {
		this.queryParameters = queryParameters;
	}

	public String getReplyToQueueName() {
		return replyToQueueName;
	}

	public void setReplyToQueueName(String replyToQueueName) {
		if(StringUtils.isNotEmpty(replyToQueueName))
		{
		this.replyToQueueName = replyToQueueName;
		}
		else
		{
			this.replyToQueueName = "";
		}
		
	}

	/**
	 * @return the requestMethod
	 */
	public String getRequestMethod() {
		return requestMethod;
	}

	/**
	 * @param requestMethod the requestMethod to set
	 */
	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}

	public String getServiceMode() {
		return serviceMode;
	}

	public void setServiceMode(String serviceMode) {
		this.serviceMode = serviceMode;
	}

	/**
	 * @return the transportHeader
	 */
	public TransportHeader getTransportHeader() {
		return transportHeader;
	}

	/**
	 * @param transportHeader the transportHeader to set
	 */
	public void setTransportHeader(TransportHeader transportHeader) {
		this.transportHeader = transportHeader;
	}
	
	
	
}
