/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author Anand Badiger
 *
 */
@Entity
@Table(name = "ods_request_transaction_id_map")
public class OdsRequestTransactionIdMap implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "flow_node_process_name")
	private String flowNodeProcessName;

	@Column(name = "flow_node_step_name")
	private String flowNodeStepName;

	@Column(name = "transaction_id_key")
	private String transactionIdKey;

	/**
	 * @return the flowNodeProcessName
	 */
	public String getFlowNodeProcessName() {
		return flowNodeProcessName;
	}

	/**
	 * @param flowNodeProcessName
	 *            the flowNodeProcessName to set
	 */
	public void setFlowNodeProcessName(String flowNodeProcessName) {
		this.flowNodeProcessName = flowNodeProcessName;
	}

	/**
	 * @return the flowNodeStepName
	 */
	public String getFlowNodeStepName() {
		return flowNodeStepName;
	}

	/**
	 * @param flowNodeStepName
	 *            the flowNodeStepName to set
	 */
	public void setFlowNodeStepName(String flowNodeStepName) {
		this.flowNodeStepName = flowNodeStepName;
	}

	/**
	 * @return the transactionIdKey
	 */
	public String getTransactionIdKey() {
		return transactionIdKey;
	}

	/**
	 * @param transactionIdKey
	 *            the transactionIdKey to set
	 */
	public void setTransactionIdKey(String transactionIdKey) {
		this.transactionIdKey = transactionIdKey;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	public OdsRequestTransactionIdMap() {
		super();

	}

	public OdsRequestTransactionIdMap(String flowNodeProcessName, String flowNodeStepName) {
		super();
		this.flowNodeProcessName = flowNodeProcessName;
		this.flowNodeStepName = flowNodeStepName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
