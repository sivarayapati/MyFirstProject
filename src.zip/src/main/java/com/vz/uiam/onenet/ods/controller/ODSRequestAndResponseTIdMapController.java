package com.vz.uiam.onenet.ods.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsResponseTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsTransactionIdMapResponse;
import com.vz.uiam.onenet.ods.service.OdsRequestResponseTransactionIdMapService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/oneDispatcher/odsTransactionIdMap")
public class ODSRequestAndResponseTIdMapController {

	private static final Logger LOGGER = Logger.getLogger(ODSRequestAndResponseTIdMapController.class);
	
	@Autowired
	OdsRequestResponseTransactionIdMapService transactionIdMapService;
	
	
	@RequestMapping(value = "/createOrUpdateRequestTransIdMap", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create or Update a record in OdsRequestTransactionIdMap", notes = "Create or Update a record in OdsRequestTransactionIdMap", response = OdsTransactionIdMapResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Created or Updated OdsParamConfig record", response =OdsTransactionIdMapResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "createOrUpdate OdsRequestTransactionIdMap Service is unavaialble") })
	public ResponseEntity<OdsTransactionIdMapResponse> createOrUpdateOdsRequestTransIdMap(@RequestBody OdsRequestTransactionIdMap request)
														throws ApplicationException {
		
		LOGGER.info("Entering createOrUpdateOdsRequestTransIdMap");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsTransactionIdMapResponse response = new OdsTransactionIdMapResponse();
		
		try {
			OdsRequestTransactionIdMap odsRequestTransIdMapResp=transactionIdMapService.createOrUpdateOdsRequestTransIdMap(request);
			if(null == odsRequestTransIdMapResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsRequestTransactionIdMap(odsRequestTransIdMapResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting createOrUpdateOdsRequestTransIdMap");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/getOdsRequestTransIdMap", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get OdsRequestTransactionIdMap Details", notes = "Get OdsRequestTransactionIdMap Details", response = OdsTransactionIdMapResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved OdsRequestTransactionIdMap record", response = OdsTransactionIdMapResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "get OdsRequestTransactionIdMap Service is unavaialble") })
	public ResponseEntity<OdsTransactionIdMapResponse> getOdsRequestTransIdMap(@RequestBody OdsRequestTransactionIdMap request)
														throws ApplicationException {
		
		LOGGER.info("Entering getOdsRequestTransIdMap");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsTransactionIdMapResponse response = new OdsTransactionIdMapResponse();
		
		try {
			List<OdsRequestTransactionIdMap> odsRequestTransIdMapResp =  transactionIdMapService.getOdsRequestTransIdMapRecords(request);
			
			if(null == odsRequestTransIdMapResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsRequestTransactionIdMapList(odsRequestTransIdMapResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting getOdsRequestTransIdMap");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/deleteOdsRequestTransIdMap", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Delete OdsRequestTransactionIdMap Details", notes = "Delete OdsRequestTransactionIdMap Details", response = OdsTransactionIdMapResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Delete OdsRequestTransactionIdMap record", response = OdsTransactionIdMapResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Delete OdsRequestTransactionIdMap Service is unavaialble") })
	public ResponseEntity<OdsTransactionIdMapResponse> deleteOdsRequestTransIdMap(@RequestBody List<OdsRequestTransactionIdMap> request)
														throws ApplicationException {
		
		LOGGER.info("Entering deleteOdsRequestTransIdMap");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsTransactionIdMapResponse response = new OdsTransactionIdMapResponse();
		
		try {
			transactionIdMapService.deleteOdsRequestTransIdMapRecord(request);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting deleteOdsRequestTransIdMap");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/createOrUpdateResponseTransIdMap", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create or Update a record in OdsResponseTransactionIdMap", notes = "Create or Update a record in OdsResponseTransactionIdMap", response = OdsTransactionIdMapResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Created or Updated OdsParamConfig record", response =OdsTransactionIdMapResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "createOrUpdate OdsResponseTransactionIdMap Service is unavaialble") })
	public ResponseEntity<OdsTransactionIdMapResponse> createOrUpdateResponseTransIdMap(@RequestBody OdsResponseTransactionIdMap odsRequest)
														throws ApplicationException {
		
		LOGGER.info("Entering createOrUpdateResponseTransIdMap");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsTransactionIdMapResponse response = new OdsTransactionIdMapResponse();
		
		try {
			OdsResponseTransactionIdMap odsResponseTransIdMapResp=transactionIdMapService.createOrUpdateOdsResponseTransIdMap(odsRequest);
			if(null == odsResponseTransIdMapResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsResponseTransactionIdMap(odsResponseTransIdMapResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting createOrUpdateResponseTransIdMap");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getOdsResponseTransIdMap", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get OdsResponseTransactionIdMap Details", notes = "Get OdsResponseTransactionIdMap Details", response = OdsTransactionIdMapResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved OdsResponseTransactionIdMap record", response = OdsTransactionIdMapResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "get OdsResponseTransactionIdMap Service is unavaialble") })
	public ResponseEntity<OdsTransactionIdMapResponse> getOdsResponseTransIdMap(@RequestBody OdsResponseTransactionIdMap request)
														throws ApplicationException {
		
		LOGGER.info("Entering getOdsResponseTransIdMap");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsTransactionIdMapResponse response = new OdsTransactionIdMapResponse();
		
		try {
			List<OdsResponseTransactionIdMap> odsResponseTransIdMapResp =  transactionIdMapService.getOdsResponseTransIdMapRecords(request);
			
			if(null == odsResponseTransIdMapResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsResponseTransactionIdMapList(odsResponseTransIdMapResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting getOdsResponseTransIdMap");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/deleteOdsResponseTransIdMap", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Delete OdsResponseTransactionIdMap Details", notes = "Delete OdsResponseTransactionIdMap Details", response = OdsTransactionIdMapResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Delete OdsResponseTransactionIdMap record", response = OdsTransactionIdMapResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Delete OdsResponseTransactionIdMap Service is unavaialble") })
	public ResponseEntity<OdsTransactionIdMapResponse> deleteOdsResponseTransIdMap(@RequestBody List<OdsResponseTransactionIdMap> request)
														throws ApplicationException {
		
		LOGGER.info("Entering deleteOdsResponseTransIdMap");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsTransactionIdMapResponse response = new OdsTransactionIdMapResponse();
		
		try {
			transactionIdMapService.deleteOdsResponseTransIdMapRecord(request);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting deleteOdsResponseTransIdMap");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
}
