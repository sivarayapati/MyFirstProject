package com.vz.uiam.onenet.ods.jpa.dto.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class TransformRequest {

	private String key;
	private String transformationType;
	private String inputDocument;
	private String requestSchema;
	
	
	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	public String getTransformationType() {
		return transformationType;
	}
	
	public void setTransformationType(String transformationType) {
		this.transformationType = transformationType;
	}

	public String getInputDocument() {
		return inputDocument;
	}

	public void setInputDocument(String inputDocument) {
		this.inputDocument = inputDocument;
	}

	public String getRequestSchema() {
		return requestSchema;
	}

	public void setRequestSchema(String requestSchema) {
		this.requestSchema = requestSchema;
	}
	
	public TransformRequest() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param transformationType
	 * @param inputDocument
	 * @param requestSchema
	 */
	public TransformRequest(String transformationType, String inputDocument, String requestSchema) {
		this.transformationType = transformationType;
		this.inputDocument = inputDocument;
		this.requestSchema = requestSchema;
	}
	
	/**
	 * @param key
	 * @param transformationType
	 * @param inputDocument
	 * @param requestSchema
	 */
	public TransformRequest(String key, String transformationType, String inputDocument, String requestSchema) {
		this.key = key;
		this.transformationType = transformationType;
		this.inputDocument = inputDocument;
		this.requestSchema = requestSchema;
	}	

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
