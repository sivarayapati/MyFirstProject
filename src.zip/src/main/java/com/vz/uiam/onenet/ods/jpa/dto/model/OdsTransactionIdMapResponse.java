package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsResponseTransactionIdMap;

@JsonInclude(Include.NON_NULL)
public class OdsTransactionIdMapResponse {

	private String statusCode;
	private String statusDesc;
	private OdsRequestTransactionIdMap odsRequestTransactionIdMap;
	private List<OdsRequestTransactionIdMap> odsRequestTransactionIdMapList;
	private OdsResponseTransactionIdMap odsResponseTransactionIdMap;
	private List<OdsResponseTransactionIdMap> odsResponseTransactionIdMapList;
	
	public String getStatusCode() {
		return statusCode;
	}
	
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	public String getStatusDesc() {
		return statusDesc;
	}
	
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	public OdsRequestTransactionIdMap getOdsRequestTransactionIdMap() {
		return odsRequestTransactionIdMap;
	}

	public void setOdsRequestTransactionIdMap(OdsRequestTransactionIdMap odsRequestTransactionIdMap) {
		this.odsRequestTransactionIdMap = odsRequestTransactionIdMap;
	}

	public List<OdsRequestTransactionIdMap> getOdsRequestTransactionIdMapList() {
		return odsRequestTransactionIdMapList;
	}

	public void setOdsRequestTransactionIdMapList(List<OdsRequestTransactionIdMap> odsRequestTransactionIdMapList) {
		this.odsRequestTransactionIdMapList = odsRequestTransactionIdMapList;
	}

	public OdsResponseTransactionIdMap getOdsResponseTransactionIdMap() {
		return odsResponseTransactionIdMap;
	}

	public void setOdsResponseTransactionIdMap(OdsResponseTransactionIdMap odsResponseTransactionIdMap) {
		this.odsResponseTransactionIdMap = odsResponseTransactionIdMap;
	}

	public List<OdsResponseTransactionIdMap> getOdsResponseTransactionIdMapList() {
		return odsResponseTransactionIdMapList;
	}

	public void setOdsResponseTransactionIdMapList(List<OdsResponseTransactionIdMap> odsResponseTransactionIdMapList) {
		this.odsResponseTransactionIdMapList = odsResponseTransactionIdMapList;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
