package com.vz.uiam.onenet.util.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.util.exception.ApplicationException;
import com.vz.uiam.onenet.util.service.JerseyRestClientService;

@RestController
@RequestMapping("/restClient")
public class JerseyRestClientController {

	private static final Logger LOGGER = Logger.getLogger(JerseyRestClientController.class);

	@Autowired
	JerseyRestClientService jerseyRestClientService;

	/**
	 * @param request
	 * @return ResponseEntity<TransformationResponse>
	 */
	@RequestMapping(value = "/route", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> route(@RequestBody String request) {
		LOGGER.info("Entering route");
		String response;
		String statusCode = StatusCode.SUCCESS.getCode();
		try {
			response = jerseyRestClientService.routeWithJerseyClient(request);
		} catch (ApplicationException exception) {
			LOGGER.error("############ApplicationException Occured while routing with Jersey Client#################"
					+ "ERROR DESCRIPTION IS:::::", exception);
			statusCode = exception.getErrCode();
			response = "{errorCode:"+ statusCode+", errorDesc: "+exception.getMessage()+"}";
		} catch (Exception exception) {
			LOGGER.error("############Exception Occured while routing with Jersey Client#################"
					+ "ERROR DESCRIPTION IS:::::", exception);
			statusCode = StatusCode.FAILED.getCode();
			response = "{errorCode:"+ statusCode+", errorDesc: "+exception.getMessage()+"}";
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		LOGGER.info("Exiting route");
		if (StatusCode.SUCCESS.getCode().equals(statusCode)) {
			LOGGER.info("with Success Response: "+response);
			return new ResponseEntity<>(response, headers, HttpStatus.OK);
		} else {
			LOGGER.info("with Error Response : "+response);
			return new ResponseEntity<>(response, headers, HttpStatus.EXPECTATION_FAILED);
		}

	}

}
