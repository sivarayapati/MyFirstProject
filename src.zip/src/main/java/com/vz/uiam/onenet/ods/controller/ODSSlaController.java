/**
 * 
 */
package com.vz.uiam.onenet.ods.controller;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.service.SlaService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author ODS.
 *
 */
@RestController
@RequestMapping("/sla")
@PreAuthorize("hasAnyAuthority('ROLE:IVAPP_USER','ROLE:IVAPP_TESTER')")
@EnableAsync
public class ODSSlaController {
	private static final Logger LOGGER = Logger.getLogger(ODSSlaController.class);

	@Autowired
	SlaService slaService;


	/**
	 * @param request
	 * @return ResponseEntity<TransformationResponse>
	 * @throws ApplicationException
	 * @throws JSONException
	 */
	@RequestMapping(value = "/createSlaEntry", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create SLA Entry", notes = "Create SLA Entry", response = String.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully created SLA Entry", response = String.class) })
	public ResponseEntity<String> createSlaEntry(@RequestBody String request)
			throws JSONException, ApplicationException {
		LOGGER.info(">>createSlaEntry()");
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		slaService.createSLAEntry(request);
		LOGGER.info("<<createSlaEntry()");
		return new ResponseEntity<>("Success",headers, HttpStatus.OK);
	}
	
	/**
	 * @param request
	 * @return ResponseEntity<TransformationResponse>
	 * @throws ApplicationException
	 * @throws JSONException
	 */
	@RequestMapping(value = "/createBonitaPayloadForSLA", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create Bonita Payload to close wait task due to SLA breach", notes = "Create Bonita Payload to close wait task due to SLA breach", response = String.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully created Payload to close Bonita Wait task", response = String.class) })
	public ResponseEntity<String> createBonitaPayloadForSLA(@RequestBody String request)
			throws JSONException, ApplicationException {
		LOGGER.info(">>createBonitaPayloadForSLA()");
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		String bonitaPayload = slaService.createPayloadtoCloseBonitaTask(request);
		LOGGER.info("<<createBonitaPayloadForSLA()");
		return new ResponseEntity<>(bonitaPayload,headers, HttpStatus.OK);
	}
}
