/**
 *
 */
package com.vz.uiam.onenet.ods.controller;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dto.model.FalloutServiceResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.jpa.dto.model.WorkflowFalloutRequest;
import com.vz.uiam.onenet.ods.service.FalloutService;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author Anand
 *
 */
@RestController
@RequestMapping("/oneDispatcher/fallout")
public class FalloutServiceController {

	private static final Logger LOGGER = Logger.getLogger(FalloutServiceController.class);

	@Autowired
	FalloutService falloutService;

	@Autowired
	ServiceUtils serviceUtils;


	/**
	 * @return boolean
	 * @throws ApplicationException
	 */
	@RequestMapping(value = "/handleFallout", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Service fallout handle", notes = "Service fallout handle", response = FalloutServiceResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Service fallout handle", response = FalloutServiceResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Fallout Service is unavaialble") })
	public ResponseEntity<FalloutServiceResponse> handleFallout(@RequestBody String request) {
		LOGGER.info("Entering handleFallout");
		
		// Call handleFallout Async method
		falloutService.handleFallout(request, null);

		// Return SUCCESS ACK
		FalloutServiceResponse response = new FalloutServiceResponse();
		response.setStatusCode(StatusCode.SUCCESS.getCode());
		response.setStatusDesc(StatusCode.SUCCESS.getDesc());

		LOGGER.info("Exiting handleFallout");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	/**
	 * @param request
	 * @return ResponseEntity<FalloutServiceResponse>
	 * @throws ApplicationException
	 */
	@RequestMapping(value = "/createFallout", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create Service Fallout", notes = "Create Service Fallout", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Create Service Fallout", response = String.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Create Fallout is unavaialble") })
	public ResponseEntity<ResponseStatus> createFallout(@RequestBody WorkflowFalloutRequest request)
			throws ApplicationException {
		LOGGER.info(">>createFallout()");
		LOGGER.info("Request payload is ::::::::::::::" + request.toString());

		Boolean returnStatus = true;
		ResponseStatus response = new ResponseStatus();
		try {
			falloutService.createFallout(request);
			ResponseStatus respSts = new ResponseStatus();
			respSts.setCode(StatusCode.SUCCESS.getCode());
			respSts.setDescription("Successfully Inserted the WfParam");
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			returnStatus = false;
			response.setCode(StatusCode.ERROR_WHILE_CREATE_FALLOUT.getCode());
			response.setDescription(StatusCode.ERROR_WHILE_CREATE_FALLOUT.getDesc());
			LOGGER.error(StatusCode.ERROR_WHILE_CREATE_FALLOUT.getDesc() + e);
		}

		if (returnStatus) {
			return ResponseEntity.ok(response);
		} else {
			LOGGER.info("<<addWfParam()");
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(response);
		}
	}
	
	/**
	 * @return boolean
	 * @throws ApplicationException
	 */
	@RequestMapping(value = "/isRetryPossible", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Is Retry Possible", notes = "Is Retry Possible", response = FalloutServiceResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Is Retry Possible", response = FalloutServiceResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Fallout Service is unavaialble") })
	public ResponseEntity<FalloutServiceResponse> isRetryPossible(@RequestBody String request) {
		LOGGER.info("Entering isRetryPossible");
		
		// Call handleFallout Async method
		JSONObject requestJson = new JSONObject(request);
		FalloutServiceResponse response = new FalloutServiceResponse();
		try {
			response = falloutService.isRetryPossible(requestJson);

			// Return SUCCESS ACK
			response.setStatusCode(StatusCode.SUCCESS.getCode());
			response.setStatusDesc(StatusCode.SUCCESS.getDesc());
		}
		catch(ApplicationException applicationException) {
			LOGGER.error("############Application Exception Occured while checking is retry possible#################"
					+ "ERROR CODE:::::"+applicationException.getErrCode()+"ERROR DESCRIPTION IS:::::", applicationException);
			response.setStatusCode(StatusCode.ERROR_WHILE_IS_RETRY_POSSIBLE.getCode());
			response.setStatusDesc(StatusCode.ERROR_WHILE_IS_RETRY_POSSIBLE.getDesc());
		}
		

		LOGGER.info("Exiting isRetryPossible");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	
	/**
	 * @return boolean
	 * @throws ApplicationException
	 * request:
	 * {
	 *  "wfTaskId": "1234",
	 *	"title";"OrderNumber",
	 *	"titleVersion": "orderVersion",
	 *	"wfTaskName": "taskName",
	 *  "taskAction": "REFLOW/COMPLETE",
	 *  "userId": "VZID"
	 * }
	 * 
	 */
	@RequestMapping(value = "/retryOrComplete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Retry or Complete task", notes = "Retry or complete a fallen out task", response = FalloutServiceResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Retry or complete request made successfully", response = FalloutServiceResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Retry or Complete service is unavaialble") })
	public ResponseEntity<FalloutServiceResponse> retryOrComplete(@RequestBody String request) {
		LOGGER.info("Entering retryOrComplete");
		FalloutServiceResponse response = new FalloutServiceResponse();
		try {
			falloutService.handleRequest(request);
			
			response.setStatusCode(StatusCode.SUCCESS.getCode());
			response.setStatusDesc(StatusCode.SUCCESS.getDesc());
		} catch (ApplicationException applicationException) {
			LOGGER.error("############Application Exception Occured while trying to reflow or complete #################"
					+ "ERROR CODE:::::"+applicationException.getErrCode()+"ERROR DESCRIPTION IS:::::", applicationException);
			response.setStatusCode(applicationException.getErrCode());
			response.setStatusDesc(applicationException.getMessage());
		}


		

		LOGGER.info("Exiting retryOrComplete");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	
	/**
	 * @return FalloutServiceResponse 
	 * @param request
	 * request:
	 * {
	 *  "appKey": "ZZZDE-XXX",
	 *	"seedInfo":{
	 *		"order_number":"123",
	 *		"order_version":"1",
	 *		"document_level":"VERSION"
	 *	}
	 * }
	 * 
	 */
	@RequestMapping(value = "/completeAllUteTasks", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Complete All UTE Tasks", notes = "Complete All UTE Tasks", response = FalloutServiceResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Completed ALL Pending UTE Tasks successfully", response = FalloutServiceResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Complete All UTE Tasks service is unavaialble") })
	public ResponseEntity<FalloutServiceResponse> completeAllUteTasks(@RequestBody String request) {
		LOGGER.info("Entering completeAllUteTasks");
		FalloutServiceResponse response = new FalloutServiceResponse();
		try {
			falloutService.completeAllUteTasks(request);
			response.setStatusCode(StatusCode.SUCCESS.getCode());
			response.setStatusDesc(StatusCode.SUCCESS.getDesc());
		} catch (ApplicationException applicationException) {
			LOGGER.error("############Application Exception Occured while trying to reflow or complete #################"
					+ "ERROR CODE:::::"+applicationException.getErrCode()+"ERROR DESCRIPTION IS:::::", applicationException);
			response.setStatusCode(applicationException.getErrCode());
			response.setStatusDesc(applicationException.getMessage());
		}


		

		LOGGER.info("Exiting completeAllUteTasks");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/removePendingAutoRetriesDuringSupp", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Remove all auto retrials which are pending during supp", notes = "Remove all auto retrials which are pending during supp", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Removed Auto Retry Pending Task During Supplement successfully", response = String.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Remove Pending Auto Retry During Supp service is unavailable") })
	public ResponseEntity<FalloutServiceResponse> removePendingAutoRetriesDuringSupp(@RequestBody String request) {
		LOGGER.info("Entering removePendingAutoRetriesDuringSupp");
		FalloutServiceResponse response = new FalloutServiceResponse();
		try {
			falloutService.removePendingAutoRetriesDuringSupp(request);
			response.setStatusCode(StatusCode.SUCCESS.getCode());
			response.setStatusDesc(StatusCode.SUCCESS.getDesc());
		} catch (ApplicationException applicationException) {
			LOGGER.error("############Application Exception Occured while removing pending auto retry during supp #################"
							+ "ERROR CODE:::::" + applicationException.getErrCode() + "ERROR DESCRIPTION IS:::::",
					applicationException);
			response.setStatusCode(applicationException.getErrCode());
			response.setStatusDesc(applicationException.getMessage());
		}

		LOGGER.info("Exiting removePendingAutoRetriesDuringSupp");
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	
	
	
}
