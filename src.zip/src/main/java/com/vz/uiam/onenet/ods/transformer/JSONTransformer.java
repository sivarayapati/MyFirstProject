package com.vz.uiam.onenet.ods.transformer;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@Service
public class JSONTransformer implements Transformer {

	private static final Logger LOGGER = Logger.getLogger(JSONTransformer.class);

	@Autowired
	ServiceUtils serviceUtils;

	@Override
	public Object doTransform(Object inputDocument, Object requestSchema) throws ApplicationException {
		LOGGER.info("Entering doTransform");

		JSONObject outputJsonObject = new JSONObject();
		try {
			JSONObject inputJsonDoc = new JSONObject();
			if (inputDocument instanceof JSONObject) {
				inputJsonDoc = (JSONObject) inputDocument;
			} else if (inputDocument instanceof String) {
				inputJsonDoc = new JSONObject((String) inputDocument);
			}

			String jsonSchema = (String) requestSchema;

			serviceUtils.populateJsonPayload(jsonSchema, inputJsonDoc.toString(), outputJsonObject);
		} catch (Exception e) {
			LOGGER.error("JSON Exception Occured while gnerating the Payload from schema - ", e);
			throw new ApplicationException(StatusCode.INTERNAL_ERROR.getCode(),
					"Error occured while performing JSON Transformation.");
		}

		LOGGER.info("Exiting doTransform");
		return outputJsonObject.toString();
	}
}
