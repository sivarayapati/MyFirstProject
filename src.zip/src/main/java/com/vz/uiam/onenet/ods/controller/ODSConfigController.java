package com.vz.uiam.onenet.ods.controller;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dto.model.InsertScriptResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSConfigPayload;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSConfigResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSKeyDetails;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.service.ODSConfigService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author Ashish Goyal
 *
 */
@RestController
@RequestMapping("/oneDispatcher/odsConfig")
public class ODSConfigController {

	private static final Logger LOGGER = Logger.getLogger(ODSConfigController.class);
	
	@Autowired
	ODSConfigService odsConfigService;
	
	
	@RequestMapping(value = "/createOrUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create or Update ODS Configurations", notes = "Create or Update ODS Configurations", response = ODSConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Created or Updated ODS Configurations", response = ODSConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "createOrUpdate ODS Configurations Service is unavaialble") })
	public ResponseEntity<ODSConfigResponse> createOrUpdateOdsConfig(@RequestBody ODSConfigPayload request)
																	throws ApplicationException {
		
		LOGGER.info("Entering createOrUpdateOdsConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		ODSConfigResponse response = new ODSConfigResponse();
		
		try {
			ODSConfigPayload odsConfigResp = odsConfigService.createOrUpdateOdsConfig(request);
			
			if(null == odsConfigResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsConfigPayload(odsConfigResp);
			
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = "Error occurred while creating or updating ODS Config. " + e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = "Error occurred while creating or updating ODS Config. " + e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting createOrUpdateOdsConfig");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/get", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get ODS Configuration Details", notes = "Get ODS Configuration Details", response = ODSConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved ODS Configurations", response = ODSConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "get ODS Configurations Service is unavaialble") })
	public ResponseEntity<ODSConfigResponse> getOdsConfigurations(@RequestBody ODSKeyDetails request)
														throws ApplicationException {
		
		LOGGER.info("Entering getOdsConfigurations");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		ODSConfigResponse response = new ODSConfigResponse();
		
		try {
			ODSConfigPayload odsConfigresponse = odsConfigService.getOdsConfigurations(request);
			
			if(null == odsConfigresponse) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsConfigPayload(odsConfigresponse);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = "Error occurred while retrieving ODS Config. " + e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = "Error occurred while retrieving ODS Config. " + e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting getOdsConfigurations");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Delete ODS Configuration Details", notes = "Delete ODS Configuration Details", response = ODSConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully deleted ODS Configuration record", response = ODSConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Delete ODS Configuration Service is unavaialble") })
	public ResponseEntity<ODSConfigResponse> deleteOdsConfigurations(@RequestBody ODSKeyDetails request)
														throws ApplicationException {
		
		LOGGER.info("Entering deleteOdsConfigurations");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		ODSConfigResponse response = new ODSConfigResponse();
		
		try {
			odsConfigService.deleteOdsConfiguration(request);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = "Error occurred while deleting ODS Config. " + e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = "Error occurred while deleting ODS Config. " + e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting deleteOdsConfigurations");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	

	/**
	 * @param InsertScriptRequest
	 * @return ResponseEntity<InsertScriptResponse>
	 */
	@RequestMapping(value = "/getSqlInsertScript", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "getSqlInsertScript for all table configurations", notes = "getSqlInsertScript for all table configurations", response = InsertScriptResponse.class)
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successfully parsed the Input Response Document", response = ResponseStatus.class) })
	public ResponseEntity<InsertScriptResponse> getSqlInsertScript(@RequestBody ODSKeyDetails request) {
		LOGGER.info("Entering getSqlInsertScript");

		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		InsertScriptResponse insertScriptResponse = new InsertScriptResponse();
		try {
			String insertScript = odsConfigService.generateInsertScripts(request);
			if (StringUtils.isEmpty(insertScript)) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}

			insertScriptResponse.setInsertScript(insertScript);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = "Error occurred while exporting ODS Config. " + e.getMessage();
		} catch (Exception exception) {
			LOGGER.error("Exception Occurred - ", exception);
			statusCode = StatusCode.APP_ERROR.getCode();
			statusMsg = "Error occurred while exporting ODS Config. " + exception.getMessage();
		}
		
		insertScriptResponse.setStatusCode(statusCode);
		insertScriptResponse.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting getSqlInsertScript");

		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(insertScriptResponse, headers, HttpStatus.OK);

	}
}
