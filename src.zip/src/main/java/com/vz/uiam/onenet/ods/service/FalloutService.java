/**
 *
 */
package com.vz.uiam.onenet.ods.service;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFallout;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFalloutConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.WorkflowFalloutConfigRepo;
import com.vz.uiam.onenet.ods.jpa.dao.repository.WorkflowFalloutRepo;
import com.vz.uiam.onenet.ods.jpa.dto.model.FalloutServiceResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsTransformerConfigDto;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.WorkflowFalloutRequest;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

import ma.glasnost.orika.MapperFacade;

/**
 * @author Anand
 *
 */
@Service("falloutService")
public class FalloutService {

	private static final Logger LOGGER = Logger.getLogger(FalloutService.class);

	@Autowired
	WorkflowFalloutConfigRepo configRepo;

	@Autowired
	WorkflowFalloutRepo fallOutRepo;

	@Autowired
	@Lazy(value = true)
	ODSService odsService;

	@Autowired
	OdsMandatoryAttrsService odsMandatoryAttrsService;

	@Autowired
	OdsParamConfigRepository odsParamConfigRepo;

	@Autowired
	OdsTransformerConfigService odsTransformerConfigService;

	@Autowired
	ServiceUtils serviceUtils;

	@Autowired
	ServiceUtils utils;

	@Autowired
	MapperFacade mapper;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	OdsInterfaceRequestRepository odsInterfaceRequestRepo;

	@Autowired
	OdsRequestLogRepository odsRequestLogRepository;

	@Autowired
	BonitaService bonitaService;

	@Autowired
	ManifestService manifestService;

	/**
	 * @param request
	 * @return WorkflowFalloutConfig
	 * @throws ApplicationException
	 */
	public void handleRequest(String request) throws ApplicationException {

		JSONObject requestJson = new JSONObject(request);

		// Validate the request
		String wfTaskId = requestJson.optString("wfTaskId");
		String title = requestJson.optString("title");
		String titleVersion = requestJson.optString("titleVersion");
		String wfTaskName = requestJson.optString("wfTaskName");
		String taskAction = requestJson.optString("taskAction");
		String userId = requestJson.optString("userId");
		OdsRequestLog odsRequestLog;
		if (!("REFLOW".equals(taskAction)) && !("COMPLETE".equals(taskAction))) {
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(),
					"Invalid taskAction. It should be either REFLOW or COMPLETE.");
		}
		if (!StringUtils.isEmpty(wfTaskId)) {
			odsRequestLog = odsRequestLogRepository.findByWfTaskId(wfTaskId);
		} else {
			odsRequestLog = odsRequestLogRepository.findByTitleAndTitleVersionAndWfTaskName(title, titleVersion,
					wfTaskName);
		}

		if (odsRequestLog == null) {
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					"No Record found in OdsRequestLog table for title: " + title + ", TitleVersion:  " + titleVersion
							+ ", WfTaskName: " + wfTaskName);
		}
		odsRequestLog.setUserId(userId);
		odsRequestLogRepository.save(odsRequestLog);

		if ("REFLOW".equalsIgnoreCase(taskAction)) {
			if (Constants.SUCCESS.equals(odsRequestLog.getResponseStatus())
					&& (Constants.FAILURE.equals(odsRequestLog.getWfTaskStatus())
							|| Constants.ODS_REQUEST_LOG_STATUS_PENDING.equals(odsRequestLog.getWfTaskStatus()))) {

				// Complete WF Receive Task with payload from
				// WF_Task_Completion_Payload in ods_request_log
				closeBonitaTask(odsRequestLog);
				odsRequestLogRepository.save(odsRequestLog);
			} else {
				// Get WF_Request_Payload from ods_request_log and call
				// AsyncODSRequestProxy
				callService("asyncOdsRequestProxy", odsRequestLog.getWfRequestPayload());
			}
		} else if ("COMPLETE".equalsIgnoreCase(taskAction)) {
			// Complete WF Receive Task with payload from
			// WF_Task_Completion_Payload in ods_request_log
			if ("SUCCESS".equals(odsRequestLog.getWfTaskStatus())) {
				LOGGER.info("The task " + odsRequestLog.getWfTaskName() + " with task ID " + odsRequestLog.getWfTaskId()
						+ " is already complete");
			} else {
				try{
					JSONObject workflowRequest = new JSONObject(odsRequestLog.getWfRequestPayload());
					closePendingUteTasks(workflowRequest);
				}
				catch(ApplicationException ae) {
					LOGGER.info("Application Exception while trying to close pending UTE Task : "+ae);
				}
				closeBonitaTask(odsRequestLog);
				odsRequestLogRepository.save(odsRequestLog);
			}
		}

	}

	/**
	 * This is generic method to call a service configured in
	 * 
	 * @param appParamKey
	 * @param payload
	 * @return String
	 * @throws ApplicationException
	 */
	public ResponseEntity<String> callService(String appParamKey, String payload) throws ApplicationException {
		LOGGER.info("Entering callService");

		/* Get service URL from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.APPLICATION_PARAM.toString(), appParamKey);

		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue())) {
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(),
							OdsParamConfigType.APPLICATION_PARAM.toString(), appParamKey, null));
		}
		LOGGER.info("Service URL from config table : " + odsAppParam.getValue());

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(payload, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(odsAppParam.getValue(), HttpMethod.POST, httpEntity, String.class);
		} catch (Exception e) {
			LOGGER.error("Error while calling " + appParamKey + " Service", e);
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Error while calling " + appParamKey + " Service. " + e.getMessage());
		}

		String response;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			response = responseEntity.getBody();
			if (StringUtils.isEmpty(response)) {
				LOGGER.error("Response from " + appParamKey + " is Empty");
			}
		} else {
			LOGGER.error("Error Received failure response from " + appParamKey + " Service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from " + appParamKey + " Service");
		}

		LOGGER.info("Response from " + appParamKey + " service is:::" + response);
		LOGGER.info("Exiting callService");
		return responseEntity;
	}

	/**
	 * @param request
	 * @return void
	 * @throws ApplicationException
	 */
	public void closeBonitaTask(OdsRequestLog odsRequestLog) throws ApplicationException {
		try {
			bonitaService.completeBonitaReceiveTask(odsRequestLog.getWfTaskCompletionPayload());

			// Update WF_Task_Status to 'SUCCESS' in ods_request_log table
			odsRequestLog.setWfTaskStatus(Constants.SUCCESS);
			Timestamp currentTimestamp = serviceUtils.getCurrentTimestamp();
			odsRequestLog.setLastModifiedTime(currentTimestamp);
			odsRequestLog.setCompletionTime(currentTimestamp);
			odsRequestLogRepository.save(odsRequestLog);

		} catch (Exception ex) {
			LOGGER.error("Exception while closing Bonita task : " + ex);
			// Update WF_Task_Status to 'FAILURE' in ods_request_log table
			odsRequestLog.setWfTaskStatus(Constants.FAILURE);
			odsRequestLog.setLastModifiedTime(serviceUtils.getCurrentTimestamp());
			odsRequestLogRepository.save(odsRequestLog);
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(), "Failure while closing Bonita task");
		}
	}

	/**
	 * @param request
	 * @return WorkflowFalloutConfig
	 * @throws ApplicationException
	 */
	public WorkflowFalloutConfig getFalloutConfig(WorkflowFalloutRequest request) throws ApplicationException {
		WorkflowFalloutConfig config = configRepo.findByWorkFlowStepNameAndWorkFlowFalloutErrorCode(
				request.getWorkFlowStepName(), request.getWorkFlowFalloutErrorCode());
		return config;
	}

	/**
	 * @param request
	 * @return WorkflowFalloutConfig
	 * @throws ApplicationException
	 */
	public void createFallout(WorkflowFalloutRequest request) throws ApplicationException {
		WorkflowFallout fallout = fallOutRepo.getByStatusAndCaseIdAndWorkFlowStepName(Constants.STATUS_PENDING,
				request.getCaseId(), request.getWorkFlowStepName());

		if (null != fallout) {
			fallout.setWorkFlowFalloutErrorCode(request.getWorkFlowFalloutErrorCode());
			fallout.setWorkFlowFalloutErrorDesc(request.getWorkFlowFalloutErrorDesc());
			fallOutRepo.save(fallout);
		} else {
			createNewFallout(request);
		}

	}

	/**
	 * @param request
	 */
	private void createNewFallout(WorkflowFalloutRequest request) {
		WorkflowFallout newFallout = mapper.map(request, WorkflowFallout.class);
		newFallout.setWorkFlowStepRetryCounter(0);
		newFallout.setStatus(Constants.STATUS_PENDING);
		fallOutRepo.save(newFallout);
	}

	/**
	 * 
	 * @param handleFalloutReq
	 * @throws ApplicationException
	 */
	@Async
	public void handleFallout(String handleFalloutReq, OdsRequestLog odsRequestLog) {
		LOGGER.info("Entering handleFallout");

		FalloutServiceResponse falloutSvcResp;

		JSONObject handleFalloutReqJson = new JSONObject(handleFalloutReq);

		try {
			falloutSvcResp = handleWorkflowFallout(handleFalloutReqJson, odsRequestLog);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			LOGGER.info("Making the retryFalg as false");
			falloutSvcResp = prepareHandleFalloutResponse(handleFalloutReqJson, false, 0);
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			LOGGER.info("Making the retryFalg as false");
			falloutSvcResp = prepareHandleFalloutResponse(handleFalloutReqJson, false, 0);
		}

		// Complete the Manual Task only when isRetry is TRUE
		try {
			if (falloutSvcResp.getIsRetry())
				completeManualTask(falloutSvcResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred while completing Manual Task - ", e);
		}

		LOGGER.info("Exiting handleFallout");
	}

	/**
	 *
	 * @param handleFalloutReq
	 * @return
	 * @throws ApplicationException
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public FalloutServiceResponse handleWorkflowFallout(JSONObject handleFalloutReqJson, OdsRequestLog odsRequestLog)
			throws ApplicationException {
		LOGGER.info("Entering handleWorkflowFallout");

		Boolean createUteTask = false;
		Boolean retryFlag = false;
		Integer timer = 0;

		String errorCode = handleFalloutReqJson.optString(Constants.FALLOUT_ERROR_CODE);
		String caseId = handleFalloutReqJson.optString(Constants.PROCESS_INSTANCE_ID);
		String falloutStepName = handleFalloutReqJson.optString(Constants.FALLOUT_STEP_NAME);

		WorkflowFallout fallout = fallOutRepo.getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(caseId,
				falloutStepName, errorCode, Constants.STATUS_PENDING);

		if (fallout == null) {
			LOGGER.info("############### Fallout record not found. Creating a UTE task ###############");

			createUteTask = true;
		} else {
			WorkflowFalloutRequest falloutConfigReq = new WorkflowFalloutRequest(fallout.getCaseId(),
					fallout.getWorkFlowStepName(), fallout.getWorkFlowFalloutErrorCode(),
					fallout.getWorkFlowFalloutErrorDesc());
			WorkflowFalloutConfig config = getFalloutConfig(falloutConfigReq);
			if (config == null) {
				LOGGER.info("############### Fallout Config record not found. Creating a UTE task ###############");
				fallout.setStatus(Constants.PROCESSED);
				fallOutRepo.save(fallout);

				createUteTask = true;
			} else {
				// Compare the fallout with config
				if (fallout.getWorkFlowStepRetryCounter() < config.getMaxRetryCounter()) {
					LOGGER.info("############### Retry threshold NOT reached. Hence retry ###############");
					// set retry flag == true and increment the counter
					retryFlag = true;
					timer = config.getRetryInterval();
					fallout.setExpiryTime(serviceUtils.addBufferInMinutesToTime(serviceUtils.getCurrentTimestamp(),timer));
					fallOutRepo.save(fallout);
				} else {
					LOGGER.info("############### Retry threshold reached. Creating a UTE task ###############");
					fallout.setStatus(Constants.PROCESSED);
					fallout.setExpiryTime(null);
					fallOutRepo.save(fallout);
					createUteTask = true;
				}
			}
		}

		if (createUteTask && odsRequestLog != null && (!Constants.SUCCESS.equals(odsRequestLog.getWfTaskStatus()))) {
			JSONObject uteTaskListDocumentPayload = getUteTaskListdocument(handleFalloutReqJson);
			createOrUpdateUTETaskForFallout(handleFalloutReqJson,uteTaskListDocumentPayload);
		}

		FalloutServiceResponse response = prepareHandleFalloutResponse(handleFalloutReqJson, retryFlag, timer);
		LOGGER.info("Exiting handleFallout");

		return response;
	}
	
	public JSONObject getUteTaskListdocument(JSONObject workflowRequest) throws ApplicationException {
		LOGGER.info("Entering getUteTaskListdocument");
		JSONObject manifestRequestPayload = manifestService.fetchManifestRequestPayload(workflowRequest);
		OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(
				OdsParamConfigType.ODS.toString(), OdsParamConfigType.ODS_PARAM.toString(),
				Constants.UTE_TASK_LIST_DOC_NAME_LITERAL);
		String manifestDocumentName = odsAppParam.getValue();
		JSONObject manifestDocument = manifestService.buildManifestDocument(manifestRequestPayload,manifestDocumentName);
		JSONObject documentPayload = manifestDocument.getJSONObject(manifestDocumentName);
		LOGGER.info("Exiting getUteTaskListdocument");
		return documentPayload;
	}
	
	public boolean isUteTaskExist(JSONObject uteTaskListDocument, String externalTaskId) throws ApplicationException {
		LOGGER.info("Entering isUteTaskExist for externalTaskId "+externalTaskId);
		boolean isUteTaskExist = false;
		JSONObject documentPayload = uteTaskListDocument.getJSONObject(Constants.MANIFEST_DOCUMENT_PAYLOAD_STR);
		if(documentPayload!=null && documentPayload.has(externalTaskId))
			isUteTaskExist = true;
		LOGGER.info("Exiting isUteTaskExist with "+isUteTaskExist);
		return isUteTaskExist;
	}

	/**
	 *
	 * @param handleFalloutReq
	 * @return
	 * @throws ApplicationException
	 */
	public FalloutServiceResponse isRetryPossible(JSONObject requestJson) throws ApplicationException {
		LOGGER.info("Entering isRetryPossible");
		Boolean retryFlag = false;
		String errorCode = requestJson.optString(Constants.FALLOUT_ERROR_CODE);
		String falloutStepName = requestJson.optString(Constants.FALLOUT_STEP_NAME);
		String transactionId = requestJson.optString(Constants.TRANSACTION_ID);

		OdsInterfaceRequest odsInterfaceReq = odsInterfaceRequestRepo.findByTransactionIdAndStatus(transactionId,
				StatusCode.REQUEST_PENDING.toString());
		if (odsInterfaceReq == null) {
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					"No Pending record found in OdsInterfaceRequest for transactionId - " + transactionId);
		}
		ResponseConfigParams responseConfigParam = (ResponseConfigParams) serviceUtils
				.convertJsonStringToObject(odsInterfaceReq.getResponseConfigParam(), ResponseConfigParams.class);
		String caseId = responseConfigParam.getCaseID();

		WorkflowFalloutRequest falloutConfigReq = new WorkflowFalloutRequest(caseId, falloutStepName, errorCode);
		WorkflowFalloutConfig config = getFalloutConfig(falloutConfigReq);

		if (config != null) {
			WorkflowFallout fallout = fallOutRepo.getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(
					caseId, falloutStepName, errorCode, Constants.STATUS_PENDING);

			if (fallout == null) {
				if (config.getMaxRetryCounter() > 0) {
					LOGGER.info(
							"############### There is Config. No Fallout created yet. Hence retry true ###############");
					retryFlag = true;
				}
			} else {
				if (fallout.getWorkFlowStepRetryCounter() < config.getMaxRetryCounter()) {
					LOGGER.info("############### Retry threshold NOT reached. Hence retry true ###############");
					retryFlag = true;
				}
			}
		}

		FalloutServiceResponse response = new FalloutServiceResponse();
		response.setIsRetry(retryFlag);
		LOGGER.info("Exiting isRetryPossible");
		return response;
	}

	/**
	 * 
	 * @param requestJson
	 * @throws ApplicationException
	 */
	public void createOrUpdateUTETaskForFallout(JSONObject requestJson, JSONObject uteTaskListDocumentPayload) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateUTETaskForFallout");

		OdsParamConfig odsParamConfig = odsParamConfigRepo.findByParamKeyAndTypeAndName(
				requestJson.getString(Constants.MANIFEST_APP_KEY_STR), OdsParamConfigType.APPLICATION_PARAM.toString(),
				Constants.UTE_REQUEST_DOCUMENT_NAMES);
		String requestDocumentName = null;

		if (odsParamConfig != null && (!StringUtils.isEmpty(odsParamConfig.getValue()))) {
			requestDocumentName = odsParamConfig.getValue();
		} else {
			LOGGER.error("Request Document Name to build UTE Schema is not configure for "
					+ requestJson.getString(Constants.MANIFEST_APP_KEY_STR));
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(),
					"Request Document Name to build UTE Schema is not configure for "
							+ requestJson.getString(Constants.MANIFEST_APP_KEY_STR));
		}

		String manifestPayload = buildManifestPayload(requestJson);

		// Make call to manifest service and get the Manifest document-payload
		String documentPayload = serviceUtils.buildManifestDocument(manifestPayload, requestDocumentName);

		String externalTaskId = serviceUtils.buildExternalTaskId(requestJson.optString(Constants.ROOT_CASE_ID), requestJson.optString(Constants.ACTIVITY_INSTANCE_ID));
		boolean isUteTaskExist = isUteTaskExist(uteTaskListDocumentPayload,externalTaskId);
		
		JSONObject finalDocument = new JSONObject(documentPayload);
		finalDocument.put(Constants.REQUEST_PAYLOAD, requestJson);
		
		String uteResponse;
		
		if(!isUteTaskExist) {
			//Create UTE Task
			uteResponse = createUteTaskService(finalDocument);
			if (StringUtils.isNotEmpty(uteResponse)) {
				JSONObject uteResponseJson = new JSONObject(uteResponse);
				addUteTaskToManifest(uteResponseJson, requestJson, uteTaskListDocumentPayload);
			} else {
				LOGGER.error("Received empty response from create UTE Task Service");
				throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
						"Received empty response from create UTE Task Service.");
			}
		}
		else {
			//Update UTE Task
			LOGGER.info("There is already 1 UTE task open for this step - "+externalTaskId+". So not creating another UTE task");
			uteResponse = updateUteTaskService(finalDocument);
		}

		
		LOGGER.info("Exiting createOrUpdateUTETaskForFallout");
	}

	public JSONObject composeEntityAttributesForManifestRequest(String transformerKey, JSONObject requestJson)
			throws ApplicationException {
		LOGGER.info("Entering composeEntityAttributesForManifestRequest");
		String requestStr = requestJson.toString();
		OdsTransformerConfigDto request = new OdsTransformerConfigDto(transformerKey, requestStr);
		String manifestRequestPayloadStr = odsTransformerConfigService.tranformDocument(request);
		LOGGER.info("Exiting composeEntityAttributesForManifestRequest");
		return new JSONObject(manifestRequestPayloadStr);
	}

	public JSONObject getManifestDocument(JSONObject manifestRequestPayload, String manifestDocumentName) {
		LOGGER.info("Entering getManifestDocument");
		JSONObject manifestDocument;
		try {
			manifestDocument = manifestService.buildManifestDocument(manifestRequestPayload, manifestDocumentName);
			if (manifestDocument != null) {
				JSONObject documentPayload = manifestDocument.getJSONObject(manifestDocumentName)
						.getJSONObject(Constants.MANIFEST_DOCPAYLOAD_KEY);
				if (documentPayload == null || "{}".equals(documentPayload.toString())) {
					LOGGER.info("Manifest Document not found. So creating a new one.");
					manifestDocument = new JSONObject();
				}
				else
					manifestDocument = manifestDocument.getJSONObject(manifestDocumentName);
			}
		} catch (ApplicationException e) {
			LOGGER.info("Manifest Document not found. So creating a new one." + e);
			manifestDocument = new JSONObject();
		}
		LOGGER.info("Exiting getManifestDocument");
		return manifestDocument;
	}

	public JSONObject composeDocumentPayload(JSONObject uteResponseJson) {
		LOGGER.info("Entering composeDocumentPayload");
		JSONObject documentSubPayload = new JSONObject();
		documentSubPayload.put(Constants.EXTERNAL_TASK_ID_LITERAL,
				uteResponseJson.getString(Constants.EXTERNAL_TASK_ID_LITERAL));
		JSONObject taskHeader = uteResponseJson.getJSONObject(Constants.TASK_HEADER_LITERAL);
		documentSubPayload.put(Constants.TASK_SOURCE_LITERAL, taskHeader.getString(Constants.TASK_SOURCE_LITERAL));
		documentSubPayload.put(Constants.USER_ID_LITERAL, taskHeader.getString(Constants.USER_ID_LITERAL));
		documentSubPayload.put(Constants.CREATOR_LITERAL, taskHeader.getString(Constants.CREATOR_LITERAL));
		documentSubPayload.put(Constants.STATUS_LITERAL, Constants.STATUS_IN_PROGRESS_LITERAL);
		JSONObject documentPayload = new JSONObject();
		documentPayload.put(uteResponseJson.getString(Constants.EXTERNAL_TASK_ID_LITERAL), documentSubPayload);
		LOGGER.info("Exiting composeDocumentPayload");
		return documentPayload;
	}

	public void addUteTaskToManifest(JSONObject uteResponseJson, JSONObject requestJson, JSONObject manifestDocument) throws ApplicationException {
		LOGGER.info("Entering addUteTaskToManifest");
		String uteTaskCreationStatusCode = uteResponseJson.getString(Constants.UTE_TASK_CREATION_STATUS_CODE);
		String uteTaskCreationStatusMsg = uteResponseJson.getString(Constants.UTE_TASK_CREATION_STATUS_MSG);

		if (Constants.UTE_TASK_CREATION_STATUS_CODE_SUCCESS.equals(uteTaskCreationStatusCode)
				&& Constants.UTE_TASK_CREATION_STTUS_MSG_SUCCESS.equals(uteTaskCreationStatusMsg)) {

			// compose entity-attributes BEGINS
			JSONObject manifestRequestPayload = manifestService.fetchManifestRequestPayload(requestJson);
			// compose entity-attributes ENDS

			// GET Manifest DocumentName
			OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(
					OdsParamConfigType.ODS.toString(), OdsParamConfigType.ODS_PARAM.toString(),
					Constants.UTE_TASK_LIST_DOC_NAME_LITERAL);
			String manifestDocumentName = odsAppParam.getValue();

			// Compose document-payload BEGINS
			JSONObject documentPayload = composeDocumentPayload(uteResponseJson);
			// compose document-payload ENDS

			if (manifestDocument!=null && !"{}".equals(manifestDocument.toString())) {
				((JSONObject) manifestDocument.get(Constants.MANIFEST_DOCPAYLOAD_KEY)).put(
						uteResponseJson.getString(Constants.EXTERNAL_TASK_ID_LITERAL),
						documentPayload.getJSONObject(uteResponseJson.getString(Constants.EXTERNAL_TASK_ID_LITERAL)));
			} else
				manifestDocument.put(Constants.MANIFEST_DOCPAYLOAD_KEY, documentPayload);

			manifestDocument.put(Constants.ENTITY_DATA_STR,
					manifestRequestPayload.getJSONObject(Constants.ENTITY_DATA_STR));
			manifestDocument.getJSONObject(Constants.ENTITY_DATA_STR).put(Constants.MANIFEST_DOCUMENT_NAME_STR,
					manifestDocumentName);
			LOGGER.info("UTE Task List Manifest Document to be updated : " + manifestDocument.toString());
			manifestService.createOrUpdateManifestDoc(manifestDocument.toString());

		} else {
			LOGGER.error("Received failure response from create UTE Task Service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from create UTE Task Service.");
		}
		LOGGER.info("Exiting addUteTaskToManifest");
	}

	/**
	 * The method verifies the mandatory attributes configured in the
	 * ods_mandatory_attrs for given APPKEY. These attributes are required in order
	 * to fetch the document from Manifest DB.
	 *
	 * @param requestObj
	 * @param details
	 * @throws ApplicationException
	 */
	public String buildManifestPayload(JSONObject requestObj) throws ApplicationException {
		LOGGER.info("Entering buildManifestPayload");

		odsService.validateAppkey(requestObj);

		// Validate Manifest attributes
		List<OdsMandatoryAttributes> mandatoryAttrbsList = odsMandatoryAttrsService
				.getMandatoryAttributeList(requestObj.getString(Constants.MANIFEST_APP_KEY_STR));
		if (CollectionUtils.isEmpty(mandatoryAttrbsList)) {
			LOGGER.error(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
			throw new ApplicationException(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getCode(),
					StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
		}

		JSONArray manifestAttributesArray = new JSONArray();
		odsService.validateManifestAttributes(requestObj, mandatoryAttrbsList, manifestAttributesArray);
		LOGGER.info("Manifest Attributes Array is :::::" + manifestAttributesArray.toString());
		// Prepare Manifest Get Request
		String entityData = odsService.buildManifestPayload(requestObj, manifestAttributesArray);
		LOGGER.info("Manifest Request Payload is ::::: " + entityData);

		LOGGER.info("Exiting buildManifestPayload");
		return entityData;
	}

	/**
	 * 
	 * @param createUteTaskPayload
	 * @throws ApplicationException
	 */
	public String createUteTaskService(JSONObject createUteTaskPayload) throws ApplicationException {
		LOGGER.info("Entering createUteTaskService");

		/* Get UTETask Creation URl from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.CREATE_UTE_TASK_URL);

		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(),
							OdsParamConfigType.ODS_PARAM.toString(), Constants.CREATE_UTE_TASK_URL, null));

		String transformerKey = createUteTaskPayload.getJSONObject(Constants.REQUEST_PAYLOAD)
				.optString(Constants.MANIFEST_APP_KEY_STR) + Constants.UTE_SCHEMA_TRANSFORM_KEY_SUFFIX;

		String utRequestPayLoad = createUteTaskPayload.toString();
		OdsTransformerConfigDto request = new OdsTransformerConfigDto(transformerKey, utRequestPayLoad);
		String finalUtePayLoad = odsTransformerConfigService.tranformDocument(request);

		LOGGER.info("create UTE Task payload - " + finalUtePayLoad);

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(finalUtePayLoad, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = serviceUtils.callService(odsAppParam, httpEntity);

		String response;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			response = responseEntity.getBody();
		} else {
			LOGGER.error("Received failure response from create UTE Task Service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from create UTE Task Service. "
							+ serviceUtils.getResponseStatusAndBody(responseEntity));
		}
		LOGGER.info("UTE Response : " + response);
		LOGGER.info("Exiting createUteTaskService");
		return response;
	}
	
	/**
	 * 
	 * @param createUteTaskPayload
	 * @throws ApplicationException
	 */
	public String updateUteTaskService(JSONObject updateUteTaskPayload) throws ApplicationException {
		LOGGER.info("Entering updateUteTaskService");

		/* Get UTETask Creation URl from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.UPDATE_UTE_TASK_URL);

		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(),
							OdsParamConfigType.ODS_PARAM.toString(), Constants.UPDATE_UTE_TASK_URL, null));

		String transformerKey = updateUteTaskPayload.getJSONObject(Constants.REQUEST_PAYLOAD)
				.optString(Constants.MANIFEST_APP_KEY_STR) + Constants.UPDATE_UTE_SCHEMA_TRANSFORM_KEY_SUFFIX;

		String utRequestPayLoad = updateUteTaskPayload.toString();
		OdsTransformerConfigDto request = new OdsTransformerConfigDto(transformerKey, utRequestPayLoad);
		String finalUtePayLoad = odsTransformerConfigService.tranformDocument(request);

		LOGGER.info("Update UTE Task payload - " + finalUtePayLoad);

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(finalUtePayLoad, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = serviceUtils.callService(odsAppParam, httpEntity);

		String response;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			response = responseEntity.getBody();
		} else {
			LOGGER.error("Received failure response from Update UTE Task Service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from Update UTE Task Service. "
							+ serviceUtils.getResponseStatusAndBody(responseEntity));
		}
		LOGGER.info("UTE Response : " + response);
		LOGGER.info("Exiting updateUteTaskService");
		return response;
	}

	
	/**
	 * Completes a UTE task in UTE
	 * 
	 */
	public String completeUteTask(JSONObject externalTaskIdJson, JSONObject workflowRequest) throws ApplicationException {
		LOGGER.info("Entering completeUteTask");

		/* Get UTETask Creation URl from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.COMPLETE_UTE_TASK_URL);

		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(),
							OdsParamConfigType.ODS_PARAM.toString(), Constants.COMPLETE_UTE_TASK_URL, null));

		String transformerKey = workflowRequest.optString(Constants.MANIFEST_APP_KEY_STR) + Constants.COMPLETE_UTE_SCHEMA_TRANSFORM_KEY_SUFFIX;

		String uteRequestPayLoad = externalTaskIdJson.toString();
		OdsTransformerConfigDto request = new OdsTransformerConfigDto(transformerKey, uteRequestPayLoad);
		String finalUtePayLoad = odsTransformerConfigService.tranformDocument(request);

		LOGGER.info("Complete UTE Task payload - " + finalUtePayLoad);

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(finalUtePayLoad, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = serviceUtils.callService(odsAppParam, httpEntity);

		String response;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			response = responseEntity.getBody();
		} else {
			LOGGER.error("Received failure response from Complete UTE Task Service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from Complete UTE Task Service. "
							+ serviceUtils.getResponseStatusAndBody(responseEntity));
		}
		LOGGER.info("UTE Response : " + response);
		LOGGER.info("Exiting completeUteTask");
		return response;
	}

	/**
	 * 
	 * @param falloutSvcResp
	 * @throws ApplicationException
	 */
	public void completeManualTask(FalloutServiceResponse falloutSvcResp) throws ApplicationException {
		LOGGER.info("Entering completeManualTask");

		JSONObject completeManualTaskReq = preparePayloadForCompletingManualTask(falloutSvcResp);
		LOGGER.info("Payload for completing Manual Task - " + completeManualTaskReq.toString(2));

		callCompleteManualTaskService(completeManualTaskReq.toString());

		LOGGER.info("Exiting completeManualTask");
	}

	/**
	 * API to call Service to complete Manual Task
	 * 
	 * @param completeManualTaskReq
	 * @throws ApplicationException
	 */
	public void callCompleteManualTaskService(String completeManualTaskReq) throws ApplicationException {
		LOGGER.info("Entering callCompleteManualTaskService");

		/* Get UTETask Creation URl from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.COMPLETE_MANUAL_TASK_URL);

		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(),
							OdsParamConfigType.ODS_PARAM.toString(), Constants.COMPLETE_MANUAL_TASK_URL, null));

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(completeManualTaskReq, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = serviceUtils.callService(odsAppParam, httpEntity);

		String response;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			response = responseEntity.getBody();
		} else {
			LOGGER.error("Received failure response from Complete Manual Task service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from Complete Manual Task service. "
							+ serviceUtils.getResponseStatusAndBody(responseEntity));
		}
		LOGGER.info("Response from Complete Manual Task service - " + response);

		LOGGER.info("Exiting callCompleteManualTaskService");
	}

	/**
	 * API to create payload for completing Manual task
	 * 
	 * @param falloutSvcResp
	 * @return
	 */
	public JSONObject preparePayloadForCompletingManualTask(FalloutServiceResponse falloutSvcResp) {
		LOGGER.info("Entering preparePayloadForCompletingManualTask");

		JSONObject completeManualTaskReq = new JSONObject();

		completeManualTaskReq.put(Constants.FALLOUT_CASE_ID, falloutSvcResp.getCaseId());
		completeManualTaskReq.put(Constants.FALLOUT_TASK_NAME, falloutSvcResp.getWorkFlowStepName());

		JSONObject taskContractVars = new JSONObject();
		taskContractVars.put(Constants.FALLOUT_ISRETRY_VAR, falloutSvcResp.getIsRetry());
		taskContractVars.put(Constants.FALLOUT_RETRYINTERVAL_VAR, falloutSvcResp.getWorkFlowStepRetryFrequency());

		completeManualTaskReq.put(Constants.FALLOUT_TASK_CONTRACT_VAR, taskContractVars);

		LOGGER.info("Exiting preparePayloadForCompletingManualTask");
		return completeManualTaskReq;
	}

	/**
	 * 
	 * @param handleFalloutReqJson
	 * @param isRetry
	 * @param timer
	 * @return
	 */
	public FalloutServiceResponse prepareHandleFalloutResponse(JSONObject handleFalloutReqJson, Boolean isRetry,
			int timer) {
		LOGGER.info("Entering prepareHandleFalloutResponse");

		FalloutServiceResponse response = new FalloutServiceResponse();

		response.setCaseId(handleFalloutReqJson.optString(Constants.PROCESS_INSTANCE_ID));
		response.setWorkFlowStepName(handleFalloutReqJson.optString(Constants.FLOW_STEP_NAME));
		response.setIsRetry(isRetry);
		response.setWorkFlowStepRetryFrequency(timer);

		LOGGER.info("Handle Fallout Async Response - " + response);

		LOGGER.info("Exiting prepareHandleFalloutResponse");
		return response;
	}
	
	public void closePendingUteTasks(JSONObject workflowRequest) throws ApplicationException {
		LOGGER.info("Entering closePendingUteTasks");
		JSONObject manifestRequestPayload = manifestService.fetchManifestRequestPayload(workflowRequest);
		OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.UTE_TASK_LIST_DOC_NAME_LITERAL);
		String manifestDocumentName = odsAppParam.getValue();
		JSONObject manifestDocument = manifestService.buildManifestDocument(manifestRequestPayload,
				manifestDocumentName);
		JSONObject documentPayload = manifestDocument.getJSONObject(manifestDocumentName)
				.getJSONObject(Constants.MANIFEST_DOCUMENT_PAYLOAD_STR);
		LOGGER.info("UTE Task List Manifest Document Fetched :" + manifestDocument);

		String externalTaskId = serviceUtils.buildExternalTaskId(workflowRequest.getString(Constants.ROOT_CASE_ID),
				workflowRequest.getString(Constants.ACTIVITY_INSTANCE_ID));
		String externalTaskIdSchema = "$." + manifestDocumentName + "." + Constants.MANIFEST_DOCUMENT_PAYLOAD_STR + "."
				+ externalTaskId;

		if (documentPayload != null && documentPayload.has(externalTaskId)) {
			JSONObject externalTaskIdJson = (JSONObject) serviceUtils.getJsonSchemaValue(externalTaskIdSchema,
					manifestDocument.toString());

			if (externalTaskIdJson != null && StringUtils.isNotEmpty(externalTaskIdJson.toString())
					&& !"{}".equals(externalTaskIdJson.toString())) {
				completeUteTaskAndUpdateManifest(workflowRequest, manifestDocument, manifestRequestPayload,
						externalTaskIdJson, manifestDocumentName, externalTaskId);
			}
		}
		LOGGER.info("Exiting closePendingUteTasks");
	}
	
	public void completeUteTaskAndUpdateManifest(JSONObject workflowRequest, JSONObject manifestDocument,
			JSONObject manifestRequestPayload, JSONObject externalTaskIdJson, String manifestDocumentName,
			String externalTaskId) throws ApplicationException {
		LOGGER.info("Entering completeUteTaskAndUpdateManifest");
		String uteResponse = completeUteTask(externalTaskIdJson, workflowRequest);
		if (StringUtils.isNotEmpty(uteResponse)) {
			removeUteTaskFromManifest(manifestDocument, manifestRequestPayload, manifestDocumentName, externalTaskId);
		} else {
			LOGGER.error("Received empty response from Complete UTE Task Service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received empty response from Complete UTE Task Service.");
		}
		LOGGER.info("Exiting completeUteTaskAndUpdateManifest");
	}
	
	public void removeUteTaskFromManifest(JSONObject manifestDocument, JSONObject manifestRequestPayload,
			String manifestDocumentName, String externalTaskId) throws ApplicationException {
		LOGGER.info("Entering removeUteTaskFromManifest");
		manifestDocument = manifestDocument.getJSONObject(manifestDocumentName);
		manifestDocument.getJSONObject(Constants.MANIFEST_DOCUMENT_PAYLOAD_STR).remove(externalTaskId);

		manifestDocument.put(Constants.ENTITY_DATA_STR,
				manifestRequestPayload.getJSONObject(Constants.ENTITY_DATA_STR));
		manifestDocument.getJSONObject(Constants.ENTITY_DATA_STR).put(Constants.MANIFEST_DOCUMENT_NAME_STR,
				manifestDocumentName);

		LOGGER.info("UTE Task List Manifest Document to be updated : " + manifestDocument.toString());
		manifestService.createOrUpdateManifestDoc(manifestDocument.toString());
		LOGGER.info("Exiting removeUteTaskFromManifest");
	}
	
	public void completeAllUteTasks(String wfRequest) throws ApplicationException {
		LOGGER.info("Entering completeAllUteTasks");
		JSONObject workflowRequest = new JSONObject(wfRequest);
		JSONObject manifestRequestPayload = manifestService.fetchManifestRequestPayload(workflowRequest);
		OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.UTE_TASK_LIST_DOC_NAME_LITERAL);
		String manifestDocumentName = odsAppParam.getValue();
		JSONObject manifestDocument = manifestService.buildManifestDocument(manifestRequestPayload,
				manifestDocumentName);
		JSONObject documentPayload = manifestDocument.getJSONObject(manifestDocumentName)
				.getJSONObject(Constants.MANIFEST_DOCUMENT_PAYLOAD_STR);
		LOGGER.info("UTE Task List Manifest Document Fetched :" + manifestDocument);
		
		for (String externalTaskId : new HashSet<String>(documentPayload.keySet())) {
			JSONObject externalTaskIdJson = documentPayload.getJSONObject(externalTaskId);
			
			if (externalTaskIdJson != null && StringUtils.isNotEmpty(externalTaskIdJson.toString())
				&& !"{}".equals(externalTaskIdJson.toString())) {
			
				completeUteTaskAndUpdateManifest(workflowRequest, manifestDocument, manifestRequestPayload,
						externalTaskIdJson, manifestDocumentName, externalTaskId);
			
			}
		}
		LOGGER.info("Exiting completeAllUteTasks");
	}
	
	public void removePendingAutoRetriesDuringSupp(String wfRequest) throws ApplicationException {
		LOGGER.info("Entering removePendingAutoRetriesDuringSupp");
		JSONObject workflowRequest = new JSONObject(wfRequest);
		String rootCaseId = workflowRequest.getString(Constants.ROOT_CASE_ID);
		List<WorkflowFallout> odsFallOutList = fallOutRepo.getByRootCaseIdAndStatusAndExpiryTimeIsNotNull(rootCaseId,
				Constants.STATUS_PENDING);
		for (WorkflowFallout fallout : odsFallOutList) {
			fallout.setExpiryTime(null);
			fallout.setStatus(Constants.PROCESSED);
			fallOutRepo.save(fallout);
		}
		LOGGER.info("Exiting removePendingAutoRetriesDuringSupp");
	}
	
	public void updateStatusAndExpiryTimeByWfTaskIdAndStatus(String status, String wfTaskId)
			throws ApplicationException {
		LOGGER.info("Entering updateStatusAndExpiryTimeByWfTaskIdAndStatus");
		List<WorkflowFallout> wfFallouts = fallOutRepo.getByStatusAndWfTaskId(status, wfTaskId);
		for (WorkflowFallout wfFallout : wfFallouts) {
			wfFallout.setExpiryTime(null);
			wfFallout.setStatus(Constants.PROCESSED);
			fallOutRepo.save(wfFallout);
		}
		LOGGER.info("Entering updateStatusAndExpiryTimeByWfTaskIdAndStatus");
	}
}
