/**
 * 
 */
package com.vz.uiam.onenet.ods.service;

import java.util.Calendar;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

/**
 * @author Ashish Goyal
 *
 */
@Service
public class ODSJsonResponseHandler {

	private static final Logger LOGGER = Logger.getLogger(ODSJsonResponseHandler.class);
	
		
	@Autowired
	ServiceUtils serviceUtils;
	
	@Autowired
	ODSResponseHandler odsResponseHandler;
	
	@Autowired
	OdsRequestResponseTransactionIdMapService odsRequestResponseTransactionIdMapService;
	
	@Autowired
	OdsRequestLogRepository odsRequestLogRepository;
	
	@Autowired
	NotesService notesService;
	

	/**
	 * @param response
	 * @return JSONObject
	 * @throws ApplicationException  
	 */
	public JSONObject handleJsonResponse(String response, String transactionId, OdsInterfaceRequest odsInterfaceReq)throws ApplicationException {
		LOGGER.info("Entering handleJsonResponse");		

		JSONObject originalResponse = null;
		
		originalResponse = new JSONObject(response);	
		
		if(!odsResponseHandler.checkForAckInResponse(response,odsInterfaceReq)) { 			//Proceed further only if Ack not found in response.					
				
			ResponseConfigParams responseConfigParam   = odsResponseHandler.getResponseConfigParams(odsInterfaceReq);
			String requestKey = odsResponseHandler.buildRequestKey(responseConfigParam);
			//Get ODS_Request_log table entry
			OdsRequestLog odsRequestLog = odsRequestLogRepository.findByWfTaskId(odsInterfaceReq.getTaskId());
			
			if(odsRequestLog != null){
				odsResponseHandler.prepareNotesPayloadAddNotes(odsRequestLog,Constants.RESPONSE_RECEIVED_SUCCESSFULLY,response,responseConfigParam,requestKey);		
			}
			//Update ods_interface_request row with response
			odsInterfaceReq.setResponse(response);
			odsInterfaceReq.setResponseTime(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
			
			//Process the response 
			ResponseStatus responseStatus = odsResponseHandler.processResponse(response, odsInterfaceReq, responseConfigParam, requestKey);
			
			//Add or update the status in response payload
			odsResponseHandler.addOrUpdateStatus(originalResponse, responseStatus);
				
		}
		return originalResponse;
	}
	
	

	
	
	
	
	/**
	 * @param response
	 * @return transactionId
	 * @throws ApplicationException  
	 */
	public String getTransactionIdFromJsonResponse(String response) throws ApplicationException {
		LOGGER.info("Entering getTransactionIdFromJsonResponse");
		String transactionId = null;
		transactionId = serviceUtils.getTransactionIdFromResponse(response);
		if (StringUtils.isEmpty(transactionId)) {
			// Get the root tag of the response JSON
			String rootTagName = serviceUtils.getRootTagFromJson(response);
			LOGGER.info("rootTagName : " + rootTagName);
			
			if (StringUtils.isEmpty(rootTagName)){
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "rootTagName not found in the JSON response");
			}
			// Get transactionIdKey using the rootTagName
			String transactionIdKey = odsResponseHandler.getTransIdKeyFromOdsRespTransIdMap(rootTagName);
			LOGGER.info("transactionIdKey : " + transactionIdKey);
			// Get the TransactionId from the response
			transactionId = odsRequestResponseTransactionIdMapService.generateTransactionIdUsingTransactionIdKey(response, transactionIdKey);
		}
		LOGGER.info("transactionId : " + transactionId);
		LOGGER.info("Exiting getTransactionIdFromJsonResponse");
		return transactionId;
	}
	
	
	/**
	 * @param response
	 * @return JSONObject
	 * @throws ApplicationException  
	 */
	public JSONObject doJsonResponseProcessing(String response, String transactionId) throws ApplicationException {
		LOGGER.info("Entering doJsonResponseProcessing");
		
		JSONObject originalResponse =  new JSONObject(response);
		
		if(originalResponse.has("ackResponse")) {
			return originalResponse;
		}
		// Get OdsInterfaceRequest record for the TransactionId
		OdsInterfaceRequest odsInterfaceReq = odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(transactionId,
				StatusCode.REQUEST_PENDING.toString());

		// Update the response in OdsInterfaceRequest
		odsInterfaceReq.setResponse(response);
		odsInterfaceReq.setResponseTime(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
		
		// convert Response Config Param JSON String to Object
		ResponseConfigParams responseConfigParam = (ResponseConfigParams) serviceUtils
				.convertJsonStringToObject(odsInterfaceReq.getResponseConfigParam(), ResponseConfigParams.class);
		
		String requestKey = serviceUtils.buildKey(responseConfigParam.getFlowNodeProcessName(),
				responseConfigParam.getFlowNodeStepName());
		// call the Notes AddOrUpdate Service
		odsResponseHandler.updateResponseInNotes(transactionId, response, requestKey);
		LOGGER.info("######responseConfigParam retrived in response processing########: " + responseConfigParam);
		
		ResponseStatus responseStatus = odsResponseHandler.processResponse(response, odsInterfaceReq);
		odsResponseHandler.addOrUpdateStatus(originalResponse, responseStatus);
		
		LOGGER.info("Exiting doJsonResponseProcessing");
		
		return originalResponse;
	}
	
	/**
	 * Handle exceptions occured during JSON Response processing
	 * 
	 * @param originalResponse
	 * @param failureResponseStatus
	 */
	public void handleException(JSONObject originalResponse, ResponseStatus failureResponseStatus, OdsInterfaceRequest odsInterfaceReq) {
		
		LOGGER.info("Entering handleException");
		
		odsResponseHandler.addOrUpdateStatus(originalResponse, failureResponseStatus);
		
		notesService.addNotesForException(odsInterfaceReq, originalResponse.toString(), failureResponseStatus );
		
		if (odsInterfaceReq != null) {
		
			ResponseConfigParams responseConfigParam;
			try {
				responseConfigParam = (ResponseConfigParams) serviceUtils
						.convertJsonStringToObject(odsInterfaceReq.getResponseConfigParam(), ResponseConfigParams.class);
				if (responseConfigParam != null)
				{
					OdsRequestLog odsRequestLog = odsRequestLogRepository.findByWfTaskId(odsInterfaceReq.getTaskId());
					if (!(Constants.SUCCESS.equals(odsRequestLog.getResponseStatus()))) {
						odsResponseHandler.createFallout(responseConfigParam, failureResponseStatus);
						odsResponseHandler.handleFallout(failureResponseStatus, responseConfigParam, odsRequestLog);
					}
				}
			} catch (Exception e) {
				LOGGER.error("############Exception occured while creating fallout for the exception occurred during JSON response processing#################"
						+ "ERROR DESCRIPTION IS:::::", e);
			}
		}
		
		LOGGER.info("Exiting handleException");
	}
	
}
