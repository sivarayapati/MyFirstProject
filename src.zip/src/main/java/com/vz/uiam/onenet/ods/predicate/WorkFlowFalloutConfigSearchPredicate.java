package com.vz.uiam.onenet.ods.predicate;

import org.apache.commons.lang3.StringUtils;

import com.mysema.query.types.expr.BooleanExpression;
import com.vz.uiam.onenet.ods.jpa.dao.model.QOdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dao.model.QWorkflowFalloutConfig;


public class WorkFlowFalloutConfigSearchPredicate {

	private static QWorkflowFalloutConfig odsWorkflowFalloutConfig = QWorkflowFalloutConfig.workflowFalloutConfig;
	
	public WorkFlowFalloutConfigSearchPredicate() {
		super();
	}
	
	
	public BooleanExpression isWorkflowProcessNameEqualsIg(String workflowProcessName) {
		return !StringUtils.isEmpty(workflowProcessName) ? odsWorkflowFalloutConfig.workflowProcessName.equalsIgnoreCase(workflowProcessName) : null;
	}
	
	public BooleanExpression isWorkFlowStepNameEqualsIg(String workFlowStepName) {
		return !StringUtils.isEmpty(workFlowStepName) ? odsWorkflowFalloutConfig.workFlowStepName.equalsIgnoreCase(workFlowStepName) : null;
	}
}
