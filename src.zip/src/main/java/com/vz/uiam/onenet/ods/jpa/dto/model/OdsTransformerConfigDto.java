/**
 *
 */
package com.vz.uiam.onenet.ods.jpa.dto.model;

/**
 * @author Anand Badiger
 *
 */
public class OdsTransformerConfigDto {

	private String transformerKey;

	private String transformerType;

	private String requestDocument;

	/**
	 * @return the transformerKey
	 */
	public String getTransformerKey() {
		return transformerKey;
	}

	/**
	 * @param transformerKey the transformerKey to set
	 */
	public void setTransformerKey(String transformerKey) {
		this.transformerKey = transformerKey;
	}

	/**
	 * @return the transformerType
	 */
	public String getTransformerType() {
		return transformerType;
	}

	/**
	 * @param transformerType the transformerType to set
	 */
	public void setTransformerType(String transformerType) {
		this.transformerType = transformerType;
	}



	/**
	 * @param transformerKey
	 * @param transformerType
	 * @param requestDocument
	 */
	public OdsTransformerConfigDto(String transformerKey, String transformerType, String requestDocument) {
		super();
		this.transformerKey = transformerKey;
		this.transformerType = transformerType;
		this.requestDocument = requestDocument;
	}


	/**
	 * @param transformerKey
	 * @param transformerType
	 * @param requestDocument
	 */
	public OdsTransformerConfigDto(String transformerKey, String requestDocument) {
		super();
		this.transformerKey = transformerKey;
		this.requestDocument = requestDocument;
	}


	/**
	 * @return the requestDocument
	 */
	public String getRequestDocument() {
		return requestDocument;
	}

	/**
	 * @param requestDocument the requestDocument to set
	 */
	public void setRequestDocument(String requestDocument) {
		this.requestDocument = requestDocument;
	}

	public OdsTransformerConfigDto() {
	}
}
