/**
 *
 */
package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

import net.logstash.logback.encoder.org.apache.commons.lang.StringUtils;

/**
 * The Data Model class for SERVICE_ROUTE_MAP_TABLE
 *
 * @author Anand
 *
 */
@Entity
@Table(name = "ods_service_route_map")
public class OdsServiceRouterMapDetails implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "app_key")
	private String appKey;

	@Column(name = "flow_node_process_name")
	private String flowNodeProcessName;

	@Column(name = "flow_node_step_name")
	private String flowNodeStepName;

	@Column(name = "target_end_point_url")
	private String targetEndPointUrl;

	@Column(name = "request_document_name")
	private String requestDocumentName;

	@Column(name = "request_schema")
	private String requestSchema;

	@Column(name = "response_document_name")
	private String responseDocumentName;


	@Column(name = "transformation_Type")
	private String transformationType;

	@Column(name = "route_protocol")
	private String routerProtocol;

	@Column(name = "send_milestone_enabled")
	private String sendMilestoneFlag;

	@Column(name = "username")
	private String userName;

	@Column(name = "password")
	private String password;

	@Column(name = "region")
	private String region;
	
	@Column(name = "reply_to_queue_name")
	private String replyToQueueName;

	@Column(name = "src_system_name")
	private String srcSystemName;
	
	@Column(name = "dest_system_name")
	private String destSystemName;
	
	@Column(name = "request_method")
	private String requestMethod;

	@Column(name = "service_mode")
	private String serviceMode;
	
	public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the flowNodeProcessName
	 */
	public String getFlowNodeProcessName() {
		return flowNodeProcessName;
	}

	/**
	 * @param flowNodeProcessName the flowNodeProcessName to set
	 */
	public void setFlowNodeProcessName(String flowNodeProcessName) {
		this.flowNodeProcessName = flowNodeProcessName;
	}

	/**
	 * @return the flowNodeStepName
	 */
	public String getFlowNodeStepName() {
		return flowNodeStepName;
	}

	/**
	 * @param flowNodeStepName the flowNodeStepName to set
	 */
	public void setFlowNodeStepName(String flowNodeStepName) {
		this.flowNodeStepName = flowNodeStepName;
	}

	/**
	 * @return the targetEndPointUrl
	 */
	public String getTargetEndPointUrl() {
		return targetEndPointUrl;
	}

	/**
	 * @param targetEndPointUrl the targetEndPointUrl to set
	 */
	public void setTargetEndPointUrl(String targetEndPointUrl) {
		this.targetEndPointUrl = targetEndPointUrl;
	}

	/**
	 * @return the requestDocumentName
	 */
	public String getRequestDocumentName() {
		return requestDocumentName;
	}

	/**
	 * @param requestDocumentName the requestDocumentName to set
	 */
	public void setRequestDocumentName(String requestDocumentName) {
		this.requestDocumentName = requestDocumentName;
	}

	/**
	 * @return the requestSchema
	 */
	public String getRequestSchema() {
		return requestSchema;
	}

	/**
	 * @param requestSchema the requestSchema to set
	 */
	public void setRequestSchema(String requestSchema) {
		this.requestSchema = requestSchema;
	}

	/**
	 * @return the responseDocumentName
	 */
	public String getResponseDocumentName() {
		return responseDocumentName;
	}

	/**
	 * @param responseDocumentName the responseDocumentName to set
	 */
	public void setResponseDocumentName(String responseDocumentName) {
		this.responseDocumentName = responseDocumentName;
	}

	/**
	 * @return the transformationType
	 */
	public String getTransformationType() {
		return transformationType;
	}

	/**
	 * @param transformationType the transformationType to set
	 */
	public void setTransformationType(String transformationType) {
		this.transformationType = transformationType;
	}

	/**
	 * @return the routerProtocol
	 */
	public String getRouterProtocol() {
		return routerProtocol;
	}

	/**
	 * @param routerProtocol the routerProtocol to set
	 */
	public void setRouterProtocol(String routerProtocol) {
		this.routerProtocol = routerProtocol;
	}

	/**
	 * @return the sendMilestoneFlag
	 */
	public String getSendMilestoneFlag() {
		return sendMilestoneFlag;
	}

	/**
	 * @param sendMilestoneFlag the sendMilestoneFlag to set
	 */
	public void setSendMilestoneFlag(String sendMilestoneFlag) {
		this.sendMilestoneFlag = sendMilestoneFlag;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the password
	 */
	public String getPassword() throws ApplicationException {
		String pwd = "";
		if (StringUtils.isNotEmpty(password))
			pwd = ServiceUtils.base64Decode(password);

		return pwd;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) throws ApplicationException {
		if (StringUtils.isNotEmpty(password))
			this.password = ServiceUtils.base64Encode(password);
		else
			this.password = "";
	}
	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	public String getReplyToQueueName() {
		return replyToQueueName;
	}

	public void setReplyToQueueName(String replyToQueueName) {
		this.replyToQueueName = replyToQueueName;
	}

	/**
	 * @return the srcSystemName
	 */
	public String getSrcSystemName() {
		return srcSystemName;
	}

	/**
	 * @param srcSystemName the srcSystemName to set
	 */
	public void setSrcSystemName(String srcSystemName) {
		this.srcSystemName = srcSystemName;
	}

	/**
	 * @return the destSystemName
	 */
	public String getDestSystemName() {
		return destSystemName;
	}

	/**
	 * @param destSystemName the destSystemName to set
	 */
	public void setDestSystemName(String destSystemName) {
		this.destSystemName = destSystemName;
	}

	public OdsServiceRouterMapDetails() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param id
	 * @param flowNodeProcessName
	 * @param flowNodeStepName
	 * @param targetEndPointUrl
	 * @param requestDocumentName
	 * @param requestSchema
	 * @param responseDocumentName
	 * @param responseSchema
	 * @param transformationType
	 */
	public OdsServiceRouterMapDetails(Integer id, String flowNodeProcessName, String flowNodeStepName, String targetEndPointUrl,
			String requestDocumentName, String requestSchema, String responseDocumentName, String transformationType) {
		this.id = id;
		this.flowNodeProcessName = flowNodeProcessName;
		this.flowNodeStepName = flowNodeStepName;
		this.targetEndPointUrl = targetEndPointUrl;
		this.requestDocumentName = requestDocumentName;
		this.requestSchema = requestSchema;
		this.responseDocumentName = responseDocumentName;
		this.transformationType = transformationType;
	}

	/**
	 *
	 * @param flowNodeProcessName
	 * @param flowNodeStepName
	 */
	public OdsServiceRouterMapDetails(String flowNodeProcessName, String flowNodeStepName) {
		super();
		this.flowNodeProcessName = flowNodeProcessName;
		this.flowNodeStepName = flowNodeStepName;
	}

	/**
	 *
	 * @param appKey
	 * @param flowNodeProcessName
	 * @param flowNodeStepName
	 */
	public OdsServiceRouterMapDetails(String appKey, String flowNodeProcessName, String flowNodeStepName) {
		super();
		this.appKey = appKey;
		this.flowNodeProcessName = flowNodeProcessName;
		this.flowNodeStepName = flowNodeStepName;
		
	}
    
	/**
	 *
	 * @param appKey
	 * @param flowNodeProcessName
	 * @param flowNodeStepName
	 * @param region
	 */
	public OdsServiceRouterMapDetails(String appKey, String flowNodeProcessName, String flowNodeStepName,String region) {
		super();
		this.appKey = appKey;
		this.flowNodeProcessName = flowNodeProcessName;
		this.flowNodeStepName = flowNodeStepName;
		this.region = region;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @return the requestMethod
	 */
	public String getRequestMethod() {
		return requestMethod;
	}

	/**
	 * @param requestMethod the requestMethod to set
	 */
	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}

	public String getServiceMode() {
		return serviceMode;
	}

	public void setServiceMode(String serviceMode) {
		this.serviceMode = serviceMode;
	}
}
