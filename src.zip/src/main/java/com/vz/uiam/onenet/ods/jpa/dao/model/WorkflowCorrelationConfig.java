/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The Data Model class for SERVICE_ROUTE_MAP_TABLE
 * 
 * @author Anand
 *
 */
@Entity
@Table(name = "ods_wf_correlation_config")
public class WorkflowCorrelationConfig implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "correlation_key")
	private String correlationKey;

	@Column(name = "correlation_schema")
	private String correaltionSchema;

	@Column(name = "content_schema")
	private String contentSchema;

	
	/**
	 * @return the key
	 */
	public String getCorrelationKey() {
		return correlationKey;
	}

	/**
	 * @param key the key to set
	 */
	public void setCorrelationKey(String key) {
		this.correlationKey = key;
	}

	/**
	 * @return the corealtionSchema
	 */
	public String getCorrealtionSchema() {
		return correaltionSchema;
	}

	/**
	 * @param corealtionSchema the corealtionSchema to set
	 */
	public void setCorrealtionSchema(String corealtionSchema) {
		this.correaltionSchema = corealtionSchema;
	}

	/**
	 * @return the contentSchema
	 */
	public String getContentSchema() {
		return contentSchema;
	}

	/**
	 * @param contentSchema the contentSchema to set
	 */
	public void setContentSchema(String contentSchema) {
		this.contentSchema = contentSchema;
	}

	/**
	 * @param id
	 * @param corealtionSchema
	 * @param contentSchema
	 */
	public WorkflowCorrelationConfig(String key, String corealtionSchema, String contentSchema) {
		this.correlationKey = key;
		this.correaltionSchema = corealtionSchema;
		this.contentSchema = contentSchema;
	}

	/**
	 * 
	 */
	public WorkflowCorrelationConfig() {
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
