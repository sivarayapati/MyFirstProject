/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The Data Model class for SERVICE_ROUTE_MAP_TABLE
 * 
 * @author Anand
 *
 */
@Entity
@Table(name = "ods_interface_request")
public class OdsInterfaceRequest implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "transaction_id")
	private String transactionId;
	
	@Column(name = "task_id")
	private String taskId;

	@Column(name = "corelation_payload")
	private String coreleationPayload;

	@Column(name = "manifest_payload")
	private String manifestPayload;

	@Column(name = "request")
	private String request;

	@Column(name = "request_time")
	private Timestamp requestTime;

	@Column(name = "response")
	private String response;

	@Column(name = "response_time")
	private Timestamp responseTime;

	@Column(name = "status")
	private String status;

	@Column(name = "response_config_param")
	private String responseConfigParam;

	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * @param transactionId
	 *            the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
	/**
	 * @return the taskId
	 */
	public String getTaskId() {
		return taskId;
	}

	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	/**
	 * @return the coreleationPayload
	 */
	public String getCoreleationPayload() {
		return coreleationPayload;
	}

	/**
	 * @param coreleationPayload
	 *            the coreleationPayload to set
	 */
	public void setCoreleationPayload(String coreleationPayload) {
		this.coreleationPayload = coreleationPayload;
	}

	/**
	 * @return the manifestPayload
	 */
	public String getManifestPayload() {
		return manifestPayload;
	}

	/**
	 * @param manifestPayload
	 *            the manifestPayload to set
	 */
	public void setManifestPayload(String manifestPayload) {
		this.manifestPayload = manifestPayload;
	}

	/**
	 * @return the request
	 */
	public String getRequest() {
		return request;
	}

	/**
	 * @param request
	 *            the request to set
	 */
	public void setRequest(String request) {
		this.request = request;
	}

	/**
	 * @return the requestTime
	 */
	public Timestamp getRequestTime() {
		return requestTime;
	}

	/**
	 * @param requestTime
	 *            the requestTime to set
	 */
	public void setRequestTime(Timestamp requestTime) {
		this.requestTime = requestTime;
	}

	/**
	 * @return the response
	 */
	public String getResponse() {
		return response;
	}

	/**
	 * @param response
	 *            the response to set
	 */
	public void setResponse(String response) {
		this.response = response;
	}

	/**
	 * @return the responseTime
	 */
	public Timestamp getResponseTime() {
		return responseTime;
	}

	/**
	 * @param responseTime
	 *            the responseTime to set
	 */
	public void setResponseTime(Timestamp responseTime) {
		this.responseTime = responseTime;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	public String getResponseConfigParam() {
		return responseConfigParam;
	}

	public void setResponseConfigParam(String responseConfigParam) {
		this.responseConfigParam = responseConfigParam;
	}

	
	public OdsInterfaceRequest() {
		// TODO Auto-generated constructor stub
	}

	
	/**
	 * @param transactionId
	 * @param coreleationPayload
	 * @param manifestPayload
	 * @param request
	 * @param requestTime
	 * @param response
	 * @param responseTime
	 * @param status
	 */
	public OdsInterfaceRequest(String transactionId, String coreleationPayload, String manifestPayload, String request,
			Timestamp requestTime, String response, Timestamp responseTime, String status) {
		this.transactionId = transactionId;
		this.coreleationPayload = coreleationPayload;
		this.manifestPayload = manifestPayload;
		this.request = request;
		this.requestTime = requestTime;
		this.response = response;
		this.responseTime = responseTime;
		this.status = status;
	}
	
	

	/**
	 * @param coreleationPayload
	 * @param manifestPayload
	 */
	public OdsInterfaceRequest(String coreleationPayload, String manifestPayload) {
		this.coreleationPayload = coreleationPayload;
		this.manifestPayload = manifestPayload;
	}
	
	/**
	 * @param coreleationPayload
	 * @param manifestPayload
	 */
	public OdsInterfaceRequest(String transactionId, String coreleationPayload, String manifestPayload, String responseConfigParam) {
		this.coreleationPayload = coreleationPayload;
		this.manifestPayload = manifestPayload;
		this.responseConfigParam = responseConfigParam;
		this.transactionId = transactionId;
	}

	/**
	 * @param transactionId
	 * @param coreleationPayload
	 * @param manifestPayload
	 * @param request
	 * @param requestTime
	 * @param response
	 * @param responseTime
	 * @param status
	 * @param responseConfigParam
	 */
	public OdsInterfaceRequest(String transactionId, String coreleationPayload, String manifestPayload, String request,
			Timestamp requestTime,String status, String responseConfigParam) {
		super();
		this.transactionId = transactionId;
		this.coreleationPayload = coreleationPayload;
		this.manifestPayload = manifestPayload;
		this.request = request;
		this.requestTime = requestTime;
		this.status = status;
		this.responseConfigParam = responseConfigParam;
	}
	
	/**
	 * @param transactionId
	 * @param coreleationPayload
	 * @param manifestPayload
	 * @param request
	 * @param requestTime
	 * @param response
	 * @param responseTime
	 * @param status
	 * @param responseConfigParam
	 */
	public OdsInterfaceRequest(String transactionId, String coreleationPayload, String manifestPayload, String request,
			Timestamp requestTime, String response, Timestamp responseTime, String status, String responseConfigParam) {
		super();
		this.transactionId = transactionId;
		this.coreleationPayload = coreleationPayload;
		this.manifestPayload = manifestPayload;
		this.request = request;
		this.requestTime = requestTime;
		this.response = response;
		this.responseTime = responseTime;
		this.status = status;
		this.responseConfigParam = responseConfigParam;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
