package com.vz.uiam.onenet.ods.config;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.cloud.Cloud;
import org.springframework.cloud.CloudException;
import org.springframework.cloud.CloudFactory;
import org.springframework.cloud.service.common.RedisServiceInfo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;


/**
 * @author Loganathan Murugesan
 *
 */
@Configuration
public class CacheManagerConfig extends CachingConfigurerSupport {

	private static final Logger LOGGER = Logger.getLogger(CacheManagerConfig.class);

	@Bean
	public CacheManager cacheManager() {
		CloudFactory cloudFactory = new CloudFactory();
		try {
			Cloud cloud = cloudFactory.getCloud();
			LOGGER.info("Received Cloud Connector. Connecting to Redis");
			RedisServiceInfo serviceInfo = (RedisServiceInfo) cloud.getServiceInfo("one-dispatcher-redis");
			String serviceID = serviceInfo.getId();
			RedisConnectionFactory cf = cloud.getServiceConnector(serviceID, RedisConnectionFactory.class, null);

			RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String, Object>();
			redisTemplate.setConnectionFactory(cf);
			redisTemplate.afterPropertiesSet();

			RedisCacheManager cacheManager = new RedisCacheManager(redisTemplate);
			cacheManager.setCacheNames(null);
			cacheManager.setUsePrefix(true);
			cacheManager.setTransactionAware(true);
			LOGGER.info("Created a RedisCacheManager");
			return cacheManager;
		} catch (CloudException ce) {
			LOGGER.info("Cloud Connection Exception");
			LOGGER.info(ce);
			LOGGER.info("Created a ConcurrentMapCacheManager");
			return new ConcurrentMapCacheManager();
		}
	}
}