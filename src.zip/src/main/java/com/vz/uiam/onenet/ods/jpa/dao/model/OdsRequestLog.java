package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Data Model class for ODS_REQUEST_LOG
 *
 * @author ODS
 *
 */
@Entity
@Table(name = "ods_request_log")
public class OdsRequestLog implements Serializable {
	
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ods_request_log_id")
	private Integer odsRequestLogId;

	@Column(name = "title")
	private String title;
	
	@Column(name = "title_version")
	private String titleVersion;
	
	@Column(name = "wf_task_id")
	private String wfTaskId;
	
	@Column(name = "wf_task_name")
	private String wfTaskName;
	
	@Column(name = "wf_request_payload")
	private String wfRequestPayload;
	
	@Column(name = "created_time")
	private Timestamp createdTime; 
	
	@Column(name = "expiry_time")
	private Timestamp expiryTime; 
	
	@Column(name = "wf_task_status")
	private String wfTaskStatus;
	
	@Column(name = "last_modified_time")
	private Timestamp lastModifiedTime; 
	
	@Column(name = "completion_time")
	private Timestamp completionTime; 
	
	@Column(name = "response_status")
	private String responseStatus;
	
	@Column(name = "wf_task_completion_payload")
	private String wfTaskCompletionPayload;
	
	@Column(name = "user_id")
	private String userId;

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	
	/**
	 * @param userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the odsRequestLogId
	 */
	public Integer getOdsRequestLogId() {
		return odsRequestLogId;
	}

	/**
	 * @param odsRequestLogId the odsRequestLogId to set
	 */
	public void setOdsRequestLogId(Integer odsRequestLogId) {
		this.odsRequestLogId = odsRequestLogId;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the titleVersion
	 */
	public String getTitleVersion() {
		return titleVersion;
	}

	/**
	 * @param titleVersion the titleVersion to set
	 */
	public void setTitleVersion(String titleVersion) {
		this.titleVersion = titleVersion;
	}

	/**
	 * @return the wfTaskId
	 */
	public String getWfTaskId() {
		return wfTaskId;
	}

	/**
	 * @param wfTaskId the wfTaskId to set
	 */
	public void setWfTaskId(String wfTaskId) {
		this.wfTaskId = wfTaskId;
	}

	/**
	 * @return the wfTaskName
	 */
	public String getWfTaskName() {
		return wfTaskName;
	}

	/**
	 * @param wfTaskName the wfTaskName to set
	 */
	public void setWfTaskName(String wfTaskName) {
		this.wfTaskName = wfTaskName;
	}

	/**
	 * @return the wfRequestPayload
	 */
	public String getWfRequestPayload() {
		return wfRequestPayload;
	}

	/**
	 * @param wfRequestPayload the wfRequestPayload to set
	 */
	public void setWfRequestPayload(String wfRequestPayload) {
		this.wfRequestPayload = wfRequestPayload;
	}

	/**
	 * @return the wfTaskStatus
	 */
	public String getWfTaskStatus() {
		return wfTaskStatus;
	}

	/**
	 * @param wfTaskStatus the wfTaskStatus to set
	 */
	public void setWfTaskStatus(String wfTaskStatus) {
		this.wfTaskStatus = wfTaskStatus;
	}

	/**
	 * @return the responseStatus
	 */
	public String getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus the responseStatus to set
	 */
	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	/**
	 * @return the wfTaskCompletionPayload
	 */
	public String getWfTaskCompletionPayload() {
		return wfTaskCompletionPayload;
	}

	/**
	 * @param wfTaskCompletionPayload the wfTaskCompletionPayload to set
	 */
	public void setWfTaskCompletionPayload(String wfTaskCompletionPayload) {
		this.wfTaskCompletionPayload = wfTaskCompletionPayload;
	}

	/**
	 * @return the createdTime
	 */
	public Timestamp getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime the createdTime to set
	 */
	public void setCreatedTime(Timestamp createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return the expiryTime
	 */
	public Timestamp getExpiryTime() {
		return expiryTime;
	}

	/**
	 * @param expiryTime the expiryTime to set
	 */
	public void setExpiryTime(Timestamp expiryTime) {
		this.expiryTime = expiryTime;
	}

	/**
	 * @return the lastModifiedTime
	 */
	public Timestamp getLastModifiedTime() {
		return lastModifiedTime;
	}

	/**
	 * @param lastModifiedTime the lastModifiedTime to set
	 */
	public void setLastModifiedTime(Timestamp lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

	/**
	 * @return the completionTime
	 */
	public Timestamp getCompletionTime() {
		return completionTime;
	}

	/**
	 * @param completionTime the completionTime to set
	 */
	public void setCompletionTime(Timestamp completionTime) {
		this.completionTime = completionTime;
	}

}
