/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The Data Model class for SERVICE_ROUTE_MAP_TABLE
 * 
 * @author Anand
 *
 */
@Entity
@Table(name = "ods_mandatory_attrs")
public class OdsMandatoryAttributes implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "validation_Id")
	private Integer validationId;

	@Column(name = "attr_key")
	private String attrKey;

	@Column(name = "json_path")
	private String jsonPath;


	/**
	 * @return the validationId
	 */
	public Integer getValidationId() {
		return validationId;
	}

	/**
	 * @param validationId the validationId to set
	 */
	public void setValidationId(Integer validationId) {
		this.validationId = validationId;
	}

	/**
	 * @return the key
	 */
	public String getAttrKey() {
		return attrKey;
	}

	/**
	 * @param attrKey the key to set
	 */
	public void setAttrKey(String attrKey) {
		this.attrKey = attrKey;
	}

	/**
	 * @return the jsonPath
	 */
	public String getJsonPath() {
		return jsonPath;
	}

	/**
	 * @param jsonPath the jsonPath to set
	 */
	public void setJsonPath(String jsonPath) {
		this.jsonPath = jsonPath;
	}

	/**
	 * @param validationId
	 * @param key
	 * @param jsonPath
	 */
	public OdsMandatoryAttributes(Integer validationId, String key, String jsonPath) {
		this.validationId = validationId;
		this.attrKey = key;
		this.jsonPath = jsonPath;
	}

	public OdsMandatoryAttributes(String attrKey) {
		super();
		this.attrKey = attrKey;
	}

	public OdsMandatoryAttributes() {
		
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
