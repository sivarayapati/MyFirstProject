package com.vz.uiam.onenet.ods.jpa.dao.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;


@Transactional
@Repository
public interface OdsRequestLogRepository extends JpaRepository<OdsRequestLog, Integer>{

	public OdsRequestLog findByWfTaskId(String wfTaskId);
	
	public OdsRequestLog findByTitleAndTitleVersionAndWfTaskName(String title, String titleVersion, String wfTaskName);
	
	public List<OdsRequestLog> findByWfTaskStatusAndResponseStatusAndExpiryTimeBefore(String wfTaskStatus, String responseStatus, Timestamp expiryTime);
	
	public List<OdsRequestLog> findByTitleAndTitleVersion(String title, String titleVersion);
	
	public List<OdsRequestLog> findByWfTaskStatusAndResponseStatus(String wfTaskStatus, String responseStatus);
	
	public OdsRequestLog findByWfTaskIdAndResponseStatus(String wfTaskId, String responseStatus);
}
