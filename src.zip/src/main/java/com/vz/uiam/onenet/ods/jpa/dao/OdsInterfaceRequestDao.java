package com.vz.uiam.onenet.ods.jpa.dao;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;

public class OdsInterfaceRequestDao {

	@Autowired
	OdsInterfaceRequestRepository odsInterfaceRequestRepository;
	
	@Transactional
	public OdsInterfaceRequest getInterfaceRequest(String transactionId, String status) {
	return odsInterfaceRequestRepository.findByTransactionIdAndStatus(transactionId, status);
	}

}
