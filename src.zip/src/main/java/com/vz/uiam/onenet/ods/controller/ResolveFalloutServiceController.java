/**
 * 
 */
package com.vz.uiam.onenet.ods.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveFalloutServiceResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveHandleFalloutRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveWorkflowFalloutRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.service.ResolveFalloutService;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author Kiran
 *
 */
@RestController
@RequestMapping("/oneDispatcher/fallout")
public class ResolveFalloutServiceController {

	private static final Logger LOGGER = Logger.getLogger(ResolveFalloutServiceController.class);

	@Autowired
	ResolveFalloutService resolveFalloutService;
	
	@Autowired
	ServiceUtils serviceUtils;
	
	
	/**
	 * @return boolean
	 * @throws ApplicationException
	 */
	@RequestMapping(value = "/resolveHandleFallout", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Service fallout handle", notes = "Service fallout handle", response = ResolveFalloutServiceResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Service fallout handle", response = ResolveFalloutServiceResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Fallout Service is unavaialble") })
	public ResponseEntity<ResolveFalloutServiceResponse> handleFallout(@RequestBody ResolveHandleFalloutRequest request)
			throws ApplicationException {
		LOGGER.info("Entering resolveHandleFallout");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		
		ResolveFalloutServiceResponse response = null;
		try {
			response = resolveFalloutService.handleFallout(request);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
			
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
			
		}
		
		if (response == null)
			response = new ResolveFalloutServiceResponse();
		
		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
				
		LOGGER.info("Exiting resolveHandleFallout");
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
	
	/**
	 * @param request
	 * @return ResponseEntity<ResolveResolveFalloutServiceResponse>
	 * @throws ApplicationException
	 */
	@RequestMapping(value = "/resolveCreateFallout", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create Service Fallout", notes = "Create Service Fallout", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Create Service Fallout", response = String.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Create Fallout is unavaialble") })
	public ResponseEntity<ResponseStatus> createFallout(@RequestBody ResolveWorkflowFalloutRequest request)
			throws ApplicationException {
		LOGGER.info(">>resolveCreateFallout()");
		LOGGER.info("Request payload is ::::::::::::::" + request.toString());
		
		Boolean returnStatus = true;
		ResponseStatus response = new ResponseStatus();
		try {
			resolveFalloutService.createFallout(request);
			ResponseStatus respSts = new ResponseStatus();
			respSts.setCode(StatusCode.SUCCESS.getCode());
			respSts.setDescription("Successfully Inserted the WfParam");
			
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			returnStatus = false;
			response.setCode(StatusCode.ERROR_WHILE_CREATE_FALLOUT.getCode());
			response.setDescription(StatusCode.ERROR_WHILE_CREATE_FALLOUT.getDesc());
			LOGGER.error(StatusCode.ERROR_WHILE_CREATE_FALLOUT.getDesc() + e);
		}
		response.setSuccess(returnStatus);
		if (returnStatus) {
			
			return ResponseEntity.ok(response);
			
		} else {
			LOGGER.info("<<addWfParam()");
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(response);
		}
		
	}
}
