package com.vz.uiam.onenet.ods.constants;

public enum OdsParamConfigType {

	ODS("Param internal to One Dispatcher Service param key"),
	ODS_PARAM("Param internal to One Dispatcher Service"),
	WORKFLOW_CORRELATION_PARAM("Workflow correlation Params"),
	APPLICATION_PARAM("Param to handle hard coded values in Request schema"),
	RESPONSE_STATUS_PARAM("Param to get the status code and its SUCCESS Value"),
	RESPONSE_PARAM("Param to parse response param and update the manifest payload"),
	NOTES_PARAM("Param to update request and response in notes service"),
	WORKFLOW_PARAM("Param related to workflow"), 
	DATA_SERVICE_REQUEST("Custom Data Service instead of Manifest document");
	
    private final String desc;

    private OdsParamConfigType(String desc) {
    	this.desc = desc;
    }

    /**
     * Return the message of this type.
     */
    public String getDesc() {
    	return this.desc;
    }
}
