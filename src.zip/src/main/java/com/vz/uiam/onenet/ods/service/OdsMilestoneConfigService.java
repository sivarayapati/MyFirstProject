package com.vz.uiam.onenet.ods.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsMilestoneConfigRepository;

/**
 * @author Ashish Goyal
 *
 */
@Service
@Transactional(rollbackOn = { ApplicationException.class, Exception.class, RuntimeException.class })
public class OdsMilestoneConfigService {

	private static final Logger LOGGER = Logger.getLogger(OdsMilestoneConfigService.class);
	
	@Autowired
	OdsMilestoneConfigRepository odsMilestoneConfigRepo;
	
	/**
	 * API to delete the OdsMilestoneConfig records
	 * 
	 * @param odsMilestoneConfigList
	 * @throws ApplicationException
	 */
	public void deleteOdsMilestoneConfigRecord(List<OdsMilestoneConfig> odsMilestoneConfigList) throws ApplicationException {
		LOGGER.info("Entering deleteOdsMilestoneConfigRecord");

		try {
			for (OdsMilestoneConfig odsMilestoneConfig : odsMilestoneConfigList) {
				if (odsMilestoneConfig.getOdsMilestoneConfigId() != null) {
					odsMilestoneConfigRepo.delete(odsMilestoneConfig.getOdsMilestoneConfigId());
				} else if (!StringUtils.isEmpty(odsMilestoneConfig.getFlowNodeProcessName())
						&& !StringUtils.isEmpty(odsMilestoneConfig.getFlowNodeStepName())) {

					OdsMilestoneConfig existingOdsMilestoneConfig = odsMilestoneConfigRepo.findByFlowNodeStepNameAndFlowNodeProcessNameAndMilestoneName(odsMilestoneConfig.getFlowNodeStepName(),
									                                odsMilestoneConfig.getFlowNodeProcessName(),odsMilestoneConfig.getMilestoneName());
					if (existingOdsMilestoneConfig != null)
						odsMilestoneConfigRepo.delete(existingOdsMilestoneConfig);

				} else {
					throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
							"Provide either [id] or [flowNodeProcessName and flowNodeStepName]");
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error while deleting OdsMilestoneConfig records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), e.getMessage());
		}

		LOGGER.info("Exiting deleteOdsMilestoneConfigRecord");
	}
	
	/**
	 * @param inputOdsMilestoneConfig
	 * @return OdsMilestoneConfig
	 * @throws ApplicationException
	 */
	public OdsMilestoneConfig createOrUpdateMilestoneConfig(OdsMilestoneConfig inputOdsMilestoneConfig) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateMilestoneConfig");
		
		OdsMilestoneConfig existingOdsMilestoneConfig = null;
		
		if (inputOdsMilestoneConfig.getOdsMilestoneConfigId() != null) {
			existingOdsMilestoneConfig = odsMilestoneConfigRepo.findOne(inputOdsMilestoneConfig.getOdsMilestoneConfigId());
			
			if (existingOdsMilestoneConfig == null)
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "OdsMilestoneConfig record not found for ID - " + inputOdsMilestoneConfig.getOdsMilestoneConfigId());
		} else if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getFlowNodeProcessName())
				&& !StringUtils.isEmpty(inputOdsMilestoneConfig.getFlowNodeStepName())) {
			existingOdsMilestoneConfig = odsMilestoneConfigRepo.findByFlowNodeStepNameAndFlowNodeProcessNameAndMilestoneName(inputOdsMilestoneConfig.getFlowNodeStepName(),
							             inputOdsMilestoneConfig.getFlowNodeProcessName(),inputOdsMilestoneConfig.getMilestoneName());
		}
		
		if (existingOdsMilestoneConfig == null) {
			doMilestoneConfigValidation(inputOdsMilestoneConfig);
		}
		
		OdsMilestoneConfig newOdsMilestoneConfig = getUpdatedOdsMilestoneConfigRecord(inputOdsMilestoneConfig, existingOdsMilestoneConfig);
		newOdsMilestoneConfig = odsMilestoneConfigRepo.save(newOdsMilestoneConfig);
		
		LOGGER.info("Exiting createOrUpdateMilestoneConfig");
		return newOdsMilestoneConfig;
	}
	
	
	/**
	 * API to retrieve OdsMilestoneConfig records
	 * 
	 * @param odsMilestoneConfig
	 * @return
	 * @throws ApplicationException
	 */
	public List<OdsMilestoneConfig> getMilestoneConfig(OdsMilestoneConfig odsMilestoneConfig) throws ApplicationException {
		LOGGER.info("Entering getMilestoneConfig");
		
		if (StringUtils.isEmpty(odsMilestoneConfig.getFlowNodeProcessName()) || StringUtils.isEmpty(odsMilestoneConfig.getFlowNodeStepName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Please provide  flowNodeProcessName and flowNodeStepName");
		
		List<OdsMilestoneConfig> odsMilestoneConfigRspList = null;
		try {
			odsMilestoneConfigRspList = odsMilestoneConfigRepo
					.findByFlowNodeProcessNameAndFlowNodeStepName(odsMilestoneConfig.getFlowNodeProcessName(),
							odsMilestoneConfig.getFlowNodeStepName());
		} catch (Exception e) {
			LOGGER.error("Error while getting OdsMilestoneConfig records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while getting OdsMilestoneConfig records. " + e.getMessage());
		}
		
		LOGGER.info("Exiting getMilestoneConfig");
		return odsMilestoneConfigRspList;
	}
	
	/**
	 * API to validate input OdsMilestoneConfig
	 * 
	 * @param odsMilestoneConfig
	 * @throws ApplicationException
	 */
	public void doMilestoneConfigValidation(OdsMilestoneConfig inputOdsMilestoneConfig) throws ApplicationException {
		LOGGER.info("Entering doMilestoneConfigValidation");
		
		if (StringUtils.isEmpty(inputOdsMilestoneConfig.getFlowNodeProcessName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "flowNodeProcessName is null or empty");
		if (StringUtils.isEmpty(inputOdsMilestoneConfig.getFlowNodeStepName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "flowNodeStepName is null or empty");
		if (StringUtils.isEmpty(inputOdsMilestoneConfig.getMilestoneName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Milestone Name is null or empty");
		if (StringUtils.isEmpty(inputOdsMilestoneConfig.getDestinationAppName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Destination App Name of Milestone is null or empty");
		if (StringUtils.isEmpty(inputOdsMilestoneConfig.getTargetEndpointUrl()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Milestone targetEndpointUrl is null or empty");
		if (StringUtils.isEmpty(inputOdsMilestoneConfig.getRequestSchema()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Milestone requestSchema is null or empty");
		if (StringUtils.isEmpty(inputOdsMilestoneConfig.getRequestDocumentName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Milestone requestDocumentName is null or empty");
		if (StringUtils.isEmpty(inputOdsMilestoneConfig.getTransformationType()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Milestone transformationType is null or empty");
		if (StringUtils.isEmpty(inputOdsMilestoneConfig.getRouteProtocol()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Milestone routeProtocol is null or empty");
		
		String sendMilestone = inputOdsMilestoneConfig.getSendMilestone();
		if (StringUtils.isNotEmpty(sendMilestone) && !"YES".equalsIgnoreCase(sendMilestone) && !"NO".equalsIgnoreCase(sendMilestone)) {
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "Milestone - sendMilestone value should be either [YES or NO]");
		} else if (StringUtils.isEmpty(sendMilestone))
			inputOdsMilestoneConfig.setSendMilestone("NO");
		
		String sendFalloutNotification = inputOdsMilestoneConfig.getSendFalloutNotification();
		if (StringUtils.isNotEmpty(sendFalloutNotification) && !"YES".equalsIgnoreCase(sendFalloutNotification) && !"NO".equalsIgnoreCase(sendFalloutNotification)) {
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "Milestone - sendFalloutNotification value should be either [YES or NO]");
		} else if (StringUtils.isEmpty(sendFalloutNotification))
			inputOdsMilestoneConfig.setSendFalloutNotification("NO");
		
		LOGGER.info("Exiting doMilestoneConfigValidation");
	}
	
	/**
	 * API to update the input OdsMilestoneConfig record with the exiting one 
	 * 
	 * @param inputOdsMilestoneConfig
	 * @param existingOdsMilestoneConfig
	 * @return
	 */
	public OdsMilestoneConfig getUpdatedOdsMilestoneConfigRecord(OdsMilestoneConfig inputOdsMilestoneConfig,
																			OdsMilestoneConfig existingOdsMilestoneConfig) {
		LOGGER.info("Entering getUpdatedOdsMilestoneConfigRecord");
		
		if (existingOdsMilestoneConfig == null)
			return inputOdsMilestoneConfig;
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getFlowNodeProcessName()))
			existingOdsMilestoneConfig.setFlowNodeProcessName(inputOdsMilestoneConfig.getFlowNodeProcessName());
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getFlowNodeStepName()))
			existingOdsMilestoneConfig.setFlowNodeStepName(inputOdsMilestoneConfig.getFlowNodeStepName());
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getMilestoneName()))
			existingOdsMilestoneConfig.setMilestoneName(inputOdsMilestoneConfig.getMilestoneName());
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getDestinationAppName()))
			existingOdsMilestoneConfig.setDestinationAppName(inputOdsMilestoneConfig.getDestinationAppName());
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getTargetEndpointUrl()))
			existingOdsMilestoneConfig.setTargetEndpointUrl(inputOdsMilestoneConfig.getTargetEndpointUrl());
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getUserName()))
			existingOdsMilestoneConfig.setUserName(inputOdsMilestoneConfig.getUserName());
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getPassword()))
			existingOdsMilestoneConfig.setPassword(inputOdsMilestoneConfig.getPassword());
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getRequestSchema()))
			existingOdsMilestoneConfig.setRequestSchema(inputOdsMilestoneConfig.getRequestSchema());
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getRequestDocumentName()))
			existingOdsMilestoneConfig.setRequestDocumentName(inputOdsMilestoneConfig.getRequestDocumentName());
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getTransformationType()))
			existingOdsMilestoneConfig.setTransformationType(inputOdsMilestoneConfig.getTransformationType());
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getRouteProtocol()))
			existingOdsMilestoneConfig.setRouteProtocol(inputOdsMilestoneConfig.getRouteProtocol());
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getSendMilestone()))
			existingOdsMilestoneConfig.setSendMilestone(inputOdsMilestoneConfig.getSendMilestone().toUpperCase());
		else
			existingOdsMilestoneConfig.setSendMilestone("NO");
		
		if (!StringUtils.isEmpty(inputOdsMilestoneConfig.getSendFalloutNotification()))
			existingOdsMilestoneConfig.setSendFalloutNotification(inputOdsMilestoneConfig.getSendFalloutNotification().toUpperCase());
		else
			existingOdsMilestoneConfig.setSendFalloutNotification("NO");
		
		LOGGER.info("Exiting getUpdatedOdsMilestoneConfigRecord");
		return existingOdsMilestoneConfig;
	}
	
	
}