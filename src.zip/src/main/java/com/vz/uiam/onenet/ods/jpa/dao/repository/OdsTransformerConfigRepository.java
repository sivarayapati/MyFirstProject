package com.vz.uiam.onenet.ods.jpa.dao.repository;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsTransformerConfig;



/**
 * @author Anand
 *
 */
@Transactional
@Repository
public interface OdsTransformerConfigRepository extends JpaRepository<OdsTransformerConfig, Integer> {

	@Cacheable(value="odsTransformerConfig", key="#p0", unless="#result == null", condition="#p0!=null")
	OdsTransformerConfig findByTransformerKey(String transformerKey);
	
	@CacheEvict(value="odsTransformerConfig", key="#p0.transformerKey", condition="#p0.transformerKey!=null")
	public OdsTransformerConfig save(OdsTransformerConfig odsTransformerConfig);
	
}