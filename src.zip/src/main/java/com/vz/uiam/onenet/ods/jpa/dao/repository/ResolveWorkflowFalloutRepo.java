/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.ResolveWorkflowFallout;

/**
 * @author Kiran
 *
 */
@Transactional
@Repository
public interface ResolveWorkflowFalloutRepo extends CrudRepository<ResolveWorkflowFallout, Integer> {
	static final long serialVersionUID = 1L;

	/**
	 * @param status
	 * @param errorCode
	 * @return WorkflowFallout
	 */
	public ResolveWorkflowFallout getByStatusOrWorkFlowFalloutErrorCode(String status, String errorCode);

	/**
	 * @param caseId
	 * @param WorkFlowStepName
	 * @param FlowFalloutErrorCode
	 * @param status
	 * @param WorkFlowProcessName
	 * @return WorkflowFallout
	 */
	public ResolveWorkflowFallout getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatusAndWorkFlowProcessName(
			String caseId, String WorkFlowStepName, String FlowFalloutErrorCode,String status,String WorkFlowProcessName);
	
	/**
	 * @param caseId
	 * @param WorkFlowStepName
	 * @param status
	 * @param WorkFlowProcessName
	 * @return WorkflowFallout
	 */
	public ResolveWorkflowFallout getByCaseIdAndWorkFlowStepNameAndStatusAndWorkFlowProcessName(
			String caseId, String WorkFlowStepName, String status,String WorkFlowProcessName);

	/**
	 * @param caseId
	 * @param workFlowStepName
	 * @param workFlowFalloutErrorCode
	 * @return WorkflowFallout
	 */ 
	public ResolveWorkflowFallout getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCode(String caseId,
			String workFlowStepName, String workFlowFalloutErrorCode);
	
	/**
	 * @param caseId
	 * @param workFlowStepName
	 * @return WorkflowFallout
	 */ 
	public ResolveWorkflowFallout getByCaseIdAndWorkFlowStepName(String caseId,
			String workFlowStepName); 
}