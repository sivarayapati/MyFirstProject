/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.repository;

import java.util.List;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;

/**
 * @author Anand
 *
 */
@Transactional
@Repository
public interface OdsMandatoryAttrsRepository extends JpaRepository<OdsMandatoryAttributes, Integer> {	
	
	public OdsMandatoryAttributes findByValidationId(Integer validationId);
	
	@Cacheable(value="odsMandatoryAttrs", key="#p0", unless="#result == null", condition="#p0!=null")
	public List<OdsMandatoryAttributes> findByAttrKey(String attrKey);
	
	@Cacheable(value="odsMandatoryAttrs", key="#p0.concat('|').concat(#p1)", unless="#result == null", condition="#p0!=null && #p1!=null")
	public OdsMandatoryAttributes findByAttrKeyAndJsonPath(String attrKey, String jsonPath);	
	
	@Caching(evict = {
			@CacheEvict(value = "odsMandatoryAttrs", key="#p0.attrKey", condition="#p0.attrKey!=null"),
			  @CacheEvict(value = "odsMandatoryAttrs", key="#p0.attrKey.concat('|').concat(#p0.jsonPath)", condition="#p0.attrKey!=null && #p0.jsonPath!=null")			  
			})
	public OdsMandatoryAttributes save(OdsMandatoryAttributes odsMandatoryAttributes);
	
	@Caching(evict = {
			@CacheEvict(value = "odsMandatoryAttrs", key="#p0.attrKey", condition="#p0.attrKey!=null"),
			  @CacheEvict(value = "odsMandatoryAttrs", key="#p0.attrKey.concat('|').concat(#p0.jsonPath)", condition="#p0.attrKey!=null && #p0.jsonPath!=null")			  
			})
	public void delete(OdsMandatoryAttributes odsMandatoryAttributes);
	
}