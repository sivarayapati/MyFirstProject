package com.vz.uiam.onenet.ods.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsParamConfigResponse;
import com.vz.uiam.onenet.ods.service.OdsParamConfigService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


/**
 * @author Ashish Goyal
 *
 */
@RestController
@RequestMapping("/oneDispatcher/odsParamConfig")
public class ODSParamConfigController {

	private static final Logger LOGGER = Logger.getLogger(ODSParamConfigController.class);
	
	@Autowired
	OdsParamConfigService odsParamConfigService;
	
	
	@RequestMapping(value = "/createOrUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create or Update a record in OdsParamConfig", notes = "Create or Update a record in OdsParamConfig", response = OdsParamConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Created or Updated OdsParamConfig record", response = OdsParamConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "createOrUpdate OdsParamConfig Service is unavaialble") })
	public ResponseEntity<OdsParamConfigResponse> createOrUpdateOdsParamConfig(@RequestBody OdsParamConfig request)
														throws ApplicationException {
		
		LOGGER.info("Entering createOrUpdateOdsParamConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsParamConfigResponse response = new OdsParamConfigResponse();
		
		try {
			OdsParamConfig odsParamConfigResp =  odsParamConfigService.createOrUpdateOdsParamConfig(request);
			
			if(null == odsParamConfigResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsParamConfig(odsParamConfigResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting createOrUpdateOdsParamConfig");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/get", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get OdsParamConfig Details", notes = "Get OdsParamConfig Details", response = OdsParamConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved OdsParamConfig record", response = OdsParamConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "get OdsParamConfig Service is unavaialble") })
	public ResponseEntity<OdsParamConfigResponse> getOdsParamConfig(@RequestBody OdsParamConfig request)
														throws ApplicationException {
		
		LOGGER.info("Entering getOdsParamConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsParamConfigResponse response = new OdsParamConfigResponse();
		
		try {
			List<OdsParamConfig> odsParamConfigResp =  odsParamConfigService.getOdsParamConfigRecords(request);
			
			if(null == odsParamConfigResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsParamConfigList(odsParamConfigResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting getOdsParamConfig");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Delete OdsParamConfig Details", notes = "Delete OdsParamConfig Details", response = OdsParamConfigResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Delete OdsParamConfig record", response = OdsParamConfigResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Delete OdsParamConfig Service is unavaialble") })
	public ResponseEntity<OdsParamConfigResponse> deleteOdsParamConfig(@RequestBody List<OdsParamConfig> request)
														throws ApplicationException {
		
		LOGGER.info("Entering deleteOdsParamConfig");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsParamConfigResponse response = new OdsParamConfigResponse();
		
		try {
			odsParamConfigService.deleteOdsParamConfigRecord(request);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting deleteOdsParamConfig");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
}
