package com.vz.uiam.onenet.ods.jpa.dto.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class ODSKeyDetails {

	private String appKey;
	private String flowNodeProcessName;
	private String flowNodeStepName;
	private String configurationType;
	private String level;
	private String region;
	
	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getAppKey() {
		return appKey;
	}
	
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	
	public String getFlowNodeProcessName() {
		return flowNodeProcessName;
	}
	
	public void setFlowNodeProcessName(String flowNodeProcessName) {
		this.flowNodeProcessName = flowNodeProcessName;
	}
	
	public String getFlowNodeStepName() {
		return flowNodeStepName;
	}
	
	public void setFlowNodeStepName(String flowNodeStepName) {
		this.flowNodeStepName = flowNodeStepName;
	}
	
	public String getConfigurationType() {
		return configurationType;
	}
	
	public void setConfigurationType(String configurationType) {
		this.configurationType = configurationType;
	}
	
	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
