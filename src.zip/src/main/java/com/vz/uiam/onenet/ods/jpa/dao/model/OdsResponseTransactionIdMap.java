/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author Anand Badiger
 *
 */
@Entity
@Table(name = "ods_response_transaction_id_map")
public class OdsResponseTransactionIdMap implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "root_tag_name")
	private String rootTagName;
	
	@Column(name = "transaction_id_key")
	private String transactionIdKey;
	
	/**
	 * @return the rootTagName
	 */
	public String getRootTagName() {
		return rootTagName;
	}

	/**
	 * @param rootTagName the rootTagName to set
	 */
	public void setRootTagName(String rootTagName) {
		this.rootTagName = rootTagName;
	}

	/**
	 * @return the transactionIdKey
	 */
	public String getTransactionIdKey() {
		return transactionIdKey;
	}

	/**
	 * @param transactionIdKey the transactionIdKey to set
	 */
	public void setTransactionIdKey(String transactionIdKey) {
		this.transactionIdKey = transactionIdKey;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	public OdsResponseTransactionIdMap() {
		super();
		
	}
	
	public OdsResponseTransactionIdMap(String rootTagName) {
		super();
		this.rootTagName = rootTagName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}	
	
	
}
