package com.vz.uiam.onenet.ods.jpa.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;



/**
 * @author Anand
 *
 */
@Transactional
@Repository
public interface OdsInterfaceRequestRepository extends JpaRepository<OdsInterfaceRequest, Integer> {

	public OdsInterfaceRequest findByTransactionIdAndStatus(String transactionId, String status);
	
	public List<OdsInterfaceRequest> findByTaskIdAndStatus(String taskId, String status);
}