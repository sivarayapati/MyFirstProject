/**
 * 
 */
package com.vz.uiam.onenet.ods.service;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsMandatoryAttrsRepository;


/**
 * @author Anand
 *
 */
@Service
@Transactional(rollbackOn = { ApplicationException.class, Exception.class, RuntimeException.class })
public class OdsMandatoryAttrsService {

	private static final Logger LOGGER = Logger.getLogger(OdsMandatoryAttrsService.class);
	
	@Autowired
	OdsMandatoryAttrsRepository mandatoryAttrsRepo;
	
	
	/**
	 * API to create or Update a record in OdsMandatoryAttributes table
	 * 
	 * @param inputOdsMandatoryAttrs
	 * @return
	 * @throws ApplicationException
	 */
	public OdsMandatoryAttributes createOrUpdateOdsMandatoryAttrs(OdsMandatoryAttributes inputOdsMandatoryAttrs) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateOdsMandatoryAttrs");
		
		OdsMandatoryAttributes existingOdsMandatoryAttrs = null;
		
		if (inputOdsMandatoryAttrs.getValidationId() != null) {
			existingOdsMandatoryAttrs = mandatoryAttrsRepo.findOne(inputOdsMandatoryAttrs.getValidationId());
			
			if (existingOdsMandatoryAttrs == null)
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "OdsMandatoryAttributes record not found for ID - " + inputOdsMandatoryAttrs.getValidationId());
		}
		
		if (existingOdsMandatoryAttrs == null) {
			existingOdsMandatoryAttrs = mandatoryAttrsRepo.findByAttrKeyAndJsonPath(inputOdsMandatoryAttrs.getAttrKey(), inputOdsMandatoryAttrs.getJsonPath());
			if (existingOdsMandatoryAttrs != null)
				throw new ApplicationException(StatusCode.DATA_HANDLING_ERROR.getCode(), "OdsMandatoryAttributes record already exists for the input data. " + existingOdsMandatoryAttrs);
			 else {
					doOdsMandatoryAttrsValidation(inputOdsMandatoryAttrs);
				}
		} else {
			doOdsMandatoryAttrsValidation(inputOdsMandatoryAttrs);
		}
		
		OdsMandatoryAttributes newOdsMandatoryAttrs = mandatoryAttrsRepo.save(
															getUpdatedOdsMandatoryAttrsRecord(inputOdsMandatoryAttrs, existingOdsMandatoryAttrs));
		
		LOGGER.info("Exiting createOrUpdateOdsMandatoryAttrs");
		return newOdsMandatoryAttrs;
	}
	
	
	/**
	 * @param appKey
	 * @return List<OdsMandatoryAttributes>
	 */
	public List<OdsMandatoryAttributes> getMandatoryAttributeList(String attrKey) throws ApplicationException {
		LOGGER.debug(">>getMandatoryAttributeList");
		return mandatoryAttrsRepo.findByAttrKey(attrKey);
	}

	
	/**
	 * API to delete the OdsMandatoryAttributes records
	 * 
	 * @param odsMandatoryAttrsList
	 * @throws ApplicationException
	 */
	public void deleteOdsMandatoryAttrsRecord(List<OdsMandatoryAttributes> odsMandatoryAttrsList) throws ApplicationException {
		LOGGER.info("Entering deleteOdsMandatoryAttrsRecord");
		
		try {
			for (OdsMandatoryAttributes odsMandatoryAttrs : odsMandatoryAttrsList) {
				if (odsMandatoryAttrs.getValidationId() != null) {
					OdsMandatoryAttributes odsMandatoryAttr = mandatoryAttrsRepo.findByValidationId(odsMandatoryAttrs.getValidationId());
					mandatoryAttrsRepo.delete(odsMandatoryAttr);
				} else if (!StringUtils.isEmpty(odsMandatoryAttrs.getAttrKey()) &&
								!StringUtils.isEmpty(odsMandatoryAttrs.getJsonPath())) {
					
					OdsMandatoryAttributes existingOdsMandatoryAttrs = mandatoryAttrsRepo.findByAttrKeyAndJsonPath(
																odsMandatoryAttrs.getAttrKey(), odsMandatoryAttrs.getJsonPath());
					
					if (existingOdsMandatoryAttrs != null)
						mandatoryAttrsRepo.delete(existingOdsMandatoryAttrs);
					else
						throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Record not found for the given input."
								+ " attrKey[" + odsMandatoryAttrs.getAttrKey() + "] and jsonPath[" + odsMandatoryAttrs.getJsonPath() + "]");
				} else if (!StringUtils.isEmpty(odsMandatoryAttrs.getAttrKey())) {
					
					List<OdsMandatoryAttributes> existingOdsMandatoryAttrs = mandatoryAttrsRepo.findByAttrKey(odsMandatoryAttrs.getAttrKey());
			
					if (!CollectionUtils.isEmpty(existingOdsMandatoryAttrs)) {
						mandatoryAttrsRepo.delete(existingOdsMandatoryAttrs);
					} else
						throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Record not found for the given input."
								+ " attrKey[" + odsMandatoryAttrs.getAttrKey() + "]");
				} else {
					throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Provide either [validationId] or [attrKey] or [attrKey and jsonPath]");
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error while deleting OdsMandatoryAttributes records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while deleting OdsMandatoryAttributes records. " + e.getMessage());
		}
		
		LOGGER.info("Exiting deleteOdsMandatoryAttrsRecord");
	}
	
	
	/**
	 * API to update the input OdsMandatoryAttributes record with the exiting one 
	 * 
	 * @param inputOdsMandatoryAttrs
	 * @param existingOdsMandatoryAttrs
	 * @return
	 * @throws ApplicationException 
	 */
	public OdsMandatoryAttributes getUpdatedOdsMandatoryAttrsRecord(OdsMandatoryAttributes inputOdsMandatoryAttrs,
												OdsMandatoryAttributes existingOdsMandatoryAttrs) throws ApplicationException {
		LOGGER.info("Entering getUpdatedOdsMandatoryAttrsRecord");
		
		if (existingOdsMandatoryAttrs == null)
			return inputOdsMandatoryAttrs;
		
		if (!StringUtils.isEmpty(inputOdsMandatoryAttrs.getAttrKey()))
			existingOdsMandatoryAttrs.setAttrKey(inputOdsMandatoryAttrs.getAttrKey());
		
		if (!StringUtils.isEmpty(inputOdsMandatoryAttrs.getJsonPath()))
			existingOdsMandatoryAttrs.setJsonPath(inputOdsMandatoryAttrs.getJsonPath());
		
		LOGGER.info("Exiting getUpdatedOdsMandatoryAttrsRecord");
		return existingOdsMandatoryAttrs;
	}
	
	
	/**
	 * API to do validation on input OdsMandatoryAttributes record
	 * 
	 * @param odsMandatoryAttrs
	 * @throws ApplicationException
	 */
	public void doOdsMandatoryAttrsValidation(OdsMandatoryAttributes odsMandatoryAttrs) throws ApplicationException {
		LOGGER.info("Entering doOdsMandatoryAttrsValidation");
		
		if (StringUtils.isEmpty(odsMandatoryAttrs.getAttrKey()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "attrKey is null or empty");
		if (StringUtils.isEmpty(odsMandatoryAttrs.getJsonPath()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "jsonPath is null or empty");
		
		LOGGER.info("Exiting doOdsMandatoryAttrsValidation");
	}
	
	/**
	 * Method to validate if manifest attributes are configured in the ODS Mandatory Attributes table 
	 * given appKey in the DB/Cache.
	 * 
	 * @param String appKey
	 * @throws ODSRequestValidationException
	 * @throws ApplicationException 
	 */
	public void validateManifestAttributes(String appKey) throws ApplicationException {
		List<OdsMandatoryAttributes> mandatoryAttrbsList = getMandatoryAttributeList(appKey);
		if (CollectionUtils.isEmpty(mandatoryAttrbsList)) {
			LOGGER.error(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
			throw new ApplicationException(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getCode(),
					StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
		}
	}
	
}
