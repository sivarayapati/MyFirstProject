package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class OdsWorkflowParamsId implements Serializable {
	
	private static final long serialVersionUID = -4969365599169978923L;

	@Column(name = "root_case_id")
	private Integer rootCaseId;

	@Column(name = "wf_param_name")
	private String wfParamName;
	
	
	public OdsWorkflowParamsId(int rootCaseId, String paramName) {
		this.rootCaseId = rootCaseId;
		this.wfParamName = paramName;
	}

	/**
	 * @return rootCaseId
	 */
	public Integer getRootCaseId() {
		return rootCaseId;
	}

	/**
	 * @param rootCaseId
	 */
	public void setRootCaseId(Integer rootCaseId) {
		this.rootCaseId = rootCaseId;
	}

	
	/**
	 * @return wfParamName
	 */
	public String getWfParamName() {
		return wfParamName;
	}

	/**
	 * @param wfParamName
	 */
	public void setWfParamName(String wfParamName) {
		this.wfParamName = wfParamName;
	}

	public OdsWorkflowParamsId() {
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rootCaseId == null) ? 0 : rootCaseId.hashCode());
		result = prime * result + ((wfParamName == null) ? 0 : wfParamName.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OdsWorkflowParamsId other = (OdsWorkflowParamsId) obj;
		if (rootCaseId == null) {
			if (other.rootCaseId != null)
				return false;
		} else if (!rootCaseId.equals(other.rootCaseId))
			return false;
		if (wfParamName == null) {
			if (other.wfParamName != null)
				return false;
		} else if (!wfParamName.equals(other.wfParamName))
			return false;
		return true;
	}
	
	
}
