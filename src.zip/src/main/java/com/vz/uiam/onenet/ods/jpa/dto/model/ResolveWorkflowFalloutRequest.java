/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Request Model class
 * 
 * @author Kiran
 *
 */
public class ResolveWorkflowFalloutRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String caseId;
	private String workFlowStepName;
	private String workFlowFalloutErrorCode;
	private String workFlowFalloutErrorDesc;
	private String workFlowProcessName;
	private String rootCaseId;
	/*private String workFlowFalloutErrorCategory;
	public String getWorkFlowFalloutErrorCategory() {
		return workFlowFalloutErrorCategory;
	}

	public void setWorkFlowFalloutErrorCategory(String workFlowFalloutErrorCategory) {
		this.workFlowFalloutErrorCategory = workFlowFalloutErrorCategory;
	}*/

	public String getRootCaseId() {
		return rootCaseId;
	}

	public void setRootCaseId(String rootCaseId) {
		this.rootCaseId = rootCaseId;
	}

	

	/**
	 * @return the workFlowStepName
	 */
	public String getWorkFlowStepName() {
		return workFlowStepName;
	}

	/**
	 * @param workFlowStepName
	 *            the workFlowStepName to set
	 */
	public void setWorkFlowStepName(String workFlowStepName) {
		this.workFlowStepName = workFlowStepName;
	}

	/**
	 * @return the caseId
	 */
	public String getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId
	 *            the caseId to set
	 */
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return the workFlowFalloutErrorCode
	 */
	public String getWorkFlowFalloutErrorCode() {
		return workFlowFalloutErrorCode;
	}

	/**
	 * @param workFlowFalloutErrorCode
	 *            the workFlowFalloutErrorCode to set
	 */
	public void setWorkFlowFalloutErrorCode(String workFlowFalloutErrorCode) {
		this.workFlowFalloutErrorCode = workFlowFalloutErrorCode;
	}

	/**
	 * @return the workFlowFalloutErrorDes
	 */
	public String getWorkFlowFalloutErrorDesc() {
		return workFlowFalloutErrorDesc;
	}

	/**
	 * @param workFlowFalloutErrorDes
	 *            the workFlowFalloutErrorDes to set
	 */
	public void setWorkFlowFalloutErrorDesc(String workFlowFalloutErrorDes) {
		this.workFlowFalloutErrorDesc = workFlowFalloutErrorDes;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @param caseId
	 * @param workFlowStepName
	 * @param workFlowStepRetryCounter
	 * @param status
	 * @param workFlowFalloutErrorCode
	 * @param workFlowFalloutErrorDes
	 */
	public ResolveWorkflowFalloutRequest(String caseId, String workFlowStepName,
			String workFlowFalloutErrorCode, String workFlowFalloutErrorDes) {
		this.caseId = caseId;
		this.workFlowStepName = workFlowStepName;
		this.workFlowFalloutErrorCode = workFlowFalloutErrorCode;
		this.workFlowFalloutErrorDesc = workFlowFalloutErrorDes;
	}

	/**
	 * @param workFlowStepName
	 * @param workFlowFalloutErrorCode
	 */
	public ResolveWorkflowFalloutRequest(String workFlowStepName,
			String workFlowFalloutErrorCode) {
		this.workFlowStepName = workFlowStepName;
		this.workFlowFalloutErrorCode = workFlowFalloutErrorCode;
	}
	
	
	public ResolveWorkflowFalloutRequest(String workFlowStepName,
			String workFlowFalloutErrorCode,String workFlowProcessName) {
		this.workFlowStepName = workFlowStepName;
		this.workFlowFalloutErrorCode = workFlowFalloutErrorCode;
		this.workFlowProcessName=workFlowProcessName;
	}

	public ResolveWorkflowFalloutRequest() {
		// TODO Auto-generated constructor stub
	}

	public String getWorkFlowProcessName() {
		return workFlowProcessName;
	}

	public void setWorkFlowProcessName(String workFlowProcessName) {
		this.workFlowProcessName = workFlowProcessName;
	}

}