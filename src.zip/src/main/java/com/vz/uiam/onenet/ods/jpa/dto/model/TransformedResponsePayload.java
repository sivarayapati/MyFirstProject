/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dto.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author Anand
 *
 */
public class TransformedResponsePayload {
	
	private String body;
	private String header;
	
	/**
	 * @return the body
	 */
	public String getBody() {
		return body;
	}
	/**
	 * @param body the body to set
	 */
	public void setBody(String body) {
		this.body = body;
	}
	/**
	 * @return the header
	 */
	public String getHeader() {
		return header;
	}
	/**
	 * @param header the header to set
	 */
	public void setHeader(String header) {
		this.header = header;
	}
	
	public TransformedResponsePayload() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param body
	 * @param header
	 */
	public TransformedResponsePayload(String body, String header) {
		super();
		this.body = body;
		this.header = header;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}

}
