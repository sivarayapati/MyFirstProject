package com.vz.uiam.onenet.ods.jpa.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsSchedulerLock;


@Transactional
@Repository
public interface OdsSchedulerLockRepository extends JpaRepository<OdsSchedulerLock, Integer> {

	public OdsSchedulerLock findByLockKeyAndLockValue(String odsRetryBonitaTaskCompletionKey,
			String odsSchedulerSwitchOff);
    public OdsSchedulerLock save(OdsSchedulerLock OdsSchedulerLock);

}
