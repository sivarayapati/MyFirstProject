package com.vz.uiam.onenet.ods.service;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsTransformerConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFalloutConfig;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSConfigPayload;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSKeyDetails;

/**
 * @author Ashish Goyal
 *
 */
@Service
@Transactional(rollbackOn = { ApplicationException.class, Exception.class, RuntimeException.class })
public class ODSConfigService {

	private static final Logger LOGGER = Logger.getLogger(ODSConfigService.class);

	private static final String SCRIPT_SEPARATOR = "-----------------------------------------------------------\n";

	@Autowired
	OdsServiceRouteMapService odsServiceRouteMapSvc;

	@Autowired
	OdsMandatoryAttrsService odsMandatoryAttrsSvc;

	@Autowired
	OdsParamConfigService odsParamConfigSvc;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	OdsRequestResponseTransactionIdMapService odsReqResTIdMapService;

	@Autowired
	ODSWorkFlowFalloutConfigService odsWorkFlowFalloutConfigService;

	@Autowired
	OdsTransformerConfigService odsTransformerConfigService;

	@Autowired
	OdsMilestoneConfigService odsMilestoneConfigService;

	/**
	 * API to create or Update ODS Configurations
	 * 
	 * @param odsConfigPayload
	 * @return
	 * @throws ApplicationException
	 */
	public ODSConfigPayload createOrUpdateOdsConfig(ODSConfigPayload odsConfigPayload) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateOdsConfig");

		ODSKeyDetails keyDetails = odsConfigPayload.getKeyDetails();
		List<OdsServiceRouterMapDetails> serviceRouteMapList = odsConfigPayload.getServiceRouteMap();
		List<OdsMandatoryAttributes> mandatoryAttrsList = odsConfigPayload.getMandatoryAttrs();
		List<OdsParamConfig> paramConfigList = odsConfigPayload.getParamConfig();
		OdsRequestTransactionIdMap reqTransactionIdMap = odsConfigPayload.getOdsRequestTransactionIdMap();
		List<WorkflowFalloutConfig> workflowFalloutConfigList = odsConfigPayload.getWorkflowFalloutConfig();
		OdsTransformerConfig odsTransformerConfig = odsConfigPayload.getOdsTransformerConfig();
		List<OdsMilestoneConfig> odsMilestoneConfigList = odsConfigPayload.getOdsMilestoneConfig();

		ODSConfigPayload respODSConfigPayload = new ODSConfigPayload();
		
		if (keyDetails == null)
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "keyDetails is required");
		
		respODSConfigPayload.setKeyDetails(keyDetails);
		
		if (!CollectionUtils.isEmpty(serviceRouteMapList))
			respODSConfigPayload.setServiceRouteMap(createOrUpdateServiceRouteMap(serviceRouteMapList));

		if (!CollectionUtils.isEmpty(mandatoryAttrsList))
			respODSConfigPayload.setMandatoryAttrs(createOrUpdateOdsMandatoryAttrs(mandatoryAttrsList));

		if (!CollectionUtils.isEmpty(paramConfigList))
			respODSConfigPayload.setParamConfig(createOrUpdateOdsParamConfig(paramConfigList));

		if (reqTransactionIdMap != null)
			respODSConfigPayload.setOdsRequestTransactionIdMap(createOrUpdateReqTransactionIDMap(reqTransactionIdMap));

		if (!CollectionUtils.isEmpty(workflowFalloutConfigList))
			respODSConfigPayload.setWorkflowFalloutConfig(createOrUpdateOdsWorkflowFalloutConfig(workflowFalloutConfigList));

		if (odsTransformerConfig != null)
			createOrUpdateOdsTransformerConfig(odsTransformerConfig);

		if (!CollectionUtils.isEmpty(odsMilestoneConfigList))
			respODSConfigPayload.setOdsMilestoneConfig(createOrUpdateOdsMilestoneConfig(odsMilestoneConfigList));

		LOGGER.info("Exiting createOrUpdateOdsConfig");
		return respODSConfigPayload;

	}

	/**
	 * API to create or Update Service Route Map
	 * 
	 * @param keyDetails
	 * @param serviceRouteMap
	 * @return
	 * @throws ApplicationException
	 */
	private List<OdsServiceRouterMapDetails> createOrUpdateServiceRouteMap(
			List<OdsServiceRouterMapDetails> serviceRouteMapList) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateServiceRouteMap");

		List<OdsServiceRouterMapDetails> serviceRouteMapRspList = new ArrayList<>();
		for (OdsServiceRouterMapDetails serviceRouteMap : serviceRouteMapList) {
			serviceRouteMapRspList.add(odsServiceRouteMapSvc.createOrUpdateServiceRouteMap(serviceRouteMap));
		}

		LOGGER.info("Exiting createOrUpdateServiceRouteMap");
		return serviceRouteMapRspList;
	}

	/**
	 * API to create ODS Mandatory Attributes
	 * 
	 * @param mandatoryAttrsList
	 * @return
	 * @throws ApplicationException
	 */
	private List<OdsMandatoryAttributes> createOrUpdateOdsMandatoryAttrs(
			List<OdsMandatoryAttributes> mandatoryAttrsList) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateOdsMandatoryAttrs");

		List<OdsMandatoryAttributes> mandatoryAttrsRspList = new ArrayList<>();

		for (OdsMandatoryAttributes odsMandatoryAttrs : mandatoryAttrsList)
			mandatoryAttrsRspList.add(odsMandatoryAttrsSvc.createOrUpdateOdsMandatoryAttrs(odsMandatoryAttrs));

		LOGGER.info("Exiting createOrUpdateOdsMandatoryAttrs");
		return mandatoryAttrsRspList;
	}

	/**
	 * API to create ODS Param Config
	 * 
	 * @param paramConfigList
	 * @return
	 * @throws ApplicationException
	 */
	private List<OdsParamConfig> createOrUpdateOdsParamConfig(List<OdsParamConfig> paramConfigList)
			throws ApplicationException {
		LOGGER.info("Entering createOrUpdateOdsParamConfig");

		List<OdsParamConfig> paramconfigRspList = new ArrayList<>();

		for (OdsParamConfig odsParamConfig : paramConfigList) {
			paramconfigRspList.add(odsParamConfigSvc.createOrUpdateOdsParamConfig(odsParamConfig));
		}

		LOGGER.info("Exiting createOrUpdateOdsParamConfig");
		return paramconfigRspList;
	}

	/**
	 * API to create or Update OdsRequestTransactionIdMap
	 * 
	 * @param odsReqTIdMap
	 * @return
	 * @throws ApplicationException
	 */
	private OdsRequestTransactionIdMap createOrUpdateReqTransactionIDMap(OdsRequestTransactionIdMap odsReqTIdMap)
			throws ApplicationException {
		LOGGER.info("Entering createOrUpdateReqTransactionIDMap");

		OdsRequestTransactionIdMap requestTIdMap = odsReqResTIdMapService
				.createOrUpdateOdsRequestTransIdMap(odsReqTIdMap);

		LOGGER.info("Exiting createOrUpdateReqTransactionIDMap");
		return requestTIdMap;
	}

	/**
	 * API to create WorkflowFalloutConfig
	 * 
	 * @param workFlowFalloutConfigList
	 * @return
	 * @throws ApplicationException
	 */
	private List<WorkflowFalloutConfig> createOrUpdateOdsWorkflowFalloutConfig(
			List<WorkflowFalloutConfig> workFlowFalloutConfigList) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateOdsWorkflowFalloutConfig");

		List<WorkflowFalloutConfig> workflowFalloutConfigRspList = new ArrayList<>();

		for (WorkflowFalloutConfig workflowFalloutConfig : workFlowFalloutConfigList) {
			workflowFalloutConfigRspList
					.add(odsWorkFlowFalloutConfigService.createOrUpdateWorkflowFalloutConfig(workflowFalloutConfig));
		}

		LOGGER.info("Exiting createOrUpdateOdsWorkflowFalloutConfig");
		return workflowFalloutConfigRspList;
	}

	/**
	 * API to create or Update OdsTransformerConfig
	 * 
	 * @param odsTransformerConfig
	 * @return
	 * @throws ApplicationException
	 */
	private OdsTransformerConfig createOrUpdateOdsTransformerConfig(OdsTransformerConfig odsTransformerConfig)
			throws ApplicationException {
		LOGGER.info("Entering createOrUpdateOdsTransformerConfig");

		OdsTransformerConfig odsTransformerConfigResp = odsTransformerConfigService
				.createOrUpdateOdsTransformerConfig(odsTransformerConfig);

		LOGGER.info("Exiting createOrUpdateOdsTransformerConfig");
		return odsTransformerConfigResp;
	}

	/**
	 * API to create WorkflowFalloutConfig
	 * 
	 * @param workFlowFalloutConfigList
	 * @return
	 * @throws ApplicationException
	 */
	private List<OdsMilestoneConfig> createOrUpdateOdsMilestoneConfig(List<OdsMilestoneConfig> odsMilestoneConfigList)
			throws ApplicationException {
		LOGGER.info("Entering createOrUpdateOdsMilestoneConfig");

		List<OdsMilestoneConfig> odsMilestoneConfigRspList = new ArrayList<>();

		for (OdsMilestoneConfig odsMilestoneConfig : odsMilestoneConfigList) {
			odsMilestoneConfigRspList.add(odsMilestoneConfigService.createOrUpdateMilestoneConfig(odsMilestoneConfig));
		}

		LOGGER.info("Exiting createOrUpdateOdsMilestoneConfig");
		return odsMilestoneConfigRspList;
	}

	/**
	 * API to get the ODS Configurations
	 * 
	 * @param keyDetails
	 * @throws ApplicationException
	 */
	public ODSConfigPayload getOdsConfigurations(ODSKeyDetails keyDetails) throws ApplicationException {
		LOGGER.info("Entering getOdsConfigurations");

		if (StringUtils.isEmpty(keyDetails.getAppKey()) && StringUtils.isEmpty(keyDetails.getFlowNodeProcessName())
				&& StringUtils.isEmpty(keyDetails.getFlowNodeStepName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					"Please provide either appKey or flowNodeProcessName or flowNodeStepName");

		ODSConfigPayload odsConfigResponse = new ODSConfigPayload();

		odsConfigResponse.setKeyDetails(keyDetails);

		// Get the service Route Map record
		List<OdsServiceRouterMapDetails> odsSvcRouterDetails = odsServiceRouteMapSvc
				.getServiceRouteMapRecords(new OdsServiceRouterMapDetails(keyDetails.getAppKey(),
						keyDetails.getFlowNodeProcessName(), keyDetails.getFlowNodeStepName(), keyDetails.getRegion()));
		if (CollectionUtils.isEmpty(odsSvcRouterDetails))
			return odsConfigResponse;

		odsConfigResponse.setServiceRouteMap(odsSvcRouterDetails);

		// Get the Mandatory Attributes List
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<>();

		if (!StringUtils.isEmpty(keyDetails.getAppKey()))
			odsMandatoryAttrsList.addAll(odsMandatoryAttrsSvc.getMandatoryAttributeList(keyDetails.getAppKey()));
		if (!StringUtils.isEmpty(keyDetails.getFlowNodeProcessName())
				|| !StringUtils.isEmpty(keyDetails.getFlowNodeStepName()))
			odsMandatoryAttrsList
					.addAll(odsMandatoryAttrsSvc.getMandatoryAttributeList(keyDetails.getFlowNodeProcessName()
							+ Constants.KEYBUILDER_SEPERATOR + keyDetails.getFlowNodeStepName()));

		odsConfigResponse.setMandatoryAttrs(odsMandatoryAttrsList);

		// Get the Param Config List
		List<OdsParamConfig> odsParamConfigList = new ArrayList<>();
		if (!StringUtils.isEmpty(keyDetails.getAppKey()))
			odsParamConfigList
					.addAll(odsParamConfigSvc.getOdsParamConfigRecords(new OdsParamConfig(keyDetails.getAppKey())));
		if (!StringUtils.isEmpty(keyDetails.getFlowNodeProcessName())
				|| !StringUtils.isEmpty(keyDetails.getFlowNodeStepName()))
			odsParamConfigList.addAll(
					odsParamConfigSvc.getOdsParamConfigRecords(new OdsParamConfig(keyDetails.getFlowNodeProcessName()
							+ Constants.KEYBUILDER_SEPERATOR + keyDetails.getFlowNodeStepName())));

		odsConfigResponse.setParamConfig(odsParamConfigList);

		// Get the OdsRequestTransactionIdMap record
		if (!StringUtils.isEmpty(keyDetails.getFlowNodeProcessName())
				&& !StringUtils.isEmpty(keyDetails.getFlowNodeStepName())) {
			List<OdsRequestTransactionIdMap> odsReqList = odsReqResTIdMapService
					.getOdsRequestTransIdMapRecords(new OdsRequestTransactionIdMap(keyDetails.getFlowNodeProcessName(),
							keyDetails.getFlowNodeStepName()));
			if (odsReqList != null && !odsReqList.isEmpty())
				odsConfigResponse.setOdsRequestTransactionIdMap(odsReqList.get(0));
		}

		// Get the WorkflowFalloutConfig List
		List<WorkflowFalloutConfig> workflowFalloutConfigList = new ArrayList<>();
		if (!StringUtils.isEmpty(keyDetails.getFlowNodeProcessName())
				|| !StringUtils.isEmpty(keyDetails.getFlowNodeStepName()))
			workflowFalloutConfigList = odsWorkFlowFalloutConfigService.getWorkflowFalloutConfig(
					new WorkflowFalloutConfig(keyDetails.getFlowNodeStepName(), keyDetails.getFlowNodeProcessName()));
		odsConfigResponse.setWorkflowFalloutConfig(workflowFalloutConfigList);

		// Get the OdsTransformerConfig
		if ("AppLevel".equals(keyDetails.getLevel())) {
			if (!StringUtils.isEmpty(keyDetails.getAppKey())) {
				odsConfigResponse.setOdsTransformerConfig(
						odsTransformerConfigService.getOdsTransformerConfig(keyDetails.getAppKey()));
			}
		} else {
			if (!StringUtils.isEmpty(keyDetails.getFlowNodeProcessName())
					&& !StringUtils.isEmpty(keyDetails.getFlowNodeStepName())) {

				odsConfigResponse.setOdsTransformerConfig(
						odsTransformerConfigService.getOdsTransformerConfig(keyDetails.getFlowNodeProcessName()
								.concat("_").concat(keyDetails.getFlowNodeStepName()).concat("_RSP_SCHEMA")));
			}
		}

		// Get the OdsMilestoneConfig List
		List<OdsMilestoneConfig> odsMilestoneConfigList = new ArrayList<>();
		if (!StringUtils.isEmpty(keyDetails.getFlowNodeProcessName())
				|| !StringUtils.isEmpty(keyDetails.getFlowNodeStepName()))
			odsMilestoneConfigList = odsMilestoneConfigService.getMilestoneConfig(
					new OdsMilestoneConfig(keyDetails.getFlowNodeProcessName(), keyDetails.getFlowNodeStepName()));
		odsConfigResponse.setOdsMilestoneConfig(odsMilestoneConfigList);

		LOGGER.info("Exiting getOdsConfigurations");
		return odsConfigResponse;
	}

	/**
	 * API to delete the ODS configurations
	 * 
	 * @param keyDetails
	 * @throws ApplicationException
	 */
	public void deleteOdsConfiguration(ODSKeyDetails keyDetails) throws ApplicationException {
		LOGGER.info("Entering deleteOdsConfiguration");

		if (StringUtils.isEmpty(keyDetails.getAppKey()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Please provide appKey");

		if (StringUtils.isEmpty(keyDetails.getFlowNodeProcessName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Please provide flowNodeProcessName");

		if (StringUtils.isEmpty(keyDetails.getFlowNodeStepName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Please provide flowNodeStepName");

		// Delete service Route Map record
		List<OdsServiceRouterMapDetails> serviceRouteMapList = new ArrayList<>();
		serviceRouteMapList.add(new OdsServiceRouterMapDetails(keyDetails.getAppKey(),
				keyDetails.getFlowNodeProcessName(), keyDetails.getFlowNodeStepName()));
		odsServiceRouteMapSvc.deleteServiceRouteMapRecord(serviceRouteMapList);

		// Delete Mandatory Attributes
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(odsMandatoryAttrsSvc.getMandatoryAttributeList(keyDetails.getFlowNodeProcessName()
				+ Constants.KEYBUILDER_SEPERATOR + keyDetails.getFlowNodeStepName()))) {
			odsMandatoryAttrsList.add(new OdsMandatoryAttributes(keyDetails.getFlowNodeProcessName()
					+ Constants.KEYBUILDER_SEPERATOR + keyDetails.getFlowNodeStepName()));
		}
		if (!CollectionUtils.isEmpty(odsMandatoryAttrsList))
			odsMandatoryAttrsSvc.deleteOdsMandatoryAttrsRecord(odsMandatoryAttrsList);

		// Delete Param Configs
		List<OdsParamConfig> odsParamConfigList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(
				odsParamConfigSvc.getOdsParamConfigRecords(new OdsParamConfig(keyDetails.getFlowNodeProcessName()
						+ Constants.KEYBUILDER_SEPERATOR + keyDetails.getFlowNodeStepName())))) {
			odsParamConfigList.add(new OdsParamConfig(keyDetails.getFlowNodeProcessName()
					+ Constants.KEYBUILDER_SEPERATOR + keyDetails.getFlowNodeStepName()));
		}
		if (!CollectionUtils.isEmpty(odsParamConfigList))
			odsParamConfigSvc.deleteOdsParamConfigRecord(odsParamConfigList);

		// Delete OdsRequestTransactionIdMap record
		List<OdsRequestTransactionIdMap> odsReqTransactionIdMapList = new ArrayList<>();
		odsReqTransactionIdMapList.add(
				new OdsRequestTransactionIdMap(keyDetails.getFlowNodeProcessName(), keyDetails.getFlowNodeStepName()));
		if (!CollectionUtils.isEmpty(odsReqTransactionIdMapList))
			odsReqResTIdMapService.deleteOdsRequestTransIdMapRecord(odsReqTransactionIdMapList);

		// Delete WorkflowFalloutConfig
		List<WorkflowFalloutConfig> workflowFalloutConfigList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(odsWorkFlowFalloutConfigService.getWorkflowFalloutConfig(
				new WorkflowFalloutConfig(keyDetails.getFlowNodeStepName(), keyDetails.getFlowNodeProcessName())))) {
			workflowFalloutConfigList.add(
					new WorkflowFalloutConfig(keyDetails.getFlowNodeStepName(), keyDetails.getFlowNodeProcessName()));
		}
		if (!CollectionUtils.isEmpty(workflowFalloutConfigList))
			odsWorkFlowFalloutConfigService.deleteWorkflowFalloutConfigRecord(workflowFalloutConfigList);

		// Delete OdsTransformerConfig record
		OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig(keyDetails.getAppKey());
		OdsTransformerConfig odsTransformerConfigsteplevel = new OdsTransformerConfig(keyDetails
				.getFlowNodeProcessName().concat("_").concat(keyDetails.getFlowNodeStepName()).concat("_RSP_SCHEMA"));
		odsTransformerConfigService.deleteOdsTransformerConfigRecord(odsTransformerConfig);
		odsTransformerConfigService.deleteOdsTransformerConfigRecord(odsTransformerConfigsteplevel);

		// Delete OdsMilestoneConfig
		List<OdsMilestoneConfig> odsMilestoneConfigList = new ArrayList<>();
		if (!CollectionUtils.isEmpty(odsMilestoneConfigService.getMilestoneConfig(
				new OdsMilestoneConfig(keyDetails.getFlowNodeProcessName(), keyDetails.getFlowNodeStepName())))) {
			odsMilestoneConfigList
					.add(new OdsMilestoneConfig(keyDetails.getFlowNodeProcessName(), keyDetails.getFlowNodeStepName()));
		}
		if (!CollectionUtils.isEmpty(odsMilestoneConfigList))
			odsMilestoneConfigService.deleteOdsMilestoneConfigRecord(odsMilestoneConfigList);

		LOGGER.info("Exiting deleteOdsConfiguration");
	}

	/**
	 * Method to generate the Insert Scripts.
	 * 
	 * @throws ApplicationException
	 */
	public String generateInsertScripts(ODSKeyDetails request) throws ApplicationException {
		LOGGER.info("Entering generateInsertScripts");

		if (StringUtils.isEmpty(request.getAppKey()))
			throw new ApplicationException(StatusCode.BAD_REQUEST.getCode(), "Please provide appKey.");

		boolean isAppOnlyConfig = false;
		if (StringUtils.isEmpty(request.getFlowNodeProcessName()) && StringUtils.isEmpty(request.getFlowNodeStepName()))
			isAppOnlyConfig = true;

		StringBuilder insertScript = new StringBuilder();

		if (isAppOnlyConfig) {
			insertScript.append("------------- APP Level Script for " + request.getAppKey() + " -------------\n")
					.append(generateInsertScripts(request.getAppKey(), "", "", "", isAppOnlyConfig));
		}

		OdsServiceRouterMapDetails odsServiceRouterMapDetails = new OdsServiceRouterMapDetails();
		odsServiceRouterMapDetails.setAppKey(request.getAppKey());
		odsServiceRouterMapDetails.setFlowNodeProcessName(request.getFlowNodeProcessName());
		odsServiceRouterMapDetails.setFlowNodeStepName(request.getFlowNodeStepName());
		odsServiceRouterMapDetails.setRegion(request.getRegion());
		List<OdsServiceRouterMapDetails> serviceRouteMapList = odsServiceRouteMapSvc
				.getServiceRouteMapRecords(odsServiceRouterMapDetails);

		for (OdsServiceRouterMapDetails odsSvcRouteMapDtl : serviceRouteMapList) {
			insertScript.append(SCRIPT_SEPARATOR).append("\tScript for - ")
					.append("\n\t\t App : " + odsSvcRouteMapDtl.getAppKey())
					.append("\n\t\t Process : " + odsSvcRouteMapDtl.getFlowNodeProcessName())
					.append("\n\t\t Step : " + odsSvcRouteMapDtl.getFlowNodeStepName() + "\n")
					.append(generateInsertScripts(odsSvcRouteMapDtl.getAppKey(),
							odsSvcRouteMapDtl.getFlowNodeProcessName(), odsSvcRouteMapDtl.getFlowNodeStepName(),
							odsSvcRouteMapDtl.getRegion(), false));
		}

		LOGGER.info("Insert Scripts : ");
		LOGGER.info("###############################################################################");
		LOGGER.info(insertScript.toString());
		LOGGER.info("###############################################################################");
		LOGGER.info("Exiting generateInsertScripts");
		return insertScript.toString();
	}

	/**
	 * Method to generate the Insert Scripts.
	 * 
	 * @throws ApplicationException
	 */
	public String generateInsertScripts(String appKey, String processName, String stepName, String region,
			boolean isAppOnlyConfig) throws ApplicationException {
		LOGGER.info("Entering generateInsertScripts");
		LOGGER.info("appKey ::::" + appKey + "processName::::" + processName + "stepName::::" + stepName + " region::::"
				+ region);
		LOGGER.info("isAppOnlyConfig : " + isAppOnlyConfig);

		Map<String, String> tblNameAndPrimaryColValues = new LinkedHashMap<>();
		addTableNames(tblNameAndPrimaryColValues);

		List<String> escapeQuoteColList;
		Set<String> tblNameCol = tblNameAndPrimaryColValues.keySet();
		Object params[];

		StringBuilder insertScript = new StringBuilder(SCRIPT_SEPARATOR);

		for (String tableName : tblNameCol) {
			escapeQuoteColList = new ArrayList<>();
			String primaryColumn = tblNameAndPrimaryColValues.get(tableName);
			String paramKey = processName + "_" + stepName;
			String sql = "select * from  " + tableName + "  where";

			if ("ods_service_route_map".equalsIgnoreCase(tableName) && !isAppOnlyConfig) {
				if (StringUtils.isNotEmpty(region)) {
					sql = sql + " FLOW_NODE_PROCESS_NAME=? and FLOW_NODE_STEP_NAME=? and APP_KEY=? and region=?";
					params = new Object[] { processName, stepName, appKey, region };
				} else {
					sql = sql + " FLOW_NODE_PROCESS_NAME=? and FLOW_NODE_STEP_NAME=? and APP_KEY=?";
					params = new Object[] { processName, stepName, appKey };
				}
				insertScript
						.append(prepareInsertScripts(sql, tableName, params, primaryColumn, false, escapeQuoteColList));

			} else if ("ods_mandatory_attrs".equalsIgnoreCase(tableName)) {
				sql = sql + " ATTR_KEY=?";

				if (isAppOnlyConfig)
					params = new Object[] { appKey };
				else
					params = new Object[] { paramKey };

				insertScript
						.append(prepareInsertScripts(sql, tableName, params, primaryColumn, false, escapeQuoteColList));

			} else if ("ods_param_config".equalsIgnoreCase(tableName)) {
				sql = sql + " PARAM_KEY=?  order by TYPE";

				if (isAppOnlyConfig)
					params = new Object[] { appKey };
				else
					params = new Object[] { paramKey };

				insertScript
						.append(prepareInsertScripts(sql, tableName, params, primaryColumn, false, escapeQuoteColList));

			} else if ("ods_request_transaction_id_map".equalsIgnoreCase(tableName) && !isAppOnlyConfig) {
				sql = "select ID, FLOW_NODE_PROCESS_NAME, FLOW_NODE_STEP_NAME, TRANSACTION_ID_KEY"
						+ " from ods_request_transaction_id_map " + " where " + " FLOW_NODE_PROCESS_NAME=? "
						+ " and FLOW_NODE_STEP_NAME=? ";

				params = new Object[] { processName, stepName };

				insertScript
						.append(prepareInsertScripts(sql, tableName, params, primaryColumn, false, escapeQuoteColList));

			} else if ("ods_milestone_config".equalsIgnoreCase(tableName) && !isAppOnlyConfig) {

				sql = sql + " FLOW_NODE_PROCESS_NAME=? and FLOW_NODE_STEP_NAME=? ";
				params = new Object[] { processName, stepName };

				insertScript
						.append(prepareInsertScripts(sql, tableName, params, primaryColumn, false, escapeQuoteColList));

			} else if ("ods_workflow_fallout_config".equalsIgnoreCase(tableName) && !isAppOnlyConfig) {
				sql = sql + "  workflow_process_name=? and workflow_stepname=?";

				params = new Object[] { processName, stepName };

				insertScript
						.append(prepareInsertScripts(sql, tableName, params, primaryColumn, false, escapeQuoteColList));
			} else if ("ods_transformer_config".equalsIgnoreCase(tableName) && isAppOnlyConfig) {
				sql = sql + "  transformer_key like ?";

				params = new Object[] { appKey + "%" };

				insertScript
						.append(prepareInsertScripts(sql, tableName, params, primaryColumn, false, escapeQuoteColList));
			}
		}

		insertScript.append(SCRIPT_SEPARATOR);
		LOGGER.info("Exiting generateInsertScripts");

		return insertScript.toString();
	}

	private String prepareInsertScripts(String sql, String tableName, Object[] params, String primaryColumn,
			boolean isInsertIgnore, List<String> escapeQuoteColList) throws ApplicationException {
		LOGGER.info("Entering prepareInsertScripts");

		StringBuilder insertScript = new StringBuilder();

		Map<String, Object> colNamesAnValues = getCommaSepareatedColumnNamesandValues(sql, params, primaryColumn,
				escapeQuoteColList);
		String colString = colNamesAnValues.get("columnNameString").toString();
		List<String> finalColumnsValuesList = (List<String>) colNamesAnValues.get("finalColumnsValuesList");

		if (CollectionUtils.isNotEmpty(finalColumnsValuesList))
			insertScript.append("\n");

		for (String columnValues : finalColumnsValuesList) {
			if (!StringUtils.isEmpty(columnValues)) {
				if (isInsertIgnore)
					insertScript.append(String.format("INSERT IGNORE INTO %s (%s) VALUES (%s);", tableName, colString,
							columnValues)).append("\n");
				else
					insertScript.append(
							String.format("INSERT INTO %s (%s) VALUES (%s);", tableName, colString, columnValues))
							.append("\n");
			}
		}

		LOGGER.info("Exiting prepareInsertScripts");
		return insertScript.toString();
	}

	/**
	 * Method to return the Comma separated Column Names and values.
	 * 
	 * @param sql
	 * @param params
	 * @param primaryColumn
	 * @return
	 */
	private Map<String, Object> getCommaSepareatedColumnNamesandValues(String sql, Object[] params,
			String primaryColumn, List<String> escapeQuoteColList) throws ApplicationException {
		LOGGER.info("Entering getCommaSepareatedColumnNames");

		List<Integer> escapeQuoteColumns = new ArrayList<>();
		Map<String, Object> columnsNamesValues = new HashMap<>();
		try {
			Map<String, Object> namesandValues = jdbcTemplate.query(sql, params,
					new ResultSetExtractor<Map<String, Object>>() {

						@Override
						public Map<String, Object> extractData(ResultSet rs) throws SQLException, DataAccessException {
							Map<String, Object> colNamesAndValues = new HashMap<>();
							List<String> columnsList = new ArrayList<>();
							ResultSetMetaData rsMetaData = rs.getMetaData();
							int idColumnSequence = 0;
							int columnCount = rsMetaData.getColumnCount();
							for (int i = 1; i <= columnCount; i++) {
								String colName = rsMetaData.getColumnLabel(i);

								if (!colName.equalsIgnoreCase(primaryColumn)) {
									columnsList.add(colName.toUpperCase());
								} else {
									idColumnSequence = i;
								}

								if (escapeQuoteColList.stream().anyMatch(colName::equalsIgnoreCase))
									escapeQuoteColumns.add(i);
							}

							String colNameString = StringUtils.join(columnsList, ", ");

							List<String> finalColumnsValuesList = new ArrayList<>();
							while (rs.next()) {
								List<String> columnsValueList = new ArrayList<>();
								for (int i = 1; i <= columnsList.size() + 1; i++) {
									if (i != idColumnSequence) {
										String colValue = rs.getString(i);
										if (colValue != null) {
											if (CollectionUtils.isNotEmpty(escapeQuoteColumns)
													&& escapeQuoteColumns.contains(i))
												columnsValueList.add(colValue.replace("\n", "").replace("\r", ""));
											else
												columnsValueList
														.add("'" + colValue.replace("\n", "").replace("\r", "") + "'");
										} else {
											columnsValueList.add("null");
										}
									}
								}
								String colValuesString = StringUtils.join(columnsValueList, ", ");
								finalColumnsValuesList.add(colValuesString);
							}
							colNamesAndValues.put("columnListString", colNameString);
							colNamesAndValues.put("finalValuesList", finalColumnsValuesList);
							return colNamesAndValues;
						}
					});
			columnsNamesValues.put("columnNameString", namesandValues.get("columnListString"));
			columnsNamesValues.put("finalColumnsValuesList", namesandValues.get("finalValuesList"));

		} catch (Exception sqle) {
			LOGGER.error("Exception while getting Comma separated Column names and values.", sqle);
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Error while getting Comma separated Column names. " + sqle.getMessage());
		}

		LOGGER.info("Exiting getCommaSepareatedColumnNamesAndValues");
		return columnsNamesValues;
	}

	private void addTableNames(Map<String, String> tableNamesMap) {
		LOGGER.info("Entering addTableNames");

		tableNamesMap.put("ods_service_route_map", "ID");
		tableNamesMap.put("ods_mandatory_attrs", "VALIDATION_ID");
		tableNamesMap.put("ods_param_config", "PARAM_ID");
		tableNamesMap.put("ods_request_transaction_id_map", "ID");
		tableNamesMap.put("ods_milestone_config", "ods_milestone_config_Id");
		tableNamesMap.put("ods_workflow_fallout_config", "id");
		tableNamesMap.put("ods_transformer_config", "ods_transformer_config_id");

		LOGGER.info("Exiting addTableNames");
	}
}
