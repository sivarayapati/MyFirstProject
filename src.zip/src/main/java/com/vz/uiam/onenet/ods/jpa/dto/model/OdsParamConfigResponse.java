package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;


/**
 * @author Ashish Goyal
 *
 */
@JsonInclude(Include.NON_NULL)
public class OdsParamConfigResponse {

	private String statusCode;
	private String statusDesc;
	private OdsParamConfig odsParamConfig;
	private List<OdsParamConfig> odsParamConfigList;
	
	public String getStatusCode() {
		return statusCode;
	}
	
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	public String getStatusDesc() {
		return statusDesc;
	}
	
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	public OdsParamConfig getOdsParamConfig() {
		return odsParamConfig;
	}
	
	public void setOdsParamConfig(OdsParamConfig odsParamConfig) {
		this.odsParamConfig = odsParamConfig;
	}
	
	public List<OdsParamConfig> getOdsParamConfigList() {
		return odsParamConfigList;
	}
	
	public void setOdsParamConfigList(List<OdsParamConfig> odsParamConfigList) {
		this.odsParamConfigList = odsParamConfigList;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
