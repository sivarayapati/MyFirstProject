package com.vz.uiam.onenet.util.constants;

public enum StatusCode {

	SUCCESS("0", "Success"),
	FAILED("1", "Got Failure response"),	
	ERROR_PROCESSING_JSON("701", "Error processing JSON"),
	ERROR_CONNECTION_REFUSED("702", "Connection Refused"),
	ERROR_INTERFACE_EXCEPTION("703","Interface Exception"),
	ERROR_IOEXCEPTION("704","IOException"),
	HTTP_ERROR("705", "HTTP Error");
	


	private final String code;
	private final String desc;

	private StatusCode(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	/**
	 * Return the String value of this status code.
	 */
	public String getCode() {
		return this.code;
	}

	/**
	 * Return the message of this status code.
	 */
	public String getDesc() {
		return this.desc;
	}
}
