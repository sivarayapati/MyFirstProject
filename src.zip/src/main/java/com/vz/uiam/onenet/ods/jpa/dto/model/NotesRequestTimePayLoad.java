package com.vz.uiam.onenet.ods.jpa.dto.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class NotesRequestTimePayLoad {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String Request;
	private String DateTime;
	
	public String getRequest() {
		return Request;
	}
	public void setRequest(String request) {
		Request = request;
	}
	public String getDateTime() {
		return DateTime;
	}
	public void setDateTime(String dateTime) {
		DateTime = dateTime;
	}
	public NotesRequestTimePayLoad(String request, String dateTime) {
		super();
		Request = request;
		DateTime = dateTime;
	}
	
	
}
