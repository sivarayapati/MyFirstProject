package com.vz.uiam.onenet.ods.predicate;

import org.apache.commons.lang3.StringUtils;

import com.mysema.query.types.expr.BooleanExpression;
import com.vz.uiam.onenet.ods.jpa.dao.model.QOdsParamConfig;

/**
 * @author Ashish Goyal
 *
 */
public class OdsParamConfigPredicate {

	private static QOdsParamConfig odsParamConfig = QOdsParamConfig.odsParamConfig;
	
	public OdsParamConfigPredicate() {
		super();
	}
	
	public BooleanExpression isKeyEqualsIg(String key) {
		return !StringUtils.isEmpty(key) ? odsParamConfig.paramKey.equalsIgnoreCase(key) : null;
	}
	
	public BooleanExpression isTypeEqualsIg(String type) {
		return !StringUtils.isEmpty(type) ? odsParamConfig.type.equalsIgnoreCase(type) : null;
	}
	
	public BooleanExpression isNameEqualsIg(String name) {
		return !StringUtils.isEmpty(name) ? odsParamConfig.name.equalsIgnoreCase(name) : null;
	}
}
