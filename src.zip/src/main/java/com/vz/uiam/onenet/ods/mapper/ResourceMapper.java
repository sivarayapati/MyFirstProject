package com.vz.uiam.onenet.ods.mapper;

import org.springframework.beans.factory.annotation.Autowired;

import ma.glasnost.orika.MapperFacade;

public class ResourceMapper {

    @Autowired
    MapperFacade mapper;

  
}
