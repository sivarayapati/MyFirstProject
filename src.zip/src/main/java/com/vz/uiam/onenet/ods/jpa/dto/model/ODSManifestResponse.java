package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author ODS.
 *
 */
@JsonInclude(Include.NON_NULL)
public class ODSManifestResponse implements Serializable {
	/**
	 * Serial Version UID
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Retrieved Manifest Documents.
	 */
	private String manifestDocuments;

	/**
	 * Constructor.
	 */
	public ODSManifestResponse() {

	}

	/**
	 * Constructor.
	 * 
	 * @param manifestDocuments
	 */
	public ODSManifestResponse(String manifestDocuments) {
		this.manifestDocuments = manifestDocuments;
	}

	/**
	 * @return the manifestDocuments
	 */
	public String getManifestDocuments() {
		return manifestDocuments;
	}

	/**
	 * @param manifestDocuments
	 *            the manifestDocuments to set
	 */
	public void setManifestDocuments(String manifestDocuments) {
		this.manifestDocuments = manifestDocuments;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
