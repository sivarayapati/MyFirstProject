package com.vz.uiam.onenet.ods.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mysema.query.jpa.impl.JPAQuery;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.QOdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.predicate.OdsParamConfigPredicate;


/**
 * @author Ashish Goyal
 *
 */
@Service
@Transactional(rollbackOn = { ApplicationException.class, Exception.class, RuntimeException.class })
public class OdsParamConfigService {

	private static final Logger LOGGER = Logger.getLogger(OdsParamConfigService.class);
	
	@Autowired
	OdsParamConfigRepository odsParamConfigRepo;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	/**
	 * API to create or Update a record in OdsParamConfig table
	 * 
	 * @param inputOdsParamConfig
	 * @return
	 * @throws ApplicationException
	 */
	public OdsParamConfig createOrUpdateOdsParamConfig(OdsParamConfig inputOdsParamConfig) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateOdsParamConfig");
		
		OdsParamConfig existingOdsParamConfig = null;
		
		if (inputOdsParamConfig.getParamId() != null) {
			existingOdsParamConfig = odsParamConfigRepo.findOne(inputOdsParamConfig.getParamId());
			
			if (existingOdsParamConfig == null)
				throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "OdsParamConfig record not found for ID - " + inputOdsParamConfig.getParamId());
		} else if (!StringUtils.isEmpty(inputOdsParamConfig.getParamKey()) &&
						!StringUtils.isEmpty(inputOdsParamConfig.getType()) &&
						!StringUtils.isEmpty(inputOdsParamConfig.getName())) {
			existingOdsParamConfig = odsParamConfigRepo.findByParamKeyAndTypeAndName(inputOdsParamConfig.getParamKey(),
															inputOdsParamConfig.getType(), inputOdsParamConfig.getName());
		}
		
		if (existingOdsParamConfig == null) {
			doOdsParamConfigValidation(inputOdsParamConfig);
		}
		
		OdsParamConfig newServiceRoueteMap = odsParamConfigRepo.save(
															getUpdatedOdsParamConfigRecord(inputOdsParamConfig, existingOdsParamConfig));
		
		LOGGER.info("Exiting createOrUpdateOdsParamConfig");
		return newServiceRoueteMap;
	}
	
	
	/**
	 * API to retrieve OdsParamConfig records
	 * 
	 * @param odsParamConfig
	 * @return
	 * @throws ApplicationException
	 */
	public List<OdsParamConfig> getOdsParamConfigRecords(OdsParamConfig odsParamConfig) throws ApplicationException {
		LOGGER.info("Entering getOdsParamConfigRecords");
		
		if (StringUtils.isEmpty(odsParamConfig.getParamKey()) && StringUtils.isEmpty(odsParamConfig.getType()) &&
											StringUtils.isEmpty(odsParamConfig.getName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Please provide either paramKey or type or name");
		
		List<OdsParamConfig> odsParamConfigRspList = null;
		QOdsParamConfig odsParamConfigQdsl = QOdsParamConfig.odsParamConfig;
		
		OdsParamConfigPredicate odsParamConfigSearchPredicate = new OdsParamConfigPredicate();
		
		JPAQuery query = getJPAQryInstance();
		
		try {
			odsParamConfigRspList = query.from(odsParamConfigQdsl)
					.where(odsParamConfigSearchPredicate.isKeyEqualsIg(odsParamConfig.getParamKey()),
							odsParamConfigSearchPredicate.isTypeEqualsIg(odsParamConfig.getType()),
							odsParamConfigSearchPredicate.isNameEqualsIg(odsParamConfig.getName()))
					.list(new QOdsParamConfig(odsParamConfigQdsl));
		} catch (Exception e) {
			LOGGER.error("Error while getting OdsParamConfig records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while getting OdsParamConfig records. " + e.getMessage());
		}
		
		LOGGER.info("Exiting getOdsParamConfigRecords");
		return odsParamConfigRspList;
	}

	
	/**
	 * API to delete the OdsParamConfig records
	 * 
	 * @param odsParamConfigList
	 * @throws ApplicationException
	 */
	public void deleteOdsParamConfigRecord(List<OdsParamConfig> odsParamConfigList) throws ApplicationException {
		LOGGER.info("Entering deleteOdsParamConfigRecord");
		
		try {
			for (OdsParamConfig odsParamConfig : odsParamConfigList) {
				if (odsParamConfig.getParamId() != null) {
					odsParamConfigRepo.delete(odsParamConfig.getParamId());
				} else if (!StringUtils.isEmpty(odsParamConfig.getParamKey()) &&
						!StringUtils.isEmpty(odsParamConfig.getType()) &&
						!StringUtils.isEmpty(odsParamConfig.getName())) {
					
					OdsParamConfig existingOdsParamConfig = odsParamConfigRepo.findByParamKeyAndTypeAndName(
										odsParamConfig.getParamKey(), odsParamConfig.getType(), odsParamConfig.getName());
					
					if (existingOdsParamConfig != null)
						odsParamConfigRepo.delete(existingOdsParamConfig);
					else
						throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Record not found for the given input."
								+ " paramKey[" + odsParamConfig.getParamKey() + "]" + ", type[" + odsParamConfig.getType() + "]" + " and name[" + odsParamConfig.getName() + "]");
				} else if (!StringUtils.isEmpty(odsParamConfig.getParamKey())) {
					List<OdsParamConfig> existingOdsParamConfig = odsParamConfigRepo.findByParamKey(odsParamConfig.getParamKey());
					
					if (!CollectionUtils.isEmpty(existingOdsParamConfig)) {
						odsParamConfigRepo.delete(existingOdsParamConfig);
					} else
						throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Record not found for the given input."
								+ " paramKey[" + odsParamConfig.getParamKey() + "]");
				} else {
					throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "Provide either [paramId] or [paramKey, type and name]");
				}
			}
		} catch (Exception e) {
			LOGGER.error("Error while deleting OdsParamConfig records - ", e);
			throw new ApplicationException(StatusCode.APP_ERROR.getCode(), "Error while deleting OdsParamConfig records. " + e.getMessage());
		}
		
		LOGGER.info("Exiting deleteOdsParamConfigRecord");
	}
	
	
	/**
	 * API to update the input OdsParamConfig record with the exiting one 
	 * 
	 * @param inputOdsParamConfig
	 * @param existingOdsParamConfig
	 * @return
	 * @throws ApplicationException 
	 */
	public OdsParamConfig getUpdatedOdsParamConfigRecord(OdsParamConfig inputOdsParamConfig,
												OdsParamConfig existingOdsParamConfig) throws ApplicationException {
		LOGGER.info("Entering getUpdatedOdsParamConfigRecord");
		
		if (existingOdsParamConfig == null)
			return inputOdsParamConfig;
		
		if (!StringUtils.isEmpty(inputOdsParamConfig.getParamKey()))
			existingOdsParamConfig.setParamKey(inputOdsParamConfig.getParamKey());
		
		if (!StringUtils.isEmpty(inputOdsParamConfig.getType()))
			existingOdsParamConfig.setType(inputOdsParamConfig.getType());
		
		if (!StringUtils.isEmpty(inputOdsParamConfig.getName()))
			existingOdsParamConfig.setName(inputOdsParamConfig.getName());
		
		if (!StringUtils.isEmpty(inputOdsParamConfig.getValue()))
			existingOdsParamConfig.setValue(inputOdsParamConfig.getValue());
		
		LOGGER.info("Exiting getUpdatedOdsParamConfigRecord");
		return existingOdsParamConfig;
	}
	
	
	/**
	 * API to do validation on input OdsParamConfig record
	 * 
	 * @param odsParamConfig
	 * @throws ApplicationException
	 */
	public void doOdsParamConfigValidation(OdsParamConfig odsParamConfig) throws ApplicationException {
		LOGGER.info("Entering doOdsParamConfigValidation");
		
		if (StringUtils.isEmpty(odsParamConfig.getParamKey()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "paramKey is null or empty");
		if (StringUtils.isEmpty(odsParamConfig.getType()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "type is null or empty");
		if (StringUtils.isEmpty(odsParamConfig.getName()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "name is null or empty");
		if (StringUtils.isEmpty(odsParamConfig.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(), "value is null or empty");
		
		LOGGER.info("Exiting doOdsParamConfigValidation");
	}
	
	
	/**
	 * @param paramKey
	 * @param type
	 * @param List of names
	 * @return OdsParamConfig
	 * @throws ApplicationException
	 */
	public List<OdsParamConfig> getOdsParamConfigByParamKeyAndTypeAndNameIn(String paramKey, String type, List<String> names)
			throws ApplicationException{
		LOGGER.info("Entering getOdsParamConfigByTypeAndNameIn");
		List<OdsParamConfig> odsParamsByTypeAndName= null;		
		for(String name : names) {
			OdsParamConfig odsParamConfig = odsParamConfigRepo.findByParamKeyAndTypeAndName(paramKey,type,name);
			if(odsParamConfig != null) {
				if(CollectionUtils.isEmpty(odsParamsByTypeAndName)) {
					odsParamsByTypeAndName= new ArrayList<OdsParamConfig>();
				}
				LOGGER.info("Matching ODS Param Config :"+odsParamConfig.getParamKey()+" "+odsParamConfig.getType()+" "+odsParamConfig.getName()+" "+odsParamConfig.getValue());
				odsParamsByTypeAndName.add(odsParamConfig);
			}
		}			
		LOGGER.info("Exiting getOdsParamConfigByTypeAndNameIn");
		return odsParamsByTypeAndName;
	}
	
	/**
	 * Service method to retrieve the ODS Param Config row
	 * given ParamKey, Type and Name.
	 * 
	 * @param String paramKey
	 * @param String type
	 * @param String name
	 * @return OdsParamCofig
	 * @throws ApplicationException
	 */
	public OdsParamConfig findByParamKeyAndTypeAndName(String paramKey, String type, String name)
			throws ApplicationException {
		return odsParamConfigRepo.findByParamKeyAndTypeAndName(paramKey, type, name);
	}
	

	public JPAQuery getJPAQryInstance() {
		return new JPAQuery(entityManager);
	}

	/**
	 * Service method to retrieve the List of ODS Param Config row
	 * given ParamKey, Type.
	 * 
	 * @param String paramKey
	 * @param String type
	 * @return List<OdsParamConfig>
	 * @throws ApplicationException
	 */
	public List<OdsParamConfig> findByParamKeyAndType(String paramKey, String type) throws ApplicationException {
		return odsParamConfigRepo.findByParamKeyAndType(paramKey, type);
	}
}
