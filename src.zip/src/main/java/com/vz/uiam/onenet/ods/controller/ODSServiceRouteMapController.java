package com.vz.uiam.onenet.ods.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsServiceRouteMapResponse;
import com.vz.uiam.onenet.ods.service.OdsServiceRouteMapService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


/**
 * @author Ashish Goyal
 *
 */
@RestController
@RequestMapping("/oneDispatcher/serviceRouteMap")
public class ODSServiceRouteMapController {
	
	private static final Logger LOGGER = Logger.getLogger(ODSServiceRouteMapController.class);
	
	@Autowired
	OdsServiceRouteMapService odsServiceRouteMapService;

	
	@RequestMapping(value = "/createOrUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create or Update a record in Service Route Map", notes = "Create or Update a record in Service Route Map", response = OdsServiceRouteMapResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Created or Updated ServiceRouteMap record", response = OdsServiceRouteMapResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "createOrUpdate ServiceRouteMap Service is unavaialble") })
	public ResponseEntity<OdsServiceRouteMapResponse> createOrUpdateServiceRouteMap(@RequestBody OdsServiceRouterMapDetails request)
														throws ApplicationException {
		
		LOGGER.info("Entering createOrUpdateServiceRouteMap");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsServiceRouteMapResponse response = new OdsServiceRouteMapResponse();
		
		try {
			OdsServiceRouterMapDetails odsSvcRoutMapResp =  odsServiceRouteMapService.createOrUpdateServiceRouteMap(request);
			
			if(null == odsSvcRoutMapResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsServiceRouteMap(odsSvcRoutMapResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting createOrUpdateServiceRouteMap");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
		
	}

	
	@RequestMapping(value = "/get", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get Service Route Map Details", notes = "Get Service Route Map Details", response = OdsServiceRouteMapResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved ServiceRouteMap record", response = OdsServiceRouteMapResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "get ServiceRouteMap Service is unavaialble") })
	public ResponseEntity<OdsServiceRouteMapResponse> getServiceRouteMap(@RequestBody OdsServiceRouterMapDetails request)
														throws ApplicationException {
		
		LOGGER.info("Entering getServiceRouteMap");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsServiceRouteMapResponse response = new OdsServiceRouteMapResponse();
		
		try {
			List<OdsServiceRouterMapDetails> odsSvcRoutMapResp =  odsServiceRouteMapService.getServiceRouteMapRecords(request);
			
			if(null == odsSvcRoutMapResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsServiceRouteMapList(odsSvcRoutMapResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting getServiceRouteMap");
			
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Delete Service Route Map Details", notes = "Delete Service Route Map Details", response = OdsServiceRouteMapResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Delete ServiceRouteMap record", response = OdsServiceRouteMapResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Delete ServiceRouteMap Service is unavaialble") })
	public ResponseEntity<OdsServiceRouteMapResponse> deleteServiceRouteMap(@RequestBody List<OdsServiceRouterMapDetails> request)
														throws ApplicationException {
		
		LOGGER.info("Entering deleteServiceRouteMap");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsServiceRouteMapResponse response = new OdsServiceRouteMapResponse();
		
		try {
			odsServiceRouteMapService.deleteServiceRouteMapRecord(request);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting deleteServiceRouteMap");

		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
}
