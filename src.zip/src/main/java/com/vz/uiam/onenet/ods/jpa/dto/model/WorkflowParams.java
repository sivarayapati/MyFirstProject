/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dto.model;

/**
 * @author Newt
 *
 */
public class WorkflowParams {
	private String flowNodeProcessName;
	private String flowNodeStepName;
	/**
	 * @return the flowNodeProcessName
	 */
	public String getFlowNodeProcessName() {
		return flowNodeProcessName;
	}
	/**
	 * @param flowNodeProcessName the flowNodeProcessName to set
	 */
	public void setFlowNodeProcessName(String flowNodeProcessName) {
		this.flowNodeProcessName = flowNodeProcessName;
	}
	/**
	 * @return the flowNodeStepName
	 */
	public String getFlowNodeStepName() {
		return flowNodeStepName;
	}
	/**
	 * @param flowNodeStepName the flowNodeStepName to set
	 */
	public void setFlowNodeStepName(String flowNodeStepName) {
		this.flowNodeStepName = flowNodeStepName;
	}
	
}
