/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The Data Model class for SERVICE_ROUTE_MAP_TABLE
 * @author Kiran
 *
 */
@Entity
@Table(name = "ods_workflow_fallout_config")
public class ResolveWorkflowFalloutConfig implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "workflow_stepname")
	private String workFlowStepName;
	
	

	@Column(name = "workflow_process_name")
	private String workFlowProcessName;

	public String getWorkFlowProcessName() {
		return workFlowProcessName;
	}

	public void setWorkFlowProcessName(String workFlowProcessName) {
		this.workFlowProcessName = workFlowProcessName;
	}

	@Column(name = "max_retry_counter")
	private int maxRetryCounter;

	@Column(name = "retry_interval")
	private int retryInterval;

	@Column(name = "workflow_fallout_error_code")
	private String workFlowFalloutErrorCode;
    
	@Column(name = "workflow_fallout_error_category")
	private String workFlowFalloutErrorCategory;
	public String getWorkFlowFalloutErrorCategory() {
		return workFlowFalloutErrorCategory;
	}

	public void setWorkFlowFalloutErrorCategory(String workFlowFalloutErrorCategory) {
		this.workFlowFalloutErrorCategory = workFlowFalloutErrorCategory;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the workFlowStepName
	 */
	public String getWorkFlowStepName() {
		return workFlowStepName;
	}

	/**
	 * @param workFlowStepName the workFlowStepName to set
	 */
	public void setWorkFlowStepName(String workFlowStepName) {
		this.workFlowStepName = workFlowStepName;
	}

	/**
	 * @return the workFlowStepRetryConfig
	 */
	public int getMaxRetryCounter() {
		return maxRetryCounter;
	}

	/**
	 * @param workFlowStepRetryConfig the workFlowStepRetryConfig to set
	 */
	public void setMaxRetryCounter(int workFlowStepRetryConfig) {
		this.maxRetryCounter = workFlowStepRetryConfig;
	}

	/**
	 * @return the workFlowStepRetryFrequency
	 */
	public int getRetryInterval() {
		return retryInterval;
	}

	/**
	 * @param workFlowStepRetryFrequency the workFlowStepRetryFrequency to set
	 */
	public void setRetryInterval(int workFlowStepRetryFrequency) {
		this.retryInterval = workFlowStepRetryFrequency;
	}

	/**
	 * @return the workFlowFalloutErrorCode
	 */
	public String getWorkFlowFalloutErrorCode() {
		return workFlowFalloutErrorCode;
	}

	/**
	 * @param workFlowFalloutErrorCode the workFlowFalloutErrorCode to set
	 */
	public void setWorkFlowFalloutErrorCode(String workFlowFalloutErrorCode) {
		this.workFlowFalloutErrorCode = workFlowFalloutErrorCode;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
	
}