package com.vz.uiam.onenet.ods.jpa.dao.repository;

import java.util.List;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import java.lang.String;


@Transactional
@Repository
public interface OdsParamConfigRepository extends JpaRepository<OdsParamConfig, Integer> {
	
	@Cacheable(value="odsParams", key="#p0.concat('|').concat(#p1).concat('|').concat(#p2)", unless="#result == null", condition="#p0!=null && #p1!=null && #p2!=null")
	public OdsParamConfig findByParamKeyAndTypeAndName(String paramKey, String type, String name);
	
	public List<OdsParamConfig> findByParamKeyAndTypeAndNameIn(String key, String type, List<String> names);
	
	@Cacheable(value="odsParams", key="#p0.concat('|').concat(#p1)", unless="#result == null", condition="#p0!=null && #p1!=null")
	public List<OdsParamConfig> findByParamKeyAndType(String paramKey, String type);
	
	@Cacheable(value="odsParams", key="#p0", unless="#result == null", condition="#p0!=null")
	public List<OdsParamConfig> findByParamKey(String paramkey);	
	
	@Caching(evict = {
			  @CacheEvict(value = "odsParams", key="#p0.paramKey", condition="#p0.paramKey!=null"),
			  @CacheEvict(value = "odsParams", key="#p0.paramKey.concat('|').concat(#p0.type)", condition="#p0.paramKey!=null && #p0.type!=null"),
			  @CacheEvict(value = "odsParams", key="#p0.paramKey.concat('|').concat(#p0.type).concat('|').concat(#p0.name)", condition="#p0.paramKey!=null && #p0.type!=null && #p0.name!=null")
			})
	public OdsParamConfig save(OdsParamConfig odsParamConfig);	
	
}
