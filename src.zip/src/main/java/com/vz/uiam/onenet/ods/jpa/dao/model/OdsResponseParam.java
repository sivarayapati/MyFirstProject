/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dao.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The Data Model class for SERVICE_ROUTE_MAP_TABLE
 * 
 * @author Anand
 *
 */
@Entity
@Table(name = "ods_response_param_map")
public class OdsResponseParam implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "key")
	private String key;

	@Column(name = "response_param")
	private String responseParam;

	@Column(name = "document_param")
	private String documentParam;

	
	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * @return the responseParam
	 */
	public String getResponseParam() {
		return responseParam;
	}

	/**
	 * @param responseParam the responseParam to set
	 */
	public void setResponseParam(String responseParam) {
		this.responseParam = responseParam;
	}

	/**
	 * @return the documentParam
	 */
	public String getDocumentParam() {
		return documentParam;
	}

	/**
	 * @param documentParam the documentParam to set
	 */
	public void setDocumentParam(String documentParam) {
		this.documentParam = documentParam;
	}

	
	/**
	 * @param key
	 * @param responseParam
	 * @param documentParam
	 */
	public OdsResponseParam(String key, String responseParam, String documentParam) {
		this.key = key;
		this.responseParam = responseParam;
		this.documentParam = documentParam;
	}

	/**
	 * 
	 */
	public OdsResponseParam() {
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
