package com.vz.uiam.onenet.ods.jpa.dto.model;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author Kiran
 *
 */
public class ResolveHandleFalloutRequest {

	private String caseId;
	private String stepName;
	private String errorCode;
	private String processName;
	private String rootCaseId;
	
	public String getRootCaseId() {
		return rootCaseId;
	}

	public void setRootCaseId(String rootCaseId) {
		this.rootCaseId = rootCaseId;
	}

	public String getCaseId() {
		return caseId;
	}
	
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	
	public String getStepName() {
		return stepName;
	}
	
	public void setStepName(String stepName) {
		this.stepName = stepName;
	}
	
	public String getErrorCode() {
		return errorCode;
	}
	
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}