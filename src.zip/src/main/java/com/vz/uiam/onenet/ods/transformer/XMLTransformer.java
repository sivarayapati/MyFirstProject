package com.vz.uiam.onenet.ods.transformer;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.stereotype.Service;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;



@Service
public class XMLTransformer implements com.vz.uiam.onenet.ods.transformer.Transformer {
	
	private static final Logger LOGGER = Logger.getLogger(XMLTransformer.class);

	@Override
	public Object doTransform(Object inputDocument, Object requestSchema) throws ApplicationException {
		LOGGER.info("Entering doTransform");
		
		String transformedXml = null;
		
		try {
			String xmlStr = "";
			if(inputDocument instanceof JSONObject) {
				JSONObject inputDoc = (JSONObject) inputDocument;
				/*
				 * since an XML can have only one root tag, add our entire json in a
				 * parent json object before converting to XML
				 */
				JSONObject parentJsonObj = new JSONObject();
				parentJsonObj.put(Constants.ONE_DISPATCHER_ROOT_TAG, inputDoc);
				
				// Convert final JSON to XML
				xmlStr = XML.toString(parentJsonObj);
			} else if(inputDocument instanceof String) {
				xmlStr = (String) inputDocument;
			} 
			String xsltSchema = (String) requestSchema;
			
			LOGGER.info("JSON to xml is : " + xmlStr);	
			
			
			// Create an instance of the TransformerFactory
			TransformerFactory transfomerFactory = new net.sf.saxon.TransformerFactoryImpl();
			Source stylesheetSource = new StreamSource(new StringReader(xsltSchema));
			Transformer transformer = transfomerFactory.newTransformer(stylesheetSource);
			//OMIT_XML_DECLARATION in the XmlTransformation Response
			transformer.setOutputProperty(Constants.OMIT_XML_DECLARATION, "yes");
			/*
			 * An object to hold the results. It can be a file. In This example,
			 * we output to console.
			 */
			StringWriter writer = new StringWriter();
			Source inputSource = new StreamSource(new StringReader(xmlStr));
			transformer.transform(inputSource, new StreamResult(writer));

			transformedXml = writer.toString();
			
		} catch (Exception e) {
			LOGGER.error("Error occured while doing XSLT Transformation - ", e);
			throw new ApplicationException(StatusCode.INTERNAL_ERROR.getCode(), "Error occured while performing XSLT Transformation.");
		} /* end try */
		
		LOGGER.info("Exiting doTransform");
		return transformedXml;
	}

}
