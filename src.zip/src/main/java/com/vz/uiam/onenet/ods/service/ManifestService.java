package com.vz.uiam.onenet.ods.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@Service
public class ManifestService {
	/**
	 * Logger object.
	 */
	private static final Logger LOGGER = Logger.getLogger(ManifestService.class);
	
	@Autowired
	OdsMandatoryAttrsService odsMandatoryAttrsService;
	
	@Autowired
	OdsParamConfigRepository odsParamConfigRepo;
	
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	ServiceUtils serviceUtils;
	
	public JSONObject fetchManifestRequestPayload(JSONObject workflowRequest)
			throws ApplicationException {
		LOGGER.info("Entering fetchManifestDocument");
		
		String appKey = workflowRequest.getString(Constants.MANIFEST_APP_KEY_STR);
		odsMandatoryAttrsService.validateManifestAttributes(appKey);
		List<OdsMandatoryAttributes> odsMandatoryAttributesList = odsMandatoryAttrsService
				.getMandatoryAttributeList(appKey);
		JSONArray manifestEntityAttributesArray = buildManifestEntityAttributesArray(workflowRequest,
				odsMandatoryAttributesList);
		JSONObject manifestRequestPayload = buildManifestPayload(appKey, manifestEntityAttributesArray);
		LOGGER.info("Exiting fetchManifestDocument");
		return manifestRequestPayload;
	}

	/**
	 * Method to build the Manifest attributes JSON Array.
	 * 
	 * @param JSONObject
	 *            workflowRequest
	 * @param List<OdsMandatoryAttributes>
	 *            odsMandatoryAttributesList
	 * @return JSONArray
	 * @throws ODSRequestValidationException
	 */
	private JSONArray buildManifestEntityAttributesArray(JSONObject workflowRequest,
			List<OdsMandatoryAttributes> odsMandatoryAttributesList) throws ApplicationException {
		JSONArray odsManifestAttributesArray = new JSONArray();
		String workflowRequestString = workflowRequest.toString();
		for (OdsMandatoryAttributes odsMandatoryAttribute : odsMandatoryAttributesList) {
			String jsonPath = odsMandatoryAttribute.getJsonPath();
			Object objectValues = null;
			try {
				objectValues = JsonPath.read(workflowRequestString, jsonPath);
			} catch (PathNotFoundException ex) {
				LOGGER.error(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc(), ex);
				throw new ApplicationException(
						StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getCode(),
						StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
			}
			if (objectValues != null) {
				String stringValues = String.valueOf(objectValues);
				if (StringUtils.isEmpty(stringValues.trim())) {
					LOGGER.error(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NULL.getDesc());
					throw new ApplicationException(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NULL.getCode(),
							StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NULL.getDesc());
				} else {
					// Build Manifest Attribute List
					String[] keyStr = jsonPath.split(Constants.SPLIT_STRING_BY_PERIOD_EXPRESSION);
					JSONObject attributes = new JSONObject();
					attributes.put(Constants.MANIFEST_NAME_KEY_STR, keyStr[2]);
					attributes.put(Constants.MANIFEST_VALUE_KEY_STR, stringValues);
					odsManifestAttributesArray.put(attributes);
				}
			} else {
				LOGGER.error(StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
				throw new ApplicationException(
						StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getCode(),
						StatusCode.ERROR_MANDATORY_MANIFEST_ATTRIBS_NOTCONFGIURED.getDesc());
			}
		}
		return odsManifestAttributesArray;
	}
	
	
	/**
	 * API to get the manifest document, after updating the document name in the getManifest payload
	 * 
	 * @param manifestReqPayload
	 * @param manifestDocumentNames
	 * @return String
	 * @throws ApplicationException
	 */
	public JSONObject buildManifestDocument(JSONObject manifestReqPayload, String manifestDocumentNames)
			throws ApplicationException {
		LOGGER.info("Entering buildManifestDocument");

		JSONObject manifestDoc = new JSONObject();

		String[] manifestDocumentNameArry = manifestDocumentNames.split(Constants.MANIFEST_DOCUMENT_NAME_SPLITTER);
		for (String manifestDocumentName : manifestDocumentNameArry) {
			JSONObject documentPayload = new JSONObject();
			JSONObject manifestPayload = null;
			if (manifestDocumentName.startsWith(Constants.METADATA_KEY)) {
				manifestPayload = buildManifestPayloadForAdminDocuments(manifestReqPayload);
				String[] tokens = manifestDocumentName.split("\\.");
				manifestDocumentName = tokens[1];
			} else {
				manifestPayload = manifestReqPayload;
			}
			String populatedDocPayloadStr = populateDocumentNameAndGetManifest(manifestPayload, manifestDocumentName);
			documentPayload = new JSONObject(populatedDocPayloadStr);
			manifestDoc.put(manifestDocumentName, documentPayload);
		}

		LOGGER.info("Exiting buildManifestDocument");

		return manifestDoc;
	}
	
	/**
	 * Method to 
	 *
	 * @param appKey
	 * @throws ApplicationException
	 */
	private JSONObject buildManifestPayloadForAdminDocuments(JSONObject manifestReqPayload)
			throws ApplicationException {
		JSONObject entityDataJSONObject = manifestReqPayload.getJSONObject(Constants.ENTITY_DATA_STR);
		String appKey = entityDataJSONObject.getString(Constants.MANIFEST_APP_KEY_STR);
		
		JSONArray manifestAttributesArray = new JSONArray();
		JSONObject attributes = new JSONObject();
		attributes.put(Constants.MANIFEST_NAME_KEY_STR, Constants.APPLICATION_KEY);
		attributes.put(Constants.MANIFEST_VALUE_KEY_STR, appKey);
		manifestAttributesArray.put(attributes);
		attributes = new JSONObject();
		attributes.put(Constants.MANIFEST_NAME_KEY_STR, Constants.DATA_TYPE);
		attributes.put(Constants.MANIFEST_VALUE_KEY_STR, Constants.METADATA);
		manifestAttributesArray.put(attributes);
		attributes = new JSONObject();
		attributes.put(Constants.MANIFEST_NAME_KEY_STR, Constants.DOCUMENT_LEVEL);
		attributes.put(Constants.MANIFEST_VALUE_KEY_STR, Constants.GLOBAL);
		manifestAttributesArray.put(attributes);
			
		// Prepare Manifest Get Request
		JSONObject entityData = buildManifestPayload(Constants.METADATA_APP_KEY, manifestAttributesArray);

		return entityData;
	}
	
	/**
	 * @param appKey
	 * @param manifestAttributesArray
	 * @return JSONObject
	 * @throws JSONException
	 */
	public JSONObject buildManifestPayload(String appKey, JSONArray manifestAttributesArray) throws JSONException {
		JSONObject entityData = new JSONObject();
		JSONObject valueMap = new JSONObject();
		JSONObject attributesMap = new JSONObject();

		attributesMap.put(Constants.MANIFEST_ATTRIBUTE_STR, manifestAttributesArray);
		valueMap.put(Constants.MANIFEST_ENTITY_ATTRIBUTES_STR, attributesMap);
		valueMap.put(Constants.MANIFEST_APP_KEY_STR, appKey);
		entityData.put(Constants.ENTITY_DATA_STR, valueMap);

		return entityData;
	}
	
	/**
	 * @param manfiestPayload
	 * @param manifestDocumentName
	 * @return
	 * @throws ApplicationException
	 */
	private String populateDocumentNameAndGetManifest(JSONObject manifestPayload, String manifestDocumentName)
			throws ApplicationException {
		manifestPayload.getJSONObject(Constants.ENTITY_DATA_STR).put(Constants.MANIFEST_DOCUMENT_NAME_STR,
				manifestDocumentName);

		String manifestResp = getManifestDocument(manifestPayload.toString());
		JSONObject manfiestRespJson = new JSONObject(manifestResp);
		JSONObject documentPayload = new JSONObject();
		documentPayload.put(Constants.MANIFEST_DOCUMENT_PAYLOAD_STR,
				manfiestRespJson.getJSONObject(Constants.MANIFEST_DOCUMENT_PAYLOAD_STR));
		
		return documentPayload.toString();
	}
	
	/**
	 * API to get the manifest document
	 * 
	 * @param manifestReqPayload
	 * @return String
	 * @throws ApplicationException
	 */
	public String getManifestDocument(String manifestReqPayload) throws ApplicationException {
		LOGGER.info("Entering getManifestDocument");

		/* Get MANIFEST_GET_SERVICE_URL from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.GET_MANIFEST_ENDPOINT_URL);
		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(), OdsParamConfigType.ODS_PARAM.toString(),
							Constants.GET_MANIFEST_ENDPOINT_URL, null));
		LOGGER.info("Manifest GET URL : " + odsAppParam.getValue());
		LOGGER.info("Manifest Request Payload : "+manifestReqPayload);

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(manifestReqPayload, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = null;

		try {
			responseEntity = restTemplate.exchange(odsAppParam.getValue(), HttpMethod.POST, httpEntity, String.class);
		} catch (Exception e) {
			LOGGER.error("Error while calling Manifest GET Service", e);
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Error while calling Manifest GET Service. ");
		}

		String manifestResponse;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			manifestResponse = responseEntity.getBody();
			if (StringUtils.isEmpty(manifestResponse)) {
				LOGGER.error(StatusCode.MANIFEST_RESPONSE_IS_NULL.getDesc());
				throw new ApplicationException(StatusCode.MANIFEST_RESPONSE_IS_NULL.getCode(),
						StatusCode.MANIFEST_RESPONSE_IS_NULL.getDesc());
			}
			else{
				JSONObject responseJson = new JSONObject(manifestResponse);
				if(Constants.MANIFEST_DOC_NOT_FOUND_CODE.equals(((JSONObject) responseJson.get("status")).get("code"))){
					responseJson.put(Constants.MANIFEST_DOCPAYLOAD_KEY, new JSONObject());
					LOGGER.error("Document not found in Manifest. Returning "+responseJson.toString());
					return responseJson.toString();
				}
			}
		} else {
			LOGGER.error("Error Received failure response from Manifest GET Service");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Received failure response from Manifest GET Service");
		}
		LOGGER.info("Exiting getManifestDocument");
		return manifestResponse;
	}
	
	/**
	 * API to create or Update the Document in manifest
	 *
	 * @param manifestBuildPayload
	 * @throws ApplicationException
	 */
	public void createOrUpdateManifestDoc(String manifestBuildPayload) throws ApplicationException {
		LOGGER.info("Entering createOrUpdateManifestDoc");
		LOGGER.info("Updating Manifest with Payload :"+manifestBuildPayload);
		/* Get MANIFEST_GET_SERVICE_URL from App Param table */
		OdsParamConfig odsAppParam = odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.BUILD_MANIFEST_ENDPOINT_URL);
		if (odsAppParam == null || StringUtils.isEmpty(odsAppParam.getValue()))
			throw new ApplicationException(StatusCode.DATA_NOT_FOUND.getCode(),
					serviceUtils.prepareOdsParamErrorMsg(OdsParamConfigType.ODS.toString(), OdsParamConfigType.ODS_PARAM.toString(),
							Constants.BUILD_MANIFEST_ENDPOINT_URL, null));
		LOGGER.info("Manifest Build URL : " + odsAppParam.getValue());

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> httpEntity = new HttpEntity<>(manifestBuildPayload, httpHeaders);

		/* call the service */
		ResponseEntity<String> responseEntity = serviceUtils.callService(odsAppParam, httpEntity);

		String manifestResponse;
		if (responseEntity != null && responseEntity.getStatusCode() == HttpStatus.OK) {
			manifestResponse = responseEntity.getBody();
			if (StringUtils.isEmpty(manifestResponse)) {
				LOGGER.error(StatusCode.MANIFEST_RESPONSE_IS_NULL.getDesc());
				throw new ApplicationException(StatusCode.MANIFEST_RESPONSE_IS_NULL.getCode(),
						StatusCode.MANIFEST_RESPONSE_IS_NULL.getDesc());
			}
		} else {
			LOGGER.error("Error during creating/updating the manifest document");
			throw new ApplicationException(StatusCode.HTTP_ERROR.getCode(),
					"Error during creating/updating the manifest document");
		}
		LOGGER.info("Manifest Response :"+manifestResponse);
		LOGGER.info("Exiting createOrUpdateManifestDoc");
	}


}
