/**
 * 
 */
package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.io.Serializable;

/**
 * @author Anand
 *
 */
public class WorkflowParam implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String paramName;
	private String paramValue;
	/**
	 * @return the paramName
	 */
	public String getParamName() {
		return paramName;
	}
	/**
	 * @param paramName the paramName to set
	 */
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	/**
	 * @return the paramValue
	 */
	public String getParamValue() {
		return paramValue;
	}
	/**
	 * @param paramValue the paramValue to set
	 */
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WorkflowParam [paramName=" + paramName + ", paramValue=" + paramValue + "]";
	}
	public WorkflowParam() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param paramName
	 * @param paramValue
	 */
	public WorkflowParam(String paramName, String paramValue) {
		super();
		this.paramName = paramName;
		this.paramValue = paramValue;
	}
	
}
