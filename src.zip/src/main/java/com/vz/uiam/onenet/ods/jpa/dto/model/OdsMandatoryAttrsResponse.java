package com.vz.uiam.onenet.ods.jpa.dto.model;

import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;


/**
 * @author Ashish Goyal
 *
 */
@JsonInclude(Include.NON_NULL)
public class OdsMandatoryAttrsResponse {

	private String statusCode;
	private String statusDesc;
	private OdsMandatoryAttributes odsMandatoryAttributes;
	private List<OdsMandatoryAttributes> odsMandatoryAttributesList;
	
	
	public String getStatusCode() {
		return statusCode;
	}
	
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	public String getStatusDesc() {
		return statusDesc;
	}
	
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	
	public OdsMandatoryAttributes getOdsMandatoryAttributes() {
		return odsMandatoryAttributes;
	}
	
	public void setOdsMandatoryAttributes(OdsMandatoryAttributes odsMandatoryAttributes) {
		this.odsMandatoryAttributes = odsMandatoryAttributes;
	}
	
	public List<OdsMandatoryAttributes> getOdsMandatoryAttributesList() {
		return odsMandatoryAttributesList;
	}
	
	public void setOdsMandatoryAttributesList(List<OdsMandatoryAttributes> odsMandatoryAttributesList) {
		this.odsMandatoryAttributesList = odsMandatoryAttributesList;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this); 
	}
}
