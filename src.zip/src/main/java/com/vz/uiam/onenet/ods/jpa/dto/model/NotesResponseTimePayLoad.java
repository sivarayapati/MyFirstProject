package com.vz.uiam.onenet.ods.jpa.dto.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class NotesResponseTimePayLoad {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String Response;
	private String DateTime;
	
	public String getResponse() {
		return Response;
	}
	public void setResponse(String response) {
		Response = response;
	}
	public String getDateTime() {
		return DateTime;
	}
	public void setDateTime(String dateTime) {
		DateTime = dateTime;
	}
	public NotesResponseTimePayLoad(String response, String dateTime) {
		super();
		Response = response;
		DateTime = dateTime;
	}
	
	
}
