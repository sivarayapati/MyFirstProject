package com.vz.uiam.onenet.ods.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsMandatoryAttrsResponse;
import com.vz.uiam.onenet.ods.service.OdsMandatoryAttrsService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


/**
 * @author Ashish Goyal
 *
 */
@RestController
@RequestMapping("/oneDispatcher/odsMandatoryAttrs")
public class ODSMandatoryAttrsController {

	private static final Logger LOGGER = Logger.getLogger(ODSMandatoryAttrsController.class);
	
	@Autowired
	OdsMandatoryAttrsService odsMandatoryAttrsService;
	
	
	@RequestMapping(value = "/createOrUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Create or Update a record in OdsMandatoryAttributes", notes = "Create or Update a record in OdsMandatoryAttributes", response = OdsMandatoryAttrsResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Created or Updated OdsMandatoryAttributes record", response = OdsMandatoryAttrsResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "createOrUpdate OdsMandatoryAttributes Service is unavaialble") })
	public ResponseEntity<OdsMandatoryAttrsResponse> createOrUpdateOdsMandatoryAttrs(@RequestBody OdsMandatoryAttributes request)
														throws ApplicationException {
		
		LOGGER.info("Entering createOrUpdateOdsMandatoryAttrs");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsMandatoryAttrsResponse response = new OdsMandatoryAttrsResponse();
		
		try {
			OdsMandatoryAttributes odsMandatoryAttrsResp =  odsMandatoryAttrsService.createOrUpdateOdsMandatoryAttrs(request);
			
			if(null == odsMandatoryAttrsResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsMandatoryAttributes(odsMandatoryAttrsResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting createOrUpdateOdsMandatoryAttrs");

		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/get", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Get OdsMandatoryAttributes Details", notes = "Get OdsMandatoryAttributes Details", response = OdsMandatoryAttrsResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved OdsMandatoryAttributes records", response = OdsMandatoryAttrsResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "get OdsMandatoryAttributes Service is unavaialble") })
	public ResponseEntity<OdsMandatoryAttrsResponse> getOdsMandatoryAttrs(@RequestBody OdsMandatoryAttributes request)
														throws ApplicationException {
		
		LOGGER.info("Entering getOdsMandatoryAttrs");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsMandatoryAttrsResponse response = new OdsMandatoryAttrsResponse();
		
		try {
			List<OdsMandatoryAttributes> odsMandatoryAttrsResp =  odsMandatoryAttrsService.getMandatoryAttributeList(request.getAttrKey());
			
			if(null == odsMandatoryAttrsResp) {
				statusCode = StatusCode.APP_ERROR.getCode();
				statusMsg = StatusCode.APP_ERROR.getDesc();
			}
			
			response.setOdsMandatoryAttributesList(odsMandatoryAttrsResp);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting getOdsMandatoryAttrs");

		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/delete", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value = "Delete OdsMandatoryAttributes Details", notes = "Delete OdsMandatoryAttributes Details", response = OdsMandatoryAttrsResponse.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully Delete OdsMandatoryAttributes record", response = OdsMandatoryAttrsResponse.class),
			@ApiResponse(code = 400, message = "Invalid input provided"),
			@ApiResponse(code = 404, message = "Delete OdsMandatoryAttributes Service is unavaialble") })
	public ResponseEntity<OdsMandatoryAttrsResponse> deleteOdsMandatoryAttrs(@RequestBody List<OdsMandatoryAttributes> request)
														throws ApplicationException {
		
		LOGGER.info("Entering deleteOdsMandatoryAttrs");
		
		String statusCode = StatusCode.SUCCESS.getCode();
		String statusMsg = StatusCode.SUCCESS.getDesc();
		
		OdsMandatoryAttrsResponse response = new OdsMandatoryAttrsResponse();
		
		try {
			odsMandatoryAttrsService.deleteOdsMandatoryAttrsRecord(request);
		} catch (ApplicationException e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode = e.getErrCode();
			statusMsg = e.getMessage();
		} catch (Exception e) {
			LOGGER.error("Exception Occurred - ", e);
			statusCode =  StatusCode.APP_ERROR.getCode();
			statusMsg = e.getMessage();
		}

		response.setStatusCode(statusCode);
		response.setStatusDesc(statusMsg);
		
		LOGGER.info("Exiting deleteOdsMandatoryAttrs");
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(Constants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}
}
