/**
 *
 */
package com.vz.uiam.onenet.ods.jpa.dao.repository;


import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFallout;

/**
 * @author Anand
 *
 */
@Transactional
@Repository
public interface WorkflowFalloutRepo extends JpaRepository<WorkflowFallout, Integer> {
	static final long serialVersionUID = 1L;

	/**
	 * @param status
	 * @param errorCode
	 * @return WorkflowFallout
	 */
	public WorkflowFallout getByStatusOrWorkFlowFalloutErrorCode(String status, String errorCode);

	/**
	 * @param caseId
	 * @param WorkFlowStepName
	 * @param FlowFalloutErrorCode
	 * @param status
	 * @return WorkflowFallout
	 */
	public WorkflowFallout getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(String caseId,
			String WorkFlowStepName, String FlowFalloutErrorCode, String status);

	/**
	 * @param caseId
	 * @param workFlowStepName
	 * @param workFlowProcessName
	 * @param workFlowFalloutErrorCode
	 * @param status
	 * @return WorkflowFallout
	 */
	public WorkflowFallout getByCaseIdAndWorkFlowProcessNameAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(
			String caseId, String workFlowProcessName, String workFlowStepName, String workFlowFalloutErrorCode,
			String status);

	/**
	 * @param caseId
	 * @param workFlowStepName
	 * @param workFlowFalloutErrorCode
	 * @param workFlowProcessName
	 * @return WorkflowFallout
	 */
	public WorkflowFallout getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndWorkFlowProcessName(
			String caseId, String workFlowStepName, String workFlowFalloutErrorCode, String workFlowProcessName);

	/**
	 * @param caseId
	 * @param workFlowStepName
	 * @param status
	 * @return WorkflowFallout
	 */
	public WorkflowFallout getByStatusAndCaseIdAndWorkFlowStepName(String status, String caseId,
			String workFlowStepName);
	
	/**
	 * @param rootCaseId
	 * @param status
	 * @return expiryTime
	 */
	public List<WorkflowFallout> getByRootCaseIdAndStatusAndExpiryTimeIsNotNull(String rootCaseId, String status);
	
	public List<WorkflowFallout> getByStatusAndExpiryTimeBefore(String status, Timestamp currentTime);
	
	public List<WorkflowFallout> getByStatusAndWfTaskId(String status, String wfTaskId);
	
	

}
