use ng_orchestration;

delete from ods_request_log where wf_task_id='1234' ;


commit;