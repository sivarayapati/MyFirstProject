use ng_orchestration;

INSERT INTO ods_param_config
(param_key,
type,
name,
value)
VALUES
('Test-param_key',
'JSON',
'Test-Name',
'Test-Value');


INSERT INTO ods_param_config
(param_key,
type,
name,
value)
VALUES
('Test11_TestOneDispatcher',
'NOTES_PARAM',
'region',
'$.seedInfo.region');

INSERT INTO ods_param_config
(param_key,
type,
name,
value)
VALUES
('Test111_TestOneDispatcher',
'DATA_SERVICE_REQUEST',
'dataServiceRequestUrl',
'http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxy/ManifestGetProxy');

INSERT INTO ods_param_config
(param_key,
type,
name,
value)
VALUES
('LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber',
'RESPONSE_STATUS_PARAM',
'STATUS_CODE_SCHEMA',
'$.nbaTransaction.statuscode');

INSERT INTO ods_param_config
(param_key,
type,
name,
value)
VALUES
(
'LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber',
'RESPONSE_PARAM',
'$.nbaTransaction.requests.groups.trails.attribute[?(@.name == ''UNLOCKED_ONTS'')]',
'$.document-payload.ontSerialNum');

INSERT INTO ods_param_config
(param_key,
type,
name,
value)
VALUES
(
'LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber',
'RESPONSE_STATUS_PARAM',
'STATUS_CODE_SUCCESS_VALUE',
'V0000');

INSERT INTO ods_param_config
(param_key,
type,
name,
value)
VALUES
(
'ZZZDE-NGPON2',
'WORKFLOW_PARAM',
'OntSerialNo',
'$.nbaTransaction.requests.groups.trails.attribute[?(@.name == ''TRANSACTION_ID'')]');

INSERT INTO ods_param_config
(param_key,
type,
name,
value)
VALUES
(
'LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber_test',
'RESPONSE_STATUS_PARAM',
'STATUS_CODE_SUCCESS_VALUE',
'0');

INSERT INTO ods_param_config
(param_key,
type,
name,
value)
VALUES
(
'LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber',
'NOTES_PARAM',
'orderNumber',
'$.requestPayload.seedInfo.order_number');

INSERT INTO ods_param_config
(param_key,
type,
name,
value)
VALUES
('Test11_TestOneDispatcher',
'DATA_SERVICE_REQUEST',
'dataServiceRequestUrl',
'http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxy/ManifestGetProxy');


commit;