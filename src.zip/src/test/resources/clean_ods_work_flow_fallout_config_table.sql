use ng_orchestration;

delete from ods_workflow_fallout_config where workflow_process_name='process123' and workflow_stepname='test1';
delete from ods_workflow_fallout_config where workflow_process_name='LCI_OVER_NGPON2_Pre_Activation_Test' and workflow_stepname='AddONT_Test' ;
delete from ods_workflow_fallout_config where workflow_process_name='process123' and workflow_stepname='step1' ;

commit;