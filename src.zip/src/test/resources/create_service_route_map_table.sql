use ng_orchestration;
INSERT INTO ods_service_route_map
(flow_node_process_name,
flow_node_step_name,
target_end_point_url,
request_document_name,
request_schema,
response_document_name,
transformation_type,
route_protocol,app_key)
VALUES
('Test1',
'TestOneDispatcher',
'http://1111.11.11.11/',
'{"A":"B"}',
'Test-Message',
'JSON',
'JSON',
'REST','Test1_TestOneDispatcher');


INSERT INTO ods_service_route_map
(flow_node_process_name,
flow_node_step_name,
target_end_point_url,
request_document_name,
request_schema,
response_document_name,
transformation_type,
route_protocol,app_key,username,password)
VALUES
('Test11',
'TestOneDispatcher',
'http://1111.11.11.11/',
'Test-Message',
'',
'JSON',
'',
'REST','Test11_TestOneDispatcher','test','dGVzdA==');


INSERT INTO ods_service_route_map
(flow_node_process_name,
flow_node_step_name,
target_end_point_url,
request_document_name,
request_schema,
response_document_name,
transformation_type,
route_protocol,app_key,username,password)
VALUES
('Test111',
'TestOneDispatcher',
'http://1111.11.11.11/',
'{"A":"B"}',
'Test-Message',
'JSON',
'JSON',
'REST','Test1_TestOneDispatcher','test','dGVzdA==');

INSERT INTO ods_service_route_map
(flow_node_process_name,
flow_node_step_name,
target_end_point_url,
request_document_name,
request_schema,
response_document_name,
transformation_type,
route_protocol,app_key,username,password)
VALUES
('LCI_OVER_NGPON2_Pre_Activation',
'AddONT',
'http://1111.11.11.11/',
'{"A":"B"}',
'Test-Message',
'JSON',
'JSON',
'REST','LCI_OVER_NGPON2_Pre_Activation_AddONT','test','dGVzdA==');

INSERT INTO ods_service_route_map
(flow_node_process_name,
flow_node_step_name,
target_end_point_url,
request_document_name,
request_schema,
response_document_name,
transformation_type,
route_protocol,app_key)
VALUES
('Test246',
'TestOneDispatcher',
'',
'Test-Message',
'{"A":"B"}',
'JSON',
'JSON',
'REST','Test246_TestOneDispatcher');

INSERT INTO ods_service_route_map
(flow_node_process_name,
flow_node_step_name,
target_end_point_url,
request_document_name,
request_schema,
response_document_name,
transformation_type,
route_protocol,app_key)
VALUES
('Test247',
'TestOneDispatcher',
'http://1111.11.11.11/',
'',
'{"A":"B"}',
'JSON',
'JSON',
'REST','Test247_TestOneDispatcher');

INSERT INTO ods_service_route_map
(flow_node_process_name,
flow_node_step_name,
target_end_point_url,
request_document_name,
request_schema,
response_document_name,
transformation_type,
route_protocol,app_key)
VALUES
('Test248',
'TestOneDispatcher',
'http://1111.11.11.11/',
'TestMessage',
'{"A":"B"}',
'JSON',
'JSON',
'REST','');

INSERT INTO ods_service_route_map
(id,flow_node_process_name,
flow_node_step_name,
target_end_point_url,
request_document_name,
request_schema,
response_document_name,
transformation_type,
route_protocol,app_key,send_milestone_enabled)
VALUES
(222,'Test255',
'TestOneDispatcher',
'http://1111.11.11.11/',
'TestMessage',
'{"A":"B"}',
'JSON',
'JSON',
'','Test249_TestOneDispatcher','YES');



commit;