use ng_orchestration;

delete from ods_interface_request where transaction_id='000|1122DISCONNECT0023' ;
delete from ods_interface_request where transaction_id='119968815' ;

commit;