use ng_orchestration;

INSERT INTO ods_request_transaction_id_map
(flow_node_process_name,
flow_node_step_name,
transaction_id_key)
VALUES
('TestProcessName',
'TestFlowNodeStepName',
'TestTransactionIdKey');

INSERT INTO ods_request_transaction_id_map
(flow_node_process_name,
flow_node_step_name,
transaction_id_key)
VALUES
('Test11',
'TestOneDispatcher',
'TestTransactionIdKey');

INSERT INTO ods_request_transaction_id_map
(flow_node_process_name,
flow_node_step_name,
transaction_id_key)
VALUES
('Test111',
'TestOneDispatcher',
'TestTransactionIdKey');

INSERT INTO ods_request_transaction_id_map
(
flow_node_process_name,
flow_node_step_name,
transaction_id_key)
VALUES
(
'LCI_OVER_NGPON2_Pre_Activation_Test',
'AddONT_Test',
'TestTransactionIdKey');

INSERT INTO ods_request_transaction_id_map
(
flow_node_process_name,
flow_node_step_name,
transaction_id_key)
VALUES
(
'LCI_OVER_NGPON2_Pre_Activation',
'RetrieveONTSerialNumber',
'DEFAULT');
commit;