use ng_orchestration;

delete from ods_transformer_config where transformer_key='LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber';

delete from ods_transformer_config where transformer_key="Test_Transformation121";

delete from ods_transformer_config where transformer_key="Test_Transformation122";



commit;