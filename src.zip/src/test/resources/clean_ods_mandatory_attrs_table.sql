use ng_orchestration;

delete from ods_mandatory_attrs where attr_key='Test-ODS' ;
delete from ods_mandatory_attrs where attr_key='LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber' ;
delete from ods_mandatory_attrs where attr_key='LCI_OVER_NGPON2_Pre_Activation_Test_AddONT_Test' ;
commit;