use ng_orchestration;

delete from ods_workflow_fallout where CASE_ID="1234" ;

commit;

