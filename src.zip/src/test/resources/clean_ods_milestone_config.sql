use ng_orchestration;

delete from ods_milestone_config where target_end_point_url='http://test.com' ;

delete from ods_milestone_config where flow_node_process_name='Test11' and flow_node_step_name='TestOneDispatcher';
delete from ods_milestone_config where flow_node_process_name='Test1' and flow_node_step_name='TestOneDispatcher';


commit;