use ng_orchestration;

insert into tbl_wf_decision_params(
root_case_id,
wf_param_name,
wf_param_value)
values(
'100',
'JunitProcess1',
'Value1'
);


commit;