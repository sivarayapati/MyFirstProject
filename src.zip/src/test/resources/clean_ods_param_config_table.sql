use ng_orchestration;

delete from ods_param_config where param_key='Test-param_key' ;
delete from ods_param_config where param_key='Test11_TestOneDispatcher' ;
delete from ods_param_config where param_key='Test111_TestOneDispatcher' ;
delete from ods_param_config where param_key='LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber' and type='RESPONSE_STATUS_PARAM' ;
delete from ods_param_config where param_key='LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber' and type='RESPONSE_PARAM' ;
delete from ods_param_config where param_key='LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber_test' and type='RESPONSE_STATUS_PARAM' ;
delete from ods_param_config where param_key='ZZZDE-NGPON2' and type='WORKFLOW_PARAM' and name='OntSerialNo';
delete from ods_param_config where param_key='LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber' and type='NOTES_PARAM' ;

commit;