use ng_orchestration;

INSERT INTO ods_response_transaction_id_map
(root_tag_name,
transaction_id_key)
VALUES
('TestrootTagName',
'TestTransactionIdKeyUPD');


commit;