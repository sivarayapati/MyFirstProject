use ng_orchestration;

delete from tbl_wf_decision_params where root_case_id='100' and wf_param_name='JunitProcess1';

commit;