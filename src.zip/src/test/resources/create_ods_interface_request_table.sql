use ng_orchestration;

INSERT INTO ods_interface_request
(id,transaction_id, corelation_payload, manifest_payload, status, response_config_param,request_time)
VALUES
(0,
'000|1122DISCONNECT0023',
'{\"bonitaProcessName\":\"LCI_DATA_PROVISIONING\",\"bonitaMessageName\":\"odnProvRecieveMsg\",\"correlations\":{\"orderNumber\":\"11ROHANAND44422\",\"caseId\":\"769290\",\"orderVersion\":\"000\"},\"bonitaFlowNodeName\":\"ODN-Provisioning\"}',
'{\"entity-data\":{\"app-key\":\"ZZZDE-NGPON2\",\"entity-attributes\":{\"attribute\":[{\"name\":\"order_number\",\"value\":\"11ROHANAND44422\"},{\"name\":\"order_version\",\"value\":\"000\"},{\"name\":\"product_type\",\"value\":\"Data\"},{\"name\":\"region\",\"value\":\"NJ\"},{\"name\":\"supp_type\",\"value\":\"Pending\"}]}}}',
'REQUEST_PENDING',
'{ \"rootProcessName\" : null, \"flowNodeProcessName\" : \"LCI_DATA_PROVISIONING\", \"flowNodeStepName\" : \"ODN-Provisioning\", \"caseID\" : \"769290\", \"parentCaseID\" : \"769290\", \"rootCaseID\" : \"769290\", \"responseDocumentName\" : \"PlanningMessage\", \"transformationType\" : \"XML\", \"appKey\" : \"ZZZDE-NGPON2\" }',
'2018-01-16 23:10:39');

INSERT INTO ods_interface_request
(id,transaction_id, corelation_payload, manifest_payload, status, response_config_param,request_time)
VALUES
(0,
'119968815',
'{\"bonitaProcessName\":\"LCI_DATA_PROVISIONING\",\"bonitaMessageName\":\"odnProvRecieveMsg\",\"correlations\":{\"orderNumber\":\"11ROHANAND44422\",\"caseId\":\"769290\",\"orderVersion\":\"000\"},\"bonitaFlowNodeName\":\"ODN-Provisioning\"}',
'{\"entity-data\":{\"app-key\":\"ZZZDE-NGPON2\",\"entity-attributes\":{\"attribute\":[{\"name\":\"order_number\",\"value\":\"11ROHANAND44422\"},{\"name\":\"order_version\",\"value\":\"000\"},{\"name\":\"product_type\",\"value\":\"Data\"},{\"name\":\"region\",\"value\":\"NJ\"},{\"name\":\"supp_type\",\"value\":\"Pending\"}]}}}',
'REQUEST_PENDING',
'{ \"rootProcessName\" : null, \"flowNodeProcessName\" : \"LCI_DATA_PROVISIONING\", \"flowNodeStepName\" : \"ODN-Provisioning\", \"caseID\" : \"769290\", \"parentCaseID\" : \"769290\", \"rootCaseID\" : \"769290\", \"responseDocumentName\" : \"PlanningMessage\", \"transformationType\" : \"XML\", \"appKey\" : \"ZZZDE-NGPON2\" }',
'2018-01-16 23:10:39');

commit;