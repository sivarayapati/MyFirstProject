use ng_orchestration;

delete from ods_response_transaction_id_map where root_tag_name='TestrootTagName' ;



commit;