use ng_orchestration;

INSERT INTO ods_workflow_fallout_config
(
workflow_process_name,
workflow_stepname,
max_retry_counter,
retry_interval,
workflow_fallout_error_code
)
VALUES
(
'process123',
'test1',
2,
30,
'DEFAULT_ERROR_CODE');

INSERT INTO ods_workflow_fallout_config
(
workflow_process_name,
workflow_stepname,
max_retry_counter,
retry_interval,
workflow_fallout_error_code
)
VALUES
(
'LCI_OVER_NGPON2_Pre_Activation_Test',
'AddONT_Test',
2,
30,
'DEFAULT_ERROR_CODE');

INSERT INTO ods_workflow_fallout_config
(id,
workflow_process_name,
workflow_stepname,
max_retry_counter,
retry_interval,
workflow_fallout_error_code
)
VALUES
(100,
'process123',
'step1',
2,
30,
'DEFAULT_ERROR_CODE');


commit;