use ng_orchestration;

delete from ods_service_route_map where flow_node_step_name='TestOneDispatcher';
delete from ods_service_route_map where app_key='LCI_OVER_NGPON2_Pre_Activation_AddONT' and flow_node_process_name='LCI_OVER_NGPON2_Pre_Activation' and flow_node_step_name='AddONT';

commit;