use ng_orchestration;

Update ods_interface_request set status='REQUEST_PENDING'  where transaction_id='000|1122DISCONNECT0023';
Update ods_interface_request set status='REQUEST_PENDING'  where transaction_id='119968815';
Update ods_interface_request set status=''  where transaction_id='TestTransactionIdKey';
commit;