use ng_orchestration;

INSERT INTO ods_milestone_config
(ods_milestone_config_Id,
milestone_name,
destination_app_name,
target_end_point_url,
request_schema,
request_document_name,
transformation_type,
route_protocol,
send_milestone,
send_fallout_notification,
flow_node_process_name,
flow_node_step_name)
VALUES
(111,
'Milestone1',
'App1',
'http://test.com',
'{test:$.test}',
'TEST-Message',
'JSON',
'REST',
'YES',
'NO',
'Test1',
'TestOneDispatcher'
);

INSERT INTO ods_milestone_config
(ods_milestone_config_Id,
milestone_name,
destination_app_name,
target_end_point_url,
request_schema,
request_document_name,
transformation_type,
route_protocol,
send_milestone,
send_fallout_notification,
flow_node_process_name,
flow_node_step_name)
VALUES
(112,
'Milestone2',
'App2',
'http://test.com',
'{test:$.test}',
'TEST-Message',
'JSON',
'REST',
'YES',
'NO',
'Test11',
'TestOneDispatcher'
);

commit;