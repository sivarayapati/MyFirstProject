use ng_orchestration;

INSERT INTO ng_orchestration.ods_request_log
(
title,
title_version,
wf_task_id,
wf_task_name,
wf_request_payload,
wf_task_status,
response_status)
VALUES
(
'$.seedInfo.order_number',
'$.seedInfo.order_version',
'1234',
'CreateOrder',
'{"processInstanceId":"1522721","seedInfo":{"document_level":"VERSION","order_number":"30049573","order_version":"0"},"orderId":"30049573","app-key":"ZZZDE-VRD","rootProcessInstanceId":"1573557","activityInstanceId":"1522721","flowNodeProcessName":"LCI_DATA_CREATE_CLR","flowNodeStepName":"CreateOrder"}',
'PENDING',
'SUCCESS');

commit;