use ng_orchestration;

INSERT INTO ods_mandatory_attrs
(attr_key,
json_path)
VALUES
('Test-ODS','$.TestJosn.Test');

INSERT INTO ods_mandatory_attrs
(attr_key,
json_path)
VALUES
('LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber','$.requestPayload.seedInfo.region');

INSERT INTO ods_mandatory_attrs
(attr_key,
json_path)
VALUES
('Test111_TestOneDispatcher','$.TestJosn.Test');
commit;