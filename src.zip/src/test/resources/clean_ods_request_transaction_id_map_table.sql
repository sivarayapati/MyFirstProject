use ng_orchestration;

delete from ods_request_transaction_id_map where flow_node_process_name='TestProcessName' ;
delete from ods_request_transaction_id_map where flow_node_process_name='Test11' ;
delete from ods_request_transaction_id_map where flow_node_process_name='Test111' ;
delete from ods_request_transaction_id_map where flow_node_process_name='LCI_OVER_NGPON2_Pre_Activation_Test' ;
delete from ods_request_transaction_id_map where flow_node_process_name='LCI_OVER_NGPON2_Pre_Activation' ;


commit;