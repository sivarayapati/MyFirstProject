use ng_orchestration;

INSERT INTO ng_orchestration.ods_milestone_transaction
(ods_milestone_transaction_id,
root_case_id,
process_name,
step_name,
ods_milestone_config_Id,
request_payload,
status,
status_desc,
manifest_payload
)
VALUES
(111,
'TestRoot1234',
'Test1',
'TestOneDispatcher',
111,
'{"entity-data":{"app-key":"ZZZDE-NGPON2","entity-attributes":{"attribute":[{"name":"order_number","value":"CCOG639221728"},{"name":"order_version","value":"000"},{"name":"product_type","value":"Data"},{"name":"region","value":"NJ"},{"name":"supp_type","value":"Pending"}]}}}',
'SENT',
'SUCCESS',
'{"entity-data":{"app-key":"ZZZDE-NGPON2","entity-attributes":{"attribute":[{"name":"order_number","value":"CCOG639221728"},{"name":"order_version","value":"001"},{"name":"product_type","value":"Data"},{"name":"region","value":"NJ"},{"name":"supp_type","value":"Pending"}]}}}');

INSERT INTO ng_orchestration.ods_milestone_transaction
(ods_milestone_transaction_id,
root_case_id,
process_name,
step_name,
ods_milestone_config_Id,
request_payload,
status,
status_desc,
manifest_payload
)
VALUES
(112,
'TestRoot123',
'Test1',
'TestOneDispatcher',
111,
'{"entity-data":{"app-key":"ZZZDE-NGPON2","entity-attributes":{"attribute":[{"name":"order_number","value":"CCOG639221728"},{"name":"order_version","value":"000"},{"name":"product_type","value":"Data"},{"name":"region","value":"NJ"},{"name":"supp_type","value":"Pending"}]}}}',
'FAILED',
'payload not available',
'{"entity-data":{"app-key":"ZZZDE-NGPON2","entity-attributes":{"attribute":[{"name":"order_number","value":"CCOG639221728"},{"name":"order_version","value":"001"},{"name":"product_type","value":"Data"},{"name":"region","value":"NJ"},{"name":"supp_type","value":"Pending"}]}}}');

commit;