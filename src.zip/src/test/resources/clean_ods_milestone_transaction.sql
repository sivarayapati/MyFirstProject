use ng_orchestration;

delete from ods_milestone_transaction where root_case_id='TestRoot1234' ;
delete from ods_milestone_transaction where root_case_id='TestRoot123' ;

commit;