use ng_orchestration;

INSERT INTO ods_transformer_config
(transformer_key,
transformer_type,
transformer_schema)
VALUES
('LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber',
'XML',
'<?xml version="1.0"?>
 <xsl:stylesheet version="1.0"
 	xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
 
 	<xsl:template match="/">
 		<root>
 			<xsl:apply-templates mode="header" />
 			<xsl:apply-templates mode="body" />
 		</root>
 	</xsl:template>
 
 	<xsl:template match="OneDispatcher" mode="header">
 		<header>
 			<wsse:Security xmlns:wsse="http://schemas.xmlsoap.org/ws/2002/07/secext">
 				<wsse:UsernameToken>
 					<wsse:Username>
 						<xsl:value-of select="ApplicationParam/VNM_USERNAME" />
 					</wsse:Username>
 					<wsse:Password>
 						<xsl:value-of select="ApplicationParam/VNM_PASSWORD" />
 					</wsse:Password>
 				</wsse:UsernameToken>
 			</wsse:Security>
 		</header>
 	</xsl:template>
 
 	<xsl:template match="OneDispatcher" mode="body">
 		<body>
 			<m:activateNonBlocking xmlns:m="http://venom.verizon.com/webservices">
 				<customer>NAUTILUS_ACT</customer>
 				<params>
 					<xsl:text disable-output-escaping="yes">&lt;![CDATA[</xsl:text>
 					<nbaTransaction xsi:schemaLocation="urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd"
 						xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:vnm.verizon.com/Schemas/NBParms">
 						<xsl:element name="requests" xmlns="">
 							<requestType>VNM_RTRV_UNLOCKED_ONTS</requestType>
 							<groups>
 								<trails>
 									<tpaOptical>
 										<rack>
 											<xsl:value-of
 												select="PlanningMessage/document-payload/PlanningMsgRsp/PonCircuit/Olt/Rack" />
 										</rack>
 										<shelf>
 											<xsl:value-of
 												select="PlanningMessage/document-payload/PlanningMsgRsp/PonCircuit/Olt/ShelfId" />
 										</shelf>
 										<slot>
 											<xsl:value-of
 												select="PlanningMessage/document-payload/PlanningMsgRsp/PonCircuit/Olt/SlotId" />
 										</slot>
 										<port>
 											<xsl:value-of
 												select="PlanningMessage/document-payload/PlanningMsgRsp/PonCircuit/Olt/OltPortNumber" />
 										</port>
 									</tpaOptical>
 									<attribute name="PONSYSTEMID">
 										<xsl:value-of
 											select="PlanningMessage/document-payload/PlanningMsgRsp/ActivationInfo/PonDetails/PonSystemId" />
 									</attribute>
 									<attribute name="TRANSACTION_ID">
 										<xsl:value-of select="transactionId" />
 									</attribute> <!-- iVAPP Identifier -->
 									<attribute name="RESPONSEURL">
 										<xsl:value-of select="ApplicationParam/VNM_RESPONSE_URL" />
 									</attribute>
 									<attribute name="TIMEOUT">
 										<xsl:value-of select="ApplicationParam/VNM_TIMEOUT" />
 									</attribute> <!-- iVAPP SLA with VNM for this Request -->
 								</trails>
 							</groups>
 							<mne>
 								<tid>
 									<xsl:value-of
 										select="PlanningMessage/document-payload/PlanningMsgRsp/PonCircuit/Olt/OltTid" />
 								</tid>
 							</mne>
 						</xsl:element>
 					</nbaTransaction>
 					<xsl:text disable-output-escaping="yes">]]&gt;</xsl:text>
 				</params>
 			</m:activateNonBlocking>
 		</body>
 	</xsl:template>
 </xsl:stylesheet>');


INSERT INTO ods_transformer_config
(ods_transformer_config_id,transformer_key,
transformer_type,transformer_schema)
VALUES
(9499899,'Test_Transformation122','JSON','{}');
 

commit;