package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dto.model.HandleFalloutRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.WorkflowFalloutRequest;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class FalloutServiceControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(FalloutServiceControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	FalloutServiceController falloutServiceController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	/**
	 * 
	 */
	@Test
	public void testHandleFallout() {
		try {
			LOGGER.info("****************************Entering to testHandleFallout*****************************");
			URI url = new URI("/oneDispatcher/fallout/handleFallout");
			HandleFalloutRequest handleFalloutRequest =new HandleFalloutRequest();
			handleFalloutRequest.setCaseId("123");
			handleFalloutRequest.setErrorCode("ERROR_CODE_1");
			handleFalloutRequest.setStepName("ODS-Test");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(handleFalloutRequest)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testHandleFallout*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for handleFallout: ",e);
		}
	}
	@Test
	public void testHandleFallout1() {
		try {
			LOGGER.info("****************************Entering to testHandleFallout1*****************************");
			URI url = new URI("/oneDispatcher/fallout/handleFallout");
			HandleFalloutRequest handleFalloutRequest =new HandleFalloutRequest();
			handleFalloutRequest.setCaseId("123111");
			handleFalloutRequest.setErrorCode("ERROR_CODE_111");
			handleFalloutRequest.setStepName("ODS-Test11");			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(handleFalloutRequest)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testHandleFallout1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for handleFallout: ",e);
		}
	}
	@Test
	public void testCreateFallout() {
		try {
			LOGGER.info("****************************Entering to testCreateFallout*****************************");
			URI url = new URI("/oneDispatcher/fallout/createFallout");
			WorkflowFalloutRequest	workflowFalloutRequest = new WorkflowFalloutRequest();
			workflowFalloutRequest.setCaseId("123");
			workflowFalloutRequest.setWorkFlowStepName("ODS-Test");
			workflowFalloutRequest.setWorkFlowFalloutErrorCode("ERROR_CODE_1");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(workflowFalloutRequest)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateFallout*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createFallout: ",e);
		}
	}
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_workflow_fallout_table.sql") })
	public void testCreateFallout1() {
		try {
			LOGGER.info("****************************Entering to testCreateFallout1*****************************");
			URI url = new URI("/oneDispatcher/fallout/createFallout");
			WorkflowFalloutRequest	workflowFalloutRequest = new WorkflowFalloutRequest();
			workflowFalloutRequest.setCaseId("1234");
			workflowFalloutRequest.setWorkFlowStepName("ODS-Test1");
			workflowFalloutRequest.setWorkFlowFalloutErrorCode("ERROR_CODE_11");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(workflowFalloutRequest)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateFallout1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createFallout: ",e);
		}
	}
	
	@Test
	@SqlGroup({	@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_work_flow_fallout_config_table.sql") ,
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_work_flow_fallout__config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_work_flow_fallout_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_interface_request_table.sql"),
		})
	public void testisRetryPossible() {
		try {
			LOGGER.info("****************************Entering to testisRetryPossible*****************************");
			URI url = new URI("/oneDispatcher/fallout/isRetryPossible");
			String request ="{\"errorCode\" : \"DEFAULT_ERROR_CODE\",\"falloutStepName\":\"AddONT_Test\",\"transactionId\":\"119968815\"}";
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(request))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testisRetryPossible*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createFallout: ",e);
		}
	}
	@Test
	public void testisRetryOrComplete() {
		try {
			LOGGER.info("****************************Entering to testisRetryOrComplete*****************************");
			URI url = new URI("/oneDispatcher/fallout/retryOrComplete");
			String request ="{\"errorCode\" : \"DEFAULT_ERROR_CODE\",\"falloutStepName\":\"AddONT_Test\",\"transactionId\":\"119968815\"}";
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(request))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testisRetryOrComplete*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createFallout: ",e);
		}
	}
	
	@Test
	@SqlGroup({	@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_log_table.sql") ,
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_request_log_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_request_log_table.sql"),
		
		})
	public void testisRetryOrComplete1() {
		try {
			LOGGER.info("****************************Entering to testisRetryOrComplete1*****************************");
			URI url = new URI("/oneDispatcher/fallout/retryOrComplete");
			String request ="{\"wfTaskId\" : \"1234\",\"taskAction\":\"REFLOW\",\"wfTaskName\":\"ute\"}";
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(request))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testisRetryOrComplete1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createFallout: ",e);
		}
	}
	
	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}
	
	

}
