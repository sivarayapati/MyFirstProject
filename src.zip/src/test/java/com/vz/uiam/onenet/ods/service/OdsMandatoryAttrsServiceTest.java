package com.vz.uiam.onenet.ods.service;

import static org.mockito.Mockito.doNothing;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsMandatoryAttrsRepository;

@RunWith(MockitoJUnitRunner.class)
public class OdsMandatoryAttrsServiceTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(OdsMandatoryAttrsServiceTest.class);

	@InjectMocks
	OdsMandatoryAttrsService odsMandatoryAttrsService;
	
	@Mock
	OdsMandatoryAttrsRepository mandatoryAttrsRepo;
	
	@Test
	public void testGetUpdatedOdsMandatoryAttrsRecord() throws ApplicationException {
		LOGGER.info("Entering testGetUpdatedOdsMandatoryAttrsRecord");
		
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.seedInfo.orderNumber");
		
		odsMandatoryAttrsService.getUpdatedOdsMandatoryAttrsRecord(inputOdsMandatoryAttrs, new OdsMandatoryAttributes());
		
		LOGGER.info("Entering testGetUpdatedOdsMandatoryAttrsRecord");
	}
	
	@Test
	public void testDeleteOdsMandatoryAttrsRecord1() throws ApplicationException {
		LOGGER.info("Entering testDeleteOdsMandatoryAttrsRecord1");
		
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setValidationId(111);
		
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);
		
		doNothing().when(mandatoryAttrsRepo).delete(inputOdsMandatoryAttrs.getValidationId());
		
		odsMandatoryAttrsService.deleteOdsMandatoryAttrsRecord(odsMandatoryAttrsList);
		
		LOGGER.info("Entering testDeleteOdsMandatoryAttrsRecord1");
	}
	
	@Test
	public void testDeleteOdsMandatoryAttrsRecord2() throws ApplicationException {
		LOGGER.info("Entering testDeleteOdsMandatoryAttrsRecord2");
		
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);
		Mockito.when(mandatoryAttrsRepo.findByAttrKey(inputOdsMandatoryAttrs.getAttrKey())).thenReturn(odsMandatoryAttrsList);
		doNothing().when(mandatoryAttrsRepo).delete(inputOdsMandatoryAttrs);
		
		odsMandatoryAttrsService.deleteOdsMandatoryAttrsRecord(odsMandatoryAttrsList);
		
		LOGGER.info("Entering testDeleteOdsMandatoryAttrsRecord2");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDeleteOdsMandatoryAttrsRecord3() throws ApplicationException {
		LOGGER.info("Entering testDeleteOdsMandatoryAttrsRecord3");
		
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);
		
		odsMandatoryAttrsService.deleteOdsMandatoryAttrsRecord(odsMandatoryAttrsList);
		
		LOGGER.info("Entering testDeleteOdsMandatoryAttrsRecord3");
	}
}
