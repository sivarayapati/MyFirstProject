package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFalloutConfig;
import com.vz.uiam.onenet.ods.service.ODSWorkFlowFalloutConfigService;

@RunWith(MockitoJUnitRunner.class)
public class ODSWorkFlowFalloutConfigControllerMockitoTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory
			.getLogger(ODSWorkFlowFalloutConfigControllerMockitoTest.class);

	@InjectMocks
	ODSWorkFlowFalloutConfigController odsWorkFlowFalloutConfigController;

	@Mock
	ODSWorkFlowFalloutConfigService odsWorkFlowFalloutConfigService;

	@Test
	public void testCreateOrUpdateWorkFlowFalloutConfig() throws ApplicationException {
		LOGGER.info("Entering testCreateOrUpdateWorkFlowFalloutConfig");

		WorkflowFalloutConfig config = new WorkflowFalloutConfig();
		config.setMaxRetryCounter(3);
		config.setRetryInterval(10);
		WorkflowFalloutConfig workFlwFOConfigResp = null;
		when(odsWorkFlowFalloutConfigService.createOrUpdateWorkflowFalloutConfig(config))
				.thenReturn(workFlwFOConfigResp);

		odsWorkFlowFalloutConfigController.createOrUpdateWorkFlowFalloutConfig(config);

		LOGGER.info("Exiting testCreateOrUpdateWorkFlowFalloutConfig");
	}

	@Test
	public void testGetWorkFlowFalloutConfig() throws ApplicationException {
		LOGGER.info("Entering testGetWorkFlowFalloutConfig");

		WorkflowFalloutConfig config = new WorkflowFalloutConfig();
		config.setMaxRetryCounter(3);
		config.setRetryInterval(10);
		List<WorkflowFalloutConfig> workflowFalloutConfigList = null;
		when(odsWorkFlowFalloutConfigService.getWorkflowFalloutConfig(config)).thenReturn(workflowFalloutConfigList);

		odsWorkFlowFalloutConfigController.getWorkFlowFalloutConfig(config);

		LOGGER.info("Exiting testGetWorkFlowFalloutConfig");
	}

	@Test
	public void testGetWorkFlowFalloutConfig1() throws ApplicationException {
		LOGGER.info("Entering testGetWorkFlowFalloutConfig1");

		WorkflowFalloutConfig config = new WorkflowFalloutConfig();
		config.setMaxRetryCounter(3);
		config.setRetryInterval(10);
		when(odsWorkFlowFalloutConfigService.getWorkflowFalloutConfig(config)).thenThrow(Exception.class);

		odsWorkFlowFalloutConfigController.getWorkFlowFalloutConfig(config);

		LOGGER.info("Exiting testGetWorkFlowFalloutConfig1");
	}

	@Test
	public void testDeleteWorkFlowFalloutConfig() throws ApplicationException {
		LOGGER.info("Entering testDeleteWorkFlowFalloutConfig");

		WorkflowFalloutConfig config = new WorkflowFalloutConfig();
		config.setMaxRetryCounter(3);
		config.setRetryInterval(10);
		List<WorkflowFalloutConfig> workflowFalloutConfigList = new ArrayList<>();
		workflowFalloutConfigList.add(config);
		Mockito.doThrow(Exception.class).when(odsWorkFlowFalloutConfigService)
				.deleteWorkflowFalloutConfigRecord(workflowFalloutConfigList);

		odsWorkFlowFalloutConfigController.deleteWorkFlowFalloutConfig(workflowFalloutConfigList);

		LOGGER.info("Exiting testDeleteWorkFlowFalloutConfig");
	}
}
