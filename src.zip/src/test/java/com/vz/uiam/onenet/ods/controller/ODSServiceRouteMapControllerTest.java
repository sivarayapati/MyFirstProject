package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class ODSServiceRouteMapControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSServiceRouteMapControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	ODSServiceRouteMapController odsServiceRouteMapController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	/**
	 * 
	 */
	@Test
	public void testCreateOrUpdateServiceRouteMap() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateServiceRouteMap*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/createOrUpdate");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails = new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails.setAppKey("TEST-Process-Name_TEST-Step-Name");
			odsServiceRouterMapDetails.setFlowNodeProcessName("TEST-Process-Name");
			odsServiceRouterMapDetails.setFlowNodeStepName("TEST-Step-Name");
			odsServiceRouterMapDetails.setRequestDocumentName("TEST-Message");
			odsServiceRouterMapDetails.setRequestSchema("{test:$.test}");
			odsServiceRouterMapDetails.setResponseDocumentName("Test-doc");
			odsServiceRouterMapDetails.setRouterProtocol("REST");
			odsServiceRouterMapDetails.setTargetEndPointUrl("http://test.com");
			odsServiceRouterMapDetails.setTransformationType("JSON");

			Set<OdsMilestoneConfig> odsMilestoneConfigList = new HashSet<OdsMilestoneConfig>();
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();

			odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
			odsMilestoneConfig.setRequestDocumentName("TEST-Message");
			odsMilestoneConfig.setRequestSchema("{test:$.test}");
			odsMilestoneConfig.setTransformationType("JSON");
			odsMilestoneConfig.setRouteProtocol("REST");
			odsMilestoneConfig.setSendMilestone("YES");
			odsMilestoneConfig.setSendFalloutNotification("NO");

			odsMilestoneConfigList.add(odsMilestoneConfig);
			
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateServiceRouteMap*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateServiceRouteMap: ",e);
		}
	}
	
	@Test
	public void testCreateOrUpdateServiceRouteMap1() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateServiceRouteMap1*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/createOrUpdate");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateServiceRouteMap1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateServiceRouteMap: ",e);
		}
	}
	
	@Test
	public void testCreateOrUpdateServiceRouteMap2() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateServiceRouteMap2*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/createOrUpdate");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails.setId(1234);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateServiceRouteMap2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateServiceRouteMap: ",e);
		}
	}
	
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql")})
	public void testCreateOrUpdateServiceRouteMap3() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateServiceRouteMap3*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/createOrUpdate");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails.setId(222);
			odsServiceRouterMapDetails.setFlowNodeProcessName("Test1");
			odsServiceRouterMapDetails.setFlowNodeStepName("TestOneDispatcher");
			odsServiceRouterMapDetails.setRequestDocumentName("TEST-Message");
			odsServiceRouterMapDetails.setRequestSchema("{test:$.test}");
			odsServiceRouterMapDetails.setResponseDocumentName("Test-doc");
			odsServiceRouterMapDetails.setRouterProtocol("REST");
			odsServiceRouterMapDetails.setTargetEndPointUrl("http://test.com");
			odsServiceRouterMapDetails.setTransformationType("JSON");
			

			Set<OdsMilestoneConfig> odsMilestoneConfigList = new HashSet<OdsMilestoneConfig>();
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();

			odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
			odsMilestoneConfig.setRequestDocumentName("TEST-Message");
			odsMilestoneConfig.setRequestSchema("{test:$.test}");
			odsMilestoneConfig.setTransformationType("JSON");
			odsMilestoneConfig.setRouteProtocol("REST");
			odsMilestoneConfig.setSendMilestone("YES");
			odsMilestoneConfig.setSendFalloutNotification("NO");

			odsMilestoneConfigList.add(odsMilestoneConfig);
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateServiceRouteMap3*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateServiceRouteMap: ",e);
		}
	}
	
	@Test
	public void testCreateOrUpdateServiceRouteMap4() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateServiceRouteMap4*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/createOrUpdate");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails.setFlowNodeProcessName("Test1");
			odsServiceRouterMapDetails.setFlowNodeStepName("");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsServiceRouterMapDetails odsServiceRouterMapDetails11 =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails11.setAppKey("Test1_TestStep");
			odsServiceRouterMapDetails11.setFlowNodeProcessName("");
			odsServiceRouterMapDetails11.setFlowNodeStepName("");
			MvcResult result11 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails11)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result11.getResponse().getContentAsString());
	
			
			OdsServiceRouterMapDetails odsServiceRouterMapDetails1 =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails1.setAppKey("Test1_TestStep");
			odsServiceRouterMapDetails1.setFlowNodeProcessName("Test1");
			odsServiceRouterMapDetails1.setFlowNodeStepName("");
			odsServiceRouterMapDetails.setRequestDocumentName("");
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
		
			
			OdsServiceRouterMapDetails odsServiceRouterMapDetails2 =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails2.setAppKey("Test1_TestStep");
			odsServiceRouterMapDetails2.setFlowNodeProcessName("Test1");
			odsServiceRouterMapDetails2.setFlowNodeStepName("");
			MvcResult result2 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails2)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result2 : " + result2.getResponse().getContentAsString());
		
			
			OdsServiceRouterMapDetails odsServiceRouterMapDetails3 =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails3.setAppKey("Test1_TestStep");
			odsServiceRouterMapDetails3.setFlowNodeProcessName("Test1");
			odsServiceRouterMapDetails3.setFlowNodeStepName("TestOneDispatcher1");
			odsServiceRouterMapDetails3.setTargetEndPointUrl("");
			odsServiceRouterMapDetails3.setRouterProtocol("");
			odsServiceRouterMapDetails3.setRequestSchema("");
			odsServiceRouterMapDetails3.setResponseDocumentName("");
		
			MvcResult result3 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails3)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result3 : " + result3.getResponse().getContentAsString());
			OdsServiceRouterMapDetails odsServiceRouterMapDetails4 =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails4.setAppKey("Test1_TestStep");
			odsServiceRouterMapDetails4.setFlowNodeProcessName("Test1");
			odsServiceRouterMapDetails4.setFlowNodeStepName("TestOneDispatcher1");
			odsServiceRouterMapDetails4.setTargetEndPointUrl("http;//");
			odsServiceRouterMapDetails4.setRequestDocumentName("TEST-Message");
			odsServiceRouterMapDetails4.setRouterProtocol("");
			odsServiceRouterMapDetails.setSendMilestoneFlag("");
				
			MvcResult result4 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails4)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result4 : " + result4.getResponse().getContentAsString());
			
			OdsServiceRouterMapDetails odsServiceRouterMapDetails5=new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails5.setAppKey("Test1_TestStep");
			odsServiceRouterMapDetails5.setFlowNodeProcessName("Test1");
			odsServiceRouterMapDetails5.setFlowNodeStepName("TestOneDispatcher1");
			odsServiceRouterMapDetails5.setTargetEndPointUrl("http;//");
			odsServiceRouterMapDetails5.setRequestDocumentName("TEST-Message");
			odsServiceRouterMapDetails5.setRequestSchema("test");
			odsServiceRouterMapDetails.setSendMilestoneFlag("");
			odsServiceRouterMapDetails5.setRouterProtocol("REST");
		
			MvcResult result5 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails5)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result5 : " + result5.getResponse().getContentAsString());
			
			OdsServiceRouterMapDetails odsServiceRouterMapDetails6=new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails6.setAppKey("Test1_TestStep");
			odsServiceRouterMapDetails6.setFlowNodeProcessName("Test1");
			odsServiceRouterMapDetails6.setFlowNodeStepName("TestOneDispatcher1");
			odsServiceRouterMapDetails6.setRequestDocumentName("TEST-Message");
			odsServiceRouterMapDetails6.setRequestSchema("test");
			odsServiceRouterMapDetails6.setResponseDocumentName("resdoc");
			odsServiceRouterMapDetails6.setRouterProtocol("route");
			odsServiceRouterMapDetails6.setTargetEndPointUrl("");
		
			MvcResult result6 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails6)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result6 : " + result6.getResponse().getContentAsString());

			OdsServiceRouterMapDetails odsServiceRouterMapDetails7=new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails7.setAppKey("Test1_TestStep");
			odsServiceRouterMapDetails7.setFlowNodeProcessName("Test1");
			odsServiceRouterMapDetails7.setFlowNodeStepName("TestOneDispatcher1");
			odsServiceRouterMapDetails7.setRequestDocumentName("TEST-Message");
			odsServiceRouterMapDetails7.setRequestSchema("test");
			odsServiceRouterMapDetails7.setResponseDocumentName("resdoc");
			odsServiceRouterMapDetails7.setRouterProtocol("route");
			odsServiceRouterMapDetails7.setTargetEndPointUrl("http://test.com");
			odsServiceRouterMapDetails7.setTransformationType("");
		
			MvcResult result7 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails7)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result7 : " + result7.getResponse().getContentAsString());

			OdsServiceRouterMapDetails odsServiceRouterMapDetails8=new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails8.setAppKey("Test1_TestStep");
			odsServiceRouterMapDetails8.setFlowNodeProcessName("Test1");
			odsServiceRouterMapDetails8.setFlowNodeStepName("TestOneDispatcher1");
			odsServiceRouterMapDetails8.setRequestDocumentName("TEST-Message");
			odsServiceRouterMapDetails8.setRequestSchema("test");
			odsServiceRouterMapDetails8.setResponseDocumentName("res");
			odsServiceRouterMapDetails8.setRouterProtocol("");
			odsServiceRouterMapDetails8.setTargetEndPointUrl("http://test.com");
			odsServiceRouterMapDetails8.setTransformationType("json");
		
		
			MvcResult result8 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails8)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result8 : " + result8.getResponse().getContentAsString());
		
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateServiceRouteMap4*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateServiceRouteMap: ",e);
		}
	}
	
	@Test
	@SqlGroup({	@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql")})
	public void testCreateOrUpdateServiceRouteMap5() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateServiceRouteMap5*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/createOrUpdate");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails.setId(222);
			odsServiceRouterMapDetails.setFlowNodeProcessName("Test1");
			odsServiceRouterMapDetails.setFlowNodeStepName("TestOneDispatcher");
			odsServiceRouterMapDetails.setRequestDocumentName("TEST-Message");
			odsServiceRouterMapDetails.setRequestSchema("{test:$.test}");
			odsServiceRouterMapDetails.setResponseDocumentName("Test-doc");
			odsServiceRouterMapDetails.setRouterProtocol("REST");
			odsServiceRouterMapDetails.setTargetEndPointUrl("http://test.com");
			odsServiceRouterMapDetails.setTransformationType("JSON");
			

			Set<OdsMilestoneConfig> odsMilestoneConfigList = new HashSet<OdsMilestoneConfig>();
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
            odsMilestoneConfig.setOdsMilestoneConfigId(112);
			odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
			odsMilestoneConfig.setRequestDocumentName("TEST-Message");
			odsMilestoneConfig.setRequestSchema("{test:$.test}");
			odsMilestoneConfig.setTransformationType("JSON");
			odsMilestoneConfig.setRouteProtocol("REST");
			odsMilestoneConfig.setSendMilestone("YES");
			odsMilestoneConfig.setSendFalloutNotification("NO");

			odsMilestoneConfigList.add(odsMilestoneConfig);
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateServiceRouteMap5*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateServiceRouteMap: ",e);
		}
	}
	
	@Test
	public void testGetServiceRouteMap() {
		try {
			LOGGER.info("****************************Entering to testGetServiceRouteMap*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/get");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails.setFlowNodeProcessName("TEST-Process-Name");
			odsServiceRouterMapDetails.setFlowNodeStepName("TEST-Step-Name");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetServiceRouteMap*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getServiceRouteMap: ",e);
		}
	}
	
	@Test
	public void testGetServiceRouteMap1() {
		try {
			LOGGER.info("****************************Entering to testGetServiceRouteMap1*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/get");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsServiceRouterMapDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetServiceRouteMap1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getServiceRouteMap: ",e);
		}
	}
	
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql")})
	public void testDeleteServiceRouteMap() {
		try {
			LOGGER.info("****************************Entering to testDeleteServiceRouteMap*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/delete");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails.setFlowNodeProcessName("Test11");
			odsServiceRouterMapDetails.setFlowNodeStepName("TestOneDispatcher");
			List<OdsServiceRouterMapDetails> attrList= new ArrayList<>();
			attrList.add(odsServiceRouterMapDetails);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteServiceRouteMap*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteServiceRouteMap: ",e);
		}
	}
	
	@Test
	public void testDeleteServiceRouteMap1() {
		try {
			LOGGER.info("****************************Entering to testDeleteServiceRouteMap1*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/delete");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails.setFlowNodeProcessName("TEST-Process-Name1");
			odsServiceRouterMapDetails.setFlowNodeStepName("TEST-Step-Name1");
			List<OdsServiceRouterMapDetails> attrList= new ArrayList<>();
			attrList.add(odsServiceRouterMapDetails);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsServiceRouterMapDetails odsServiceRouterMapDetails1 =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails1.setFlowNodeProcessName("TEST-Process-Name1");
			odsServiceRouterMapDetails1.setFlowNodeStepName("TEST-Step-Name1");
			List<OdsServiceRouterMapDetails> attrList1= new ArrayList<>();
			attrList1.add(odsServiceRouterMapDetails1);
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			

			OdsServiceRouterMapDetails odsServiceRouterMapDetails2 =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails2.setFlowNodeProcessName("");
			odsServiceRouterMapDetails2.setFlowNodeStepName("");
			List<OdsServiceRouterMapDetails> attrList2= new ArrayList<>();
			attrList2.add(odsServiceRouterMapDetails2);
			MvcResult result2 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList2)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result2 : " + result2.getResponse().getContentAsString());
		
			
			LOGGER.info("****************************Exiting from testDeleteServiceRouteMap1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteServiceRouteMap: ",e);
		}
	}
	
    @Test
    @SqlGroup({
    	@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql")})
	public void testDeleteServiceRouteMap2() {
		try {
			LOGGER.info("****************************Entering to testDeleteServiceRouteMap2*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/delete");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails.setId(222);
			List<OdsServiceRouterMapDetails> attrList= new ArrayList<>();
			attrList.add(odsServiceRouterMapDetails);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteServiceRouteMap2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteServiceRouteMap: ",e);
		}
	}
    
    @Test
	@SqlGroup({
	@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
	@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
	@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql")})
	public void testDeleteServiceRouteMap3() {
		try {
			LOGGER.info("****************************Entering to testDeleteServiceRouteMap3*****************************");
			URI url = new URI("/oneDispatcher/serviceRouteMap/delete");
			OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails.setFlowNodeProcessName("Test246");
			odsServiceRouterMapDetails.setAppKey("Test246_TestOneDispatcher");
			odsServiceRouterMapDetails.setFlowNodeStepName("TestOneDispatcher");
		
			List<OdsServiceRouterMapDetails> attrList= new ArrayList<>();
			attrList.add(odsServiceRouterMapDetails);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
			.content(convertObjectToJsonBytes(attrList)))
			.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
			.andReturn();
		
			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
		
			OdsServiceRouterMapDetails odsServiceRouterMapDetails1 =new OdsServiceRouterMapDetails();
			odsServiceRouterMapDetails1.setFlowNodeProcessName("Test2461");
			odsServiceRouterMapDetails1.setAppKey("Test246_TestOneDispatcher1");
			odsServiceRouterMapDetails1.setFlowNodeStepName("TestOneDispatcher1");
		
			List<OdsServiceRouterMapDetails> attrList1= new ArrayList<>();
			attrList1.add(odsServiceRouterMapDetails);
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
			.content(convertObjectToJsonBytes(attrList)))
			.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();
		
			LOGGER.debug("Result : " + result1.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteServiceRouteMap2*****************************");
	
		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteServiceRouteMap: ",e);
		}
	}
    
	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

}
