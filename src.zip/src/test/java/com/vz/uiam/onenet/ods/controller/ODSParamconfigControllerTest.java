package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class ODSParamconfigControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSParamconfigControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	ODSParamConfigController odsParamConfigController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	/**
	 * 
	 */
	@Test
	public void testCreateOrUpdateOdsParamConfig() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateOdsParamConfig*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/createOrUpdate");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setName("TEST");
			odsParamConfig.setParamKey("TEST-Param-Key");
			odsParamConfig.setValue("Test-Value");
			odsParamConfig.setType("TEST-Type");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateOdsParamConfig*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsParamConfig: ",e);
		}
	}
	@Test
	
	public void testCreateOrUpdateOdsParamConfig1() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateOdsParamConfig1*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/createOrUpdate");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateOdsParamConfig1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsParamConfig: ",e);
		}
	}
	@Test
	public void testCreateOrUpdateOdsParamConfig2() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateOdsParamConfig2*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/createOrUpdate");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setParamId(1010);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateOdsParamConfig2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsParamConfig: ",e);
		}
	}
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public void testCreateOrUpdateOdsParamConfig3() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateOdsParamConfig3*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/createOrUpdate");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setParamId(100);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateOdsParamConfig3*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsParamConfig: ",e);
		}
	}
	@Test
	public void testCreateOrUpdateOdsParamConfig4() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateOdsParamConfig4*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/createOrUpdate");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setParamKey("ParamKey");
			odsParamConfig.setType("");
			odsParamConfig.setName("");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsParamConfig odsParamConfig1 =new OdsParamConfig();
			odsParamConfig1.setParamKey("ParamKey");
			odsParamConfig1.setName("");
			odsParamConfig1.setType("type");
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			OdsParamConfig odsParamConfig2 =new OdsParamConfig();
			odsParamConfig2.setParamKey("ParamKey");
			odsParamConfig2.setName("name");
			odsParamConfig2.setType("type");
			odsParamConfig2.setValue("");
			MvcResult result2 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig2)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result2 : " + result2.getResponse().getContentAsString());
			
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateOdsParamConfig4*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsParamConfig: ",e);
		}
	}
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public void testCreateOrUpdateOdsParamConfig5() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateOdsParamConfig5*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/createOrUpdate");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setName("Test-Name");
			odsParamConfig.setParamKey("Test-param_key");
			odsParamConfig.setType("JSON");
			odsParamConfig.setValue("value");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateOdsParamConfig5*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsParamConfig: ",e);
		}
	}
	@Test
	public void testGetOdsParamConfig() {
		try {
			LOGGER.info("****************************Entering to testGetOdsParamConfig*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/get");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setName("TEST");
			odsParamConfig.setParamKey("TEST-Param-Key");
			odsParamConfig.setValue("Test-Value");
			odsParamConfig.setType("TEST-Type");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetOdsParamConfig*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsParamConfig: ",e);
		}
	}
	@Test
	public void testGetOdsParamConfig1() {
		try {
			LOGGER.info("****************************Entering to testGetOdsParamConfig1*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/get");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setParamKey("TEST-Param-Key-Key");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetOdsParamConfig1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsParamConfig: ",e);
		}
	}
	@Test
	public void testGetOdsParamConfig2() {
		try {
			LOGGER.info("****************************Entering to testGetOdsParamConfig2*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/get");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setName("");
			odsParamConfig.setParamKey("");
			odsParamConfig.setType("");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetOdsParamConfig2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsParamConfig: ",e);
		}
	}
	@Test
	public void testGetOdsParamConfig4() {
		try {
			LOGGER.info("****************************Entering to testGetOdsParamConfig4*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/get");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setParamKey("100");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsParamConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetOdsParamConfig4*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsParamConfig: ",e);
		}
	}
	@Test
	public void testDeleteOdsParamConfig() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsParamConfig*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/delete");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setName("TEST");
			odsParamConfig.setParamKey("TEST-Param-Key");
			odsParamConfig.setType("TEST-Type");
			List<OdsParamConfig> attrList= new ArrayList<>();
			attrList.add(odsParamConfig);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsParamConfig odsParamConfig1 =new OdsParamConfig();
			odsParamConfig1.setName("TEST");
			odsParamConfig1.setParamKey("TEST-Param-Key-Key");
			odsParamConfig1.setType("TEST-Type");
			List<OdsParamConfig> attrList1= new ArrayList<>();
			attrList1.add(odsParamConfig1);
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteOdsParamConfig*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsParamConfig: ",e);
		}
	}
	@Test
	public void testDeleteOdsParamConfig1() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsParamConfig1*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/delete");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setParamId(0);
			List<OdsParamConfig> attrList= new ArrayList<>();
			attrList.add(odsParamConfig);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteOdsParamConfig1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsParamConfig: ",e);
		}
	}
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public void testDeleteOdsParamConfig2() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsParamConfig2*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/delete");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setParamId(100);
			List<OdsParamConfig> attrList= new ArrayList<>();
			attrList.add(odsParamConfig);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteOdsParamConfig2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsParamConfig: ",e);
		}
	}
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public void testDeleteOdsParamConfig3() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsParamConfig3*****************************");
			URI url = new URI("/oneDispatcher/odsParamConfig/delete");
			OdsParamConfig odsParamConfig =new OdsParamConfig();
			odsParamConfig.setParamKey("Param-Key");
			List<OdsParamConfig> attrList= new ArrayList<>();
			attrList.add(odsParamConfig);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsParamConfig odsParamConfig1 =new OdsParamConfig();
			odsParamConfig1.setParamKey("Test-param_key");
			List<OdsParamConfig> attrList1= new ArrayList<>();
			attrList1.add(odsParamConfig1);
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteOdsParamConfig3*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsParamConfig: ",e);
		}
	}
	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}
	
	

}
