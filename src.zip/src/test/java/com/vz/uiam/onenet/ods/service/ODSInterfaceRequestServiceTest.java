/**
 * 
 */
package com.vz.uiam.onenet.ods.service;
import static org.mockito.Mockito.when;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSInterfaceServiceRequest;

/**
 * @author Guru
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ODSInterfaceRequestServiceTest {

	private static final Logger LOGGER = Logger.getLogger(ODSInterfaceRequestServiceTest.class);
	
	@InjectMocks
	ODSInterfaceRequestService odsRequestService;

	@Mock
	OdsInterfaceRequestRepository odsInterfaceRequestRepo;
	
	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test method for
	 * {@link com.vz.uiam.onenet.ods.service.ODSInterfaceRequestService#createInterfaceServiceRecord(com.vz.uiam.onenet.ods.jpa.dto.model.ODSInterfaceServiceRequest)}.
	 */
	@Test
	public void testCreateInterfaceServiceRecord() {
		LOGGER.info("Started ODS Interface request TEST");
		String transactionId = "1532456789";
		String taskId ="123344";
		String requestPayload ="{\"req\":\"{\"test\":\"test\"}\"}";
		String manifestPayload ="{\"req\":\"{\"test\":\"test\"}\"}";
		String corelationPayload = "{\"req\":\"{\"test\":\"test\"}\"}";
		String responseConfigParams = "{\"req\":\"{\"test\":\"test\"}\"}";
		ODSInterfaceServiceRequest interfaceServiceRequest = new ODSInterfaceServiceRequest(transactionId,taskId, requestPayload, manifestPayload, corelationPayload,responseConfigParams);
		OdsInterfaceRequest requestFromDb = new OdsInterfaceRequest();
		when(odsInterfaceRequestRepo.findByTransactionIdAndStatus(transactionId,
				StatusCode.REQUEST_PENDING.toString())).thenReturn(requestFromDb);
		
		odsRequestService.createInterfaceServiceRecord(interfaceServiceRequest);
		
		LOGGER.info("Started ODS Interface request TEST");
		
	}

}
