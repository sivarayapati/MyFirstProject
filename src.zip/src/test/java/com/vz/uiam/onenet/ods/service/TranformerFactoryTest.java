package com.vz.uiam.onenet.ods.service;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.transformer.TranformerFactory;

@RunWith(MockitoJUnitRunner.class)
public class TranformerFactoryTest {
	private static final Logger LOGGER = Logger.getLogger(TranformerFactoryTest.class);
	@InjectMocks
	TranformerFactory tranformerFactory;

	
	@Test
	public void testGetTransformerInstance() throws ApplicationException {

		LOGGER.info("Entering testGetTransformerInstance");
		
		String tranformerType = Constants.TRANSFORMATION_XML_TYPE;
		TranformerFactory.getTransformerInstance(tranformerType);
		LOGGER.info("Exiting testGetTransformerInstance");

	}

	@Test
	public void testGetTransformerInstance1() throws ApplicationException {

		LOGGER.info("Entering testGetTransformerInstance1");
		
		String tranformerType = Constants.TRANSFORMATION_JSON_TYPE;
		TranformerFactory.getTransformerInstance(tranformerType);
		LOGGER.info("Exiting testGetTransformerInstance1");

	}
	@Test
	public void testGetTransformerInstance2() throws ApplicationException {

		LOGGER.info("Entering testGetTransformerInstance2");
		
		String tranformerType = "";
		TranformerFactory.getTransformerInstance(tranformerType);
		LOGGER.info("Exiting testGetTransformerInstance2");

	}

}