package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsWorkflowParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.WfParamRequestDTO;
import com.vz.uiam.onenet.ods.jpa.dto.model.WorkflowParam;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class WorkFlowParamControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(WorkFlowParamControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	OneDispatcherController serviceRouterController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_wf_decision_params_table.sql")})
	public void testAddWfParams() {
		try {
			LOGGER.info("****************************Entering to testAddWfParams*****************************");
			URI url = new URI("/oneDispatcher/workflowParam/createOrUpdateWfParams");
			OdsWorkflowParams odsWorkflowParams = new OdsWorkflowParams();
		   	odsWorkflowParams.setWfParamValue("TestParamvalue");

			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsWorkflowParams)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testAddWfParams*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for addWfParams: ",e);
		}
	}

	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_wf_decision_params_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_wf_decision_params_table.sql")})
	public void testAddWfParams1() {
		try {
			LOGGER.info("****************************Entering to testAddWfParams1*****************************");
			URI url = new URI("/oneDispatcher/workflowParam/createOrUpdateWfParams");
			WorkflowParam wfParam =new WorkflowParam();
			wfParam.setParamName("JunitProcess1");
			wfParam.setParamValue("TestParamvalue11");
			List<WorkflowParam> wfList=new ArrayList<>();
            wfList.add(wfParam);
			WfParamRequestDTO wfParamDto= new WfParamRequestDTO();
			wfParamDto.setWorkflowParams(wfList);
			wfParamDto.setRootCaseId("100");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(wfParamDto)))
					.andExpect(status().isOk())
					.andExpect(content().contentType(Constants.APPLICATION_JSON)).andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testAddWfParams1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for addWfParams: ",e);
		}
	}
	
	@Test
	public void testAddWfParams2() {
		try {
			LOGGER.info("****************************Entering to testAddWfParams1*****************************");
			URI url = new URI("/oneDispatcher/workflowParam/createOrUpdateWfParams");
			WorkflowParam wfParam = new WorkflowParam();
			wfParam.setParamName("JunitProcess11");
			wfParam.setParamValue("TestParamvalue11");
			List<WorkflowParam> wfList=new ArrayList<>();
            wfList.add(wfParam);
			WfParamRequestDTO wfParamDto= new WfParamRequestDTO();
			wfParamDto.setWorkflowParams(wfList);
			wfParamDto.setRootCaseId("101");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(wfParamDto)))
					.andExpect(status().isOk())
					.andExpect(content().contentType(Constants.APPLICATION_JSON)).andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testAddWfParams1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for addWfParams: ",e);
		}
	}

	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_wf_decision_params_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_wf_decision_params_table.sql")})
	public void testGetWfParam() {
		try {
			LOGGER.info("****************************Entering to testGetWfParam*****************************");
			URI url = new URI("/oneDispatcher/workflowParam/getWorkflowParam");
			
			WfParamRequestDTO odsWorkflowParams = new WfParamRequestDTO();
			odsWorkflowParams.setRootCaseId("100");

			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsWorkflowParams)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testGetWfParam*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for GetWfParam: ",e);
		}
	}

	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}
}
