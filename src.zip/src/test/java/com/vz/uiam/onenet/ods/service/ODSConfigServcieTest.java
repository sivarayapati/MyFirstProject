
package com.vz.uiam.onenet.ods.service;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsTransformerConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFalloutConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsResponseTransactionIdMapRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsServiceRouterMapRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSConfigPayload;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSKeyDetails;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class ODSConfigServcieTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ODSConfigServcieTest.class);

	@InjectMocks
	ODSConfigService odsConfigService;

	@Mock
	OdsParamConfigRepository odsParamConfigRepo;

	@Mock
	OdsServiceRouterMapRepository odsServiceRouterMapRepository;

	@Mock
	OdsInterfaceRequestRepository odsRequestRepo;

	@Mock
	WorkflowParamService workflowParamService;

	@Mock
	OdsResponseTransactionIdMapRepository odsResponseTransactionIdMapRepository;

	@Mock
	ServiceUtils serviceUtils;

	@Mock
	OdsServiceRouteMapService odsServiceRouteMapSvc;

	@Mock
	OdsMandatoryAttrsService odsMandatoryAttrsSvc;

	@Mock
	OdsParamConfigService odsParamConfigSvc;

	@Mock
	OdsRequestResponseTransactionIdMapService odsReqResTIdMapService;

	@Mock
	ODSWorkFlowFalloutConfigService odsWorkFlowFalloutConfigService;
	
	@Mock
	OdsTransformerConfigService odsTransformerConfigService;

	@Mock
	JdbcTemplate jdbcTemplate;
	
	@Mock
	OdsMilestoneConfigService odsMilestoneConfigService;

	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetOdsConfigurations() {
		LOGGER.info("Entering testGetOdsConfigurations");
		ODSKeyDetails keyDetails = mock(ODSKeyDetails.class);
		try {
			odsConfigService.getOdsConfigurations(keyDetails);
		} catch (ApplicationException e) {
			LOGGER.error("Exception occurred - ", e);
		}
		LOGGER.info("Exiting testGetOdsConfigurations");
	}

	@Test
	public void testGetOdsConfigurations1() {
		LOGGER.info("Entering testGetOdsConfigurations1");
		ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
		odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsKeyDetails.setFlowNodeStepName("AddONT_Test");
		odsKeyDetails.setAppKey("Test-ODS-Key");
		List<OdsServiceRouterMapDetails> odsSvcRouterDetails = new ArrayList<>();
		OdsServiceRouterMapDetails odsServiceRouterMapDetails = mock(OdsServiceRouterMapDetails.class);
		try {
			when(odsServiceRouteMapSvc.getServiceRouteMapRecords(odsServiceRouterMapDetails))
					.thenReturn(odsSvcRouterDetails);

			odsConfigService.getOdsConfigurations(odsKeyDetails);
		} catch (ApplicationException e) {
			LOGGER.error("Exception occurred - ", e);
		}
		LOGGER.info("Exiting testGetOdsConfigurations1");
	}

	@Test
	public void testGetOdsConfigurations2() {
		LOGGER.info("Entering testGetOdsConfigurations2");
		ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
		odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsKeyDetails.setFlowNodeStepName("AddONT_Test");
		odsKeyDetails.setAppKey("Test-ODS-Key");
		odsKeyDetails.setLevel("AppLevel");
		List<OdsServiceRouterMapDetails> odsSvcRouterDetails = new ArrayList<>();

		OdsServiceRouterMapDetails svcMap = new OdsServiceRouterMapDetails();
		svcMap.setAppKey("Test-ODS-Key");
		svcMap.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		svcMap.setFlowNodeStepName("AddONT_Test");
		svcMap.setTargetEndPointUrl("http://vz.com/getdata");
		svcMap.setRouterProtocol("REST");
		svcMap.setSendMilestoneFlag("YES");

		odsSvcRouterDetails.add(svcMap);

		try {
			List<OdsRequestTransactionIdMap> odsReqList = new ArrayList<>();
			OdsRequestTransactionIdMap odsRequestTransactionIdMap = new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
			odsRequestTransactionIdMap.setFlowNodeStepName("AddONT_Test");
			odsReqList.add(odsRequestTransactionIdMap);
			OdsTransformerConfig odsTransformerConfig= new OdsTransformerConfig();
			odsTransformerConfig.setTransformerKey("TestKey");
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
			odsMilestoneConfig.setDestinationAppName("testapp");
			odsMilestoneConfig.setMilestoneName("milestone");
			List<OdsMilestoneConfig> odsMilestoneConfigRspList = new ArrayList<>();
			odsMilestoneConfigRspList.add(odsMilestoneConfig);
			when(odsReqResTIdMapService.getOdsRequestTransIdMapRecords(Mockito.any())).thenReturn(odsReqList);
			when(odsServiceRouteMapSvc.getServiceRouteMapRecords(Mockito.any())).thenReturn(odsSvcRouterDetails);
			when(odsTransformerConfigService.getOdsTransformerConfig(Mockito.any())).thenReturn(odsTransformerConfig);
			when(odsMilestoneConfigService.getMilestoneConfig(Mockito.any())).thenReturn(odsMilestoneConfigRspList);

			odsConfigService.getOdsConfigurations(odsKeyDetails);
		} catch (ApplicationException e) {
			LOGGER.error("Exception occurred - ", e);
		}
		LOGGER.info("Exiting testGetOdsConfigurations2");
	}
	
	@Test
	public void testGetOdsConfigurations3() {
		LOGGER.info("Entering testGetOdsConfigurations3");
		ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
		odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsKeyDetails.setFlowNodeStepName("AddONT_Test");
		odsKeyDetails.setAppKey("Test-ODS-Key");
		odsKeyDetails.setRegion("NORTH");
		List<OdsServiceRouterMapDetails> odsSvcRouterDetails = new ArrayList<>();
		OdsServiceRouterMapDetails odsServiceRouterMapDetails = mock(OdsServiceRouterMapDetails.class);
		try {
			when(odsServiceRouteMapSvc.getServiceRouteMapRecords(odsServiceRouterMapDetails))
					.thenReturn(odsSvcRouterDetails);

			odsConfigService.getOdsConfigurations(odsKeyDetails);
		} catch (ApplicationException e) {
			LOGGER.error("Exception occurred - ", e);
		}
		LOGGER.info("Exiting testGetOdsConfigurations3");
	}

	@Test
	public void testDeleteOdsConfiguration() {
		LOGGER.info("Entering testDeleteOdsConfiguration");
		ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
		odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsKeyDetails.setFlowNodeStepName("AddONT_Test");
		odsKeyDetails.setAppKey("Test-ODS-Key");

		try {
			List<OdsServiceRouterMapDetails> serviceRouteMapList = new ArrayList<>();
			serviceRouteMapList.add(new OdsServiceRouterMapDetails(odsKeyDetails.getAppKey(),
					odsKeyDetails.getFlowNodeProcessName(), odsKeyDetails.getFlowNodeStepName()));
			serviceRouteMapList.add(new OdsServiceRouterMapDetails(odsKeyDetails.getAppKey(),
					odsKeyDetails.getFlowNodeProcessName() + Constants.MILESTONE_CONSTANT,
					odsKeyDetails.getFlowNodeStepName() + Constants.MILESTONE_CONSTANT));

			doNothing().when(odsServiceRouteMapSvc).deleteServiceRouteMapRecord(serviceRouteMapList);

			List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<>();
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			odsMandatoryAttributes.setAttrKey(odsKeyDetails.getFlowNodeProcessName() + Constants.KEYBUILDER_SEPERATOR
					+ odsKeyDetails.getFlowNodeStepName());
			odsMandatoryAttrsList.add(odsMandatoryAttributes);
			when(odsMandatoryAttrsSvc.getMandatoryAttributeList(odsKeyDetails.getFlowNodeProcessName()
					+ Constants.KEYBUILDER_SEPERATOR + odsKeyDetails.getFlowNodeStepName()))
							.thenReturn(odsMandatoryAttrsList);

			doNothing().when(odsMandatoryAttrsSvc).deleteOdsMandatoryAttrsRecord(odsMandatoryAttrsList);

			List<OdsParamConfig> odsParamConfigList = new ArrayList<>();
			OdsParamConfig odsParamConfig = new OdsParamConfig();
			odsParamConfig.setParamKey(odsKeyDetails.getFlowNodeProcessName() + Constants.KEYBUILDER_SEPERATOR
					+ odsKeyDetails.getFlowNodeStepName());
			odsParamConfigList.add(odsParamConfig);
			when(odsParamConfigSvc.getOdsParamConfigRecords(Mockito.any())).thenReturn(odsParamConfigList);
			odsParamConfigSvc.deleteOdsParamConfigRecord(odsParamConfigList);

			List<OdsRequestTransactionIdMap> odsReqTransactionIdMapList = new ArrayList<>();
			odsReqTransactionIdMapList.add(new OdsRequestTransactionIdMap(odsKeyDetails.getFlowNodeProcessName(),
					odsKeyDetails.getFlowNodeStepName()));
			doNothing().when(odsReqResTIdMapService).deleteOdsRequestTransIdMapRecord(odsReqTransactionIdMapList);

			List<WorkflowFalloutConfig> workflowFalloutConfigList = new ArrayList<>();
			WorkflowFalloutConfig workflowFalloutConfig = new WorkflowFalloutConfig();
			workflowFalloutConfig.setWorkFlowStepName(odsKeyDetails.getFlowNodeStepName());
			workflowFalloutConfig.setWorkflowProcessName(odsKeyDetails.getFlowNodeProcessName());
			workflowFalloutConfigList.add(workflowFalloutConfig);
			when(odsWorkFlowFalloutConfigService.getWorkflowFalloutConfig(Mockito.any()))
					.thenReturn(workflowFalloutConfigList);
			OdsTransformerConfig odsTransformerConfig= new OdsTransformerConfig();
			odsTransformerConfig.setTransformerKey("TestKey");
			doNothing().when(odsTransformerConfigService).deleteOdsTransformerConfigRecord(odsTransformerConfig);

			odsConfigService.deleteOdsConfiguration(odsKeyDetails);
		} catch (ApplicationException e) {
			LOGGER.error("Exception occurred - ", e);
		}
		LOGGER.info("Exiting testDeleteOdsConfiguration");
	}
	
	@Test
	public void testCreateOrUpdateOdsConfig() {
		LOGGER.info("Entering testCreateOrUpdateOdsConfig");
		ODSConfigPayload payLoad = new ODSConfigPayload();
		List<WorkflowFalloutConfig> workflowFalloutConfigList = new ArrayList<>();
		ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
		odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsKeyDetails.setFlowNodeStepName("AddONT_Test");
		odsKeyDetails.setAppKey("Test-ODS-Key");
		WorkflowFalloutConfig workflowFalloutConfig = new WorkflowFalloutConfig();
		workflowFalloutConfig.setWorkFlowStepName(odsKeyDetails.getFlowNodeStepName());
		workflowFalloutConfig.setWorkflowProcessName(odsKeyDetails.getFlowNodeProcessName());
		workflowFalloutConfigList.add(workflowFalloutConfig);
		payLoad.setWorkflowFalloutConfig(workflowFalloutConfigList);
		payLoad.setKeyDetails(odsKeyDetails);
		
		try {
			when(odsWorkFlowFalloutConfigService.createOrUpdateWorkflowFalloutConfig(workflowFalloutConfig)).thenReturn(workflowFalloutConfig);

			odsConfigService.createOrUpdateOdsConfig(payLoad);
		} catch (ApplicationException e) {
			LOGGER.error("Exception occurred - ", e);
		}
		LOGGER.info("Exiting testCreateOrUpdateOdsConfig");
	}

	@Test
	public void testCreateOrUpdateOdsConfig1() {
		LOGGER.info("Entering testCreateOrUpdateOdsConfig1");
		ODSConfigPayload payLoad = new ODSConfigPayload();
		ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
		odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsKeyDetails.setFlowNodeStepName("AddONT_Test");
		odsKeyDetails.setAppKey("Test-ODS-Key");
		OdsTransformerConfig odsTransformerConfig= new OdsTransformerConfig();
		odsTransformerConfig.setTransformerKey("TestKey");
		payLoad.setOdsTransformerConfig(odsTransformerConfig);
		payLoad.setKeyDetails(odsKeyDetails);
		
		try {
			when(odsTransformerConfigService.createOrUpdateOdsTransformerConfig(odsTransformerConfig)).thenReturn(odsTransformerConfig);

			odsConfigService.createOrUpdateOdsConfig(payLoad);
		} catch (ApplicationException e) {
			LOGGER.error("Exception occurred - ", e);
		}
		LOGGER.info("Exiting testCreateOrUpdateOdsConfig1");
	}

	@Test
	public void testCreateOrUpdateOdsConfig2() {
		LOGGER.info("Entering testCreateOrUpdateOdsConfig2");
		ODSConfigPayload payLoad = new ODSConfigPayload();
		ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
		odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsKeyDetails.setFlowNodeStepName("AddONT_Test");
		odsKeyDetails.setAppKey("Test-ODS-Key");
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setDestinationAppName("testapp");
		odsMilestoneConfig.setMilestoneName("milestone");
		List<OdsMilestoneConfig> odsMilestoneConfigRspList = new ArrayList<>();
		odsMilestoneConfigRspList.add(odsMilestoneConfig);
		payLoad.setOdsMilestoneConfig(odsMilestoneConfigRspList);
		payLoad.setKeyDetails(odsKeyDetails);
		
		try {
			when(odsMilestoneConfigService.createOrUpdateMilestoneConfig(odsMilestoneConfig)).thenReturn(odsMilestoneConfig);

			odsConfigService.createOrUpdateOdsConfig(payLoad);
		} catch (ApplicationException e) {
			LOGGER.error("Exception occurred - ", e);
		}
		LOGGER.info("Exiting testCreateOrUpdateOdsConfig2");
	}

}
