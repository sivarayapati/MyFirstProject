package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.dao.DataIntegrityViolationException;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveHandleFalloutRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveWorkflowFalloutRequest;
import com.vz.uiam.onenet.ods.service.ResolveFalloutService;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class ResolveFalloutServiceControllerMockitoTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ResolveFalloutServiceControllerMockitoTest.class);

	@InjectMocks
	ResolveFalloutServiceController resolveFalloutServiceController;

	@Mock
	ResolveFalloutService resolveFalloutService;

	@Mock
	ServiceUtils serviceUtils;

	@SuppressWarnings("unchecked")
	@Test
	public void testHandleFallout() throws ApplicationException {

		LOGGER.info("Entering testHandleFallout");

		ResolveHandleFalloutRequest request = Mockito.mock(ResolveHandleFalloutRequest.class);
		when(resolveFalloutService.handleFallout(request)).thenThrow(DataIntegrityViolationException.class);
		resolveFalloutServiceController.handleFallout(request);
		LOGGER.info("Exiting testHandleFallout");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testHandleFallout1() throws ApplicationException {

		LOGGER.info("Entering testHandleFallout1");

		ResolveHandleFalloutRequest request = Mockito.mock(ResolveHandleFalloutRequest.class);
		when(resolveFalloutService.handleFallout(request)).thenThrow(ApplicationException.class);
		resolveFalloutServiceController.handleFallout(request);
		LOGGER.info("Exiting testHandleFallout1");

	}

	@Test
	public void testCreateFallout() throws ApplicationException {

		LOGGER.info("Entering testCreateFallout");

		ResolveWorkflowFalloutRequest request = Mockito.mock(ResolveWorkflowFalloutRequest.class);
		Mockito.doThrow(SQLException.class).when(resolveFalloutService).createFallout(request);

		resolveFalloutServiceController.createFallout(request);
		LOGGER.info("Exiting testCreateFallout");

	}

}
