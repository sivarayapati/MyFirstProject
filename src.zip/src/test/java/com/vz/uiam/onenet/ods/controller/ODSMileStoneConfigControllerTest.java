package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class ODSMileStoneConfigControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSMileStoneConfigControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	OdsMilestoneConfigController odsMilestoneConfigController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	/**
	 * 
	 */
	@Test
	public void testdeleteOdsMilestoneConfig() {
		try {
			LOGGER.info("****************************Entering to testdeleteOdsMilestoneConfig*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneConfig/delete");
			Set<OdsMilestoneConfig> odsMilestoneConfigList = new HashSet<OdsMilestoneConfig>();
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();

			odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
			odsMilestoneConfig.setRequestDocumentName("TEST-Message");
			odsMilestoneConfig.setRequestSchema("{test:$.test}");
			odsMilestoneConfig.setTransformationType("JSON");
			odsMilestoneConfig.setRouteProtocol("REST");
			odsMilestoneConfig.setSendMilestone("YES");
			odsMilestoneConfig.setSendFalloutNotification("NO");

			odsMilestoneConfigList.add(odsMilestoneConfig);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMilestoneConfigList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testdeleteOdsMilestoneConfig*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for testdeleteOdsMilestoneConfig: ",e);
		}
	}
	
	@Test
	@SqlGroup({	@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql")})
	public void testdeleteOdsMilestoneConfig1() {
		try {
			LOGGER.info("****************************Entering to testdeleteOdsMilestoneConfig1*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneConfig/delete");
			Set<OdsMilestoneConfig> odsMilestoneConfigList = new HashSet<OdsMilestoneConfig>();
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
			odsMilestoneConfig.setOdsMilestoneConfigId(111);
			odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
			odsMilestoneConfig.setRequestDocumentName("TEST-Message");
			odsMilestoneConfig.setRequestSchema("{test:$.test}");
			odsMilestoneConfig.setTransformationType("JSON");
			odsMilestoneConfig.setRouteProtocol("REST");
			odsMilestoneConfig.setSendMilestone("YES");
			odsMilestoneConfig.setSendFalloutNotification("NO");

			odsMilestoneConfigList.add(odsMilestoneConfig);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMilestoneConfigList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testdeleteOdsMilestoneConfig2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for testdeleteOdsMilestoneConfig: ",e);
		}
	}

	@Test
	@SqlGroup({	@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql")})
	public void testdeleteOdsMilestoneConfig2() {
		try {
			LOGGER.info("****************************Entering to testdeleteOdsMilestoneConfig2*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneConfig/delete");
			Set<OdsMilestoneConfig> odsMilestoneConfigList = new HashSet<OdsMilestoneConfig>();
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
			odsMilestoneConfig.setOdsMilestoneConfigId(112);
			odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
			odsMilestoneConfig.setRequestDocumentName("TEST-Message");
			odsMilestoneConfig.setRequestSchema("{test:$.test}");
			odsMilestoneConfig.setTransformationType("JSON");
			odsMilestoneConfig.setRouteProtocol("REST");
			odsMilestoneConfig.setSendMilestone("YES");
			odsMilestoneConfig.setSendFalloutNotification("NO");
			OdsServiceRouterMapDetails details = new OdsServiceRouterMapDetails();
			details.setId(222);
		
			odsMilestoneConfigList.add(odsMilestoneConfig);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMilestoneConfigList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testdeleteOdsMilestoneConfig2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for testdeleteOdsMilestoneConfig: ",e);
		}
	}
	@Test
	@SqlGroup({	@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql")})
	public void testdeleteOdsMilestoneConfig3() {
		try {
			LOGGER.info("****************************Entering to testdeleteOdsMilestoneConfig3*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneConfig/delete");
			Set<OdsMilestoneConfig> odsMilestoneConfigList = new HashSet<OdsMilestoneConfig>();
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
			odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
			odsMilestoneConfig.setFlowNodeProcessName("Test11");
			odsMilestoneConfigList.add(odsMilestoneConfig);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMilestoneConfigList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testdeleteOdsMilestoneConfig3*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for testdeleteOdsMilestoneConfig: ",e);
		}
	}
	
	
	/**
	 * 
	 */
	@Test
	public void testCreateOrUpdateMilestoneConfig() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateMilestoneConfig*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneConfig/createOrUpdate");
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
			odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
			odsMilestoneConfig.setRequestDocumentName("TEST-Message");
			odsMilestoneConfig.setRequestSchema("{test:$.test}");
			odsMilestoneConfig.setTransformationType("JSON");
			odsMilestoneConfig.setRouteProtocol("REST");
			odsMilestoneConfig.setSendMilestone("YES");
			odsMilestoneConfig.setSendFalloutNotification("NO");
			odsMilestoneConfig.setDestinationAppName("testApp");
			odsMilestoneConfig.setFlowNodeProcessName("Test11");
			odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
			odsMilestoneConfig.setMilestoneName("Milestone2");

			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMilestoneConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateMilestoneConfig*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateMilestoneConfig: ",e);
		}
	}
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql")
		})
	public void testCreateOrUpdateMilestoneConfig1() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateMilestoneConfig1*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneConfig/createOrUpdate");
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
			odsMilestoneConfig.setOdsMilestoneConfigId(112);
			odsMilestoneConfig.setRequestDocumentName("TEST-Message1");
			odsMilestoneConfig.setRequestSchema("{test:$.test}");
			odsMilestoneConfig.setTransformationType("JSON");
			odsMilestoneConfig.setRouteProtocol("REST");
			odsMilestoneConfig.setSendMilestone("YES");
			odsMilestoneConfig.setSendFalloutNotification("NO");
			odsMilestoneConfig.setDestinationAppName("testApp");
			odsMilestoneConfig.setFlowNodeProcessName("Test11");
			odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
			odsMilestoneConfig.setMilestoneName("Milestone2");

			
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMilestoneConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateMilestoneConfig1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateMilestoneConfig: ",e);
		}
	}
	
	@Test
	public void testCreateOrUpdateMilestoneConfig2() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateMilestoneConfig2*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneConfig/createOrUpdate");
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
			odsMilestoneConfig.setOdsMilestoneConfigId(113);
			odsMilestoneConfig.setRequestDocumentName("TEST-Message1");
			
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMilestoneConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateMilestoneConfig2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateMilestoneConfig: ",e);
		}
	}
	
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql")
		})
	public void testgetOdsMilestoneConfig() {
		try {
			LOGGER.info("****************************Entering to testgetOdsMilestoneConfig*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneConfig/get");
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
			odsMilestoneConfig.setFlowNodeProcessName("Test11");
			odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
			
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMilestoneConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testgetOdsMilestoneConfig*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsMilestoneConfig: ",e);
		}
	}
	@Test
	public void testgetOdsMilestoneConfig1() {
		try {
			LOGGER.info("****************************Entering to testgetOdsMilestoneConfig1*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneConfig/get");
			OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
			odsMilestoneConfig.setFlowNodeProcessName("Test11");
			odsMilestoneConfig.setFlowNodeStepName("");
			
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMilestoneConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testgetOdsMilestoneConfig1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsMilestoneConfig: ",e);
		}
	}
	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}
}
