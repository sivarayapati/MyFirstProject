package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.javers.common.collections.Arrays;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformationResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformedResponsePayload;
import com.vz.uiam.onenet.ods.service.OdsParamConfigService;
import com.vz.uiam.onenet.ods.transformer.XMLTransformer;
import com.vz.uiam.onenet.ods.util.ServiceUtils;


@RunWith(MockitoJUnitRunner.class)
public class ServiceUtilsTest {
	
	private static final Logger LOGGER = Logger.getLogger(ServiceUtilsTest.class);
	
	@InjectMocks
	ServiceUtils serviceUtils;
	
	@Mock
	RestTemplate restTemplate;
	
	@Mock
	HttpEntity<String> httpEntity;
	
	@Mock
	ResponseEntity<String> responseEntity;
	
	@Mock
	OdsParamConfigService odsParamConfigService;
	
	@Mock
	OdsParamConfigRepository odsParamConfigRepository;

	ServiceUtils svcUtils = new ServiceUtils();
	
	@Test
	public void testPopulateJsonPayload() {
		LOGGER.info("Entering testPopulateJsonPayload----------");
		
		String jsonSchema = "{ 	\"doc\" : { 		\"id\" : \"$.transactionId\", 		\"details\": [{ 			\"order_details\" : { 				\"order_number\": \"$.ORDER_NUMBER\" 			}, 			\"circuit_id\": \"$.CIRCUIT_ID\", 			\"region_s\" : \"$.STATE\" 		}], 		\"notes_type\" : \"Interface Notes\", 		\"user\" : \"SYSTEM\", 		\"notes_date\" : \"fn-sysdate(yyyy-MM-dd)\", 		\"workflow_step_s\" : \"OrderValidation\", 		\"correlation_id\": \"fn-concat(|,$.ORDER_NUMBER,$.CIRCUIT_ID,$.STATE)\" 	} }	";
		String json = "{ 	\"transactionId\": \"563\", 	\"ORDER_NUMBER\": \"ORD563\", 	\"CIRCUIT_ID\": \"CKT563\", 	\"STATE\": \"NA\" }";
		
		JSONObject outputJsonObj = new JSONObject();
		try {
			svcUtils.populateJsonPayload(jsonSchema, json, outputJsonObj);
		} catch (ApplicationException e) {
			LOGGER.error(e);
		}
		
		LOGGER.info(outputJsonObj);
		LOGGER.info("Exiting testPopulateJsonPayload----------");
	}
	
	@Test
	public void testAddOrUpdateJsonProperty() {
		LOGGER.info("Entering testAddOrUpdateJsonProperty----------");
		
		JSONObject inputJsonObj = null;
		try {
			String jsonString = "{ 	\"key1\": { 		\"key2\": \"SpecialPlanningMessage\", 		\"key3\": \"ZZZDE-NGPON2\", 		\"key4\": { 			\"key5\": [{ 				\"key6\": \"order_number\" 			}, { 				\"key6\": \"order_version\" 			}] 		} 	} }";
			inputJsonObj = new JSONObject(jsonString);
			
			String jsonSchema = "$.key1.key2";
			svcUtils.addOrUpdateJsonProperty(inputJsonObj, jsonSchema, "order1");
			LOGGER.info(inputJsonObj);
			
			jsonSchema = "$.key1.key4.key7.key8.key9.key10.key11";
			svcUtils.addOrUpdateJsonProperty(inputJsonObj, jsonSchema, "order2");
			LOGGER.info(inputJsonObj);
			
			jsonSchema = "$.key1.key4.key7.key20[0].key21.key22[0].key23";
			svcUtils.addOrUpdateJsonProperty(inputJsonObj, jsonSchema, "order3");
			LOGGER.info(inputJsonObj);
			
			jsonSchema = "$.key1.key4.key7.key20[0].key21.key22[1].key23";
			svcUtils.addOrUpdateJsonProperty(inputJsonObj, jsonSchema, "order4");
			LOGGER.info(inputJsonObj);
		} catch (ApplicationException e) {
			LOGGER.error(e);
		}
		
		LOGGER.info("Exiting testAddOrUpdateJsonProperty----------");
	}
	
	@Test(expected=Exception.class)
	public void testAddOrUpdateJsonProperty2() throws ApplicationException {
		LOGGER.info("Entering testAddOrUpdateJsonProperty2----------");
		
		String jsonSchema = "$.key1.key2";
		svcUtils.addOrUpdateJsonProperty(null, jsonSchema, "order4");
	}
	
	@Test
	public void testGetValueFromJson() {
		LOGGER.info("Entering testGetValueFromJson----------");
		
		String json = "{ 	\"nbaTransaction\": { 		\"statuscode\":  \"V0000\" } }";
		String jsonKey = "statuscode";
		String val = "";
		
		try {
			val = svcUtils.getValueFromJson(json, jsonKey);
		} catch (ApplicationException e) {
			LOGGER.error(e);
		}
		
		LOGGER.info(val);
		LOGGER.info("Exiting testGetValueFromJson----------");
	}
	
	@Test(expected=Exception.class)
	public void testGetValueFromJson2() throws ApplicationException {
		LOGGER.info("Entering testGetValueFromJson2----------");
		
		svcUtils.getValueFromJson("", "statuscode");
	}
	
	@Test
	public void testGetRootTagFromJson() {
		LOGGER.info("Entering testGetRootTagFromJson----------");
		
		String json = "{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"V0000\" 		} 	} }";
		String rootTag = "";
		
		try {
			rootTag = svcUtils.getRootTagFromJson(json);
		} catch (ApplicationException e) {
			LOGGER.error(e);
		}		
		LOGGER.info(rootTag);
		
		try {
			json = "";
			rootTag = svcUtils.getRootTagFromJson(json);
		} catch (ApplicationException e) {
			LOGGER.error(e);
		}		
		LOGGER.info(rootTag);
		
		
		LOGGER.info("Exiting testGetRootTagFromJson----------");
	}
	
	@Test
	public void testReadValueFromJson() {
		LOGGER.info("Entering testReadValueFromJson----------");
		
		String json = "{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"V0000\" 		}, 		\"attribute\": [{ 			\"name\": \"ORDER\", 			\"content\": \"CHANDRA_RTRV_OLT\" 		}, 		{ 			\"name\": \"TRANSACTION_ID\", 			\"content\": \"1496908132707|34567|7654\" 		}] 	} }";
		String jsonKey = null;
		String val = "";
		
		try {
			jsonKey = "$.nbaTransaction.statuscode";
			val = svcUtils.readValueFromJson(json, jsonKey);
			LOGGER.info(val);
			
			jsonKey = "$.nbaTransaction.attribute";
			val = svcUtils.readValueFromJson(json, jsonKey);
			LOGGER.info(val);
		} catch (ApplicationException e) {
			LOGGER.error(e);
		}
		
		try {
			json = " {}";
			val = svcUtils.readValueFromJson(json, jsonKey);
			LOGGER.info(val);
		} catch (ApplicationException e) {
			LOGGER.error(e);
		}
		
		LOGGER.info("Exiting testReadValueFromJson----------");
	}
	
	@Test(expected=Exception.class)
	public void testConvertJsonStringToObject() throws ApplicationException {
		LOGGER.info("Entering testConvertJsonStringToObject----------");
		
		LOGGER.info(svcUtils.convertJsonStringToObject("order", String.class));
	}
	
	@Test(expected=Exception.class)
	public void testConvertXmlToJson() throws ApplicationException {
		LOGGER.info("Entering testConvertXmlToJson----------");
		
		LOGGER.info(svcUtils.convertXmlToJson(null));
	}
	
	@Test
	public void testMergeJSONObjects() {
		LOGGER.info("Entering testMergeJSONObjects----------");
		
		String json1 = "{ 	\"nbaTransaction1\": { 		\"statuscode\":  \"V0000\" } }";
		String json2 = "{ 	\"nbaTransaction2\": { 		\"statuscode\":  \"V1111\" } }";
		JSONObject mergedJson = null;
		
		try {
			mergedJson = svcUtils.mergeJSONObjects(new JSONObject(json1), new JSONObject(json2));
		} catch (ApplicationException e) {
			LOGGER.error(e);
		}
		
		LOGGER.info(mergedJson);
		LOGGER.info("Exiting testMergeJSONObjects----------");
	}
	
	@Test
	public void testGenerateTransactionIdUsingTransactionIdKey() {
		LOGGER.info("Entering testGenerateTransactionIdUsingTransactionIdKey----------");
		
		String json = "{ 	\"nbaTransaction\": { 		\"statuscode\": \"V0000\" 	}, 	\"transactionId\": \"563\" }";
		String transactionIdRspKey = "$.transactionId";
		
		try {
			svcUtils.generateTransactionIdUsingTransactionIdKey(json, transactionIdRspKey);
		} catch (ApplicationException e) {
			LOGGER.error(e);
		}
		
		LOGGER.info("Exiting testGenerateTransactionIdUsingTransactionIdKey----------");
	}
	
	@Test(expected=Exception.class)
	public void testGenerateTransactionIdUsingTransactionIdKey2() throws ApplicationException {
		LOGGER.info("Entering testGenerateTransactionIdUsingTransactionIdKey2----------");
		
		String json = "{ 	\"nbaTransaction\": { 		\"statuscode\": \"V0000\" 	}, 	\"transactionId\": \"563\" }";
		LOGGER.info(svcUtils.generateTransactionIdUsingTransactionIdKey(json, null));
	}
	
	@Test
	public void testPrepareOdsParamErrorMsg() {
		LOGGER.info("Entering testPrepareOdsParamErrorMsg----------");
		
		svcUtils.prepareOdsParamErrorMsg("ODS", "ODS_PARAM", "GET_MANIFEST_ENDPOINT_URL", null);
		
		List<String> namesList = (ArrayList) Arrays.asList(new String[]{"VNM_TIMEOUT", "VNM_RESPONSE_URL"});
		svcUtils.prepareOdsParamErrorMsg("ODS", "ODS_PARAM", "", namesList);
		
		LOGGER.info("Exiting testPrepareOdsParamErrorMsg----------");
	}
	
	@Test(expected=Exception.class)
	public void testGetTransformerInstance() throws ApplicationException {
		LOGGER.info("Entering testGetTransformerInstance----------");
		
		LOGGER.info(svcUtils.getTransformerInstance(null));
	}
	
	@Test
	public void testHandleTransformationResponse() {
		LOGGER.info("Entering testHandleTransformationResponse----------");
		
		svcUtils.handleTransformationResponse("V000", "SUCCESS", new TransformationResponse(), "{}");
		
		LOGGER.info("Exiting testHandleTransformationResponse----------");
	}
	
	@Test
	public void testBase64Encode() {
		LOGGER.info("Entering testBase64Encode----------");
		
		try {
			ServiceUtils.base64Encode("xZbuT");
		} catch (ApplicationException e) {
			LOGGER.error(e);
		}
		
		LOGGER.info("Exiting testBase64Encode----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testBase64Encode1() throws ApplicationException {
		LOGGER.info("Entering testBase64Encode1----------");
		
		ServiceUtils.base64Encode(null);
		
		LOGGER.info("Exiting testBase64Encode1----------");
	}
	
	@Test
	public void testBase64Decode() {
		LOGGER.info("Entering testBase64Decode----------");
		
		try {
			ServiceUtils.base64Decode("YXNoaXNo");
		} catch (ApplicationException e) {
			LOGGER.error(e);
		}
		
		LOGGER.info("Exiting testBase64Decode----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testBase64Decode1() throws ApplicationException {
		LOGGER.info("Entering testBase64Decode1----------");
		
		ServiceUtils.base64Decode(null);
		
		LOGGER.info("Exiting testBase64Decode1----------");
	}
	
	@Test
	public void testCallService1() throws ApplicationException {
		LOGGER.info("Entering testCallService1----------");
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntity);
		serviceUtils.callService(new OdsParamConfig(), httpEntity);
		
		LOGGER.info("Exiting testCallService1----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testCallService2() throws ApplicationException {
		LOGGER.info("Entering testCallService2----------");
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenThrow(Exception.class);
		serviceUtils.callService(new OdsParamConfig(), httpEntity);
		
		LOGGER.info("Exiting testCallService2----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testGetTransformationPayload1() throws ApplicationException {
		LOGGER.info("Entering testGetTransformationPayload1----------");
		
		serviceUtils.getTransformationPayload(new TransformedResponsePayload(), "{}", "SOAP");
		
		LOGGER.info("Exiting testGetTransformationPayload1----------");
	}
	
	@Test
	public void testGetTransformationPayload2() throws ApplicationException {
		LOGGER.info("Entering testGetTransformationPayload1----------");
		
		serviceUtils.getTransformationPayload(new TransformedResponsePayload(), "{}", "REST");
		
		LOGGER.info("Exiting testGetTransformationPayload2----------");
	}
	
	@Test
	public void testGetTransformationPayload3() throws ApplicationException {
		LOGGER.info("Entering testGetTransformationPayload3----------");
		
		serviceUtils.getTransformationPayload(new TransformedResponsePayload(), "{}", "MQ");
		
		LOGGER.info("Exiting testGetTransformationPayload3----------");
	}
	
	@Test
	public void testPopulateValues() throws ApplicationException {
		LOGGER.info("Entering testPopulateValues----------");
		
		String schemaVal = "{ \"inputXml\": \"fn-transformXML()\" }";
		String requestJsonStr = "{ \"requestPayload\": { \"app-key\":\"ZZZZ-Testing\" } }";
		
		XMLTransformer xmlTransformer = Mockito.mock(XMLTransformer.class);
		
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		Mockito.doNothing().when(serviceUtilsSpy).updateRequestJsonObjectWithAppParams(anyString(), Mockito.any(), anyString(), anyString());
		Mockito.doReturn("XMLTransformer").when(serviceUtilsSpy).getTransformerClass(anyString());
		Mockito.doReturn(xmlTransformer).when(serviceUtilsSpy).getTransformerInstance(anyString());
		Mockito.when(xmlTransformer.doTransform(Mockito.any(), Mockito.any())).thenReturn("transformed_doc");
		
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		
		LOGGER.info("Exiting testPopulateValues----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testgetManifestDocument1() throws ApplicationException {
		LOGGER.info("Entering testgetManifestDocument1----------");
		
		Mockito.when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString())).thenReturn(null);
		
		serviceUtils.getManifestDocument("{}");
		
		LOGGER.info("Exiting testgetManifestDocument1----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testgetManifestDocument2() throws ApplicationException {
		LOGGER.info("Entering testgetManifestDocument2----------");
		
		Mockito.when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString())).thenReturn(new OdsParamConfig());
		
		serviceUtils.getManifestDocument("{}");
		
		LOGGER.info("Exiting testgetManifestDocument2----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testgetManifestDocument3() throws ApplicationException {
		LOGGER.info("Entering testgetManifestDocument3----------");
		
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("http://manifest.vz.com");
		
		Mockito.when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString())).thenReturn(odsParamConfig);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenThrow(Exception.class);
		
		serviceUtils.getManifestDocument("{}");
		
		LOGGER.info("Exiting testgetManifestDocument3----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testgetManifestDocument4() throws ApplicationException {
		LOGGER.info("Entering testgetManifestDocument4----------");
		
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("http://manifest.vz.com");
		
		Mockito.when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString())).thenReturn(odsParamConfig);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
		
		serviceUtils.getManifestDocument("{}");
		
		LOGGER.info("Exiting testgetManifestDocument4----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testgetManifestDocument5() throws ApplicationException {
		LOGGER.info("Entering testgetManifestDocument5----------");
		
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("http://manifest.vz.com");
		
		Mockito.when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString())).thenReturn(odsParamConfig);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		when(responseEntity.getBody()).thenReturn("");
		
		serviceUtils.getManifestDocument("{}");
		
		LOGGER.info("Exiting testgetManifestDocument5----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testTetTransformerInstance() throws ApplicationException {
		LOGGER.info("Entering testTetTransformerInstance----------");
		
		serviceUtils.getTransformerInstance("com.vz.uiam.onenet.ods.transforme.XTransformer");
		
		LOGGER.info("Exiting testTetTransformerInstance----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testUpdateRequestJsonObjectWithAppParams1() throws ApplicationException {
		LOGGER.info("Entering testUpdateRequestJsonObjectWithAppParams1----------");
		
		serviceUtils.updateRequestJsonObjectWithAppParams("ODS", new JSONObject(), "", "");
		
		LOGGER.info("Exiting testUpdateRequestJsonObjectWithAppParams1----------");
	}
	
	@Test
	public void testUpdateRequestJsonObjectWithAppParams2() throws ApplicationException {
		LOGGER.info("Entering testUpdateRequestJsonObjectWithAppParams2----------");
		
		serviceUtils.updateRequestJsonObjectWithAppParams("ODS", new JSONObject(), "{}", "JSON");
		
		LOGGER.info("Exiting testUpdateRequestJsonObjectWithAppParams2----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testUpdateRequestJsonObjectWithAppParams3() throws ApplicationException {
		LOGGER.info("Entering testUpdateRequestJsonObjectWithAppParams3----------");
		
		String requestSchema = "{ \"key1\":\"$.ApplicationParam.notesUrl\" }";
		
		Mockito.when(odsParamConfigService.getOdsParamConfigByParamKeyAndTypeAndNameIn(any(),any(),any())).thenReturn(null);
		
		serviceUtils.updateRequestJsonObjectWithAppParams("ODS", new JSONObject(), requestSchema, "JSON");
		
		LOGGER.info("Exiting testUpdateRequestJsonObjectWithAppParams3----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testGetTransformerClass() throws ApplicationException {
		LOGGER.info("Entering testGetTransformerClass----------");
		
		Mockito.when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), Mockito.any())).thenReturn(null);
		serviceUtils.getTransformerClass("JSON");
		
		LOGGER.info("Exiting testGetTransformerClass----------");
	}
	
	@Test()
	public void testExtractQueryParametersWhenParamsPresent() throws ApplicationException {
		LOGGER.info("Entering testExtractQueryParametersWhenParamsPresent----------");
		String targetEndPointUrl ="http://vnmws.ebiz.verizon.com/DispatchCommonGateway/DispatchRequest?typenm=create&token=IVAPP";
		JSONObject doc =new JSONObject(getfinaldocument());
		LOGGER.info(svcUtils.extractQueryParameters(targetEndPointUrl , doc));
		LOGGER.info("Exiting testExtractQueryParametersWhenParamsPresent----------");
	}
	
	@Test()
	public void testExtractQueryParametersWhenParamsAbsent() throws ApplicationException {
		LOGGER.info("Entering testExtractQueryParametersWhenParamsAbsent----------");
		String targetEndPointUrl ="http://vnmws.ebiz.verizon.com/DispatchCommonGateway/DispatchRequest";
		JSONObject doc =new JSONObject(getfinaldocument());
		LOGGER.info(svcUtils.extractQueryParameters(targetEndPointUrl , doc));
		LOGGER.info("Exiting testExtractQueryParametersWhenParamsAbsent----------");
	}
	
	@Test(expected=ApplicationException.class)
	public void testExtractQueryParametersWhenURLAbsent() throws ApplicationException {
		LOGGER.info("Entering testExtractQueryParametersWhenURLAbsent----------");
		String targetEndPointUrl =null;
		JSONObject doc =new JSONObject(getfinaldocument());
		LOGGER.info(svcUtils.extractQueryParameters(targetEndPointUrl,doc));
		LOGGER.info("Exiting testExtractQueryParametersWhenURLAbsent----------");
	}
	@Test(expected=ApplicationException.class)
	public void testExtractQueryParametersWhenURLIsMalformed() throws ApplicationException {
		LOGGER.info("Entering testExtractQueryParametersWhenURLIsMalformed----------");
		String targetEndPointUrl ="DispatchCommonGateway\\DispatchRequest&&typenm=create&token=IVAPP";
		JSONObject doc =new JSONObject(getfinaldocument());
		LOGGER.info(svcUtils.extractQueryParameters(targetEndPointUrl,doc));
		LOGGER.info("Exiting testExtractQueryParametersWhenURLIsMalformed----------");
	}
	@Test()
	public void testExtractQueryParametersWhenParamsPresentwithSchemaValue() throws ApplicationException {
		LOGGER.info("Entering testExtractQueryParametersWhenParamsPresentwithSchemaValue----------");
		String targetEndPointUrl ="https://vnmws.ebiz.verizon.com/ivappVideoRestWS/OnmActivationRestServices/activateNonBlocking?order_Number=$.requestPayload.seedInfo.order_number";
		JSONObject doc =new JSONObject(getfinaldocument());
		LOGGER.info(svcUtils.extractQueryParameters(targetEndPointUrl , doc));
		LOGGER.info("Exiting testExtractQueryParametersWhenParamsPresentwithSchemaValue----------");
	}
	@Test
	public void testGenerateDynamicTragetEndPointUrl() throws ApplicationException {
		LOGGER.info("Entering testGenerateDynamicTragetEndPointUrl");
		
		OdsParamConfig odsParam = new OdsParamConfig();
		odsParam.setParamKey("ZZZDE-NGPON2");
		odsParam.setType("APPLICATION_PARAM");
		odsParam.setName("serviceUrl");
		odsParam.setValue("https://vnmws.ebiz.verizon.com?token=COPRV&refId=1127201700");
		
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString())).thenReturn(odsParam);
		
        JSONObject jsonDocument = new JSONObject(getfinaldocument());
		serviceUtils.generateDynamicTargetEndPointUrl(jsonDocument, "$.ApplicationParam.serviceUrl/ivappVideoRestWS/OnmActivationRestServices/activateNonBlocking","ZZZDE-NGPON2");
		
		LOGGER.info("Exiting testGenerateDynamicTragetEndPointUrl");
	}
	
	@Test(expected=ApplicationException.class)
	public void testGenerateDynamicTargetEndPointUrl1() throws ApplicationException {
		LOGGER.info("Entering testGenerateDynamicTragetEndPointUrl1");
		
		OdsParamConfig odsParam = new OdsParamConfig();
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString())).thenReturn(odsParam);
		
        JSONObject jsonDocument = new JSONObject(getfinaldocument());
       	serviceUtils.generateDynamicTargetEndPointUrl(jsonDocument, "$.ApplicationParam.serviceUrl/ivappVideoRestWS/OnmActivationRestServices/activateNonBlocking","ZZZDE-NGPON2");
       	
		LOGGER.info("Exiting testGenerateDynamicTragetEndPointUrl1");
	}
	
	@Test(expected=ApplicationException.class)
	public void testGenerateDynamicTragetEndPointUrl2() throws ApplicationException {
		LOGGER.info("Entering testGenerateDynamicTragetEndPointUrl2");
		
		OdsParamConfig odsParam = null;
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString())).thenReturn(odsParam);
		
        JSONObject jsonDocument=new JSONObject(getfinaldocument());
       	serviceUtils.generateDynamicTargetEndPointUrl(jsonDocument, "$.ApplicationParam.serviceUrl/ivappVideoRestWS/OnmActivationRestServices/activateNonBlocking","ZZZDE-NGPON2");
       	
		LOGGER.info("Exiting testGenerateDynamicTragetEndPointUrl2");
	}
	
	@Test
	public void testGenerateDynamicTragetEndPointUrl3() throws ApplicationException {
		LOGGER.info("Entering testGenerateDynamicTragetEndPointUrl3");
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		Mockito.doNothing().when(serviceUtilsSpy).populateValues(anyString(), anyString(), anyString(), Mockito.any());
		JSONObject jsonDocument = new JSONObject(getfinaldocument());  
		serviceUtils.generateDynamicTargetEndPointUrl(jsonDocument, "$.requestPayload.serviceUrl/ivappVideoRestWS/OnmActivationRestServices/activateNonBlocking","ZZZDE-NGPON2");
		
		LOGGER.info("Exiting testGenerateDynamicTragetEndPointUrl3");
	}
	
	@Test
	public  void testUpdateRequestJsonObjectWithSchemaDefinedParams() throws JSONException, ApplicationException
	{
		LOGGER.info("Entering testUpdateRequestJsonObjectWithSchemaDefinedParams");
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setTransformationType("JSON");
		transformRequest.setInputDocument("{}");
		transformRequest.setRequestSchema("\r\n" + 
				"#define HOUSE_STREET=fn-concat( ,$.Address.HouseNo,$.Address.StreetName");
		serviceUtils.updateRequestJsonObjectWithSchemaDefinedParams(new JSONObject(getfinaldocument()), transformRequest);
		LOGGER.info("Exiting testUpdateRequestJsonObjectWithSchemaDefinedParams");
		
	}
	@Test
	public  void testUpdateRequestJsonObjectWithSchemaDefinedParams1() 
	{
		LOGGER.info("Entering testUpdateRequestJsonObjectWithSchemaDefinedParams1");
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setTransformationType("JSON");
		transformRequest.setInputDocument("{}");
		transformRequest.setRequestSchema("\r\n" + 
				"#define HOUSE_STREET=fn-concat( ,$.Address.HouseNo,$.Address.StreetName);#define Name=fn-concat( , ,$.Address.Zip)");
		try {
			serviceUtils.updateRequestJsonObjectWithSchemaDefinedParams(new JSONObject(getfinaldocument()), transformRequest);
		} catch (Exception e) {
			LOGGER.info("Exception while performing UpdateRequestJsonObjectWithSchemaDefinedParams"+e);
		} 
		LOGGER.info("Exiting testUpdateRequestJsonObjectWithSchemaDefinedParams1");
		
	}
	@Test
	public  void testUpdateRequestJsonObjectWithSchemaDefinedParams2() throws JSONException, ApplicationException
	{
		LOGGER.info("Entering testUpdateRequestJsonObjectWithSchemaDefinedParams2");
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setTransformationType("JSON");
		transformRequest.setInputDocument("{}");
		transformRequest.setRequestSchema("");
		serviceUtils.updateRequestJsonObjectWithSchemaDefinedParams(new JSONObject(getfinaldocument()), transformRequest);
		LOGGER.info("Exiting testUpdateRequestJsonObjectWithSchemaDefinedParams2");
		
	}	
	@Test
	public  void testupdateRequestJsonObjectWithConditionalDefinitions() throws JSONException, ApplicationException
	{
		LOGGER.info("Entering testupdateRequestJsonObjectWithConditionalDefinitions");
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setTransformationType("JSON");
		transformRequest.setInputDocument("{}");
		transformRequest.setRequestSchema(
				"#if $.requestPayload.processInstanceId = 34567 #then #define HOUSE_STREET=fn-concat( ,$.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.HOUSE,$.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.STREET); \r\n"
						+ "#if $.requestPayload.processInstanceId = 34567 #then #define HOUSE_STREET=fn-concat( ,$.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.HOUSE,$.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.STREET); \\r\\n\""
						+ "#endif\r\n" 
						+ "{    \"siteName\": \"fn-concat(,,$.SchemaDefinedParam.HOUSE_STREET,$order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.CITY,$.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.STATE,$order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.ZIP)\" }"
						+ "{    \\\"siteName\\\": \\\"fn-concat(,,$.SchemaDefinedParam.HOUSE_STREET,$order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.CITY,$.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.STATE,$order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.ZIP)\\\" }"
						+ "");
		serviceUtils.updateRequestJsonObjectWithConditionalDefinitions(new JSONObject(getfinaldocument()), transformRequest);
		LOGGER.info("Exiting testupdateRequestJsonObjectWithConditionalDefinitions");
		
	}
	@Test
	public  void testupdateRequestJsonObjectWithConditionalDefinitions1() 
	{
		LOGGER.info("Entering testupdateRequestJsonObjectWithConditionalDefinitions1");
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setTransformationType("JSON");
		transformRequest.setInputDocument("{}");
		transformRequest.setRequestSchema("\r\n" + 
				"#define HOUSE_STREET=fn-concat( ,$.Address.HouseNo,$.Address.StreetName);#define Name=fn-concat( , ,$.Address.Zip)");
		try {
			serviceUtils.updateRequestJsonObjectWithConditionalDefinitions(new JSONObject(getfinaldocument()), transformRequest);
		} catch (Exception e) {
			LOGGER.info("Exception while performing UpdateRequestJsonObjectWithSchemaDefinedParams"+e);
		} 
		LOGGER.info("Exiting testupdateRequestJsonObjectWithConditionalDefinitions1");
		
	}
	@Test
	public  void testupdateRequestJsonObjectWithConditionalDefinitions2() throws JSONException, ApplicationException
	{
		LOGGER.info("Entering testupdateRequestJsonObjectWithConditionalDefinitions2");
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setTransformationType("JSON");
		transformRequest.setInputDocument("{}");
		transformRequest.setRequestSchema("");
		serviceUtils.updateRequestJsonObjectWithConditionalDefinitions(new JSONObject(getfinaldocument()), transformRequest);
		LOGGER.info("Exiting testupdateRequestJsonObjectWithConditionalDefinitions2");
		
	}
	@Test
	public void testHandleJsonFormatDate() throws ApplicationException
	{
		LOGGER.info("Entering testHandleJsonFormatDate");
		String schemaVal = "{\"dueDate\" : \"fn-formatdate($.order.DUE_DATE,YYYY-MM-DD,YYYY-MM-DD'T'HH:mm:ss)\"}";
		String requestJsonStr ="{\"order\":{\"DUE_DATE\" :\"2017-12-15\"}}";
		
		
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		LOGGER.info("Exiting testHandleJsonFormatDate");
	}
	@Test
	public void testHandleJsonFormatDate1() throws ApplicationException
	{
		LOGGER.info("Entering testHandleJsonFormatDate1");
		String schemaVal = "{\"dueDate\" : \"fn-formatdate$.order.DUE_DATE,YYYY-MM-DD,YYYY-MM-DD'T'HH:mm:ss)\"}";
		String requestJsonStr ="{\"order\":{\"DUE_DATE\" :\"2017-12-15\"}}";
		
		
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		LOGGER.info("Exiting testHandleJsonFormatDate1");
	}
	@Test
	public void testHandleJsonFormatDate2() throws ApplicationException
	{
		LOGGER.info("Entering testHandleJsonFormatDate2");
		String schemaVal = "{\"dueDate\" : \"fn-formatdate($.order.DUE_DATE,YYYY-MM-DD,YYYY-MM-DD'T'HH:mm:ss,GMT)\"}";
		String requestJsonStr ="{\"order\":{\"DUE_DATE\" :\"2017-12-15\"}}";
		
		
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		LOGGER.info("Exiting testHandleJsonFormatDate2");
	}
	@Test
	public void testHandleJsonSysDate() throws ApplicationException
	{
		LOGGER.info("Entering testHandleJsonSysDate");
		String schemaVal = "{\"dueDate\" : \"fn-sysdate()\"}";
		String requestJsonStr ="{\"order\":{\"DUE_DATE\" :\"2017-12-15\"}}";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		LOGGER.info("Exiting testHandleJsonSysDate");
	}
	@Test
	public void testHandleJsonDateEpoch() throws ApplicationException
	{
		LOGGER.info("Entering testHandleJsonDateEpoch");
		String schemaVal = "{\"dueDate\" : \"fn-date-epoch(YYYY-MM-DD'T'HH:mm:ss,2017-12-15)\"}";
		String requestJsonStr ="{\"order\":{\"DUE_DATE\" :\"2017-12-15\"}}";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		
		LOGGER.info("Exiting testHandleJsonDateEpoch");
		
	}
	@Test
	public void testHandleJsonSubString() throws ApplicationException {
		LOGGER.info("Entering testHandleJsonSubString");
		String schemaVal = "fn-substring($.order.STREET,0,7)";
		String requestJsonStr ="{\"order\":{\"STREET\" :\"NOTTINGHAM ST\"}}";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		
		LOGGER.info("Exiting testHandleJsonSubString");
	}
	@Test
	public void testHandleJsonSubString1() throws ApplicationException {
		LOGGER.info("Entering testHandleJsonSubString1");
		String schemaVal = "fn-substring($.order.STREET,3)";
		String requestJsonStr ="{\"order\":{\"STREET\" :\"NOTTINGHAM ST\"}}";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		
		LOGGER.info("Exiting testHandleJsonSubString1");
	}
	@Test
	public void testHandleJsonSubString2() throws ApplicationException {
		LOGGER.info("Entering testHandleJsonSubString2");
		String schemaVal = "fn-substring($.order.STREET)";
		String requestJsonStr ="{\"order\":{\"STREET\" :\"NOTTINGHAM ST\"}}";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		
		LOGGER.info("Exiting testHandleJsonSubString2");
	}
	@Test
	public void testHandleJsonSubString3() throws ApplicationException {
		LOGGER.info("Entering testHandleJsonSubString3");
		String schemaVal = "fn-substring($.order.Address[0].STREET,0,7)";
		String requestJsonStr ="{\"order\":{\"Address\":[{\"STREET\" :\"NOTTINGHAM ST\"}]}}";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		
		LOGGER.info("Exiting testHandleJsonSubString3");
	}
	@Test(expected=ApplicationException.class)
	public void testBuildManifestDocument() throws ApplicationException
	{
		LOGGER.info("Entering testBuildManifestDocument");
		String manifestReqPayload="{\"entity-data\":{\"app-key\":\"ZZZDE-NGPON2\",\"entity-attributes\":{\"attribute\":[{\"name\":\"order_number\",\"value\":\"CCOG639221728\"},{\"name\":\"order_version\",\"value\":\"001\"},{\"name\":\"region\",\"value\":\"NJ\"},{\"name\":\"product_type\",\"value\":\"Data\"},{\"name\":\"supp_type\",\"value\":\"Pending\"}]}}}";
		String manifestDocumentNames="#Metadata.PlanningMessage";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.buildManifestDocument(manifestReqPayload, manifestDocumentNames);
		
		LOGGER.info("Exiting testBuildManifestDocument");
	}
	@Test
	public void testUserNamePasswordEncoder() throws ApplicationException
	{
		LOGGER.info("Entering testUserNamePasswordEncoder");
		String userName = "IVAPP";
		String userPwd =getPwd();
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.userNamePasswordEncoder(userName, userPwd);
		
		LOGGER.info("Exiting testUserNamePasswordEncoder");
	}
	@Test
	public void testMergeDocumentByName()
	{
		LOGGER.info("Entering testMergeDocumentByName");
		String subDocumentName = "IVAPP";
		JSONObject sourceDocument = new JSONObject();
		JSONObject documentToBeMerged = new JSONObject();
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.mergeDocumentByName(sourceDocument, documentToBeMerged, subDocumentName);
		
		LOGGER.info("Exiting testMergeDocumentByName");
	}
	@Test
	public void testGetResponseStatusAndBody()
	{
		LOGGER.info("Entering testGetResponseStatusAndBody");
		ResponseEntity<String> responseEntity1 = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.OK);
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.getResponseStatusAndBody(responseEntity1);
		
		LOGGER.info("Exiting testGetResponseStatusAndBody");
	}
	@Test
	public void testHandleJsonSubStringBefore() throws ApplicationException {
		LOGGER.info("Entering testHandleJsonSubStringBefore");
		String schemaVal = "fn-substring-before($.requestPayload.serviceUrl,':')";
		String requestJsonStr =getfinaldocument();
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		
		LOGGER.info("Exiting testHandleJsonSubStringBefore");
	}
	@Test
	public void testHandleJsonSubStringBefore1() throws ApplicationException {
		LOGGER.info("Entering testHandleJsonSubStringBefore");
		String schemaVal = "fn-substring-before($.requestPayload.serviceUrl)";
		String requestJsonStr =getfinaldocument();
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		
		LOGGER.info("Exiting testHandleJsonSubStringBefore");
	}
	@Test
	public void testHandleJsonSubStringAfter() throws ApplicationException {
		LOGGER.info("Entering testHandleJsonSubStringAfter");
		String schemaVal = "fn-substring-after($.requestPayload.serviceUrl,':')";
		String requestJsonStr =getfinaldocument();
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		
		LOGGER.info("Exiting testHandleJsonSubStringAfter");
	}
	@Test
	public void testHandleJsonSubStringAfter1() throws ApplicationException {
		LOGGER.info("Entering testHandleJsonSubStringAfter1");
		String schemaVal = "fn-substring-after($.requestPayload.serviceUrl)";
		String requestJsonStr =getfinaldocument();
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		
		LOGGER.info("Exiting testHandleJsonSubStringAfter1");
	}
	@Test
	public void testHandleJsonSysDateEpoch() throws ApplicationException
	{
		LOGGER.info("Entering testHandleJsonSysDateEpoch");
		String schemaVal = "{\"dueDate\" : \"fn-sysdate-epoch(YYYY-MM-DD'T'HH:mm:ss,2017-12-15)\"}";
		String requestJsonStr ="{\"order\":{\"DUE_DATE\" :\"2017-12-15\"}}";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.populateValues("request", schemaVal, requestJsonStr, new JSONObject());
		
		LOGGER.info("Exiting testHandleJsonSysDateEpoch");
		
	}
	@Test
	public void testgetJsonSchemaValue() {
		LOGGER.info("Entering testgetJsonSchemaValue");
		String schemaVal = "$.key1.key2";
		String jsonString = "{ 	\"key1\": { 		\"key2\": \"SpecialPlanningMessage\", 		\"key3\": \"ZZZDE-NGPON2\", 		\"key4\": { 			\"key5\": [{ 				\"key6\": \"order_number\" 			}, { 				\"key6\": \"order_version\" 			}] 		} 	} }";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.getJsonSchemaValue(schemaVal,jsonString);
		LOGGER.info("Exiting testgetJsonSchemaValue");
	}
	@Test
	public void testgetJsonSchemaValue1() {
		LOGGER.info("Entering testgetJsonSchemaValue1");
		String schemaVal = "$.key1.key4.key5[0].key6";
		String jsonString = "{ 	\"key1\": { 		\"key2\": \"SpecialPlanningMessage\", 		\"key3\": \"ZZZDE-NGPON2\", 		\"key4\": { 			\"key5\": [{ 				\"key6\": \"order_number\" 			}, { 				\"key6\": \"order_version\" 			}] 		} 	} }";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.getJsonSchemaValue(schemaVal,jsonString);
		LOGGER.info("Exiting testgetJsonSchemaValue1");
	}
	@Test
	public void testgetJsonSchemaValu2() {
		LOGGER.info("Entering testgetJsonSchemaValue2");
		String schemaVal = "$.key1.key4.spec[code='SP_IB_IP_BL_SI'].key6";
		String jsonString = "{ 	\"key1\": { 		\"key2\": \"SpecialPlanningMessage\", 		\"key3\": \"ZZZDE-NGPON2\", 		\"key4\": { 			\"key5\": [{ 				\"key6\": \"order_number\" 			}, { 				\"key6\": \"order_version\" 			}] 		} 	} }";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.getJsonSchemaValue(schemaVal,jsonString);
		LOGGER.info("Exiting testgetJsonSchemaValue2");
	}
	
	@Test
	public void testgetJsonSchemaValue4() {
		LOGGER.info("Entering testgetJsonSchemaValue4");
		String schemaVal = "$.key1.key4.key5[3].key6";
		String jsonString = "{ 	\"key1\": { 		\"key2\": \"SpecialPlanningMessage\", 		\"key3\": \"ZZZDE-NGPON2\", 		\"key4\": { 			\"key5\": [{ 				\"key6\": \"order_number\" 			}, { 				\"key6\": \"order_version\" 			}] 		} 	} }";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.getJsonSchemaValue(schemaVal,jsonString);
		LOGGER.info("Exiting testgetJsonSchemaValue4");
	}
	@Test
	public void testgetJsonSchemaValue5() {
		LOGGER.info("Entering testgetJsonSchemaValue5");
		String schemaVal = "$.key1.key4.key5[3].key6";
		String jsonString = "{ 	\"key1\": { 		\"key2\": \"SpecialPlanningMessage\", 		\"key3\": \"ZZZDE-NGPON2\", 		\"key4\": { 			\"key5\": { 				\"key6\": \"order_number\" 			} 		} 	} }";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.getJsonSchemaValue(schemaVal,jsonString);
		LOGGER.info("Exiting testgetJsonSchemaValue5");
	}
	@Test
	public void testgetJsonSchemaValu6() {
		LOGGER.info("Entering testgetJsonSchemaValu6");
		String schemaVal = "$.key1.key4.key5[code='a'].key7.key6";
		String jsonString = "{	\"key1\": {		\"key2\": \"SpecialPlanningMessage\",		\"key3\": \"ZZZDE-NGPON2\",		\"key4\": {			\"key5\": [{				\"key7\": {					\"key6\": \"order_number\"				},				\"code\": \"a\"			}, {				\"key7\": {					\"key6\": \"order_version\"				},				\"code\": \"b\"			}]		}	}}";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.getJsonSchemaValue(schemaVal,jsonString);
		LOGGER.info("Exiting testgetJsonSchemaValu6");
	}
	@Test
	public void testgetJsonSchemaValu7() {
		LOGGER.info("Entering testgetJsonSchemaValu7");
		String schemaVal = "$.key1.key4.key5[code='a'].key7";
		String jsonString = "{	\"key1\": {		\"key2\": \"SpecialPlanningMessage\",		\"key3\": \"ZZZDE-NGPON2\",		\"key4\": {			\"key5\": [{				\"key7\": {					\"key6\": \"order_number\"				},				\"code\": \"a\"			}, {				\"key7\": {					\"key6\": \"order_version\"				},				\"code\": \"b\"			}]		}	}}";
		ServiceUtils serviceUtilsSpy = Mockito.spy(serviceUtils);
		serviceUtilsSpy.getJsonSchemaValue(schemaVal,jsonString);
		LOGGER.info("Exiting testgetJsonSchemaValu7");
	}
	public String getfinaldocument() {
		return " {\"requestPayload\":{\"processInstanceId\":\"34567\",\"serviceUrl\":\"https://vnmws.ebiz.verizon.com\",\"seedInfo\":{\"product_type\":\"Data\",\"supp_type\":\"Pending\",\"order_number\":\"CCOG639221728\",\"region\":\"NJ\","
				+ "\"order_version\":\"001\"},\"app-key\":\"ZZZDE-NGPON2\",\"rootProcessInstanceId\":\"56789\",\"activityInstanceId\":\"7654\",\"parentProcessInstanceId\":\"45678\",\"flowNodeProcessName\":\"LCI_OVER_NGPON2_Pre_Activation\","
				+ "\"rootProcessName\":\"Root\",\"flowNodeStepName\":\"RetrieveONTSerialNumber\"},\"transactionId\":\"1511938969413|34567|7654\",\"PlanningMessage\":{\"document-payload\":{\"PlanningMsgRsp\":{\"InvSystem\":\"IVAPP\",\"ActivationInfo\":{\"PonDetails\":{\"PonId\":\"00000000000000000000000001010111\","
				+ "\"PonSystemId\":\"00000000000100001001\",\"ChannelPartitionIndex\":\"0010\",\"ServiceType\":\"DATA\",\"BackupPonId\":\"00000000000000110010000100010111\",\"PonType\":\"NGPON2\"}},"
				+ "\"AssignmentReuse\":\"NO\",\"PreActRequired\":\"YES\",\"OrderNumber\":\"CCOGSSPDISCOTEST19\",\"OrderId\":706514,\"VersionNumber\":\"000\",\"xmlns\":\"\",\"SubscriptionId\":\":-1--1@NYCMNYWART1\","
				+ "\"ReconnectONTDel\":\"NO\",\"OdnData\":{\"MDU_SIP_ALTL\":\"NO\",\"CTID\":\"70/VAXA/706514/ /VZNY\",\"IvappPonCircuitName\":\"S/GRCYNYGCT01/1-1-9-1\",\"DataVlan\":{\"STag\":1024,"
				+ "\"CircuitName\":\"test\",\"CTag\":4095},\"PvcNniChange\":\"YES\",\"IspPvcCircuitId\":\"70/VAXA/706514/ /VZNY\",\"IvappPonCircuitId\":103792,\"MocaProvisioned\":\"N\",\"IvappSecondaryPonCircuitName\":\"S/GRCYNYGCT01/7-25-2-1\","
				+ "\"ReplacementPortNumber\":\"\",\"SvcPortNumber\":1,\"ServiceTNDetails\":{\"SwitchClli\":\"\",\"PrimaryLecTN\":\"\"}},\"RouterCilli\":\"NYCMNYWART1\",\"PonCircuit\":{\"DistHub\":{\"DistributionFiber\":{\"StrandNumber\":2,"
				+ "\"Name\":\"H8989\"},\"HubPortNumber\":2,\"Splitter\":{\"PortNumber\":1,\"Name\":\"H8989A\"},\"XConnectAction\":\"Make\",\"GpsParams\":{\"Latitude\":26.154106,\"Longitude\":-93.129155},\"Name\":\"H8989\",\"AddressInfo\":\"HOME\"},\"Ont\":{\"PAIndicator\":\"Compatible\",\"ManufacturerName\":\"ALTL\""
				+ ",\"DesktopModel\":\"Y\",\"Address\":{\"HouseNo\":620,\"StreetName\":\"NOTTINGHAM\",\"TuName\":\"SYRACUSE\",\"Zip\":13224,\"Type\":\"RD\",\"SubLocation\":\"FLR GRD\",\"State\":\"NY\",\"MduSfu\":0,\"AddressId\":48053419},\"MocaCapable\":\"Y\","
				+ "\"Make\":\"ALTL\",\"GpsParams\":{\"Latitude\":\"\",\"Longitude\":\"\"},\"EthernetSpeed\":\"N\",\"RequiredAction\":\"Install\",\"Type\":\"SFU\",\"SequenceNumber\":1,\"Model\":\"O-211M-E\",\"GponProvisioned\":\"Y\",\"InactiveONT\":\"N\"},"
				+ "\"Olt\":{\"FeederFiber\":{\"StrandNumber\":1,\"Name\":\"F8989\"},\"SlotId\":1,\"Rack\":1,\"ManufacturerName\":\"ALTL\",\"Clli\":\"GRNKNYGNRCH\",\"OltPortNumber\":9,\"EmsId\":\"\",\"ShelfId\":1,\"OltTid\":\"TMPAFLERICERICE907\",\"Name\":\"ALTL-ONT211M\"},"
				+ "\"FiberJackCapable\":\"N\",\"DropTerminal\":{\"RELATED_ADDR_ID\":[90213,90132,90134,90135,189459,90214,90212,90215,237267,237232,237233,156737,189460,189461,90133,90153,143599,237268,189440],\"ConnectorType\":\"SC/APC\",\"DropAction\":\"TERMINATE\",\"GpsParams\":{\"Latitude\":26.154476,\"Longitude\""
				+ ":-93.128649},\"DropStatus\":\"TERMINATED\",\"DropType\":\"MDU_INSIDE\","
				+ "\"PortNumber\":2,\"Name\":102853,\"AddressInfo\":\"HOME\"},\"IvappPonCircuitId\":103792,\"PonCircuitName\":\"S/GRCYNYGCT01/1-1-9-1\",\"FiberDrop\":{\"StrandNumber\":2}}}}}}";
	}
	public String getPwd()
	{
		return "ivapp";
	}
	
}