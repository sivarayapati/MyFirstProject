/**
 * 
 */
package com.vz.uiam.onenet.util.controller;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.controller.OdsRequestLogController;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsLogEntryResponse;
import com.vz.uiam.onenet.ods.service.OdsRequestLogService;

/**
 * @author Guru
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class OdsRequestLogControllerTest {
	private static final Logger LOGGER = Logger.getLogger(OdsRequestLogControllerTest.class);
	
	@InjectMocks
	OdsRequestLogController odsRequestController;
	
	@Mock
	OdsRequestLogService odsRequestLogService;

	/**
	 * @throws com.vz.uiam.onenet.ods.exception.ApplicationException 
	 * @throws JSONException 
	 * 
	 */
	@Test
	public void testGetOdsRequestLogEntryBywfTaskId() throws JSONException, com.vz.uiam.onenet.ods.exception.ApplicationException {
		LOGGER.info("Entering into testGetOdsRequestLogEntryBywfTaskId");
		String request = "{\"wfTaskId\": \"3531346\"}";
		JSONObject requestJson = new JSONObject(request);
		OdsLogEntryResponse odsLogEntryResponse = new OdsLogEntryResponse();
		odsLogEntryResponse.setTitle("52720185");
		odsLogEntryResponse.setTitleVersion("0");
		odsLogEntryResponse.setWfTaskId("3531346");
		when(odsRequestLogService.getOdsRequestLogEntryBywfTaskId(requestJson)).thenReturn(odsLogEntryResponse);
		odsRequestController.getOdsRequestLogEntryBywfTaskId(request.toString());
		LOGGER.info("request:"+request.toString());
		LOGGER.info("Exiting into testGetOdsRequestLogEntryBywfTaskId");
		
	}
	
	/**
	 * @throws com.vz.uiam.onenet.ods.exception.ApplicationException 
	 * @throws JSONException 
	 * 
	 */
	@Test
	public void testGetOdsRequestLogEntryBywfTaskId1() throws JSONException, com.vz.uiam.onenet.ods.exception.ApplicationException {
		LOGGER.info("Entering into testGetOdsRequestLogEntryBywfTaskId1");
		String request = "{\"wfTaskId\": \"\"}";
		JSONObject requestJson = new JSONObject(request);
		OdsLogEntryResponse odsLogEntryResponse = new OdsLogEntryResponse();
		odsLogEntryResponse.setStatusCode(StatusCode.BAD_REQUEST.getCode());
		odsLogEntryResponse.setStatusDesc("TaskId is Empty or Null");	
		when(odsRequestLogService.getOdsRequestLogEntryBywfTaskId(requestJson)).thenReturn(odsLogEntryResponse);
		odsRequestController.getOdsRequestLogEntryBywfTaskId(request);
		LOGGER.info("request:"+request.toString());
		LOGGER.info("Exiting into testGetOdsRequestLogEntryBywfTaskId1");
		
	}
	
	/**
	 * @throws com.vz.uiam.onenet.ods.exception.ApplicationException 
	 * @throws JSONException 
	 * 
	 */
	@Test
	public void testGetOdsRequestLogEntryByTitleAndVersion() throws JSONException, com.vz.uiam.onenet.ods.exception.ApplicationException {
		LOGGER.info("Entering into testGetOdsRequestLogEntryByTitleAndVersion");
		List<OdsRequestLog> odsRequestLogList = new ArrayList<>();
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		String request = "{\"title\": \"52820181\",\"titleVersion\": \"0\"}";
		String title ="52820181";
		String titleVersion = "0";
		odsRequestLog.setTitle(title);
		odsRequestLog.setTitleVersion(titleVersion);
		odsRequestLogList.add(odsRequestLog);
		when(odsRequestLogService.getOdsRequestLogEntryByTitleAndTitleVersion(title,titleVersion)).thenReturn(odsRequestLogList);
		odsRequestController.getOdsRequestLogEntriesByTitleAndVersion(request);
		LOGGER.info("Exiting into testGetOdsRequestLogEntryByTitleAndVersion");
		
	}
	

}
