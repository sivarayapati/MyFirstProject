package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneTransaction;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsMilestoneTransactionRequest;
import com.vz.uiam.onenet.ods.service.MilestoneService;
import com.vz.uiam.onenet.ods.service.ODSService;
import com.vz.uiam.onenet.ods.service.OdsServiceRouteMapService;

@RunWith(MockitoJUnitRunner.class)
public class OdsMilestoneTrasctionControllerMockitoTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(OdsMilestoneTrasctionControllerMockitoTest.class);

	@InjectMocks
	OdsMilestoneTrasctionController odsMilestoneTrasctionController;

	@Mock
	MilestoneService milestoneService;

	@Mock
	OdsServiceRouteMapService odsServiceRouteMapService;

	@Mock
	ODSService odsService;

	@Test
	public void testGetOdsMilestoneTransactions() throws ApplicationException {

		LOGGER.info("Entering testGetOdsMilestoneTransactions");
		OdsMilestoneTransactionRequest request = new OdsMilestoneTransactionRequest();
		request.setRootCaseId("100");
		List<OdsMilestoneTransaction> odsMilestoneTransctionDetails = null;
		when(milestoneService.getMilestoneTransctionDetails(request.getRootCaseId()))
				.thenReturn(odsMilestoneTransctionDetails);
		odsMilestoneTrasctionController.getOdsMilestoneTransactions(request);
		LOGGER.info("Exiting testGetOdsMilestoneTransactions");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetOdsMilestoneTransactions1() throws ApplicationException {

		LOGGER.info("Entering testGetOdsMilestoneTransactions1");
		OdsMilestoneTransactionRequest request = new OdsMilestoneTransactionRequest();
		request.setRootCaseId("100");
		when(milestoneService.getMilestoneTransctionDetails(request.getRootCaseId()))
				.thenThrow(ApplicationException.class);
		odsMilestoneTrasctionController.getOdsMilestoneTransactions(request);
		LOGGER.info("Exiting testGetOdsMilestoneTransactions1");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetOdsMilestoneTransactions2() throws ApplicationException {

		LOGGER.info("Entering testGetOdsMilestoneTransactions2");
		OdsMilestoneTransactionRequest request = new OdsMilestoneTransactionRequest();
		request.setRootCaseId("100");
		when(milestoneService.getMilestoneTransctionDetails(request.getRootCaseId())).thenThrow(SQLException.class);
		odsMilestoneTrasctionController.getOdsMilestoneTransactions(request);
		LOGGER.info("Exiting testGetOdsMilestoneTransactions2");

	}

	@Test
	public void testRetryOdsMilestoneTransactions() throws ApplicationException {

		LOGGER.info("Entering testRetryOdsMilestoneTransactions");
		OdsMilestoneTransactionRequest request = new OdsMilestoneTransactionRequest();
		request.setRootCaseId("100");
		OdsMilestoneTransaction odsMilestoneTransctionDetails = null;
		when(milestoneService.retryMilestoneTransaction(request)).thenReturn(odsMilestoneTransctionDetails);
		odsMilestoneTrasctionController.retryOdsMilestoneTransactions(request);
		LOGGER.info("Exiting testRetryOdsMilestoneTransactions");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testRetryOdsMilestoneTransactions1() throws ApplicationException {

		LOGGER.info("Entering testRetryOdsMilestoneTransactions1");
		OdsMilestoneTransactionRequest request = new OdsMilestoneTransactionRequest();
		request.setRootCaseId("100");
		when(milestoneService.retryMilestoneTransaction(request)).thenThrow(ApplicationException.class);
		odsMilestoneTrasctionController.retryOdsMilestoneTransactions(request);
		LOGGER.info("Exiting testRetryOdsMilestoneTransactions1");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testRetryOdsMilestoneTransactions2() throws ApplicationException {

		LOGGER.info("Entering testRetryOdsMilestoneTransactions2");
		OdsMilestoneTransactionRequest request = new OdsMilestoneTransactionRequest();
		request.setRootCaseId("100");
		when(milestoneService.retryMilestoneTransaction(request)).thenThrow(SQLException.class);
		odsMilestoneTrasctionController.retryOdsMilestoneTransactions(request);
		LOGGER.info("Exiting testRetryOdsMilestoneTransactions2");

	}

	@Test
	public void testSendMilestone() throws ApplicationException {

		LOGGER.info("Entering testSendMilestone");
		Map<String, String> values = new HashMap<>();
		values.put(Constants.FLOW_PROCESS_NAME, "TestProcess");
		values.put(Constants.FLOW_STEP_NAME, "TestStep");
		values.put(Constants.MANIFEST_APP_KEY_STR, "appKey");
		values.put(Constants.ROOT_CASE_ID, "101");
		JSONObject request = new JSONObject(values);
		OdsServiceRouterMapDetails value = new OdsServiceRouterMapDetails();
		when(odsServiceRouteMapService.getServiceRouterMapDetails(values.get(Constants.FLOW_PROCESS_NAME),
				values.get(Constants.FLOW_STEP_NAME), values.get(Constants.ODS_REGION))).thenReturn(value);
		Mockito.doThrow(SQLException.class).when(milestoneService).sendMilestone(Mockito.any());
		odsMilestoneTrasctionController.sendMilestone(request.toString());
		LOGGER.info("Exiting testSendMilestone");

	}
}
