package com.vz.uiam.onenet.ods.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsResponseTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestTransactionIdMapRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsTransactionIdMapResponse;
import com.vz.uiam.onenet.ods.service.OdsRequestResponseTransactionIdMapService;

@RunWith(MockitoJUnitRunner.class)
public class ODSRequestAndResponseTIdMapControllerMockitoTest {
	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ODSRequestAndResponseTIdMapControllerMockitoTest.class);

	@InjectMocks
	ODSRequestAndResponseTIdMapController odsRequestAndResponseTIdMapController;

	@Mock
	OdsRequestResponseTransactionIdMapService transactionIdMapService;

	@Mock
	OdsRequestTransactionIdMapRepository odsRequestRepo;


	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testcreateOrUpdateOdsRequestTransIdMap() throws ApplicationException {
		LOGGER.info("Begin testcreateOrUpdateOdsRequestTransIdMap");
		OdsRequestTransactionIdMap request= new OdsRequestTransactionIdMap();

		OdsTransactionIdMapResponse response = new OdsTransactionIdMapResponse();

		OdsRequestTransactionIdMap odsRequestTransIdMapResp = new OdsRequestTransactionIdMap();
		HttpHeaders httpHeaders = mock(HttpHeaders.class);
		ResponseEntity<OdsTransactionIdMapResponse> responseEntity = new ResponseEntity<>(response, httpHeaders, HttpStatus.OK);
		when(transactionIdMapService.createOrUpdateOdsRequestTransIdMap(request))
		.thenReturn(odsRequestTransIdMapResp);
		responseEntity = odsRequestAndResponseTIdMapController.createOrUpdateOdsRequestTransIdMap(request);
		assertNotNull(responseEntity);
		LOGGER.info("End testcreateOrUpdateOdsRequestTransIdMap");
	}

	@Test
	public void testCreateOrUpdateOdsRequestTransIdMap1() throws ApplicationException {
		LOGGER.info("Begin testcreateOrUpdateOdsRequestTransIdMap1");
		OdsRequestTransactionIdMap request= new OdsRequestTransactionIdMap();

		OdsTransactionIdMapResponse response = null;

		OdsRequestTransactionIdMap odsRequestTransIdMapResp = null;
		HttpHeaders httpHeaders = mock(HttpHeaders.class);
		ResponseEntity<OdsTransactionIdMapResponse> responseEntity = new ResponseEntity<>(response, httpHeaders, HttpStatus.OK);
		when(transactionIdMapService.createOrUpdateOdsRequestTransIdMap(request))
		.thenReturn(odsRequestTransIdMapResp);
		responseEntity = odsRequestAndResponseTIdMapController.createOrUpdateOdsRequestTransIdMap(request);
		assertNotNull(responseEntity);
		LOGGER.info("End testcreateOrUpdateOdsRequestTransIdMap1");
	}

	@Test
	public void testGetOdsRequestTransIdMap() throws ApplicationException {
		LOGGER.info("Begin testcreateOrUpdateOdsRequestTransIdMap1");
		OdsRequestTransactionIdMap request= new OdsRequestTransactionIdMap();

		OdsTransactionIdMapResponse response = null;

		List<OdsRequestTransactionIdMap> odsRequestTransIdMapResp = null;
		HttpHeaders httpHeaders = mock(HttpHeaders.class);
		ResponseEntity<OdsTransactionIdMapResponse> responseEntity = new ResponseEntity<>(response, httpHeaders, HttpStatus.OK);
		when(transactionIdMapService.getOdsRequestTransIdMapRecords(request))
		.thenReturn(odsRequestTransIdMapResp);
		responseEntity = odsRequestAndResponseTIdMapController.getOdsRequestTransIdMap(request);
		assertNotNull(responseEntity);
		LOGGER.info("End testcreateOrUpdateOdsRequestTransIdMap1");
	}

	@Test
	public void testGetOdsRequestTransIdMap1() throws ApplicationException {
		LOGGER.info("Begin testcreateOrUpdateOdsRequestTransIdMap1");
		OdsRequestTransactionIdMap request= new OdsRequestTransactionIdMap();

		OdsTransactionIdMapResponse response = null;
		HttpHeaders httpHeaders = mock(HttpHeaders.class);
		ResponseEntity<OdsTransactionIdMapResponse> responseEntity = new ResponseEntity<>(response, httpHeaders, HttpStatus.OK);
		when(transactionIdMapService.getOdsRequestTransIdMapRecords(request))
		.thenThrow(new RuntimeException());
		responseEntity = odsRequestAndResponseTIdMapController.getOdsRequestTransIdMap(request);
		assertNotNull(responseEntity);
		LOGGER.info("End testcreateOrUpdateOdsRequestTransIdMap1");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testCreateOrUpdateOdsRequestTransIdMap2() throws ApplicationException {
		LOGGER.info("Begin testcreateOrUpdateOdsRequestTransIdMap1");
		OdsRequestTransactionIdMap request = new OdsRequestTransactionIdMap();

		when(transactionIdMapService.createOrUpdateOdsRequestTransIdMap(request)).thenThrow(NullPointerException.class);
		odsRequestAndResponseTIdMapController.createOrUpdateOdsRequestTransIdMap(request);

		LOGGER.info("End testcreateOrUpdateOdsRequestTransIdMap1");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testdelete() throws ApplicationException {
		LOGGER.info("Begin testdelete");
		OdsRequestTransactionIdMap odsRequest = new OdsRequestTransactionIdMap();
		List<OdsRequestTransactionIdMap> request = new ArrayList<>();
		request.add(odsRequest);
		Mockito.doThrow(SQLException.class).when(transactionIdMapService).deleteOdsRequestTransIdMapRecord(request);
		odsRequestAndResponseTIdMapController.deleteOdsRequestTransIdMap(request);

		LOGGER.info("End testdelete");
	}

	@Test
	public void testCreateOrUpdateResponseTransIdMap() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testCreateOrUpdateResponseTransIdMap*****************************");
		OdsResponseTransactionIdMap odsResponseTIdMap = new OdsResponseTransactionIdMap();
		odsResponseTIdMap.setRootTagName("TestrootTagName");
		odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKey");
		OdsResponseTransactionIdMap odsResponseTIdMapRes = null;
		when(transactionIdMapService.createOrUpdateOdsResponseTransIdMap(odsResponseTIdMap))
				.thenReturn(odsResponseTIdMapRes);
		odsRequestAndResponseTIdMapController.createOrUpdateResponseTransIdMap(odsResponseTIdMap);
		LOGGER.info(
				"****************************Exiting from testCreateOrUpdateResponseTransIdMap*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testCreateOrUpdateResponseTransIdMap1() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testCreateOrUpdateResponseTransIdMap1*****************************");
		OdsResponseTransactionIdMap odsResponseTIdMap = new OdsResponseTransactionIdMap();

		when(transactionIdMapService.createOrUpdateOdsResponseTransIdMap(odsResponseTIdMap))
				.thenThrow(SQLException.class);
		odsRequestAndResponseTIdMapController.createOrUpdateResponseTransIdMap(odsResponseTIdMap);
		LOGGER.info(
				"****************************Exiting from testCreateOrUpdateResponseTransIdMap1*****************************");

	}

	@Test
	public void testgetOdsResponseTransIdMap() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testgetOdsResponseTransIdMap*****************************");
		List<OdsResponseTransactionIdMap> odsResponseTransIdMapResp = null;
		OdsResponseTransactionIdMap odsResponseTIdMap = new OdsResponseTransactionIdMap();
		odsResponseTIdMap.setRootTagName("TestrootTagName");
		odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKey");
		when(transactionIdMapService.getOdsResponseTransIdMapRecords(odsResponseTIdMap))
				.thenReturn(odsResponseTransIdMapResp);
		odsRequestAndResponseTIdMapController.getOdsResponseTransIdMap(odsResponseTIdMap);

		LOGGER.info(
				"****************************Exiting from testgetOdsResponseTransIdMap*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testgetOdsResponseTransIdMap1() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testgetOdsResponseTransIdMap1*****************************");
		OdsResponseTransactionIdMap odsResponseTIdMap = new OdsResponseTransactionIdMap();

		when(transactionIdMapService.getOdsResponseTransIdMapRecords(odsResponseTIdMap))
				.thenThrow(ApplicationException.class);
		odsRequestAndResponseTIdMapController.getOdsResponseTransIdMap(odsResponseTIdMap);

		LOGGER.info(
				"****************************Exiting from testgetOdsResponseTransIdMap1*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testgetOdsResponseTransIdMap2() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testgetOdsResponseTransIdMap2*****************************");
		OdsResponseTransactionIdMap odsResponseTIdMap = new OdsResponseTransactionIdMap();

		when(transactionIdMapService.getOdsResponseTransIdMapRecords(odsResponseTIdMap)).thenThrow(SQLException.class);
		odsRequestAndResponseTIdMapController.getOdsResponseTransIdMap(odsResponseTIdMap);

		LOGGER.info(
				"****************************Exiting from testgetOdsResponseTransIdMap2*****************************");

	}

	@Test
	public void testdeleteOdsResponseTransIdMap1() throws ApplicationException {
		LOGGER.info(
				"****************************Entering to testdeleteOdsResponseTransIdMap1*****************************");
		OdsResponseTransactionIdMap odsResponseTIdMap = new OdsResponseTransactionIdMap();
		odsResponseTIdMap.setId(100);
		odsResponseTIdMap.setRootTagName("TestrootTagName");
		odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKey");
		List<OdsResponseTransactionIdMap> odsResponseList = new ArrayList<>();
		odsResponseList.add(odsResponseTIdMap);
		Mockito.doThrow(SQLException.class).when(transactionIdMapService)
				.deleteOdsResponseTransIdMapRecord(odsResponseList);
		odsRequestAndResponseTIdMapController.deleteOdsResponseTransIdMap(odsResponseList);
		LOGGER.info(
				"****************************Exiting from testdeleteOdsResponseTransIdMap1*****************************");

	}

}
