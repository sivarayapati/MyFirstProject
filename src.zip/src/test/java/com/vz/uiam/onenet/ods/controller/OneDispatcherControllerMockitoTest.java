package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.service.NotesService;
import com.vz.uiam.onenet.ods.service.ODSJsonResponseHandler;
import com.vz.uiam.onenet.ods.service.ODSResponseHandler;
import com.vz.uiam.onenet.ods.service.ODSService;
import com.vz.uiam.onenet.ods.service.ODSXmlResponseHandler;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

/**
 * @author Anand Badiger
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class OneDispatcherControllerMockitoTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(OneDispatcherControllerMockitoTest.class);

	@InjectMocks
	OneDispatcherController serviceRouterController;

	@Mock
	ODSService odsService;
	
	@Mock
	NotesService notesService;

	@Mock
	ServiceUtils serviceUtils;

	@Mock
	ODSJsonResponseHandler odsJsonResponseHandler;

	@Mock
	ODSXmlResponseHandler odsXmlResponseHandler;

	@Mock
	ODSResponseHandler odsResponseHandler;

	/**
	 *
	 */
	@Test
	public void testHealthCheck() {
		LOGGER.debug(">>healthCheck()");
		serviceRouterController.healthCheck();
		LOGGER.debug("<<healthCheck()");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testDoXmlResponseTransform() throws ApplicationException {

		LOGGER.info("****************************Entering to testDoXmlResponseTransform*****************************");

		String request = "<nbaTransaction></nbaTransaction>";
		when(odsXmlResponseHandler.getTransactionIdFromRespTransIdMap(request)).thenThrow(NullPointerException.class);
		serviceRouterController.doXmlResponseTransform(request);

		LOGGER.info("****************************Exiting from testDoXmlResponseTransform*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testDoJsonResponseTransform() throws ApplicationException {

		LOGGER.info("****************************Entering to testDoJsonResponseTransform*****************************");
		String response = "{\"ackResponse\":\"ack\"}";
		when(odsJsonResponseHandler.getTransactionIdFromJsonResponse(response)).thenThrow(NullPointerException.class);
		serviceRouterController.doJsonResponseTransform(response);
		LOGGER.info(
				"****************************Exiting from testDoJsonResponseTransform*****************************");

	}

	@Test(expected=NullPointerException.class)
	public void testDoRestSvcXmlResponseTransform() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testDoRestSvcXmlResponseTransform*****************************");
		String transactionId = "000|1122DISCONNECT0023";
		String request = "<nbaTransaction></nbaTransaction>";
		OdsInterfaceRequest odsInReq = new OdsInterfaceRequest();
		when(odsXmlResponseHandler.getTransactionIdFromXmlNodeValue(request)).thenReturn(transactionId);
		when(odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(transactionId,
				StatusCode.REQUEST_PENDING.toString())).thenReturn(odsInReq);
		serviceRouterController.doRestSvcXmlResponseTransform(request);
		LOGGER.info(
				"****************************Exiting from testDoRestSvcXmlResponseTransform*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testDoRestSvcXmlResponseTransform1() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testDoRestSvcXmlResponseTransform1*****************************");
		String transactionId = "000|1122DISCONNECT0023";
		String request = "<nbaTransaction></nbaTransaction>";
		when(odsXmlResponseHandler.getTransactionIdFromXmlNodeValue(request)).thenReturn(transactionId);
		when(odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(transactionId,
				StatusCode.REQUEST_PENDING.toString())).thenThrow(SQLException.class);
		serviceRouterController.doRestSvcXmlResponseTransform(request);
		LOGGER.info(
				"****************************Exiting from testDoRestSvcXmlResponseTransform1*****************************");

	}

}
