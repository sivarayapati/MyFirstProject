package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsMilestoneTransactionRequest;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class OdsMilestoneTrasctionControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(OdsMilestoneTrasctionControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	OdsMilestoneTrasctionController odsMilestoneTrasctionController;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_transaction.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_transaction.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_transaction.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql")
		})
	public void testGetOdsMilestoneTransactions() {
		try {
			LOGGER.info("****************************Entering to testGetOdsMilestoneTransactions*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneTransaction/get");
		    OdsMilestoneTransactionRequest request = new OdsMilestoneTransactionRequest();
		    request.setRootCaseId("TestRoot1234");
		    MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(request)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetOdsMilestoneTransactions*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for GetOdsMilestoneTransactions: ",e);
		}
	}
	@Test
	public void testGetOdsMilestoneTransactions1() {
		try {
			LOGGER.info("****************************Entering to testGetOdsMilestoneTransactions1*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneTransaction/get");
		    OdsMilestoneTransactionRequest request = new OdsMilestoneTransactionRequest();
		    request.setRootCaseId("TestRoot12345");
		    MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(request)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetOdsMilestoneTransactions1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for GetOdsMilestoneTransactions: ",e);
		}
	}
	
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_transaction.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_transaction.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_transaction.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql")
		})
	public void testRetryOdsMilestoneTransactions() {
		try {
			LOGGER.info("****************************Entering to testRetryOdsMilestoneTransactions*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneTransaction/retry");
		    OdsMilestoneTransactionRequest request = new OdsMilestoneTransactionRequest();
		    request.setRootCaseId("TestRoot1234");
		    request.setOdsMilestoneTransactionId(111);
		    MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(request)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testRetryOdsMilestoneTransactions*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for RetryOdsMilestoneTransactions: ",e);
		}
	}
	
	@Test
	public void testRetryOdsMilestoneTransactions1() {
		try {
			LOGGER.info("****************************Entering to testRetryOdsMilestoneTransactions1*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneTransaction/retry");
		    OdsMilestoneTransactionRequest request = new OdsMilestoneTransactionRequest();
		    request.setRootCaseId("TestRoot1234");
		    request.setOdsMilestoneTransactionId(0);
		    MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(request)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testRetryOdsMilestoneTransactions1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for RetryOdsMilestoneTransactions: ",e);
		}
	}
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_transaction.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_transaction.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_transaction.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_milestone_config.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_milestone_config.sql")
		})
	public void testRetryOdsMilestoneTransactions2() {
		try {
			LOGGER.info("****************************Entering to testRetryOdsMilestoneTransactions2*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneTransaction/retry");
		    OdsMilestoneTransactionRequest request = new OdsMilestoneTransactionRequest();
		    request.setRootCaseId("TestRoot1234");
		    request.setOdsMilestoneTransactionId(111);
		    request.setReProcessFlag("YES");
		    MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(request)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testRetryOdsMilestoneTransactions2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for RetryOdsMilestoneTransactions: ",e);
		}
	}
	@Test
	public void testsendMilestone() {
		try {
			LOGGER.info("****************************Entering to testsendMilestone*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneTransaction/sendMilestone");
		   
			 MvcResult result = this.mockMvc
						.perform(post(url).contentType(MediaType.APPLICATION_JSON)
								.content(getTransformRequest("ZZZDE-NGPON2","LCI_OVER_NGPON2_Pre_Activation","RetrieveONTSerialNumber")))
						.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
						.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testsendMilestone*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for SendOdsMilestone: ",e);
		}
	}
	@Test
	public void testsendMilestone1() {
		try {
			LOGGER.info("****************************Entering to testsendMilestone1*****************************");
			URI url = new URI("/oneDispatcher/odsMilestoneTransaction/sendMilestone");
		   
			 MvcResult result = this.mockMvc
						.perform(post(url).contentType(MediaType.APPLICATION_JSON)
								.content(getTransformRequest("ZZZDE-NGPON2","LCI_OVER_NGPON2_Pre_Activation","ADDONT")))
						.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
						.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testsendOdsMilestone1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for SendMilestone: ",e);
		}
	}
	
	

	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}
	public String getTransformRequest(String appKey, String flowNodeProcessName,String flowNodeStepName ) {
		Map<String, Object> mainValues=new HashMap<>();
		Map<String, Object> subValues=new HashMap<>();
		mainValues.put("app-key", appKey);
		mainValues.put("processInstanceId", "34567");
		mainValues.put("parentProcessInstanceId", "45678");
		mainValues.put("rootProcessInstanceId", "56789");
		mainValues.put("activityInstanceId", "7654");
		mainValues.put("rootProcessName", "Root");
		mainValues.put("flowNodeProcessName",flowNodeProcessName);
		mainValues.put("flowNodeStepName",  flowNodeStepName);
		subValues.put("order_number",  "CCOG639221728");
		subValues.put("order_version",  "001");
		subValues.put("product_type",  "Data");
		subValues.put("supp_type",  "Pending");
		subValues.put("region",  "NJ");
		mainValues.put("seedInfo",  subValues);

		JSONObject requestJson=new JSONObject(mainValues);
		LOGGER.info("getTransformRequest ::::"+requestJson.toString());
		return requestJson.toString();
	}
}
