package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.service.OdsMandatoryAttrsService;

@RunWith(MockitoJUnitRunner.class)

public class ODSMandatoryAttrsControllerMockitoTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSMandatoryAttrsControllerMockitoTest.class);

	@InjectMocks
	ODSMandatoryAttrsController odsMandatoryAttrsController;

	@Mock
	OdsMandatoryAttrsService odsMandatoryAttrsService;

	@Test
	public void testCreateOrUpdateOdsMandatoryAttrs() throws ApplicationException {

		LOGGER.info("Entering testCreateOrUpdateOdsMandatoryAttrs");
		OdsMandatoryAttributes request = new OdsMandatoryAttributes();
		OdsMandatoryAttributes response = null;
		when(odsMandatoryAttrsService.createOrUpdateOdsMandatoryAttrs(request)).thenReturn(response);
		odsMandatoryAttrsController.createOrUpdateOdsMandatoryAttrs(request);
		LOGGER.info("Exiting testCreateOrUpdateOdsMandatoryAttrs");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testCreateOrUpdateOdsMandatoryAttrs1() throws ApplicationException {

		LOGGER.info("Entering testCreateOrUpdateOdsMandatoryAttrs1");
		OdsMandatoryAttributes request = new OdsMandatoryAttributes();
		when(odsMandatoryAttrsService.createOrUpdateOdsMandatoryAttrs(request)).thenThrow(SQLException.class);
		odsMandatoryAttrsController.createOrUpdateOdsMandatoryAttrs(request);
		LOGGER.info("Exiting testCreateOrUpdateOdsMandatoryAttrs1");

	}

	@Test
	public void testGetOdsMandatoryAttrs() throws ApplicationException {

		LOGGER.info("Entering testGetOdsMandatoryAttrs");
		OdsMandatoryAttributes request = new OdsMandatoryAttributes();
		request.setAttrKey("attrkey");
		List<OdsMandatoryAttributes> odsMandatoryAttributes = null;
		when(odsMandatoryAttrsService.getMandatoryAttributeList(request.getAttrKey()))
				.thenReturn(odsMandatoryAttributes);
		odsMandatoryAttrsController.getOdsMandatoryAttrs(request);
		LOGGER.info("Exiting testGetOdsMandatoryAttrs");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetOdsMandatoryAttrs1() throws ApplicationException {

		LOGGER.info("Entering testGetOdsMandatoryAttrs1");
		OdsMandatoryAttributes request = new OdsMandatoryAttributes();
		request.setAttrKey("attrkey");

		when(odsMandatoryAttrsService.getMandatoryAttributeList(request.getAttrKey())).thenThrow(SQLException.class);
		odsMandatoryAttrsController.getOdsMandatoryAttrs(request);
		LOGGER.info("Exiting testGetOdsMandatoryAttrs1");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetOdsMandatoryAttrs2() throws ApplicationException {

		LOGGER.info("Entering testGetOdsMandatoryAttrs2");
		OdsMandatoryAttributes request = new OdsMandatoryAttributes();
		request.setAttrKey("attrkey");

		when(odsMandatoryAttrsService.getMandatoryAttributeList(request.getAttrKey()))
				.thenThrow(ApplicationException.class);
		odsMandatoryAttrsController.getOdsMandatoryAttrs(request);
		LOGGER.info("Exiting testGetOdsMandatoryAttrs2");

	}

	
	@Test
	public void testDeleteOdsMandatoryAttrs() throws ApplicationException {

		LOGGER.info("Entering testDeleteOdsMandatoryAttrs");
		List<OdsMandatoryAttributes> request = null;

		Mockito.doThrow(SQLException.class).when(odsMandatoryAttrsService).deleteOdsMandatoryAttrsRecord(request);
		odsMandatoryAttrsController.deleteOdsMandatoryAttrs(request);
		LOGGER.info("Exiting testDeleteOdsMandatoryAttrs");

	}

}
