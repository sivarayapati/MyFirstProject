package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dto.model.WfParamRequestDTO;
import com.vz.uiam.onenet.ods.service.WorkflowParamService;

@RunWith(MockitoJUnitRunner.class)
public class WorkFlowParamControllerMockitoTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(WorkFlowParamControllerMockitoTest.class);

	@InjectMocks
	WorkflowParamController workflowParamController;

	@Mock
	WorkflowParamService workflowParamService;
	
	@Test
	public void testHealthCheck() throws ApplicationException {
		LOGGER.info("Entering testHealthCheck");
		
		workflowParamController.healthCheck();
		
		LOGGER.info("Exiting testHealthCheck");
	}
	
	@Test
	public void testAddWfParams() throws ApplicationException {
		LOGGER.info("Entering testAddWfParams");
		
		WfParamRequestDTO request = Mockito.mock(WfParamRequestDTO.class);

		when(request.getWorkflowParams()).thenThrow(Exception.class);
		
		workflowParamController.addWfParams(request);
		
		LOGGER.info("Exiting testAddWfParams");
	}
	
	@Test
	public void testGetWfParam() throws ApplicationException {
		LOGGER.info("Entering testAddWfParams");
		
		WfParamRequestDTO request = Mockito.mock(WfParamRequestDTO.class);
		
		when(workflowParamService.getWorkflowParams(Mockito.any())).thenThrow(ApplicationException.class);
		
		workflowParamController.getWfParam(request);
		
		LOGGER.info("Exiting testAddWfParams");
	}
}
