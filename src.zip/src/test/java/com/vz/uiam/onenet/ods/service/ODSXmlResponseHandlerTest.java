
package com.vz.uiam.onenet.ods.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.context.ApplicationContext;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsTransformerConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class ODSXmlResponseHandlerTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ODSXmlResponseHandlerTest.class);

	@InjectMocks
	ODSXmlResponseHandler odsXmlResponseHandler;
	
	@Mock
	ODSResponseHandler odsResponseHandler;

	@Mock
	ServiceUtils serviceUtils;
	
	@Mock
	ApplicationContext appcontext;
	
	@Mock
	FalloutService falloutService;
	
	@Mock
	NotesService notesService;
	
	@Mock
	MilestoneService milestoneService;

	ResponseConfigParams responseConfigParam;
	OdsInterfaceRequest odsInterfaceRequest;
	
	@Mock
	OdsTransformerConfigService odsTransformerConfigService;
	
	@Mock
	OdsRequestLogRepository odsRequestLogRepository;
	
	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Before
	public void setUp() {
		responseConfigParam = new ResponseConfigParams();
		responseConfigParam.setAppKey("ZZZDE-NGPON2");
		responseConfigParam.setTransformationType("JSON");
		responseConfigParam.setFlowNodeProcessName("LCI_DATA_VALIDATION");
		responseConfigParam.setFlowNodeStepName("CircuitValidation");
		responseConfigParam.setCaseID("759480");
		responseConfigParam.setParentCaseID("759480");
		responseConfigParam.setRootCaseID("759479");
		responseConfigParam.setAppKey("ZZZDE-NGPON2");

		odsInterfaceRequest = new OdsInterfaceRequest();
		odsInterfaceRequest.setResponseConfigParam(responseConfigParam.toString());
		odsInterfaceRequest.setCoreleationPayload("");
		odsInterfaceRequest.setManifestPayload("");
		odsInterfaceRequest.setTransactionId("1497649132563|759480|17944142");
		odsInterfaceRequest.setCoreleationPayload("TestPayLoad");
		odsInterfaceRequest.setTaskId("123455");
		
	}

	@Test
	public void testGetTransactionIdFromXmlNodeValue() throws ApplicationException {
		LOGGER.info("Entering testGetTransactionIdFromXmlNodeValue");
		String transactionId = "1514976672203|34567|7654";
		String xmlResponse ="<nbaTransaction></nbaTransaction>";
		when(serviceUtils.getNodeValueFromXml(anyString(),anyString())).thenReturn(transactionId);
		odsXmlResponseHandler.getTransactionIdFromXmlNodeValue(xmlResponse);

		LOGGER.info("Exiting testGetTransactionIdFromXmlNodeValue");
	}

	@Test(expected = ApplicationException.class)
    public void testGetTransactionIdFromXmlNodeValue1() throws ApplicationException {
		LOGGER.info("Entering testGetTransactionIdFromXmlNodeValue1");
		String transactionId = "";
		String xmlResponse ="<nbaTransaction></nbaTransaction>";
		when(serviceUtils.getNodeValueFromXml(anyString(),anyString())).thenReturn(transactionId);
		odsXmlResponseHandler.getTransactionIdFromXmlNodeValue(xmlResponse);

		LOGGER.info("Exiting testGetTransactionIdFromXmlNodeValue1");
	}
	
	@Test
	public void testgetTransactionIdFromResponseUsingTransactionIdKey() throws ApplicationException
	{
		LOGGER.info("Entering testgetTransactionIdFromResponseUsingTransactionIdKey");
		String transactionId = "1514976672203|34567|7654";
		String response ="<planningMessage></planningMessage>";
		String responseXml="<planningMessage></planningMessage";
		when( serviceUtils.removeCdataFromXml(anyString())).thenReturn(responseXml);
		when( serviceUtils.getNodeValueFromXml(anyString(), anyString())).thenReturn(transactionId);
		odsXmlResponseHandler.getTransactionIdFromResponseUsingTransactionIdKey(response, "VersionNumber|OrderNumber");

		LOGGER.info("Exiting testgetTransactionIdFromResponseUsingTransactionIdKey");
	}
	
	@Test
	public void testHandleException() throws ApplicationException
	{
		LOGGER.info("Entering testHandleException");
		JSONObject originalResponse =new JSONObject();
		ResponseStatus failureResponseStatus = new ResponseStatus();
		doNothing().when(odsResponseHandler).addOrUpdateStatus(any(), any());
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		odsXmlResponseHandler.handleException(originalResponse, failureResponseStatus, odsInterfaceRequest);
		LOGGER.info("Exiting testHandleException");
		
	}
	
	@Test
	public void testdoSvcXMLResponseProcessing() throws ApplicationException {
		LOGGER.info("Entering testdoSvcXMLResponseProcessing");
		String transactionId = "1514976672203|34567|7654";
		String xmlResponse ="<nbaTransaction></nbaTransaction>";
		when(serviceUtils.getNodeValueFromXml(anyString(),anyString())).thenReturn(transactionId);
		when(odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(transactionId, StatusCode.REQUEST_PENDING.toString())).thenReturn(odsInterfaceRequest);
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		JSONObject responseXmlJsonObj = new JSONObject("{\"json\" :\"json\"}");
		when(serviceUtils.convertXmlToJson(anyString())).thenReturn(responseXmlJsonObj);
		OdsTransformerConfig odsTranformerConfig = new OdsTransformerConfig();
		when(odsTransformerConfigService.getOdsTransformerConfig(anyString())).thenReturn(odsTranformerConfig);
		ResponseStatus responseStatus = new ResponseStatus();
		when(odsResponseHandler.processResponse(any(), any())).thenReturn(responseStatus);
		doNothing().when(odsResponseHandler).updateResponseInNotes(anyString(), anyString(), anyString());
		odsXmlResponseHandler.doSvcXMLResponseProcessing(xmlResponse);

		LOGGER.info("Exiting testdoSvcXMLResponseProcessing");
	}

	@Test(expected = ApplicationException.class)
	public void testdoSvcXMLResponseProcessing1() throws ApplicationException {
		LOGGER.info("Entering testdoSvcXMLResponseProcessing1");
		String transactionId = "";
		String xmlResponse ="<nbaTransaction></nbaTransaction>";
		when(serviceUtils.getNodeValueFromXml(anyString(),anyString())).thenReturn(transactionId);
		odsXmlResponseHandler.doSvcXMLResponseProcessing(xmlResponse);

		LOGGER.info("Exiting testdoSvcXMLResponseProcessing1");
	}
	@Test
	public void testDoXMLResponseProcessing() throws ApplicationException {
		LOGGER.info("Entering testDoXMLResponseProcessing");
		String transactionId = "1514976672203|34567|7654";
		String xmlResponse ="<nbaTransaction></nbaTransaction>";
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		JSONObject responseXmlJsonObj = new JSONObject("{\"json\" :\"json\"}");
		when(serviceUtils.convertXmlToJson(anyString())).thenReturn(responseXmlJsonObj);
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode("000");
		responseStatus.setDescription("success");
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setTitle("12345");
		odsRequestLog.setTitleVersion("0");
		when(odsResponseHandler.processResponse(Mockito.anyString(), Mockito.any(OdsInterfaceRequest.class), Mockito.any(ResponseConfigParams.class), Mockito.anyString())).thenReturn(responseStatus);
		when(odsRequestLogRepository.findByWfTaskId("123455")).thenReturn(odsRequestLog);
		odsXmlResponseHandler.doXMLResponseProcessing(xmlResponse, transactionId, odsInterfaceRequest);

		LOGGER.info("Exiting testDoXMLResponseProcessing");
	}
	
	@Test
	public void testDoXMLResponseProcessing1() throws ApplicationException {
		LOGGER.info("Entering testDoXMLResponseProcessing1");
		String transactionId = "1514976672203|34567|7654";
		String xmlResponse ="<nbaTransaction></nbaTransaction>";
		OdsTransformerConfig odsTranformerConfig =new OdsTransformerConfig();
		odsTranformerConfig.setOdsTransformerId(1);
		odsTranformerConfig.setTransformerSchema("<nbaTransaction></nbaTransaction>");
		odsTranformerConfig.setTransformerType(Constants.TRANSFORMATION_XML_TYPE);
		when(odsTransformerConfigService.getOdsTransformerConfig(Mockito.anyString())).thenReturn(odsTranformerConfig);
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		JSONObject responseXmlJsonObj = new JSONObject("{\"json\" :\"json\"}");
		when(serviceUtils.convertXmlToJson(anyString())).thenReturn(responseXmlJsonObj);
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode("000");
		responseStatus.setDescription("success");
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setTitle("12345");
		odsRequestLog.setTitleVersion("0");
		when(odsResponseHandler.processResponse(Mockito.anyString(), Mockito.any(OdsInterfaceRequest.class), Mockito.any(ResponseConfigParams.class), Mockito.anyString())).thenReturn(responseStatus);
		when(odsRequestLogRepository.findByWfTaskId("123455")).thenReturn(odsRequestLog);
		odsXmlResponseHandler.doXMLResponseProcessing(xmlResponse, transactionId, odsInterfaceRequest);

		LOGGER.info("Exiting testDoXMLResponseProcessing1");
	}

	@Test
	public void testDoXMLResponseProcessing2() throws ApplicationException {
		LOGGER.info("Entering testDoXMLResponseProcessing2");
		String xmlResponse ="<nbaTransaction></nbaTransaction>";
		String rootTagName ="nbaTransaction";
		OdsTransformerConfig odsTranformerConfig =new OdsTransformerConfig();
		odsTranformerConfig.setOdsTransformerId(1);
		odsTranformerConfig.setTransformerSchema("<nbaTransaction></nbaTransaction>");
		odsTranformerConfig.setTransformerType(Constants.TRANSFORMATION_XML_TYPE);
		when(serviceUtils.getRootTagFromXml(Mockito.anyString())).thenReturn(rootTagName);
		when( odsResponseHandler.getTransIdKeyFromOdsRespTransIdMap(rootTagName)).thenReturn("transactionId");
		when(odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(Mockito.anyString(), Mockito.anyString())).thenReturn(odsInterfaceRequest);
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		JSONObject responseXmlJsonObj = new JSONObject("{\"json\" :\"json\"}");
		when(serviceUtils.convertXmlToJson(anyString())).thenReturn(responseXmlJsonObj);
		when(odsTransformerConfigService.getOdsTransformerConfig(anyString())).thenReturn(odsTranformerConfig);
		ResponseStatus responseStatus = new ResponseStatus();
		when(odsResponseHandler.processResponse(any(), any())).thenReturn(responseStatus);
		doNothing().when(odsResponseHandler).updateResponseInNotes(anyString(), anyString(), anyString());
		
		odsXmlResponseHandler.doXMLResponseProcessing(xmlResponse);

		LOGGER.info("Exiting testDoXMLResponseProcessing2");
	}
	@Test
	public void testGetTransactionIdFromRespTransIdMap() throws ApplicationException {
		LOGGER.info("Entering testGetTransactionIdFromRespTransIdMap");
		String rootTagName ="nbaTransaction";
		String xmlResponse ="<nbaTransaction></nbaTransaction>";
		when(serviceUtils.getRootTagFromXml(Mockito.anyString())).thenReturn(rootTagName);
		when( odsResponseHandler.getTransIdKeyFromOdsRespTransIdMap(rootTagName)).thenReturn("transactionId");
		odsXmlResponseHandler.getTransactionIdFromRespTransIdMap(xmlResponse);

		LOGGER.info("Exiting testGetTransactionIdFromRespTransIdMap");
	}
	@Test
	public void testHandleException1() throws ApplicationException
	{
		LOGGER.info("Entering testHandleException1");
		JSONObject originalResponse =new JSONObject();
		ResponseStatus failureResponseStatus = new ResponseStatus();
		odsInterfaceRequest = null;
		doNothing().when(odsResponseHandler).addOrUpdateStatus(any(), any());
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		odsXmlResponseHandler.handleException(originalResponse, failureResponseStatus, odsInterfaceRequest);
		LOGGER.info("Exiting testHandleException1");
		
	}
	@Test
	public void testHandleException2() throws ApplicationException
	{
		LOGGER.info("Entering testHandleException2");
		JSONObject originalResponse =new JSONObject();
		ResponseStatus failureResponseStatus = new ResponseStatus();
		doNothing().when(odsResponseHandler).addOrUpdateStatus(any(), any());
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		when(odsRequestLogRepository.findByWfTaskId(odsInterfaceRequest.getTaskId())).thenReturn(odsRequestLog);
		odsXmlResponseHandler.handleException(originalResponse, failureResponseStatus, odsInterfaceRequest);
		LOGGER.info("Exiting testHandleException2");
		
	}
	@Test(expected=ApplicationException.class)
	public void testgetTransactionIdFromResponseUsingTransactionIdKey1() throws ApplicationException
	{
		LOGGER.info("Entering testgetTransactionIdFromResponseUsingTransactionIdKey1");
		String transactionId = "";
		String response ="<planningMessage></planningMessage>";
		String responseXml="<planningMessage></planningMessage";
		when( serviceUtils.removeCdataFromXml(anyString())).thenReturn(responseXml);
		when( serviceUtils.getNodeValueFromXml(anyString(), anyString())).thenReturn(transactionId);
		odsXmlResponseHandler.getTransactionIdFromResponseUsingTransactionIdKey(response, Constants.DEFAULT);

		LOGGER.info("Exiting testgetTransactionIdFromResponseUsingTransactionIdKey1");
	}
	@Test
	public void testHandleException3() throws ApplicationException
	{
		LOGGER.info("Entering testHandleException3");
		JSONObject originalResponse =new JSONObject();
		ResponseStatus failureResponseStatus = new ResponseStatus();
		doNothing().when(odsResponseHandler).addOrUpdateStatus(any(), any());
		responseConfigParam =null;
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		odsXmlResponseHandler.handleException(originalResponse, failureResponseStatus, odsInterfaceRequest);
		LOGGER.info("Exiting testHandleException3");
		
	}


}
