
package com.vz.uiam.onenet.ods.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsResponseTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFallout;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsResponseTransactionIdMapRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsServiceRouterMapRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.WorkflowFalloutRepo;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.jpa.dto.model.WorkflowFalloutRequest;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class ODSResponseHandlerTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ODSResponseHandlerTest.class);

	@InjectMocks
	ODSResponseHandler odsResponseHandler;
	
	@InjectMocks
	ManifestService manifestServiceMock;

	@Mock
	OdsParamConfigRepository odsParamConfigRepository;

	@Mock
	RequestEntity<String> requestEntity;

	@Mock
	OdsServiceRouterMapRepository odsServiceRouterMapRepository;

	@Mock
	OdsInterfaceRequestRepository odsRequestRepo;

	@Mock
	WorkflowParamService workflowParamService;

	@Mock
	@Autowired
	OdsResponseTransactionIdMapRepository odsResponseTransactionIdMapRepository;

	@Mock
	HttpEntity<String> httpEntity;

	@Mock
	ResponseEntity<String> responseEntity;

	@Mock
	ServiceUtils serviceUtils;
	
	@Mock
	ManifestService manifestService;
	
	@Mock
	ApplicationContext appcontext;
	
	@Mock
	FalloutService falloutService;
	
	@Mock
	NotesService notesService;
	
	@Mock
	MilestoneService milestoneService;
	
	@Mock
	OdsTransformerConfigService odsTransformerConfigService;
	
	@Mock 
	OdsRequestLogRepository odsRequestLogRepository;
	
	@Mock
	OdsMandatoryAttrsService odsMandatoryAttrsService;
	
	@Mock
	BonitaService bonitaService;
	
	@Mock
	WorkflowFalloutRepo fallOutRepo;
	
	
	
	ResponseConfigParams responseConfigParam;
	OdsInterfaceRequest odsInterfaceRequest;
	WorkflowFallout wfFallout;
	String requestKey=null;
	OdsRequestLog odsRequestLog ;
	
	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Before
	public void setUp() {
		responseConfigParam = new ResponseConfigParams();
		responseConfigParam.setAppKey("ZZZDE-NGPON2");
		responseConfigParam.setTransformationType("JSON");
		responseConfigParam.setFlowNodeProcessName("LCI_DATA_VALIDATION");
		responseConfigParam.setFlowNodeStepName("CircuitValidation");
		responseConfigParam.setCaseID("759480");
		responseConfigParam.setParentCaseID("759480");
		responseConfigParam.setRootCaseID("759479");
		responseConfigParam.setAppKey("ZZZDE-NGPON2");
		responseConfigParam.setResponseDocumentName("srDocument,orderDocument");

		odsInterfaceRequest = new OdsInterfaceRequest();
		odsInterfaceRequest.setResponseConfigParam(responseConfigParam.toString());
		odsInterfaceRequest.setCoreleationPayload("");
		odsInterfaceRequest.setManifestPayload("");
		odsInterfaceRequest.setTransactionId("1497649132563|759480|17944142");
		odsInterfaceRequest.setCoreleationPayload("TestPayLoad");
		odsInterfaceRequest.setRequest("{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }");
		requestKey = "LCI_DATA_Pre_Activation_AddONT";
		
		 odsRequestLog = new OdsRequestLog();
		 odsRequestLog.setOdsRequestLogId(123);
		 odsRequestLog.setResponseStatus(StatusCode.IN_PROGRESS.toString());
		 odsRequestLog.setTitle("Process");
		 odsRequestLog.setTitleVersion("0.2");
		 odsRequestLog.setWfTaskId("12346");

	}	
	
	@Test(expected =NullPointerException.class)
	public void testprocessResponseFailure1() throws ApplicationException {
		LOGGER.info("Entering testprocessResponseFailure1");
		String statusCode = "1";

		when(serviceUtils.readValueFromJson(anyString(), anyString())).thenReturn(statusCode);
		String response = "{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"00000\" 		}, 		\"xmlns\": \"urn:vnm.verizon.com/Schemas/NBParms\", 		\"xmlns:xsi1\": \"http://www.w3.org/2001/XMLSchema-instance\", 		\"vnmdesc\": { 			\"xmlns\": \"\", 			\"content\": \"SUCCESS\" 		}, 		\"xsi:schemaLocation\": \"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\", 		\"xmlns:xsi\": \"http://www.w3.org/2001/XMLSchema\", 		\"requests\": { 			\"statuscode\": \"00000\", 			\"xmlns\": \"\", 			\"requestType\": \"VNM_RTRV_UNLOCKED_ONTS\", 			\"vnmdesc\": \"SUCCESS\", 			\"mne\": { 				\"tid\": \"TMPAFLERICERICE901\" 			}, 			\"groups\": { 				\"trails\": { 					\"tpaOptical\": { 						\"rack\": 1, 						\"port\": 1, 						\"slot\": 1, 						\"shelf\": 2 					}, 					\"attribute\": [{ 						\"name\": \"TRANSACTION_ID\", 						\"content\": \"1497649132563|759480|17944142\" 					}, { 						\"name\": \"PONSYSTEMID\", 						\"content\": 60000 					}, { 						\"name\": \"PRIORITY\", 						\"content\": \"PRIORITY_4\" 					}, { 						\"name\": \"UNLOCKED_ONTS\", 						\"content\": \"12345678,87654321\" 					}] 				} 			} 		} 	} }";
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		
		ResponseStatus res = odsResponseHandler.processResponse(response, odsInterfaceRequest);

		assertNotNull(res);
		LOGGER.info("Exiting testprocessResponseFailure1");
	}

	@Test(expected = JSONException.class)
	public void testprocessResponseFailure2() throws ApplicationException {
		LOGGER.info("Entering testprocessResponseFailure2");
		String statusCode = "1";

		when(serviceUtils.readValueFromJson(anyString(), anyString())).thenReturn(statusCode);
		String response = "{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"00000\" 		}, 		\"xmlns\": \"urn:vnm.verizon.com/Schemas/NBParms\", 		\"xmlns:xsi1\": \"http://www.w3.org/2001/XMLSchema-instance\", 		\"vnmdesc\": { 			\"xmlns\": \"\", 			\"content\": \"SUCCESS\" 		}, 		\"xsi:schemaLocation\": \"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\", 		\"xmlns:xsi\": \"http://www.w3.org/2001/XMLSchema\", 		\"requests\": { 			\"statuscode\": \"00000\", 			\"xmlns\": \"\", 			\"requestType\": \"VNM_RTRV_UNLOCKED_ONTS\", 			\"vnmdesc\": \"SUCCESS\", 			\"mne\": { 				\"tid\": \"TMPAFLERICERICE901\" 			}, 			\"groups\": { 				\"trails\": { 					\"tpaOptical\": { 						\"rack\": 1, 						\"port\": 1, 						\"slot\": 1, 						\"shelf\": 2 					}, 					\"attribute\": [{ 						\"name\": \"TRANSACTION_ID\", 						\"content\": \"1497649132563|759480|17944142\" 					}, { 						\"name\": \"PONSYSTEMID\", 						\"content\": 60000 					}, { 						\"name\": \"PRIORITY\", 						\"content\": \"PRIORITY_4\" 					}, { 						\"name\": \"UNLOCKED_ONTS\", 						\"content\": \"12345678,87654321\" 					}] 				} 			} 		} 	} }";
		responseConfigParam.setResponseDocumentName("TestDoc");
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		
		String manifest = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG711251114_CHANGE\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"000\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"PA\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"NA\" 			}] 		} 	} }";
		odsInterfaceRequest.setManifestPayload(manifest);
		ResponseStatus res = odsResponseHandler.processResponse(response, odsInterfaceRequest);

		assertNotNull(res);
		LOGGER.info("Exiting testprocessResponseFailure2");
	}
	
	@Test
	public void testprepareCorrelationContentFailure() throws ApplicationException  {
		ResponseStatus status = new ResponseStatus();
		OdsParamConfig odsParamConfig = null;
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString()))
		.thenReturn(odsParamConfig);
		doNothing().when(serviceUtils).populateJsonPayload(anyString(), anyString(),Mockito.any());
		odsResponseHandler.prepareCorrelationContent(status, null, requestKey);
		LOGGER.info("Exiting testGetManifestDocument3");
	}

	@Test
	public void testupdateResponseInNotes1() throws ApplicationException {
		LOGGER.info("Entering testupdateResponseInNotes1");
		String transictinId = "5";
		String response = "TestResponse";
		doNothing().when(notesService).updateResponseInNotes(anyString(), anyString(), anyString());
		
		odsResponseHandler.updateResponseInNotes(transictinId, response, requestKey);

		LOGGER.info("Exiting testupdateResponseInNotes1");
	}

	@Test
	public void testcloseTaskInBonitaSuccess() throws ApplicationException {
		LOGGER.info("Entering testcloseTaskInBonita1");
		String correlationData = "{ 	\"bonitaProcessName\": \"LCI_DATA_PROVISIONING\", 	\"bonitaMessageName\": \"odnProvRecieveMsg\", 	\"correlations\": { 		\"orderNumber\": \"11ROHANAND44422\", 		\"caseId\": \"769290\", 		\"orderVersion\": \"000\" 	}, 	\"bonitaFlowNodeName\": \"ODN-Provisioning\" }";
		String contentData = "{    \"rootProcessName\" : null,    \"flowNodeProcessName\" : \"LCI_DATA_PROVISIONING\",    \"flowNodeStepName\" : \"ODN-Provisioning\",    \"caseID\" : \"773396\",    \"parentCaseID\" : \"773396\",    \"rootCaseID\" : \"773396\",    \"responseDocumentName\" : \"PlanningMessage\",    \"transformationType\" : \"XML\",    \"appKey\" : \"ZZZDE-NGPON2\"  }";
		JSONObject finalCorrelationJsonData = new JSONObject();
		finalCorrelationJsonData.put("bonitaProcessName", "LCI_DATA_PROVISIONING");
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("True");
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setParamKey("ODS");
	
		ResponseEntity<String> responseEntity4 = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.OK);

		when(serviceUtils.mergeJSONObjects(any(), any())).thenReturn(finalCorrelationJsonData);
		when(serviceUtils.callService(any(), any(HttpEntity.class))).thenReturn(responseEntity4);
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.CLOSE_BONITA_TASK_URL)).thenReturn(odsParamConfig);

		odsResponseHandler.closeTaskInBonita(correlationData, contentData);

		LOGGER.info("Exiting testcloseTaskInBonita1");
	}

	@Test(expected = ApplicationException.class)
	public void testcloseTaskInBonitaFailure1() throws ApplicationException {
		LOGGER.info("Entering testcloseTaskInBonita1");
		String correlationData = "{ 	\"bonitaProcessName\": \"LCI_DATA_PROVISIONING\", 	\"bonitaMessageName\": \"odnProvRecieveMsg\", 	\"correlations\": { 		\"orderNumber\": \"11ROHANAND44422\", 		\"caseId\": \"769290\", 		\"orderVersion\": \"000\" 	}, 	\"bonitaFlowNodeName\": \"ODN-Provisioning\" }";
		String contentData = "{    \"rootProcessName\" : null,    \"flowNodeProcessName\" : \"LCI_DATA_PROVISIONING\",    \"flowNodeStepName\" : \"ODN-Provisioning\",    \"caseID\" : \"773396\",    \"parentCaseID\" : \"773396\",    \"rootCaseID\" : \"773396\",    \"responseDocumentName\" : \"PlanningMessage\",    \"transformationType\" : \"XML\",    \"appKey\" : \"ZZZDE-NGPON2\"  }";
		JSONObject finalCorrelationJsonData = new JSONObject();
		finalCorrelationJsonData.put("bonitaProcessName", "LCI_DATA_PROVISIONING");
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		
		ResponseEntity<String> responseEntity3 = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.OK);
	
		when(serviceUtils.mergeJSONObjects(any(), any())).thenReturn(finalCorrelationJsonData);
		when(serviceUtils.callService(any(), any(HttpEntity.class))).thenReturn(responseEntity3);
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.CLOSE_BONITA_TASK_URL)).thenReturn(odsParamConfig);

		odsResponseHandler.closeTaskInBonita(correlationData, contentData);

		LOGGER.info("Exiting testcloseTaskInBonita1");

	}

	@Test(expected = ApplicationException.class)
	public void testcloseTaskInBonitaFailure2() throws ApplicationException {
		LOGGER.info("Entering testcloseTaskInBonita1");
		String correlationData = "{ 	\"bonitaProcessName\": \"LCI_DATA_PROVISIONING\", 	\"bonitaMessageName\": \"odnProvRecieveMsg\", 	\"correlations\": { 		\"orderNumber\": \"11ROHANAND44422\", 		\"caseId\": \"769290\", 		\"orderVersion\": \"000\" 	}, 	\"bonitaFlowNodeName\": \"ODN-Provisioning\" }";
		String contentData = "{    \"rootProcessName\" : null,    \"flowNodeProcessName\" : \"LCI_DATA_PROVISIONING\",    \"flowNodeStepName\" : \"ODN-Provisioning\",    \"caseID\" : \"773396\",    \"parentCaseID\" : \"773396\",    \"rootCaseID\" : \"773396\",    \"responseDocumentName\" : \"PlanningMessage\",    \"transformationType\" : \"XML\",    \"appKey\" : \"ZZZDE-NGPON2\"  }";
		JSONObject finalCorrelationJsonData = new JSONObject();
		finalCorrelationJsonData.put("bonitaProcessName", "LCI_DATA_PROVISIONING");
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("True");
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setParamKey("ODS");
		
	   when(serviceUtils.mergeJSONObjects(any(), any())).thenReturn(finalCorrelationJsonData);
	   when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.CLOSE_BONITA_TASK_URL)).thenReturn(odsParamConfig);

		odsResponseHandler.closeTaskInBonita(correlationData, contentData);

		LOGGER.info("Exiting testcloseTaskInBonita1");
	}

	@Test(expected = RuntimeException.class)
	public void testcloseTaskInBonitaFailure3() throws ApplicationException {
		LOGGER.info("Entering testcloseTaskInBonita1");
		String correlationData = "{ 	\"bonitaProcessName\": \"LCI_DATA_PROVISIONING\", 	\"bonitaMessageName\": \"odnProvRecieveMsg\", 	\"correlations\": { 		\"orderNumber\": \"11ROHANAND44422\", 		\"caseId\": \"769290\", 		\"orderVersion\": \"000\" 	}, 	\"bonitaFlowNodeName\": \"ODN-Provisioning\" }";
		String contentData = "{    \"rootProcessName\" : null,    \"flowNodeProcessName\" : \"LCI_DATA_PROVISIONING\",    \"flowNodeStepName\" : \"ODN-Provisioning\",    \"caseID\" : \"773396\",    \"parentCaseID\" : \"773396\",    \"rootCaseID\" : \"773396\",    \"responseDocumentName\" : \"PlanningMessage\",    \"transformationType\" : \"XML\",    \"appKey\" : \"ZZZDE-NGPON2\"  }";
		JSONObject finalCorrelationJsonData = new JSONObject();
		finalCorrelationJsonData.put("bonitaProcessName", "LCI_DATA_PROVISIONING");
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("True");
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setParamKey("ODS");

		when(serviceUtils.mergeJSONObjects(any(), any())).thenReturn(finalCorrelationJsonData);
		when(serviceUtils.callService(any(), any(HttpEntity.class))).thenThrow(new RuntimeException());
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.CLOSE_BONITA_TASK_URL)).thenReturn(odsParamConfig);

		odsResponseHandler.closeTaskInBonita(correlationData, contentData);

		LOGGER.info("Exiting testcloseTaskInBonita1");
	}

	@Test
	public void testaddOrUpdateStatus1() throws ApplicationException {
		LOGGER.info("Entering testaddOrUpdateStatusSuccess1");
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode("200");
		responseStatus.setDescription("Success");
		JSONObject jsonData = new JSONObject();
		jsonData = null;
		odsResponseHandler.addOrUpdateStatus(jsonData, responseStatus);

		LOGGER.info("Exiting testaddOrUpdateStatusSuccess1");
	}

	@Test
	public void testaddOrUpdateStatus2() throws ApplicationException {
		LOGGER.info("Entering testaddOrUpdateStatusSuccess1");
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode("200");
		responseStatus.setDescription("Success");
		JSONObject jsonData = new JSONObject();
		JSONObject jsonData1 = new JSONObject();
		jsonData.put("status", jsonData1);

		odsResponseHandler.addOrUpdateStatus(jsonData, responseStatus);

		LOGGER.info("Exiting testaddOrUpdateStatusSuccess1");
	}

	@Test
	public void testcreateFallout1() throws ApplicationException {
		LOGGER.info("Entering testcreateFallout1");
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode("200");
		responseStatus.setDescription("Success");
		
		doNothing().when(falloutService).createFallout(Mockito.any());
		
		odsResponseHandler.createFallout(responseConfigParam, responseStatus);

		LOGGER.info("Exiting testcreateFallout1");
	}

	@Test
	public void testcloseTaskInBonita() throws ApplicationException {
		LOGGER.info("Entering testcreateFallout1");
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setCode("200");
		responseStatus.setDescription("Success");
		
		odsResponseHandler.closeTaskInBonita(odsInterfaceRequest, responseStatus, requestKey);

		LOGGER.info("Exiting testcreateFallout1");
	}

	@Test(expected = ApplicationException.class)
	public void testgetTransIdKeyFromOdsRespTransIdMapFail() throws ApplicationException {
		LOGGER.info("Entering testgetTransIdKeyFromOdsRespTransIdMap1");
		String rootTagName = "";
		OdsResponseTransactionIdMap odsResponseTransactionIdMap = new OdsResponseTransactionIdMap();
		when(odsResponseTransactionIdMapRepository.findByRootTagName(anyString()))
		.thenReturn(odsResponseTransactionIdMap);
		odsResponseHandler.getTransIdKeyFromOdsRespTransIdMap(rootTagName);

		LOGGER.info("Exiting testgetTransIdKeyFromOdsRespTransIdMap1");
	}

	@Test
	public void testgetTransIdKeyFromOdsRespTransIdMapSuccess() throws ApplicationException {
		LOGGER.info("Entering testgetTransIdKeyFromOdsRespTransIdMap1");
		String rootTagName = "";
		OdsResponseTransactionIdMap odsResponseTransactionIdMap = new OdsResponseTransactionIdMap();
		odsResponseTransactionIdMap.setTransactionIdKey("Trass1");
		
		when(odsResponseTransactionIdMapRepository.findByRootTagName(anyString()))
		.thenReturn(odsResponseTransactionIdMap);
		odsResponseHandler.getTransIdKeyFromOdsRespTransIdMap(rootTagName);

		LOGGER.info("Exiting testgetTransIdKeyFromOdsRespTransIdMap1");
	}

	@Test
	public void testgetOdsInterfaceRequestByTransactionIdAndStatusSucceess() throws ApplicationException {
		LOGGER.info("Entering testgetOdsInterfaceRequestByTransactionIdAndStatusSucceess");
		String transictionId = "123";
		String status = "Success";
		when(odsRequestRepo.findByTransactionIdAndStatus(transictionId, status)).thenReturn(odsInterfaceRequest);
		odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(transictionId, status);

		LOGGER.info("Exiting testgetOdsInterfaceRequestByTransactionIdAndStatusSucceess");
	}

	@Test(expected = ApplicationException.class)
	public void testgetOdsInterfaceRequestByTransactionIdAndStatusFail1() throws ApplicationException {
		LOGGER.info("Entering testgetOdsInterfaceRequestByTransactionIdAndStatusFail1");
		String transictionId = "123";
		String status = "Success";
		OdsInterfaceRequest odsInterfaceRequest1 = null;
		when(odsRequestRepo.findByTransactionIdAndStatus(transictionId, status)).thenReturn(odsInterfaceRequest1);
		odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(transictionId, status);

		LOGGER.info("Exiting testgetOdsInterfaceRequestByTransactionIdAndStatusFail1");
	}

	
	@Test(expected = Exception.class)
	public void createOrUpdateWorkflowParams1() throws ApplicationException  {
		LOGGER.info("Entering createOrUpdateWorkflowParams1");
		ResponseConfigParams responseConfigParam1 = new ResponseConfigParams();
		responseConfigParam1.setCaseID("123");
		String response = "{ 	\"workflowParameters\": { 		\"workflowParams\": [{ 			\"paramValue\": \"TestParam\" 		}] 	} }";
		String appKey = "ZZZDE-NGPON2";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.BUILD_MANIFEST_ENDPOINT_URL))
		.thenReturn(odsParamConfig);

		doNothing().when(workflowParamService).createWorkflowParams(anyString(), anyString(), anyString());
		when(serviceUtils.callService(any(), any(HttpEntity.class))).thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		odsResponseHandler.createOrUpdateWorkflowParams(responseConfigParam1, response, appKey);

		LOGGER.info("Exiting createOrUpdateWorkflowParams1");
	}
	
	@Test
	public void testParseResponseParamsAndUpdateManifestDoc() throws ApplicationException  {
      LOGGER.info("Entering testParseResponseParamsAndUpdateManifestDoc");
		
		String manifestPayload = "{ \"entity-data\": {} }";
		
		OdsInterfaceRequest odsIntfReq = new OdsInterfaceRequest();
		odsIntfReq.setManifestPayload(manifestPayload);
		
		ResponseConfigParams respCfgPrm = new ResponseConfigParams();
		respCfgPrm.setResponseDocumentName("Resp_Doc");
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(respCfgPrm);
		
		List<OdsParamConfig> odsParamConfigList = new ArrayList<OdsParamConfig>();
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");
		odsParamConfigList.add(odsParamConfig);
		
		ManifestService manifestServiceSpy = Mockito.spy(manifestServiceMock);
		ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
		
		when(odsParamConfigRepository.findByParamKeyAndType(Mockito.any(),	Mockito.any())).thenReturn(odsParamConfigList);
		Mockito.doReturn("{ \"document-payload\": \"\" }").when(serviceUtils).getManifestDocument(Mockito.any());
		when(serviceUtils.readValueFromJson(anyString(), anyString())).thenReturn("aaa");
		doNothing().when(serviceUtils).addOrUpdateJsonProperty(Mockito.any(), anyString(), anyString());
		doNothing().when(manifestServiceSpy).createOrUpdateManifestDoc(Mockito.any());
		
		odsResponseHandlerSpy.parseResponseParamsAndUpdateManifestDoc(odsIntfReq, "{}", requestKey);
		
		LOGGER.info("Exiting testParseResponseParamsAndUpdateManifestDoc");
	}
	
	@Test
	public void testCloseTaskInBonita() throws ApplicationException {
		LOGGER.info("Entering testCloseTaskInBonita");
		odsResponseHandler.closeTaskInBonita(null, new ResponseStatus(), requestKey);
		
		LOGGER.info("Exiting testCloseTaskInBonita");
	}
	
	@Test
	public void testBuildPayloadToUpdateManifest() throws ApplicationException {
		 LOGGER.info("Entering testBuildPayloadToUpdateManifest");
			
			String manifestPayload = "{ \"entity-data\": {} }";
				
			List<OdsParamConfig> odsParamConfigList = new ArrayList<OdsParamConfig>();
			OdsParamConfig odsParamConfig = new OdsParamConfig();
			odsParamConfig.setType("ODS_PARAM");
			odsParamConfig.setValue("$.manifestDocumentName.status.statusCode");
			odsParamConfig.setParamKey("ODS");
			odsParamConfig.setName("Response_Param");
			odsParamConfigList.add(odsParamConfig);
			
			ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
			when(manifestService.getManifestDocument(anyString())).thenReturn("{\"document-payload\" :{}}");
			
			odsResponseHandlerSpy.buildPayloadToUpdateManifest("manifestDocumentName", "{}", manifestPayload, odsParamConfigList);
			
			LOGGER.info("Exiting testBuildPayloadToUpdateManifest");
	}
	@Test
	public void testBuildPayloadToUpdateManifest1() throws ApplicationException {
		 LOGGER.info("Entering testBuildPayloadToUpdateManifest1");
			
			String manifestPayload = "{ \"entity-data\": {} }";
						
			List<OdsParamConfig> odsParamConfigList = new ArrayList<OdsParamConfig>();
			OdsParamConfig odsParamConfig = new OdsParamConfig();
			odsParamConfig.setType("ODS_PARAM");
			odsParamConfig.setValue("$.manifestDocumentName.status.statusCode");
			odsParamConfig.setParamKey("ODS");
			odsParamConfig.setName("$.nbaTransaction.Status.StatusCode");
			odsParamConfigList.add(odsParamConfig);
			
			ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
			when(manifestService.getManifestDocument(anyString())).thenReturn("{\"document-payload\" :{}}");
			
			odsResponseHandlerSpy.buildPayloadToUpdateManifest("manifestDocumentName", "{}", manifestPayload, odsParamConfigList);
			
			LOGGER.info("Exiting testBuildPayloadToUpdateManifest1");
	}
	@SuppressWarnings("unchecked")
	@Test(expected=JSONException.class)
	public void testParseResponseParamsAndUpdateManifestDoc1() throws ApplicationException  {
      LOGGER.info("Entering testParseResponseParamsAndUpdateManifestDoc");
		
		String manifestPayload = "";
		String bonitaRequest = "{\r\n" + 
				" \"app-key\": \"ZZZDE-VRD\",\r\n" + 
				"\"processInstanceId\": \"34567\",\r\n" + 
				" \"activityInstanceId\": \"7654\",\r\n" + 
				" \"parentProcessInstanceId\": \"45678\",\r\n" + 
				" \"rootProcessInstanceId\": \"56789\",\r\n" + 
				" \"flowNodeProcessName\": \"LCI_DATA_CREATE_CLR\",\r\n" + 
				" \"flowNodeStepName\": \"SearchSite\",\r\n" + 
				" \"seedInfo\": {\r\n" + 
				" \"order_number\": \"12052017004\",\r\n" + 
				" \"order_version\": \"001\",\r\n" + 
				" \"product_type\": \"Data\",\r\n" + 
				" \"supp_type\": \"Pending\",\r\n" + 
				" \"document_level\": \"VERSION\"\r\n" + 
				" }\r\n" + 
				" }";
		OdsInterfaceRequest odsIntfReq = new OdsInterfaceRequest();
		odsIntfReq.setManifestPayload(manifestPayload);
		odsIntfReq.setRequest(bonitaRequest);
		
		ResponseConfigParams respCfgPrm = new ResponseConfigParams();
		respCfgPrm.setResponseDocumentName("Resp_Doc");
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(respCfgPrm);
		
		List<OdsParamConfig> odsParamConfigList = new ArrayList<OdsParamConfig>();
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("Resp_Doc");
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setName("Test");
		odsParamConfigList.add(odsParamConfig);
		
		ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
		ManifestService manifestServiceSpy = Mockito.spy(manifestServiceMock);
		
		when(odsParamConfigRepository.findByParamKeyAndType(Mockito.any(),	Mockito.any())).thenReturn(odsParamConfigList);
		Mockito.doReturn("{ \"document-payload\": \"\" }").when(serviceUtils).getManifestDocument(Mockito.any());
		when(serviceUtils.readValueFromJson(anyString(), anyString())).thenReturn("aaa");
		doNothing().when(serviceUtils).addOrUpdateJsonProperty(Mockito.any(), anyString(), anyString());
		doNothing().when(manifestServiceSpy).createOrUpdateManifestDoc(Mockito.any());
		manifestPayload="{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG711251114_CHANGE\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"000\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"PA\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"NA\" 			}] 		} 	} }";
		when(odsTransformerConfigService.tranformDocument(Mockito.any())).thenReturn(manifestPayload);
		when(manifestService.getManifestDocument(Mockito.any())).thenThrow(ApplicationException.class);
		odsResponseHandlerSpy.parseResponseParamsAndUpdateManifestDoc(odsIntfReq, "{}", requestKey);
		
		LOGGER.info("Exiting testParseResponseParamsAndUpdateManifestDoc");
	}
	
	@Test(expected=NullPointerException.class)
	public void processResponseTest() throws ApplicationException{
		LOGGER.info("Entering processResponseTest");
		String response ="response";
		String correlationContent ="{\"contents\":{}}";
		String finalCorrelation = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG711251114_CHANGE\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"000\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"PA\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"NA\" 			}] 		} 	} }"; 
		JSONObject finalCorrelationData = new JSONObject(finalCorrelation);
		 odsInterfaceRequest.setCoreleationPayload("{\"contents\":{}}");		
		 ResponseConfigParams responseConfigParam1 = new ResponseConfigParams();
		 responseConfigParam1.setResponseDocumentName("srDocument");
		when(odsRequestLogRepository.findByWfTaskId(odsInterfaceRequest.getTaskId())).thenReturn(odsRequestLog);	
		when(serviceUtils.mergeJSONObjects(new JSONObject(odsInterfaceRequest.getCoreleationPayload()), new JSONObject(correlationContent))).thenReturn(finalCorrelationData);
		odsResponseHandler.processResponse(response, odsInterfaceRequest, responseConfigParam, requestKey);
		when(serviceUtils
				.convertJsonStringToObject(anyString(), ResponseConfigParams.class)).thenReturn(responseConfigParam1);
		LOGGER.info("Exiting processResponseTest");
		
	}
	
	@Test
	public void validateAndSendMilestoneTestFailure() throws ApplicationException{
		LOGGER.info("Entering validateAndSendMilestoneTest");
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		odsResponseHandler.validateAndSendMilestone(odsInterfaceRequest);
		LOGGER.info("Exiting validateAndSendMilestoneTest");
		
	}
	
	@Test
	public void validateAndSendMilestoneTestSuccess() throws ApplicationException{
		LOGGER.info("Entering validateAndSendMilestoneTestSuccess");
		responseConfigParam.setSendMilestone(true);
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		odsResponseHandler.validateAndSendMilestone(odsInterfaceRequest);
		LOGGER.info("Exiting validateAndSendMilestoneTestSuccess");
		
	}
	
	@Test
	public void handleFalloutTest() throws ApplicationException{
		ResponseStatus status= new ResponseStatus();
		status.setCode("202");
		status.setDescription("Not Found");
		status.setSuccess(false);
		doNothing().when(falloutService).handleFallout(Mockito.any(),Mockito.any());
		odsRequestLog.setWfRequestPayload("{}");
		odsResponseHandler.handleFallout(status, responseConfigParam, odsRequestLog);
	}
	
	@Test
	public void testprocessResponse() throws ApplicationException {
		LOGGER.info("Entering testprocessResponse");
		String statusCode = "1";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("Resp_Doc");
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setName("Test");

		when(serviceUtils.readValueFromJson(anyString(), anyString())).thenReturn(statusCode);
		String response = "{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"00000\" 		}, 		\"xmlns\": \"urn:vnm.verizon.com/Schemas/NBParms\", 		\"xmlns:xsi1\": \"http://www.w3.org/2001/XMLSchema-instance\", 		\"vnmdesc\": { 			\"xmlns\": \"\", 			\"content\": \"SUCCESS\" 		}, 		\"xsi:schemaLocation\": \"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\", 		\"xmlns:xsi\": \"http://www.w3.org/2001/XMLSchema\", 		\"requests\": { 			\"statuscode\": \"00000\", 			\"xmlns\": \"\", 			\"requestType\": \"VNM_RTRV_UNLOCKED_ONTS\", 			\"vnmdesc\": \"SUCCESS\", 			\"mne\": { 				\"tid\": \"TMPAFLERICERICE901\" 			}, 			\"groups\": { 				\"trails\": { 					\"tpaOptical\": { 						\"rack\": 1, 						\"port\": 1, 						\"slot\": 1, 						\"shelf\": 2 					}, 					\"attribute\": [{ 						\"name\": \"TRANSACTION_ID\", 						\"content\": \"1497649132563|759480|17944142\" 					}, { 						\"name\": \"PONSYSTEMID\", 						\"content\": 60000 					}, { 						\"name\": \"PRIORITY\", 						\"content\": \"PRIORITY_4\" 					}, { 						\"name\": \"UNLOCKED_ONTS\", 						\"content\": \"12345678,87654321\" 					}] 				} 			} 		} 	} }";
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
		ManifestService manifestServiceSpy = Mockito.spy(manifestServiceMock);
		Mockito.doReturn(odsParamConfig).when(odsResponseHandlerSpy).getOdsParamConfigFromRequestKey(Mockito.anyString(),Mockito.anyString());
		Mockito.doReturn(odsParamConfig).when(odsResponseHandlerSpy).getOdsParamConfigFromRequestKey(Mockito.anyString(),Mockito.anyString());
		Mockito.doReturn(odsParamConfig).when(odsResponseHandlerSpy)
				.getOdsParamConfigFromRequestKey(Mockito.anyString(),Mockito.anyString());
		Mockito.doReturn(new JSONObject()).when(odsResponseHandlerSpy).buildPayloadToUpdateManifest(Mockito.anyString(), Mockito.anyString(),Mockito.anyString(),Mockito.anyList());
		Mockito.doNothing().when(manifestServiceSpy).createOrUpdateManifestDoc(Mockito.anyString());
		Mockito.doNothing().when(odsResponseHandlerSpy).closeTaskInBonita(Mockito.anyString(), Mockito.anyString());
		ResponseStatus res = odsResponseHandlerSpy.processResponse(response, odsInterfaceRequest);

		assertNotNull(res);
		LOGGER.info("Exiting testprocessResponse");
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testprocessResponse1() throws ApplicationException {
		LOGGER.info("Entering testprocessResponse");
		String statusCode = "1";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("NON_BLANK");
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setName("Test");

		when(serviceUtils.readValueFromJson(anyString(), anyString())).thenReturn(statusCode);
		String response = "{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"00000\" 		}, 		\"xmlns\": \"urn:vnm.verizon.com/Schemas/NBParms\", 		\"xmlns:xsi1\": \"http://www.w3.org/2001/XMLSchema-instance\", 		\"vnmdesc\": { 			\"xmlns\": \"\", 			\"content\": \"SUCCESS\" 		}, 		\"xsi:schemaLocation\": \"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\", 		\"xmlns:xsi\": \"http://www.w3.org/2001/XMLSchema\", 		\"requests\": { 			\"statuscode\": \"00000\", 			\"xmlns\": \"\", 			\"requestType\": \"VNM_RTRV_UNLOCKED_ONTS\", 			\"vnmdesc\": \"SUCCESS\", 			\"mne\": { 				\"tid\": \"TMPAFLERICERICE901\" 			}, 			\"groups\": { 				\"trails\": { 					\"tpaOptical\": { 						\"rack\": 1, 						\"port\": 1, 						\"slot\": 1, 						\"shelf\": 2 					}, 					\"attribute\": [{ 						\"name\": \"TRANSACTION_ID\", 						\"content\": \"1497649132563|759480|17944142\" 					}, { 						\"name\": \"PONSYSTEMID\", 						\"content\": 60000 					}, { 						\"name\": \"PRIORITY\", 						\"content\": \"PRIORITY_4\" 					}, { 						\"name\": \"UNLOCKED_ONTS\", 						\"content\": \"12345678,87654321\" 					}] 				} 			} 		} 	} }";
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);
		ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
		ManifestService manifestServiceSpy = Mockito.spy(manifestServiceMock);
		Mockito.doReturn(odsParamConfig).when(odsResponseHandlerSpy).getOdsParamConfigFromRequestKey(Mockito.anyString(),Mockito.anyString());
		Mockito.doReturn(odsParamConfig).when(odsResponseHandlerSpy).getOdsParamConfigFromRequestKey(Mockito.anyString(),Mockito.anyString());
		Mockito.doReturn(odsParamConfig).when(odsResponseHandlerSpy)
		.getOdsParamConfigFromRequestKey(Mockito.anyString(),Mockito.anyString());
		Mockito.doReturn(new JSONObject()).when(odsResponseHandlerSpy).buildPayloadToUpdateManifest(Mockito.anyString(), Mockito.anyString(),Mockito.anyString(),Mockito.anyList());
		Mockito.doNothing().when(manifestServiceSpy).createOrUpdateManifestDoc(Mockito.anyString());
		Mockito.doNothing().when(odsResponseHandlerSpy).closeTaskInBonita(Mockito.anyString(), Mockito.anyString());
		when(serviceUtils.readValueFromJson(Mockito.anyString(), Mockito.anyString()))
				.thenThrow(ApplicationException.class).thenThrow(ApplicationException.class);
		ResponseStatus res = odsResponseHandlerSpy.processResponse(response, odsInterfaceRequest);

		assertNotNull(res);
		LOGGER.info("Exiting testprocessResponse");
	}
	
	@Test(expected = ApplicationException.class)
	public void testprocessResponse2() throws ApplicationException {
		LOGGER.info("Entering testprocessResponseFailure2");	
		String statusCode = "1";
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		List<WorkflowFallout> wfFallouts = new ArrayList();
		wfFallouts.add(wfFallout);
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo");
		

		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);
		OdsRequestLog odsRequestLogLocal = new OdsRequestLog();
		odsRequestLogLocal.setWfRequestPayload("{\"processInstanceId\":\"3451074\",\"seedInfo\":{\"document_level\":\"VERSION\",\"order_number\":\"617201802\",\"order_version\":\"1\"},\"app-key\":\"ZZZDE-VRD\",\"workOrderNumber\":\"61720182\",\"rootProcessInstanceId\":\"3451073\",\"activityInstanceId\":\"382995993\",\"flowNodeProcessName\":\"LCI_DATA_CANCEL_CLR\",\"flowNodeStepName\":\"InitializeOrder\"}");
		when(odsRequestLogRepository.findByWfTaskId(odsInterfaceRequest.getTaskId())).thenReturn(odsRequestLogLocal);
		when(serviceUtils.readValueFromJson(anyString(), anyString())).thenReturn(statusCode);
		String response = "{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"00000\" 		}, 		\"xmlns\": \"urn:vnm.verizon.com/Schemas/NBParms\", 		\"xmlns:xsi1\": \"http://www.w3.org/2001/XMLSchema-instance\", 		\"vnmdesc\": { 			\"xmlns\": \"\", 			\"content\": \"SUCCESS\" 		}, 		\"xsi:schemaLocation\": \"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\", 		\"xmlns:xsi\": \"http://www.w3.org/2001/XMLSchema\", 		\"requests\": { 			\"statuscode\": \"00000\", 			\"xmlns\": \"\", 			\"requestType\": \"VNM_RTRV_UNLOCKED_ONTS\", 			\"vnmdesc\": \"SUCCESS\", 			\"mne\": { 				\"tid\": \"TMPAFLERICERICE901\" 			}, 			\"groups\": { 				\"trails\": { 					\"tpaOptical\": { 						\"rack\": 1, 						\"port\": 1, 						\"slot\": 1, 						\"shelf\": 2 					}, 					\"attribute\": [{ 						\"name\": \"TRANSACTION_ID\", 						\"content\": \"1497649132563|759480|17944142\" 					}, { 						\"name\": \"PONSYSTEMID\", 						\"content\": 60000 					}, { 						\"name\": \"PRIORITY\", 						\"content\": \"PRIORITY_4\" 					}, { 						\"name\": \"UNLOCKED_ONTS\", 						\"content\": \"12345678,87654321\" 					}] 				} 			} 		} 	} }";
		responseConfigParam.setResponseDocumentName("TestDoc");
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);

		String manifest = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG711251114_CHANGE\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"000\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"PA\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"NA\" 			}] 		} 	} }";
		odsInterfaceRequest.setManifestPayload(manifest);
		odsInterfaceRequest.setCoreleationPayload("{}");
		JSONObject finalCorrelationJsonData = new JSONObject(response);
		ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
		ManifestService manifestServiceSpy = Mockito.spy(manifestServiceMock);

		Mockito.doNothing().when(manifestServiceSpy).createOrUpdateManifestDoc(Mockito.anyString());
		Mockito.doNothing().when(odsResponseHandlerSpy).closeTaskInBonita(Mockito.anyString(), Mockito.anyString());
		when(odsMandatoryAttrsService.getMandatoryAttributeList(Mockito.anyString())).thenReturn(odsMandatoryAttrsList);
		when(serviceUtils.mergeJSONObjects(Mockito.any(), Mockito.any())).thenReturn(finalCorrelationJsonData);
		Mockito.doNothing().when(bonitaService).completeBonitaReceiveTask(Mockito.any());
		Mockito.doReturn(odsRequestLogLocal).doReturn(odsRequestLogLocal).doThrow(ApplicationException.class).doReturn(odsRequestLogLocal).when(odsRequestLogRepository).save(odsRequestLogLocal);
		Mockito.doNothing().when(falloutService).updateStatusAndExpiryTimeByWfTaskIdAndStatus(Mockito.anyString(),Mockito.anyString());
		odsResponseHandlerSpy.processResponse(response, odsInterfaceRequest, responseConfigParam, manifest);
		LOGGER.info("Exiting testprocessResponseFailure2");
	}
	

	@Test
	public void testprocessResponse3() throws ApplicationException {
		LOGGER.info("Entering testprocessResponse3");
		String statusCode = "1";
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo");

		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);
		
		when(serviceUtils.readValueFromJson(anyString(), anyString())).thenReturn(statusCode);
		String response = "{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"00000\" 		}, 		\"xmlns\": \"urn:vnm.verizon.com/Schemas/NBParms\", 		\"xmlns:xsi1\": \"http://www.w3.org/2001/XMLSchema-instance\", 		\"vnmdesc\": { 			\"xmlns\": \"\", 			\"content\": \"SUCCESS\" 		}, 		\"xsi:schemaLocation\": \"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\", 		\"xmlns:xsi\": \"http://www.w3.org/2001/XMLSchema\", 		\"requests\": { 			\"statuscode\": \"00000\", 			\"xmlns\": \"\", 			\"requestType\": \"VNM_RTRV_UNLOCKED_ONTS\", 			\"vnmdesc\": \"SUCCESS\", 			\"mne\": { 				\"tid\": \"TMPAFLERICERICE901\" 			}, 			\"groups\": { 				\"trails\": { 					\"tpaOptical\": { 						\"rack\": 1, 						\"port\": 1, 						\"slot\": 1, 						\"shelf\": 2 					}, 					\"attribute\": [{ 						\"name\": \"TRANSACTION_ID\", 						\"content\": \"1497649132563|759480|17944142\" 					}, { 						\"name\": \"PONSYSTEMID\", 						\"content\": 60000 					}, { 						\"name\": \"PRIORITY\", 						\"content\": \"PRIORITY_4\" 					}, { 						\"name\": \"UNLOCKED_ONTS\", 						\"content\": \"12345678,87654321\" 					}] 				} 			} 		} 	} }";
		responseConfigParam.setResponseDocumentName("TestDoc");
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);

		String manifest = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG711251114_CHANGE\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"000\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"PA\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"NA\" 			}] 		} 	} }";
		odsInterfaceRequest.setManifestPayload(manifest);
		odsInterfaceRequest.setCoreleationPayload("{}");
		JSONObject finalCorrelationJsonData = new JSONObject(response);
		ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
		ManifestService manifestServiceSpy = Mockito.spy(manifestServiceMock);

		Mockito.doNothing().when(manifestServiceSpy).createOrUpdateManifestDoc(Mockito.anyString());
		Mockito.doNothing().when(odsResponseHandlerSpy).closeTaskInBonita(Mockito.anyString(), Mockito.anyString());
		when(odsMandatoryAttrsService.getMandatoryAttributeList(Mockito.anyString())).thenReturn(odsMandatoryAttrsList);
		when(serviceUtils.mergeJSONObjects(Mockito.any(), Mockito.any())).thenReturn(finalCorrelationJsonData);
		Mockito.doNothing().when(bonitaService).completeBonitaReceiveTask(Mockito.any());
		odsResponseHandlerSpy.processResponse(response, odsInterfaceRequest, responseConfigParam, manifest);

		LOGGER.info("Exiting testprocessResponse3");
	}

	@Test
	public void testprocessResponse4() throws ApplicationException {
		LOGGER.info("Entering testprocessResponse4");
		String statusCode = null;
		ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo");
		
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);
		OdsRequestLog odsRequestLogLocal = new OdsRequestLog();
		odsRequestLogLocal.setWfRequestPayload("{}");
		when(odsRequestLogRepository.findByWfTaskId(odsInterfaceRequest.getTaskId())).thenReturn(odsRequestLogLocal);
		when(serviceUtils.readValueFromJson(anyString(), anyString())).thenReturn(statusCode);
		String response = "{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"00000\" 		}, 		\"xmlns\": \"urn:vnm.verizon.com/Schemas/NBParms\", 		\"xmlns:xsi1\": \"http://www.w3.org/2001/XMLSchema-instance\", 		\"vnmdesc\": { 			\"xmlns\": \"\", 			\"content\": \"SUCCESS\" 		}, 		\"xsi:schemaLocation\": \"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\", 		\"xmlns:xsi\": \"http://www.w3.org/2001/XMLSchema\", 		\"requests\": { 			\"statuscode\": \"00000\", 			\"xmlns\": \"\", 			\"requestType\": \"VNM_RTRV_UNLOCKED_ONTS\", 			\"vnmdesc\": \"SUCCESS\", 			\"mne\": { 				\"tid\": \"TMPAFLERICERICE901\" 			}, 			\"groups\": { 				\"trails\": { 					\"tpaOptical\": { 						\"rack\": 1, 						\"port\": 1, 						\"slot\": 1, 						\"shelf\": 2 					}, 					\"attribute\": [{ 						\"name\": \"TRANSACTION_ID\", 						\"content\": \"1497649132563|759480|17944142\" 					}, { 						\"name\": \"PONSYSTEMID\", 						\"content\": 60000 					}, { 						\"name\": \"PRIORITY\", 						\"content\": \"PRIORITY_4\" 					}, { 						\"name\": \"UNLOCKED_ONTS\", 						\"content\": \"12345678,87654321\" 					}] 				} 			} 		} 	} }";
		responseConfigParam.setResponseDocumentName("TestDoc");
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);

		String manifest = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG711251114_CHANGE\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"000\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"PA\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"NA\" 			}] 		} 	} }";
		odsInterfaceRequest.setManifestPayload(manifest);
		odsInterfaceRequest.setCoreleationPayload("");
		JSONObject finalCorrelationJsonData = new JSONObject(response);
		ManifestService manifestServiceSpy = Mockito.spy(manifestServiceMock);

		Mockito.doNothing().when(manifestServiceSpy).createOrUpdateManifestDoc(Mockito.anyString());
		Mockito.doNothing().when(odsResponseHandlerSpy).closeTaskInBonita(Mockito.anyString(), Mockito.anyString());
		when(odsMandatoryAttrsService.getMandatoryAttributeList(Mockito.anyString())).thenReturn(odsMandatoryAttrsList);
		when(serviceUtils.mergeJSONObjects(Mockito.any(), Mockito.any())).thenReturn(finalCorrelationJsonData);
		Mockito.doNothing().when(bonitaService).completeBonitaReceiveTask(Mockito.any());
		odsResponseHandlerSpy.processResponse(response, odsInterfaceRequest, responseConfigParam, manifest);

		LOGGER.info("Exiting testprocessResponse4");
	}

	@Test
	public void testprocessResponse5() throws ApplicationException {
		LOGGER.info("Entering testprocessResponse5");
		String statusCode = "1";
		ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo");
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);
		
		OdsRequestLog odsRequestLogLocal = new OdsRequestLog();
		odsRequestLogLocal.setWfRequestPayload("{}");
		odsRequestLogLocal.setWfTaskStatus(Constants.SUCCESS);
		when(odsRequestLogRepository.findByWfTaskId(odsInterfaceRequest.getTaskId())).thenReturn(odsRequestLogLocal);
		when(serviceUtils.readValueFromJson(anyString(), anyString())).thenReturn(statusCode);
		String response = "{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"00000\" 		}, 		\"xmlns\": \"urn:vnm.verizon.com/Schemas/NBParms\", 		\"xmlns:xsi1\": \"http://www.w3.org/2001/XMLSchema-instance\", 		\"vnmdesc\": { 			\"xmlns\": \"\", 			\"content\": \"SUCCESS\" 		}, 		\"xsi:schemaLocation\": \"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\", 		\"xmlns:xsi\": \"http://www.w3.org/2001/XMLSchema\", 		\"requests\": { 			\"statuscode\": \"00000\", 			\"xmlns\": \"\", 			\"requestType\": \"VNM_RTRV_UNLOCKED_ONTS\", 			\"vnmdesc\": \"SUCCESS\", 			\"mne\": { 				\"tid\": \"TMPAFLERICERICE901\" 			}, 			\"groups\": { 				\"trails\": { 					\"tpaOptical\": { 						\"rack\": 1, 						\"port\": 1, 						\"slot\": 1, 						\"shelf\": 2 					}, 					\"attribute\": [{ 						\"name\": \"TRANSACTION_ID\", 						\"content\": \"1497649132563|759480|17944142\" 					}, { 						\"name\": \"PONSYSTEMID\", 						\"content\": 60000 					}, { 						\"name\": \"PRIORITY\", 						\"content\": \"PRIORITY_4\" 					}, { 						\"name\": \"UNLOCKED_ONTS\", 						\"content\": \"12345678,87654321\" 					}] 				} 			} 		} 	} }";
		responseConfigParam.setResponseDocumentName("TestDoc");
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(responseConfigParam);

		String manifest = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG711251114_CHANGE\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"000\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"PA\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"NA\" 			}] 		} 	} }";
		odsInterfaceRequest.setManifestPayload(manifest);
		odsInterfaceRequest.setCoreleationPayload("");
		JSONObject finalCorrelationJsonData = new JSONObject(response);
		ManifestService manifestServiceSpy = Mockito.spy(manifestServiceMock);

		Mockito.doNothing().when(manifestServiceSpy).createOrUpdateManifestDoc(Mockito.anyString());
		Mockito.doNothing().when(odsResponseHandlerSpy).closeTaskInBonita(Mockito.anyString(), Mockito.anyString());
		when(odsMandatoryAttrsService.getMandatoryAttributeList(Mockito.anyString())).thenReturn(odsMandatoryAttrsList);
		when(serviceUtils.mergeJSONObjects(Mockito.any(), Mockito.any())).thenReturn(finalCorrelationJsonData);
		Mockito.doNothing().when(bonitaService).completeBonitaReceiveTask(Mockito.any());
		odsResponseHandlerSpy.processResponse(response, odsInterfaceRequest, responseConfigParam, manifest);

		LOGGER.info("Exiting testprocessResponse5");
	}
	
	@Test(expected=JSONException.class)
	public void prepareCorrelationContentTest() throws ApplicationException
	{
		LOGGER.info("Entering prepareCorrelationContentTest");
		ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
		String response = "{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"00000\" 		}, 		\"xmlns\": \"urn:vnm.verizon.com/Schemas/NBParms\", 		\"xmlns:xsi1\": \"http://www.w3.org/2001/XMLSchema-instance\", 		\"vnmdesc\": { 			\"xmlns\": \"\", 			\"content\": \"SUCCESS\" 		}, 		\"xsi:schemaLocation\": \"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\", 		\"xmlns:xsi\": \"http://www.w3.org/2001/XMLSchema\", 		\"requests\": { 			\"statuscode\": \"00000\", 			\"xmlns\": \"\", 			\"requestType\": \"VNM_RTRV_UNLOCKED_ONTS\", 			\"vnmdesc\": \"SUCCESS\", 			\"mne\": { 				\"tid\": \"TMPAFLERICERICE901\" 			}, 			\"groups\": { 				\"trails\": { 					\"tpaOptical\": { 						\"rack\": 1, 						\"port\": 1, 						\"slot\": 1, 						\"shelf\": 2 					}, 					\"attribute\": [{ 						\"name\": \"TRANSACTION_ID\", 						\"content\": \"1497649132563|759480|17944142\" 					}, { 						\"name\": \"PONSYSTEMID\", 						\"content\": 60000 					}, { 						\"name\": \"PRIORITY\", 						\"content\": \"PRIORITY_4\" 					}, { 						\"name\": \"UNLOCKED_ONTS\", 						\"content\": \"12345678,87654321\" 					}] 				} 			} 		} 	} }";
		ResponseStatus status= new ResponseStatus();
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("NON_BLANK");
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setName("Test");
		JSONObject finalCorrelationJsonData = new JSONObject(response);
		JSONObject correlationJsonObj = new JSONObject();
		correlationJsonObj.put(Constants.CONTENTS, new JSONObject("{\"Test\":\"TestVal\"}"));
		
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(requestKey,	OdsParamConfigType.WORKFLOW_CORRELATION_PARAM.toString(), Constants.CONTENT_SCHEMA)).thenReturn(odsParamConfig);
		when(serviceUtils.convertObjectToJsonString(status)).thenReturn("{}");
		when(serviceUtils.mergeJSONObjects(Mockito.any(), Mockito.any())).thenReturn(finalCorrelationJsonData);
		String val= finalCorrelationJsonData.toString();
		Mockito.doNothing().when(serviceUtils).populateJsonPayload(odsParamConfig.getValue(),val, correlationJsonObj);
		odsResponseHandlerSpy.prepareCorrelationContent(status, response, requestKey);
		
		LOGGER.info("Exiting prepareCorrelationContentTest");
	}
	
	@Test
	public void createOrUpdateWorkflowParamsTest() throws ApplicationException {
		LOGGER.info("Entering prepareCorrelationContentTest");
		ODSResponseHandler odsResponseHandlerSpy = Mockito.spy(odsResponseHandler);
		String response = "{\r\n" + 
				"	\"workflowParameters\": {\r\n" + 
				"		\"workflowParams\": [{\r\n" + 
				"			\"paramName\": \"TRANSACTION_ID\",\r\n" + 
				"			\"paramValue\": \"123456\"\r\n" + 
				"		}]\r\n" + 
				"	}\r\n" + 
				"}";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("NON_BLANK");
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setName("Test");
		List<OdsParamConfig> odsParamConfigList = new ArrayList<>();
		odsParamConfigList.add(odsParamConfig);
		when(odsParamConfigRepository.findByParamKeyAndType("ZZDE-Rqn",
				OdsParamConfigType.WORKFLOW_PARAM.toString()))
		.thenReturn(odsParamConfigList);

		doNothing().when(workflowParamService).createWorkflowParams(anyString(), anyString(), anyString());
		when(serviceUtils.callService(any(), any(HttpEntity.class))).thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		odsResponseHandlerSpy.createOrUpdateWorkflowParams(responseConfigParam, response, "ZZDE-Rqn");

		LOGGER.info("Exiting prepareCorrelationContentTest");
	}
	
	@Test
	public void createFalloutTest() throws ApplicationException
	{
		LOGGER.info("Entering createFalloutTest");
		ResponseStatus failureResponseStatus= new ResponseStatus();
		Mockito.doThrow(Exception.class).when(falloutService).createFallout(Mockito.any(WorkflowFalloutRequest.class));
		
		odsResponseHandler.createFallout(responseConfigParam, failureResponseStatus);
		
		LOGGER.info("Entering createFalloutTest");
	}

}
