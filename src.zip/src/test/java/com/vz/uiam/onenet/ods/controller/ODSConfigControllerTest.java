package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsResponseTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFalloutConfig;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSConfigPayload;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSKeyDetails;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class ODSConfigControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSConfigControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	ODSParamConfigController odsParamConfigController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	/**
	 * 
	 */
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_response_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_work_flow_fallout_config_table.sql"),
		})
	public void testcreateOrUpdateOdsConfig() {
		try {
			LOGGER.info("****************************Entering to testcreateOrUpdateOdsConfig*****************************");
			URI url = new URI("/oneDispatcher/odsConfig/createOrUpdate");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(getConfigPayLoad())))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testcreateOrUpdateOdsConfig*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsConfig: ",e);
		}
	}
	
	@Test
	public void testcreateOrUpdateOdsConfig1() {
		try {
			LOGGER.info("****************************Entering to testcreateOrUpdateOdsConfig1*****************************");
			URI url = new URI("/oneDispatcher/odsConfig/createOrUpdate");
			ODSConfigPayload odsConfigPayload =new ODSConfigPayload();
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsConfigPayload)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testcreateOrUpdateOdsConfig1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsConfig: ",e);
		}
	}
	
	@Test
	public void testGetOdsConfigurations() {
		try {
			LOGGER.info("****************************Entering to testGetOdsConfigurations*****************************");
			URI url = new URI("/oneDispatcher/odsConfig/get");
			ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
			odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
			odsKeyDetails.setFlowNodeStepName("AddONT_Test");
			odsKeyDetails.setAppKey("Test-ODS-Key");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsKeyDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetOdsConfigurations*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsConfigurations: ",e);
		}
	}
	
	@Test
	public void testGetOdsConfigurations1() {
		try {
			LOGGER.info("****************************Entering to testGetOdsConfigurations1*****************************");
			URI url = new URI("/oneDispatcher/odsConfig/get");
			ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
			odsKeyDetails.setFlowNodeProcessName("");
			odsKeyDetails.setFlowNodeStepName("");
			odsKeyDetails.setAppKey("Test-ODS-Key");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsKeyDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			LOGGER.info("****************************Exiting from testGetOdsConfigurations1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsConfigurations: ",e);
		}
	}
	
	@Test
	public void testGetOdsConfigurations2() {
		try {
			LOGGER.info("****************************Entering to testGetOdsConfigurations2*****************************");
			URI url = new URI("/oneDispatcher/odsConfig/get");
			ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
			odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test1");
			odsKeyDetails.setFlowNodeStepName("");
			odsKeyDetails.setAppKey("");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsKeyDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetOdsConfigurations2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsConfigurations: ",e);
		}
	}
	
	@Test
	public void testDeleteOdsConfigurations() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsConfigurations*****************************");
			URI url = new URI("/oneDispatcher/odsConfig/delete");
			ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
			odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
			odsKeyDetails.setFlowNodeStepName("AddONT_Test");
			odsKeyDetails.setAppKey("Test-ODS-Key");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsKeyDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteOdsConfigurations*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsConfigurations: ",e);
		}
	}
	
	@Test
	public void testDeleteOdsConfigurations1() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsConfigurations1*****************************");
			URI url = new URI("/oneDispatcher/odsConfig/delete");
			ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsKeyDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteOdsConfigurations1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsConfigurations: ",e);
		}
	}
	
	@Test
	public void testDeleteOdsConfigurations2() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsConfigurations2*****************************");
			URI url = new URI("/oneDispatcher/odsConfig/delete");
			ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
			odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
			odsKeyDetails.setFlowNodeStepName("");
			odsKeyDetails.setAppKey("Test-ODS-Key");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsKeyDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			ODSKeyDetails keyDetails = new ODSKeyDetails();
			keyDetails.setFlowNodeProcessName("");
			keyDetails.setFlowNodeStepName("");
			keyDetails.setAppKey("Test-ODS-Key");
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(keyDetails)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			
			LOGGER.info("****************************Exiting from testDeleteOdsConfigurations2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsConfigurations: ",e);
		}
	}
	
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql")})
	public void testGetSqlInsertScript() {
		try {
			LOGGER.info("****************************Entering to testGetSqlInsertScript*****************************");
			URI url = new URI("/oneDispatcher/odsConfig/getSqlInsertScript");
			ODSKeyDetails request=new ODSKeyDetails();
			request.setAppKey("LCI_OVER_NGPON2_Pre_Activation_AddONT");
			request.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation");
			request.setFlowNodeStepName("AddONT");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(request)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetSqlInsertScript*****************************");
			
		} catch (Exception e) {
			LOGGER.error("Exception Occured for getSqlInsertScript: ",e);
		}
	}
	@Test
	public void testGetSqlInsertScript1() {
		try {
			LOGGER.info("****************************Entering to testGetSqlInsertScript1*****************************");
			URI url = new URI("/oneDispatcher/odsConfig/getSqlInsertScript");
			ODSKeyDetails request=new ODSKeyDetails();
			request.setAppKey("LCI_OVER_NGPON2_Pre_Activation_AddONT");
			request.setFlowNodeProcessName("");
			request.setFlowNodeStepName("");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(request)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetSqlInsertScript1*****************************");
			
		} catch (Exception e) {
			LOGGER.error("Exception Occured for getSqlInsertScript: ",e);
		}
	}
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql")})
	public void testGetSqlInsertScript2() {
		try {
			LOGGER.info("****************************Entering to testGetSqlInsertScript2*****************************");
			URI url = new URI("/oneDispatcher/odsConfig/getSqlInsertScript");
			ODSKeyDetails request=new ODSKeyDetails();
			request.setAppKey("LCI_OVER_NGPON2_Pre_Activation_AddONT");
			request.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation");
			request.setFlowNodeStepName("AddONT");
			request.setRegion("NORTH");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(request)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetSqlInsertScript2*****************************");
			
		} catch (Exception e) {
			LOGGER.error("Exception Occured for getSqlInsertScript: ",e);
		}
	}
		
	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}
	
	public ODSConfigPayload getConfigPayLoad() {
		ODSConfigPayload odsConfigPayload = new ODSConfigPayload();
		ODSKeyDetails keyDetails = new ODSKeyDetails();
		keyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		keyDetails.setFlowNodeStepName("AddONT_Test");
		keyDetails.setAppKey("Test-ODS-Key");
		
		odsConfigPayload.setKeyDetails(keyDetails);
		List<OdsServiceRouterMapDetails> serviceRouteMap =new ArrayList<>();
	    List<OdsMandatoryAttributes> mandatoryAttrs =new ArrayList<>();
	    List<OdsParamConfig> paramConfig =new ArrayList<>();
	    
	    OdsServiceRouterMapDetails odsServiceRouterMapDetails =new OdsServiceRouterMapDetails();
		odsServiceRouterMapDetails.setFlowNodeProcessName("TEST-Process-Name");
		odsServiceRouterMapDetails.setFlowNodeStepName("TEST-Step-Name");
		odsServiceRouterMapDetails.setRequestDocumentName("TEST-Message");
		odsServiceRouterMapDetails.setRequestSchema("{test:$.test}");
		odsServiceRouterMapDetails.setResponseDocumentName("Test-doc");
		odsServiceRouterMapDetails.setRouterProtocol("REST");
		odsServiceRouterMapDetails.setTargetEndPointUrl("http://test.com");
		odsServiceRouterMapDetails.setTransformationType("JSON");
		odsServiceRouterMapDetails.setAppKey("Test-ODS-Key");
		
		serviceRouteMap.add(odsServiceRouterMapDetails);
		odsConfigPayload.setServiceRouteMap(serviceRouteMap);
		
		OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
		odsMandatoryAttributes.setAttrKey("LCI_OVER_NGPON2_Pre_Activation_Test_AddONT_Test");
		odsMandatoryAttributes.setJsonPath("$.TestJosn.Test");
	
		mandatoryAttrs.add(odsMandatoryAttributes);
		odsConfigPayload.setMandatoryAttrs(mandatoryAttrs);
		
		OdsParamConfig odsParamConfig =new OdsParamConfig();
		odsParamConfig.setName("TEST");
		odsParamConfig.setParamKey("LCI_OVER_NGPON2_Pre_Activation_Test_AddONT_Test");
		odsParamConfig.setValue("Test-Value");
		odsParamConfig.setType("TEST-Type");
		
		paramConfig.add(odsParamConfig);
		odsConfigPayload.setParamConfig(paramConfig);
		
		OdsRequestTransactionIdMap odsRequestTransactionIdMap =new OdsRequestTransactionIdMap();
		odsRequestTransactionIdMap.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsRequestTransactionIdMap.setFlowNodeStepName("AddONT_Test");
		odsRequestTransactionIdMap.setTransactionIdKey("TestTransactionIdKey");
		
		
		OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
		odsResponseTIdMap.setRootTagName("TestRootTagName");
		odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");
		odsConfigPayload.setOdsRequestTransactionIdMap(odsRequestTransactionIdMap);
		
		WorkflowFalloutConfig config=new WorkflowFalloutConfig();
		config.setWorkflowProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		config.setWorkFlowStepName("AddONT_Test");
		config.setWorkFlowFalloutErrorCode("default");
		List<WorkflowFalloutConfig> workConfig=new ArrayList<>();
		workConfig.add(config);
		odsConfigPayload.setWorkflowFalloutConfig(workConfig);
		
		return odsConfigPayload;
	}
	
	

}
