package com.vz.uiam.onenet.util.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.util.constants.Constants;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class JerseyRestClientControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(JerseyRestClientControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;



	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	/**
	 * 
	 */
	@Test
	public void testRoute() {
		try {
			LOGGER.info("****************************Entering to testRoute*****************************");
			URI url = new URI("/restClient/route");
			JSONArray queryParams = new JSONArray();
			String request = "{\"endpointUrl\": \"http://google.com\",\"contentType\": \"application/json\",	\"accept\": \"application/json\",\"requestMethod\": \"POST\",\n"
					+ "			\"payload\": {},\"queryParams\":" + queryParams + "}";
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(request))
					.andExpect(status().isExpectationFailed())
					.andExpect(content().contentType(Constants.APPLICATION_JSON)).andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testRoute*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for route: ", e);
		}
	}

	@Test
	public void testRoute1() {
		try {
			LOGGER.info("****************************Entering to testRoute1*****************************");
			URI url = new URI("/restClient/route");
			String endpointUrl = "http://136.151.13.94:15053/oneDispatcher/doTransform";
			JSONArray queryParams = new JSONArray();
			Map<String, String> values = new HashMap<>();
			values.put("name", "12344345");
			values.put("value", "12344345");
			queryParams.put(values);
			String request = getRequest(endpointUrl, "POST", queryParams);
			
			LOGGER.info("request : " + request);
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(request)).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			

			LOGGER.info("****************************Exiting from testRoute1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for route1: ", e);
			
		}
	}

	@Test
	public void testRoute2() {
		try {
			LOGGER.info("****************************Entering to testRoute2*****************************");
			URI url = new URI("/restClient/route");
			String endpointUrl = "http://136.151.13.94:15053/oneDispatcher/doTransform";
			JSONArray queryParams = new JSONArray();
			Map<String, String> values = new HashMap<>();
			values.put("name", "12344345");
			values.put("value", "12344345");
			queryParams.put(values);
			String request = getRequest(endpointUrl, "GET", queryParams);
			LOGGER.info("request : " + request);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(request))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testRoute2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for route1: ", e);
		}
	}

	public String getRequest(String endpointUrl, String requestMethod, JSONArray queryParams) {
		String request = "{\"endpointUrl\": \"" + endpointUrl + "\","
				+ "\"contentType\": \"application/json\",	\"accept\": \"application/json\",\"requestMethod\": \""
				+ requestMethod + "\",\n" + "			\"payload\": {\n" + " \"app-key\": \"ZZZDE-RQN\", \n"
				+ " \"processInstanceId\": \" 12338 \", \n" + " \"activityInstanceId\": \" 4566 \", \n"
				+ " \"rootProcessInstanceId\": \" 23452 \", \n"
				+ " \"flowNodeProcessName\": \"SPLS-CRITICAL-DATES\", \n"
				+ " \"flowNodeStepName\": \"GetAvailableDueDate\", \n" + " \"seedInfo\": { \n"
				+ " \"sr_number\": \"ZYTXAD-001\" \n" + " },\n" + " \"sr_number\": \"ZYTXAD-001\" \n" + " },"
				+ "\"queryParams\":" + queryParams + "}";
		LOGGER.info("request : " + request);
		return request;
	}

}
