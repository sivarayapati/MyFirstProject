package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class ODSManifestControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSManifestControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}
    @Test
	public void healthCheck() {
		try {
			LOGGER.info("****************************Entering to healthCheckTest*****************************");
			URI url = new URI("/manifest/healthcheck");
			this.mockMvc.perform(get(url).contentType(MediaType.APPLICATION_JSON))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();
			LOGGER.info(
					"****************************Exiting from testcreateOrUpdateOdsConfig*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsConfig: ", e);
		}
	}

	@Test
	public void fetchManifestDocuments() {
		LOGGER.info("****************************Entering to fetchManifestDocuments*****************************");
		try {
			String manifestReqPayload = "{\r\n" + " \"app-key\": \"ZZZDE-RQN\", \r\n"
					+ " \"processInstanceId\": \" 12338 \", \r\n" + " \"activityInstanceId\": \" 4566 \", \r\n"
					+ " \"rootProcessInstanceId\": \" 23452 \", \r\n"
					+ " \"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", \r\n"
					+ " \"flowNodeStepName\": \"CollectOrder\", \r\n" + " \"seedInfo\": { \r\n"
					+ " \"sr_number\": \"ZYTXAD-001\" \r\n" + " },\r\n" + " \"sr_number\": \"ZYTXAD-001\" \r\n"
					+ " }\r\n" + " } \r\n" + "";
			URI url = new URI("/manifest/fetchManifestDocs");
			this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(manifestReqPayload))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();
			LOGGER.info("****************************Exiting from fetchManifestDocuments*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for fetchManifestDocuments: ", e);
		}

	}
	

	

}
