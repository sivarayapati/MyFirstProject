package com.vz.uiam.onenet.ods.service;

import static org.mockito.Mockito.when;

import java.sql.SQLException;

import javax.persistence.EntityManager;

import org.apache.log4j.Logger;
import org.hibernate.exception.ConstraintViolationException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.dao.DataIntegrityViolationException;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.OdsWorkflowParamsDAO;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsWorkflowParams;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsWorkflowParamsId;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsWorkflowParamsRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.WfParamRequestDTO;

@RunWith(MockitoJUnitRunner.class)
public class WorkFlowParamServiceTest {
	private static final Logger LOGGER = Logger.getLogger(WorkFlowParamServiceTest.class);
	@InjectMocks
	WorkflowParamService workflowParamService;

	@Mock
	private EntityManager entityManager;
	
	@Mock
	OdsWorkflowParamsDAO odsWorkflowParamsDAO;
	
	@Mock
	OdsWorkflowParamsRepository odsWorkflowParamsRepository;
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCreateWorkflowParams() throws ApplicationException {

		LOGGER.info("Entering testCreateWorkflowParams");
		String rootCaseId = "100";
		String paramName = "test";
		String paramValue = "testVal";
		OdsWorkflowParamsId pk = new OdsWorkflowParamsId(Integer.parseInt(rootCaseId),paramName);
		OdsWorkflowParams odsWfParam = new OdsWorkflowParams(pk, paramValue);
		Mockito.doThrow(DataIntegrityViolationException.class).when(odsWorkflowParamsRepository).save(odsWfParam);
		workflowParamService.createWorkflowParams(rootCaseId, paramName, paramValue);
		LOGGER.info("Exiting testCreateWorkflowParams");

	}
	@SuppressWarnings("unchecked")
	@Test
	public void testCreateWorkflowParams1() throws ApplicationException {

		LOGGER.info("Entering testCreateWorkflowParams1");
		String rootCaseId = "100";
		String paramName = "test";
		String paramValue = "testVal";
		OdsWorkflowParamsId pk = new OdsWorkflowParamsId(Integer.parseInt(rootCaseId),paramName);
		OdsWorkflowParams odsWfParam = new OdsWorkflowParams(pk, paramValue);
		when(odsWorkflowParamsRepository.save(odsWfParam)).thenThrow(ConstraintViolationException.class);
		workflowParamService.createWorkflowParams(rootCaseId, paramName, paramValue);
		LOGGER.info("Exiting testCreateWorkflowParams1");

	}
	@Test(expected=ApplicationException.class)
	public void testGetWorkflowParams() throws ApplicationException {

		LOGGER.info("Entering testGetWorkflowParams");
		WfParamRequestDTO request = new WfParamRequestDTO();
	
		workflowParamService.getWorkflowParams(request);
		LOGGER.info("Exiting testGetWorkflowParams");

	}
	@SuppressWarnings("unchecked")
	@Test(expected=ApplicationException.class)
	public void testGetWorkflowParams1() throws ApplicationException {

		LOGGER.info("Entering testGetWorkflowParams1");
		WfParamRequestDTO request = new WfParamRequestDTO();
		request.setRootCaseId("100");
		when(odsWorkflowParamsDAO.findByRootCaseId(Integer.parseInt(request.getRootCaseId()))).thenThrow(SQLException.class);
		workflowParamService.getWorkflowParams(request);
		LOGGER.info("Exiting testGetWorkflowParams1");

	}

	
}