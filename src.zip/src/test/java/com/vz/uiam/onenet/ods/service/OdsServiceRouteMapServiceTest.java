package com.vz.uiam.onenet.ods.service;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;

@RunWith(MockitoJUnitRunner.class)
public class OdsServiceRouteMapServiceTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(OdsServiceRouteMapServiceTest.class);

	@InjectMocks
	OdsServiceRouteMapService odsServiceRouteMapService;
	
	
	@Test(expected = ApplicationException.class)
	public void testDoServiceRouteMapValidation1() throws ApplicationException {
		LOGGER.info("Entering testDoServiceRouteMapValidation1");
		
		OdsServiceRouterMapDetails svcMap = new OdsServiceRouterMapDetails();
		
		odsServiceRouteMapService.doServiceRouteMapValidation(svcMap);
		
		LOGGER.info("Entering testDoServiceRouteMapValidation1");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoServiceRouteMapValidation2() throws ApplicationException {
		LOGGER.info("Entering testDoServiceRouteMapValidation2");
		
		OdsServiceRouterMapDetails svcMap = new OdsServiceRouterMapDetails();
		svcMap.setAppKey("ZZZZ-Testing");
		
		odsServiceRouteMapService.doServiceRouteMapValidation(svcMap);
		
		LOGGER.info("Entering testDoServiceRouteMapValidation2");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoServiceRouteMapValidation3() throws ApplicationException {
		LOGGER.info("Entering testDoServiceRouteMapValidation3");
		
		OdsServiceRouterMapDetails svcMap = new OdsServiceRouterMapDetails();
		svcMap.setAppKey("ZZZZ-Testing");
		svcMap.setFlowNodeProcessName("Testing_Process");
		
		odsServiceRouteMapService.doServiceRouteMapValidation(svcMap);
		
		LOGGER.info("Entering testDoServiceRouteMapValidation3");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoServiceRouteMapValidation4() throws ApplicationException {
		LOGGER.info("Entering testDoServiceRouteMapValidation4");
		
		OdsServiceRouterMapDetails svcMap = new OdsServiceRouterMapDetails();
		svcMap.setAppKey("ZZZZ-Testing");
		svcMap.setFlowNodeProcessName("Testing_Process");
		svcMap.setFlowNodeStepName("Testing_Step");
		
		odsServiceRouteMapService.doServiceRouteMapValidation(svcMap);
		
		LOGGER.info("Entering testDoServiceRouteMapValidation4");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoServiceRouteMapValidation5() throws ApplicationException {
		LOGGER.info("Entering testDoServiceRouteMapValidation5");
		
		OdsServiceRouterMapDetails svcMap = new OdsServiceRouterMapDetails();
		svcMap.setAppKey("ZZZZ-Testing");
		svcMap.setFlowNodeProcessName("Testing_Process");
		svcMap.setFlowNodeStepName("Testing_Step");
		svcMap.setTargetEndPointUrl("http://vz.com/getdata");
		
		odsServiceRouteMapService.doServiceRouteMapValidation(svcMap);
		
		LOGGER.info("Entering testDoServiceRouteMapValidation5");
	}
	
	@Test
	public void testDoServiceRouteMapValidation6() throws ApplicationException {
		LOGGER.info("Entering testDoServiceRouteMapValidation6");
		
		OdsServiceRouterMapDetails svcMap = new OdsServiceRouterMapDetails();
		svcMap.setAppKey("ZZZZ-Testing");
		svcMap.setFlowNodeProcessName("Testing_Process");
		svcMap.setFlowNodeStepName("Testing_Step");
		svcMap.setTargetEndPointUrl("http://vz.com/getdata");
		svcMap.setRouterProtocol("REST");
		
		odsServiceRouteMapService.doServiceRouteMapValidation(svcMap);
		
		LOGGER.info("Entering testDoServiceRouteMapValidation6");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoServiceRouteMapValidation7() throws ApplicationException {
		LOGGER.info("Entering testDoServiceRouteMapValidation7");
		
		OdsServiceRouterMapDetails svcMap = new OdsServiceRouterMapDetails();
		svcMap.setAppKey("ZZZZ-Testing");
		svcMap.setFlowNodeProcessName("Testing_Process");
		svcMap.setFlowNodeStepName("Testing_Step");
		svcMap.setTargetEndPointUrl("http://vz.com/getdata");
		svcMap.setRouterProtocol("REST");
		svcMap.setSendMilestoneFlag("TRUE");
		
		odsServiceRouteMapService.doServiceRouteMapValidation(svcMap);
		
		LOGGER.info("Entering testDoServiceRouteMapValidation7");
	}
	
	@Test
	public void testDoServiceRouteMapValidation8() throws ApplicationException {
		LOGGER.info("Entering testDoServiceRouteMapValidation8");
		
		OdsServiceRouterMapDetails svcMap = new OdsServiceRouterMapDetails();
		svcMap.setAppKey("ZZZZ-Testing");
		svcMap.setFlowNodeProcessName("Testing_Process");
		svcMap.setFlowNodeStepName("Testing_Step");
		svcMap.setTargetEndPointUrl("http://vz.com/getdata");
		svcMap.setRouterProtocol("REST");
		svcMap.setSendMilestoneFlag("YES");
		
		Set<OdsMilestoneConfig> odsMilestoneConfigList = new HashSet<OdsMilestoneConfig>();
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();

		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("App1");
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setRequestDocumentName("TEST-Message");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		odsMilestoneConfig.setTransformationType("JSON");
		odsMilestoneConfig.setRouteProtocol("REST");
		odsMilestoneConfig.setSendMilestone("YES");
		odsMilestoneConfig.setSendFalloutNotification("NO");

		odsMilestoneConfigList.add(odsMilestoneConfig);
		
		odsServiceRouteMapService.doServiceRouteMapValidation(svcMap);
		
		LOGGER.info("Entering testDoServiceRouteMapValidation8");
	}
	
	
}
