package com.vz.uiam.onenet.ods.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneTransaction;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsMilestoneConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsMilestoneTansactionRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsServiceRouterMapRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.MileStoneRequestObject;
import com.vz.uiam.onenet.ods.jpa.dto.model.MileStoneRequestResponsePayLoad;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsMilestoneTransactionRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformedResponsePayload;
import com.vz.uiam.onenet.ods.util.ServiceUtils;


@RunWith(MockitoJUnitRunner.class)
public class MilestoneServiceTest {

private static final Logger LOGGER = Logger.getLogger(MilestoneServiceTest.class);
	
	@InjectMocks
	MilestoneService milestoneService;

	@Mock
	OdsParamConfigRepository odsParamConfigRepo;
	
	@Mock
	RestTemplate restTemplate;

	@Mock
	RequestEntity<String> requestEntity;
	
	@Mock
	HttpEntity<String> httpEntity;

	@Mock
	ResponseEntity<String> responseEntity;
	
	@Mock
	ServiceUtils serviceUtils;
	
	@Mock 
	ODSService odsService;
	
	@Mock
	OdsServiceRouterMapRepository odsServiceRouterMapRepository;
	
	@Mock
	ApplicationContext appcontext;
	
	@Mock
	OdsMilestoneTansactionRepository odsMilestoneTansactionRepo;
	
	@Mock
	OdsMilestoneConfigRepository odsMilestoneConfigRepository;
	
	@Test(expected = ApplicationException.class)
	public void testCallMilestoneProxyServiceFailure() throws ApplicationException {
		LOGGER.info("Entering testCallMilestoneProxyServiceFailure");
		OdsParamConfig odsParamConfig = mock(OdsParamConfig.class);

		MileStoneRequestResponsePayLoad mileStonePayLoad = new MileStoneRequestResponsePayLoad();

		TransformedResponsePayload transformPayLoad = new TransformedResponsePayload();
		transformPayLoad.setBody("");
		transformPayLoad.setHeader("");
		mileStonePayLoad.setPayload(transformPayLoad);
		mileStonePayLoad.setRoutingProtocol("REST");
		mileStonePayLoad.setTargetEndPointURL("http://test.com");
		
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.MILESTONE_REQUEST_URL)).thenReturn(odsParamConfig);
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		milestoneService.callMilestoneProxyService(mileStonePayLoad);
 
		LOGGER.info("Exiting testCallMilestoneProxyServiceFailure");
	}

	@Test
	public void testCallMilestoneProxyServiceFaillure2() throws ApplicationException {
		LOGGER.info("Entering testCallMilestoneProxyServiceFaillure2");
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");

		MileStoneRequestResponsePayLoad mileStonePayLoad = new MileStoneRequestResponsePayLoad();

		TransformedResponsePayload transformPayLoad = new TransformedResponsePayload();
		transformPayLoad.setBody("");
		transformPayLoad.setHeader("");
		mileStonePayLoad.setPayload(transformPayLoad);
		mileStonePayLoad.setRoutingProtocol("REST");
		mileStonePayLoad.setTargetEndPointURL("http://test.com");
		OdsMilestoneTransaction odsMilestoneTran =new OdsMilestoneTransaction();
		odsMilestoneTran.setStepName("AddService");
		odsMilestoneTran.setProcessName("LCI_DATA_Pre_Activation");
		odsMilestoneTran.setRootCaseId("56779");
		odsMilestoneTran.setStatus(Constants.STATUS_PENDING);
		

		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.MILESTONE_REQUEST_URL)).thenReturn(odsParamConfig);
		String milestoneObj = "";
		when(serviceUtils.convertObjectToJsonString(mileStonePayLoad)).thenReturn(milestoneObj);
		
	    when(odsMilestoneTansactionRepo.save(any(OdsMilestoneTransaction.class))).thenReturn(odsMilestoneTran);
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		milestoneService.callMilestoneProxyService(mileStonePayLoad);
		LOGGER.info("Exiting testCallMilestoneProxyServiceFaillure2");
	}

	@Test
	public void testCallMilestoneProxyService3() throws ApplicationException {
		LOGGER.info("Entering testCallMilestoneProxyService3");
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");

		MileStoneRequestResponsePayLoad mileStonePayLoad = new MileStoneRequestResponsePayLoad();

		TransformedResponsePayload transformPayLoad = new TransformedResponsePayload();
		transformPayLoad.setBody("");
		transformPayLoad.setHeader("");
		mileStonePayLoad.setPayload(transformPayLoad);
		mileStonePayLoad.setRoutingProtocol("REST");
		mileStonePayLoad.setTargetEndPointURL("http://test.com");
		
		OdsMilestoneTransaction odsMilestoneTra =new OdsMilestoneTransaction();
		odsMilestoneTra.setStepName("AddService");
		odsMilestoneTra.setProcessName("LCI_DATA_Pre_Activation");
		odsMilestoneTra.setRootCaseId("56779");
		odsMilestoneTra.setStatus(Constants.STATUS_PENDING);
	

		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.MILESTONE_REQUEST_URL)).thenReturn(odsParamConfig);
		String milestoneObj = "";
		when(serviceUtils.convertObjectToJsonString(mileStonePayLoad)).thenReturn(milestoneObj);
		 when(odsMilestoneTansactionRepo.save(any(OdsMilestoneTransaction.class))).thenReturn(odsMilestoneTra);

		HttpHeaders httpHeaders = mock(HttpHeaders.class);
		String manifestRequest = "";
		ResponseEntity<String> responseEntity11 = new ResponseEntity<>("mainifestResponse", HttpStatus.OK);
		HttpEntity<String> httpEntity1 = new HttpEntity<>(manifestRequest, httpHeaders);

		when(serviceUtils.callService(odsParamConfig, httpEntity1)).thenReturn(responseEntity11);
		
		milestoneService.callMilestoneProxyService(mileStonePayLoad);

		LOGGER.info("Exiting testCallMilestoneProxyService3");
	}

	@Test
	public void testSendMilestone() throws ApplicationException {
		LOGGER.info("Entering testSendMilestone");
		ResponseConfigParams params = new ResponseConfigParams();
		MileStoneRequestObject request = new MileStoneRequestObject();
		List<OdsMilestoneConfig> milestoneConfigs = new ArrayList<>();
		when(odsMilestoneConfigRepository.findByFlowNodeProcessNameAndFlowNodeStepName(Mockito.any(), Mockito.any())).thenReturn(milestoneConfigs);
		when(serviceUtils.convertJsonStringToObject(anyString(), any())).thenReturn(params);
		
		OdsServiceRouterMapDetails odsSvcRouteMap = mock(OdsServiceRouterMapDetails.class);
		when(odsServiceRouterMapRepository.getOne(any(Integer.class))).thenReturn(odsSvcRouteMap);
		
		milestoneService.sendMilestone(request);

		LOGGER.info("Exiting testSendMilestone");

	}

	@Test
	public void testSendMilestone1() throws ApplicationException {
		LOGGER.info("Entering testSendMilestone1");
		ResponseConfigParams params = new ResponseConfigParams();
		params.setSendMilestone(true);
		MileStoneRequestObject request = new MileStoneRequestObject();
		List<OdsMilestoneConfig> milestoneConfigs = new ArrayList<>();
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setSendMilestone("NO");
		milestoneConfigs.add(odsMilestoneConfig);
		when(odsMilestoneConfigRepository.findByFlowNodeProcessNameAndFlowNodeStepName(Mockito.any(), Mockito.any())).thenReturn(milestoneConfigs);
		OdsServiceRouterMapDetails odsSvcRouteMap = mock(OdsServiceRouterMapDetails.class);
		when(odsServiceRouterMapRepository.getOne(any(Integer.class))).thenReturn(odsSvcRouteMap);
		milestoneService.sendMilestone(request);

		LOGGER.info("Exiting testSendMilestone1");
	}

	@Test
	public void testSendMilestone2() throws ApplicationException {
		LOGGER.info("Entering testSendMilestone2");
		ResponseConfigParams params = new ResponseConfigParams();
		params.setSendMilestone(true);
		MileStoneRequestObject request = new MileStoneRequestObject();

		request.setManifestPayload("manifestPayload");
		List<OdsMilestoneConfig> milestoneConfigs = new ArrayList<>();
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setSendMilestone("YES");
		milestoneConfigs.add(odsMilestoneConfig);
		when(odsMilestoneConfigRepository.findByFlowNodeProcessNameAndFlowNodeStepName(Mockito.any(), Mockito.any())).thenReturn(milestoneConfigs);
		OdsServiceRouterMapDetails odsServiceRouterMapDetails = new OdsServiceRouterMapDetails();
		odsServiceRouterMapDetails.setId(242);
		odsServiceRouterMapDetails.setFlowNodeProcessName("Test1");
		odsServiceRouterMapDetails.setFlowNodeStepName("TestOneDispatcher");
		odsServiceRouterMapDetails.setRequestDocumentName("TEST-Message");
		odsServiceRouterMapDetails.setRequestSchema("{test:$.test}");
		odsServiceRouterMapDetails.setResponseDocumentName("Test-doc");
		odsServiceRouterMapDetails.setRouterProtocol("REST");
		odsServiceRouterMapDetails.setTargetEndPointUrl("http://test.com");
		odsServiceRouterMapDetails.setTransformationType("JSON");

		
		when(odsServiceRouterMapRepository.getOne(any(Integer.class))).thenReturn(odsServiceRouterMapDetails);
		milestoneService.sendMilestone(request);

		LOGGER.info("Exiting testSendMilestone2");
	}

	@Test
	public void testSendMilestone3() throws ApplicationException {
		LOGGER.info("Entering testSendMilestone3");
		ResponseConfigParams params = new ResponseConfigParams();
		params.setSendMilestone(true);
		MileStoneRequestObject request = new MileStoneRequestObject();
		request.setManifestPayload("manifestPayload");
	
		List<OdsMilestoneConfig> milestoneConfigs = new ArrayList<>();
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setSendMilestone("NO");
		milestoneConfigs.add(odsMilestoneConfig);
		when(odsMilestoneConfigRepository.findByFlowNodeProcessNameAndFlowNodeStepName(Mockito.any(), Mockito.any())).thenReturn(milestoneConfigs);

		OdsServiceRouterMapDetails odsServiceRouterMapDetails = new OdsServiceRouterMapDetails();
		odsServiceRouterMapDetails.setId(242);
		odsServiceRouterMapDetails.setFlowNodeProcessName("Test1");
		odsServiceRouterMapDetails.setFlowNodeStepName("TestOneDispatcher");
		odsServiceRouterMapDetails.setRequestDocumentName("TEST-Message");
		odsServiceRouterMapDetails.setRequestSchema("{test:$.test}");
		odsServiceRouterMapDetails.setResponseDocumentName("Test-doc");
		odsServiceRouterMapDetails.setRouterProtocol("REST");
		odsServiceRouterMapDetails.setTargetEndPointUrl("http://test.com");
		odsServiceRouterMapDetails.setTransformationType("JSON");

		when(odsServiceRouterMapRepository.getOne(any(Integer.class))).thenReturn(odsServiceRouterMapDetails);

		milestoneService.sendMilestone(request);

		LOGGER.info("Exiting testSendMilestone3");
	}

	@Test(expected = ApplicationException.class)
	public void testsendMilestoneOrNotification6() throws ApplicationException {
		LOGGER.info("Entering testsendMilestoneOrNotification6");
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		MileStoneRequestObject request = new MileStoneRequestObject();
		
		String manifestReqPayload = "{    \"rootProcessName\" : null,    \"flowNodeProcessName\" : \"LCI_DATA_PROVISIONING\",    \"flowNodeStepName\" : \"ODN-Provisioning\",    \"caseID\" : \"773396\",    \"parentCaseID\" : \"773396\",    \"rootCaseID\" : \"773396\",    \"responseDocumentName\" : \"PlanningMessage\",    \"transformationType\" : \"XML\",    \"appKey\" : \"ZZZDE-NGPON2\"  }";
		request.setManifestPayload(manifestReqPayload);
		
		OdsMilestoneTransaction odsMilestoneTra =new OdsMilestoneTransaction();
		odsMilestoneTra.setStepName("AddService");
		odsMilestoneTra.setProcessName("LCI_DATA_Pre_Activation");
		odsMilestoneTra.setRootCaseId("56779");
		odsMilestoneTra.setStatus(Constants.STATUS_PENDING);
	
		milestoneService.sendMilestoneOrNotification(odsMilestoneConfig, request,odsMilestoneTra,"NO");

		LOGGER.info("Exiting testsendMilestoneOrNotification6");
	}

	@Test
	public void testsendMilestoneOrNotification7() throws ApplicationException {
		LOGGER.info("Entering testsendMilestoneOrNotification7");
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setRequestDocumentName("MileStoneDoc");
		odsMilestoneConfig.setTransformationType("JSON");
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setRouteProtocol("Rest");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		String manifestReqPayload = "{    \"rootProcessName\" : null,    \"flowNodeProcessName\" : \"LCI_DATA_PROVISIONING\",    \"flowNodeStepName\" : \"ODN-Provisioning\",    \"caseID\" : \"773396\",    \"parentCaseID\" : \"773396\",    \"rootCaseID\" : \"773396\",    \"responseDocumentName\" : \"PlanningMessage\",    \"transformationType\" : \"XML\",    \"appKey\" : \"ZZZDE-NGPON2\"  }";
		String documentPayload = "{    \"rootProcessName\" : null,    \"flowNodeProcessName\" : \"LCI_DATA_PROVISIONING\",    \"flowNodeStepName\" : \"ODN-Provisioning\",    \"caseID\" : \"773396\",    \"parentCaseID\" : \"773396\",    \"rootCaseID\" : \"773396\",    \"responseDocumentName\" : \"PlanningMessage\",    \"transformationType\" : \"XML\",    \"appKey\" : \"ZZZDE-NGPON2\"  }";
		
		MileStoneRequestObject request = new MileStoneRequestObject();
	    request.setManifestPayload(manifestReqPayload);
		OdsMilestoneTransaction odsMilestoneTra =new OdsMilestoneTransaction();
		odsMilestoneTra.setStepName("AddService");
		odsMilestoneTra.setProcessName("LCI_DATA_Pre_Activation");
		odsMilestoneTra.setRootCaseId("56779");
		odsMilestoneTra.setStatus(Constants.STATUS_PENDING);
		
		when(serviceUtils.buildManifestDocument(manifestReqPayload, odsMilestoneConfig.getRequestDocumentName()))
		.thenReturn(documentPayload);
		MileStoneRequestResponsePayLoad reqPayload = new MileStoneRequestResponsePayLoad();
		when(odsService.doTransformation(Mockito.any(),anyString(),anyString())).thenReturn("aaaa");
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.MILESTONE_REQUEST_URL)).thenReturn(odsParamConfig);
		String milestoneObj = "";
		when(serviceUtils.convertObjectToJsonString(reqPayload)).thenReturn(milestoneObj);
		 when(odsMilestoneTansactionRepo.save(any(OdsMilestoneTransaction.class))).thenReturn(odsMilestoneTra);

		HttpHeaders httpHeaders = mock(HttpHeaders.class);
		String manifestRequest = "";
		ResponseEntity<String> responseEntity11 = new ResponseEntity<>("mainifestResponse", HttpStatus.OK);
		HttpEntity<String> httpEntity1 = new HttpEntity<>(manifestRequest, httpHeaders);

		when(serviceUtils.callService(odsParamConfig, httpEntity1)).thenReturn(responseEntity11);
			
		milestoneService.sendMilestoneOrNotification(odsMilestoneConfig, request,odsMilestoneTra,"YES");

		LOGGER.info("Exiting testsendMilestoneOrNotification7");
	}
	
	@Test
	public void testGetMilestoneTransctionDetails() throws ApplicationException {
		LOGGER.info("Entering testGetMilestoneTransctionDetails");
		OdsMilestoneTransaction odsMilestoneTra =new OdsMilestoneTransaction();
		odsMilestoneTra.setStepName("AddService");
		odsMilestoneTra.setProcessName("LCI_DATA_Pre_Activation");
		odsMilestoneTra.setRootCaseId("56779");
		odsMilestoneTra.setStatus(Constants.STATUS_PENDING);
		List<OdsMilestoneTransaction> transList =new ArrayList<>();
		transList.add(odsMilestoneTra);
		when(odsMilestoneTansactionRepo.findByRootCaseId(Mockito.any())).thenReturn(transList);
		milestoneService.getMilestoneTransctionDetails("121");

		LOGGER.info("Exiting testGetMilestoneTransctionDetails");
	}
	@Test(expected =ApplicationException.class)
	public void testRetryMilestoneTransaction() throws ApplicationException {
		LOGGER.info("Entering testRetryMilestoneTransaction");
		OdsMilestoneTransactionRequest request =new OdsMilestoneTransactionRequest();
		request.setOdsMilestoneTransactionId(0);
		milestoneService.retryMilestoneTransaction(request);

		LOGGER.info("Exiting testRetryMilestoneTransaction");
	}
	@Test(expected =ApplicationException.class)
	public void testRetryMilestoneTransaction1() throws ApplicationException {
		LOGGER.info("Entering testRetryMilestoneTransaction1");
		OdsMilestoneTransactionRequest request =new OdsMilestoneTransactionRequest();
		request.setOdsMilestoneTransactionId(111);
		milestoneService.retryMilestoneTransaction(request);

		LOGGER.info("Exiting testRetryMilestoneTransaction1");
	}
	@Test
	public void testRetryMilestoneTransaction2() throws ApplicationException {
		LOGGER.info("Entering testRetryMilestoneTransaction2");
		OdsMilestoneTransactionRequest request =new OdsMilestoneTransactionRequest();
		request.setOdsMilestoneTransactionId(111);
		request.setReProcessFlag("YES");
		OdsMilestoneTransaction odsMilestoneTra =new OdsMilestoneTransaction();
		odsMilestoneTra.setStepName("AddService");
		odsMilestoneTra.setProcessName("LCI_DATA_Pre_Activation");
		odsMilestoneTra.setRootCaseId("56779");
		odsMilestoneTra.setStatus(Constants.STATUS_PENDING);
        MilestoneService service =Mockito.spy(milestoneService);
		when(odsMilestoneTansactionRepo.findByOdsMilestoneTransactionId(Mockito.any())).thenReturn(odsMilestoneTra);
		Mockito.doNothing().when(service).sendMilestoneOrNotification(Mockito.any(OdsMilestoneConfig.class), Mockito.any(MileStoneRequestObject.class),Mockito.any(OdsMilestoneTransaction.class),Mockito.anyString());
		
		service.retryMilestoneTransaction(request);

		LOGGER.info("Exiting testRetryMilestoneTransaction2");
	}
	
	@Test
	public void testSaveMilestoneTranasactinStatus() {
		LOGGER.info("Entering testSaveMilestoneTranasactinStatus");
		OdsMilestoneTransaction odsMilestoneTra =new OdsMilestoneTransaction();
		odsMilestoneTra.setStepName("AddService");
		odsMilestoneTra.setProcessName("LCI_DATA_Pre_Activation");
		odsMilestoneTra.setRootCaseId("56779");
		odsMilestoneTra.setStatus(Constants.STATUS_PENDING);
        milestoneService.saveMilestoneTranasactinStatus(odsMilestoneTra, true);
		LOGGER.info("Exiting testSaveMilestoneTranasactinStatus");

	}
}
