package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.service.OdsParamConfigService;

@RunWith(MockitoJUnitRunner.class)
public class ODSParamconfigControllerMockitoTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSParamconfigControllerMockitoTest.class);

	@InjectMocks
	ODSParamConfigController odsParamConfigController;

	@Mock
	OdsParamConfigService odsParamConfigService;

	/**
	 * @throws ApplicationException
	 * 
	 */
	@Test
	public void testCreateOrUpdateOdsParamConfig() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testCreateOrUpdateOdsParamConfig*****************************");

		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setName("TEST");
		odsParamConfig.setParamKey("TEST-Param-Key");
		odsParamConfig.setValue("Test-Value");
		odsParamConfig.setType("TEST-Type");
		OdsParamConfig odsParamConfigRes = null;
		when(odsParamConfigService.createOrUpdateOdsParamConfig(odsParamConfig)).thenReturn(odsParamConfigRes);
		odsParamConfigController.createOrUpdateOdsParamConfig(odsParamConfig);

		LOGGER.info(
				"****************************Exiting from testCreateOrUpdateOdsParamConfig*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test

	public void testCreateOrUpdateOdsParamConfig1() throws ApplicationException {
		LOGGER.info(
				"****************************Entering to testCreateOrUpdateOdsParamConfig1*****************************");

		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setName("TEST");
		odsParamConfig.setParamKey("TEST-Param-Key");
		odsParamConfig.setValue("Test-Value");
		odsParamConfig.setType("TEST-Type");

		when(odsParamConfigService.createOrUpdateOdsParamConfig(odsParamConfig)).thenThrow(NullPointerException.class);
		odsParamConfigController.createOrUpdateOdsParamConfig(odsParamConfig);

		LOGGER.info(
				"****************************Exiting from testCreateOrUpdateOdsParamConfig1*****************************");
	}

	@Test
	public void testGetOdsParamConfig() throws ApplicationException {

		LOGGER.info("****************************Entering to testGetOdsParamConfig*****************************");

		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setName("TEST");
		odsParamConfig.setParamKey("TEST-Param-Key");
		odsParamConfig.setValue("Test-Value");
		odsParamConfig.setType("TEST-Type");
		List<OdsParamConfig> odsParamConfigResp = null;
		when(odsParamConfigService.getOdsParamConfigRecords(odsParamConfig)).thenReturn(odsParamConfigResp);
		odsParamConfigController.getOdsParamConfig(odsParamConfig);
		LOGGER.info("****************************Exiting from testGetOdsParamConfig*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetOdsParamConfig1() throws ApplicationException {
		LOGGER.info("****************************Entering to testGetOdsParamConfig1*****************************");

		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setName("TEST");
		odsParamConfig.setParamKey("TEST-Param-Key");
		odsParamConfig.setValue("Test-Value");
		odsParamConfig.setType("TEST-Type");

		when(odsParamConfigService.getOdsParamConfigRecords(odsParamConfig)).thenThrow(SQLException.class);
		odsParamConfigController.getOdsParamConfig(odsParamConfig);
		LOGGER.info("****************************Exiting from testGetOdsParamConfig1*****************************");

	}

	@Test
	public void testDeleteOdsParamConfig() throws ApplicationException {

		LOGGER.info("****************************Entering to testDeleteOdsParamConfig*****************************");

		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setName("TEST");
		odsParamConfig.setParamKey("TEST-Param-Key");
		odsParamConfig.setType("TEST-Type");
		List<OdsParamConfig> attrList = new ArrayList<>();
		attrList.add(odsParamConfig);
		Mockito.doThrow(SQLException.class).when(odsParamConfigService).deleteOdsParamConfigRecord(attrList);
		odsParamConfigController.deleteOdsParamConfig(attrList);
		LOGGER.info("****************************Exiting from testDeleteOdsParamConfig*****************************");

	}

}
