package com.vz.uiam.onenet.ods.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.NotesRequestResponsePayLoad;
import com.vz.uiam.onenet.ods.jpa.dto.model.NotesResponseTimePayLoad;
import com.vz.uiam.onenet.ods.util.ServiceUtils;


@RunWith(MockitoJUnitRunner.class)
public class NotesServiceTest {

	private static final Logger LOGGER = Logger.getLogger(NotesServiceTest.class);
	
	@InjectMocks
	NotesService notesService;

	@Mock
	OdsParamConfigRepository odsParamConfigRepository;

	@Mock
	RestTemplate restTemplate;
	
	@Mock
	ResponseEntity<String> responseEntity;
	
	@Mock
	ServiceUtils serviceUtils;


	@Test(expected = ApplicationException.class)
	public void testgetNotesInfoById1() throws ApplicationException {
		LOGGER.info("Entering testgetNotesInfoById1");
		String notesID = "TestID";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.GET_MANIFEST_ENDPOINT_URL))
		.thenReturn(odsParamConfig);
		ResponseEntity<String> responseEntity9 = new ResponseEntity<>("", HttpStatus.ACCEPTED);

		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntity9);

		notesService.getNotesInfoById(notesID);

		LOGGER.info("Exiting testgetNotesInfoById1");

	}

	@Test(expected = ApplicationException.class)
	public void testgetNotesInfoById2() throws ApplicationException {
		LOGGER.info("Entering testgetNotesInfoById2");
		String notesID = "TestID";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString()))
		.thenReturn(odsParamConfig);
		ResponseEntity<String> responseEntity7 = new ResponseEntity<>("", HttpStatus.ACCEPTED);

		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntity7);

		notesService.getNotesInfoById(notesID);

		LOGGER.info("Exiting testgetNotesInfoById2");
	}

	@Test(expected = ApplicationException.class)
	public void testgetNotesInfoById3() throws ApplicationException {
		LOGGER.info("Entering testgetNotesInfoById3");
		String notesID = "TestID";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString()))
		.thenReturn(odsParamConfig);

		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenThrow(Exception.class);

		notesService.getNotesInfoById(notesID);

		LOGGER.info("Exiting testgetNotesInfoById3");
	}

	@Test
	public void testupdateResponseInNotes3() throws ApplicationException {
		LOGGER.info("Entering testupdateResponseInNotes3");
		String transictinId = "5";
		String response = "TestResponse";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("True");
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setParamKey("ODS");

		OdsParamConfig odsParamConfig1 = new OdsParamConfig();
		odsParamConfig1.setValue("True");
		odsParamConfig1.setType("NOTES_PARAM");
		odsParamConfig1.setParamKey("ODS");
		List<OdsParamConfig> paramConfigForNoteIdentifiers = new ArrayList<>();
		OdsParamConfig odsParamCfg1 = new OdsParamConfig();
		odsParamCfg1.setName("Notes");
		odsParamCfg1.setValue("$.requestPayload.processInstanceId");
		paramConfigForNoteIdentifiers.add(odsParamCfg1);
		String reqKey = "reqKey";
		NotesRequestResponsePayLoad notesRequestResponsePayLoad = new NotesRequestResponsePayLoad();
		notesRequestResponsePayLoad.setId("8");
		Instant instant = Instant.now();
		NotesResponseTimePayLoad notesResponseTimePayLoad = new NotesResponseTimePayLoad(response, instant.toString());
		ResponseEntity<String> responseEntity1 = new ResponseEntity<>("{\"response\":{ \"docs\":[{\"notes\":[\"Successfully Sent - AddONT request.\"],\"notes_date\":\"2017-11-07T11:41:20.668Z\",\"workflow_step_s\":\"AddONT\",\"response_message_t\":[{\"Response\":\"\",\"DateTime\":\"\"}],\"_version_\":1583413700779311104,\"order_number\":\"CCOG639221728\",\"id\":\"1510054842274|34567|7654\",\"user\":\"SYSTEM\",\"notes_type\":\"ODS Notes\"}] } }",
				HttpStatus.OK);

		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntity1);
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_GET_URL)).thenReturn(odsParamConfig1);

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ENABLE_FLAG)).thenReturn(odsParamConfig);

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(null, OdsParamConfigType.NOTES_PARAM.toString(),
				Constants.NOTES_ORDER_NUMBER)).thenReturn(odsParamConfig1);
		when(odsParamConfigRepository.findByParamKeyAndType(reqKey, OdsParamConfigType.NOTES_PARAM.toString()))
		.thenReturn(paramConfigForNoteIdentifiers);

		when(serviceUtils.convertObjectToJsonString(notesResponseTimePayLoad)).thenReturn("{}");
		when(serviceUtils.convertJsonStringToObject(anyString(), any(Class.class)))
		.thenReturn(notesRequestResponsePayLoad);

		NotesService notesServiceSpy = Mockito.spy(notesService);
		Mockito.doNothing().when(notesServiceSpy).addOrUpdateNotesPayLoad(Mockito.any()); 
		
		notesServiceSpy.updateResponseInNotes(transictinId, response, reqKey);

		LOGGER.info("Exiting testupdateResponseInNotes3");

	}
	
	@Test(expected = ApplicationException.class)
	public void testAddOrUpdateNotesPayLoad1() throws ApplicationException {
		LOGGER.info("Entering testAddOrUpdateNotesPayLoad1");
		
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ADD_OR_UPDATE_URL)).thenReturn(null);
		
		notesService.addOrUpdateNotesPayLoad("{}");
		
		LOGGER.info("Exiting testAddOrUpdateNotesPayLoad1");
	}
	
	@Test(expected = ApplicationException.class)
	public void testAddOrUpdateNotesPayLoad2() throws ApplicationException {
		LOGGER.info("Entering testAddOrUpdateNotesPayLoad2");
		
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("http://vz.com/getnotes");
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setParamKey("ODS");
		
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ADD_OR_UPDATE_URL)).thenReturn(odsParamConfig);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		
		notesService.addOrUpdateNotesPayLoad("{}");
		
		LOGGER.info("Exiting testAddOrUpdateNotesPayLoad2");
	}
	
	@Test(expected = ApplicationException.class)
	public void testAddOrUpdateNotesPayLoad3() throws ApplicationException {
		LOGGER.info("Entering testAddOrUpdateNotesPayLoad3");
		
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("http://vz.com/getnotes");
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setParamKey("ODS");
		
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ADD_OR_UPDATE_URL)).thenReturn(odsParamConfig);
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
					.thenThrow(Exception.class);
		
		notesService.addOrUpdateNotesPayLoad("{}");
		
		LOGGER.info("Exiting testAddOrUpdateNotesPayLoad3");
	}
	
	@Test
	public void testAddRequestInNotesService1() throws ApplicationException {
		LOGGER.info("Entering testAddRequestInNotesService1");
		
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ENABLE_FLAG)).thenReturn(null);
		
		notesService.addRequestInNotesService("{}", "1234", "Testing_Step", new JSONObject(), null);
		
		LOGGER.info("Exiting testAddRequestInNotesService1");
	}
	
	@Test
	public void testAddRequestInNotesService2() throws ApplicationException {
		LOGGER.info("Entering testAddRequestInNotesService2");
		
		OdsParamConfig odsParamCfg = new OdsParamConfig();
		odsParamCfg.setValue("TRUE");
		
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ENABLE_FLAG)).thenReturn(odsParamCfg);
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(null, OdsParamConfigType.NOTES_PARAM.toString(), Constants.NOTES_ORDER_NUMBER))
				.thenReturn(null);
		
		notesService.addRequestInNotesService("{}", "1234", "Testing_Step", new JSONObject(), null);
		
		LOGGER.info("Exiting testAddRequestInNotesService2");
	}
	@Test
	public void testAddRequestInNotesService3() throws ApplicationException {
		LOGGER.info("Entering testAddRequestInNotesService3");
		
		OdsParamConfig odsParamCfg = new OdsParamConfig();
		odsParamCfg.setValue("TRUE");
		List<OdsParamConfig> paramConfigForNoteIdentifiers = new ArrayList<>();
		OdsParamConfig odsParamCfg1 = new OdsParamConfig();
		odsParamCfg1.setName("Notes");
		odsParamCfg1.setValue("$.requestPayload.processInstanceId");
		paramConfigForNoteIdentifiers.add(odsParamCfg1);
		String reqKey ="reqKey";
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ENABLE_FLAG)).thenReturn(odsParamCfg);
		when(odsParamConfigRepository.findByParamKeyAndType(reqKey,OdsParamConfigType.NOTES_PARAM.toString()))
				.thenReturn(paramConfigForNoteIdentifiers);
		
		notesService.addRequestInNotesService("{}", "1234", "Testing_Step", new JSONObject(), reqKey);
		
		LOGGER.info("Exiting testAddRequestInNotesService3");
	}
	@Test
	public void testAddRequestInNotesService4() throws ApplicationException {
		LOGGER.info("Entering testAddRequestInNotesService4");
		
		OdsParamConfig odsParamCfg = new OdsParamConfig();
		odsParamCfg.setValue("TRUE");
		List<OdsParamConfig> paramConfigForNoteIdentifiers = new ArrayList<>();
		OdsParamConfig odsParamCfg1 = new OdsParamConfig();
		odsParamCfg1.setName("Notes");
		odsParamCfg1.setValue("$.requestPayload.processInstanceId");
		paramConfigForNoteIdentifiers.add(odsParamCfg1);
		String reqKey ="reqKey";
		JSONObject requestDoc =new JSONObject();
		requestDoc.put("SOURCE_SYSTEM_NAME", "Source");
		requestDoc.put("DESTINATION_SYSTEM_NAME", "Destination");
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_ENABLE_FLAG)).thenReturn(odsParamCfg);
		when(odsParamConfigRepository.findByParamKeyAndType(reqKey,OdsParamConfigType.NOTES_PARAM.toString()))
				.thenReturn(paramConfigForNoteIdentifiers);
		NotesService notesServiceSpy =Mockito.spy(notesService);
		Mockito.doNothing().when(notesServiceSpy).addOrUpdateNotesPayLoad(anyString());
		notesServiceSpy.addRequestInNotesService("{}", "1234", "Testing_Step",requestDoc, reqKey);
		
		LOGGER.info("Exiting testAddRequestInNotesService4");
	}
	@Test
	public void testValidateAndBuildNotesPayload() throws ApplicationException {
		LOGGER.info("Entering testValidateAndBuildNotesPayload");
		OdsParamConfig odsParamCfg = new OdsParamConfig();
		odsParamCfg.setValue("TRUE");
		
		JSONObject requestObj =new JSONObject();
		JSONObject notesPayload =new JSONObject();

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.NOTES_SCHEMA)).thenReturn(odsParamCfg);
		Mockito.doNothing().when(serviceUtils).populateJsonPayload(odsParamCfg.getValue(), requestObj.toString(), notesPayload);
		
		notesService.validateAndBuildNotesPayload(requestObj);

		LOGGER.info("Exiting testValidateAndBuildNotesPayload");
	}
}
