package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dto.model.WorkflowFalloutRequest;
import com.vz.uiam.onenet.ods.service.FalloutService;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class FalloutServiceControllerMockitoTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(FalloutServiceControllerMockitoTest.class);

	@InjectMocks
	FalloutServiceController falloutServiceController;

	@Mock
	FalloutService falloutService;

	@Mock
	ServiceUtils serviceUtils;

	@Test
	public void testCreateFallout() throws ApplicationException {

		LOGGER.info("Entering testCreateFallout");

		WorkflowFalloutRequest request = Mockito.mock(WorkflowFalloutRequest.class);
		Mockito.doThrow(SQLException.class).when(falloutService).createFallout(request);

		falloutServiceController.createFallout(request);
		LOGGER.info("Exiting testCreateFallout");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testIsRetryPossible() throws ApplicationException {

		LOGGER.info("Entering testIsRetryPossible");

		String request = "{}";
		when(falloutService.isRetryPossible(Mockito.any())).thenThrow(ApplicationException.class);
		falloutServiceController.isRetryPossible(request);
		LOGGER.info("Exiting testIsRetryPossible");

	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCompleteAllUteTasks() throws ApplicationException {

		LOGGER.info("Entering testCompleteAllUteTasks");

		String request = "{}";
		Mockito.doNothing().when(falloutService).completeAllUteTasks(Mockito.any());
		falloutServiceController.completeAllUteTasks(request);
		LOGGER.info("Exiting testCompleteAllUteTasks");

	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCompleteAllUteTasks1() throws ApplicationException {

		LOGGER.info("Entering testCompleteAllUteTasks1");

		String request = "{}";
		Mockito.doThrow(ApplicationException.class).when(falloutService).completeAllUteTasks(Mockito.any());
		falloutServiceController.completeAllUteTasks(request);
		LOGGER.info("Exiting testCompleteAllUteTasks1");

	}
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void testRemovePendingAutoRetryDuringSupp() throws ApplicationException {

		LOGGER.info("Entering testRemovePendingAutoRetryDuringSupp");
		String request = "{}";
		Mockito.doThrow(ApplicationException.class).when(falloutService).removePendingAutoRetriesDuringSupp(Mockito.any());
		falloutServiceController.removePendingAutoRetriesDuringSupp(request);
		LOGGER.info("Exiting testRemovePendingAutoRetryDuringSupp");

	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testRemovePendingAutoRetryDuringSupp1() throws ApplicationException {

		LOGGER.info("Entering testRemovePendingAutoRetryDuringSupp1");
		String request = "{}";
		Mockito.doNothing().when(falloutService).removePendingAutoRetriesDuringSupp(Mockito.any());
		falloutServiceController.removePendingAutoRetriesDuringSupp(request);
		LOGGER.info("Exiting testRemovePendingAutoRetryDuringSupp1");

	}

}
