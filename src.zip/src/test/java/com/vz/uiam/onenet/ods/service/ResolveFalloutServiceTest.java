package com.vz.uiam.onenet.ods.service;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;


import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.ResolveWorkflowFallout;
import com.vz.uiam.onenet.ods.jpa.dao.model.ResolveWorkflowFalloutConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.ResolveWorkflowFalloutConfigRepo;
import com.vz.uiam.onenet.ods.jpa.dao.repository.ResolveWorkflowFalloutRepo;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveHandleFalloutRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveWorkflowFalloutRequest;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

import ma.glasnost.orika.MapperFacade;

@RunWith(MockitoJUnitRunner.class)
public class ResolveFalloutServiceTest {

	@InjectMocks
	ResolveFalloutService resolveFalloutService;

	@Mock
	ResolveWorkflowFalloutConfigRepo configRepo;

	@Mock
	ResolveWorkflowFalloutRepo fallOutRepo;

	@Mock
	ServiceUtils utils;

	@Mock
	MapperFacade mapper;

	/*
	 * @param request
	 * @return WorkflowFalloutConfig
	 * @throws ApplicationException
         */
	@Test
	public void testGetFalloutConfig() throws ApplicationException {

		ResolveWorkflowFalloutConfig config = new ResolveWorkflowFalloutConfig();
		when(configRepo.findByWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndWorkFlowProcessName(anyString(),
				anyString(), anyString())).thenReturn(config);

		ResolveFalloutService odsServiceSpy = Mockito.spy(resolveFalloutService);
		odsServiceSpy.getFalloutConfig(new ResolveWorkflowFalloutRequest());

	}

	/**
	 * @param request
	 * @return WorkflowFalloutConfig
	 * @throws ApplicationException
	 *
	 *
	 */


	/**
	 * @param request
	 * @return WorkflowFalloutConfig
	 * @throws ApplicationException
	 */
	@Test
	public void testCreateFallout() throws ApplicationException {

		ResolveWorkflowFallout resolveWorkflowFallout = new ResolveWorkflowFallout();
		when(fallOutRepo.getByCaseIdAndWorkFlowStepName(anyString(), anyString())).thenReturn(resolveWorkflowFallout);

		ResolveFalloutService odsServiceSpy = Mockito.spy(resolveFalloutService);
		odsServiceSpy.createFallout(new ResolveWorkflowFalloutRequest());

		

	}
	
	
	@Test
	public void testCreateFalloutIsNull() throws ApplicationException {

		
		ResolveWorkflowFallout resolveWorkflowFallout=new ResolveWorkflowFallout();
		ResolveWorkflowFalloutRequest resolveWorkflowFalloutRequest=new ResolveWorkflowFalloutRequest();
		when(mapper.map(resolveWorkflowFalloutRequest, ResolveWorkflowFallout.class)).thenReturn(resolveWorkflowFallout);
		ResolveFalloutService odsServiceSpy = Mockito.spy(resolveFalloutService);
		odsServiceSpy.createFallout(resolveWorkflowFalloutRequest);

	}

	

	@Test
	public void testHandleFalloutWhenConfigIsNull() throws ApplicationException {
	

		ResolveWorkflowFalloutConfig config = new ResolveWorkflowFalloutConfig();
		config.setWorkFlowFalloutErrorCode("");
		config.setWorkFlowFalloutErrorCategory("");
		config.setMaxRetryCounter(0);

		when(configRepo.findByWorkFlowStepNameAndWorkFlowFalloutErrorCode(anyString(), anyString())).thenReturn(config);
		ResolveHandleFalloutRequest resolveHandleFalloutRequest = new ResolveHandleFalloutRequest();
		resolveHandleFalloutRequest.setCaseId("");
		resolveHandleFalloutRequest.setStepName("");
		resolveHandleFalloutRequest.setProcessName("");

		ResolveFalloutService resolveFallOutServiceSpy = Mockito.spy(resolveFalloutService);
		resolveFallOutServiceSpy.handleFallout(resolveHandleFalloutRequest);

		

	}

	@Test
	public void testHandleFalloutWhenFalloutIsNotNull() throws ApplicationException {

		ResolveWorkflowFalloutConfig config = null;
		when(configRepo.findByWorkFlowStepNameAndWorkFlowFalloutErrorCode(anyString(), anyString())).thenReturn(config);
		ResolveHandleFalloutRequest resolveHandleFalloutRequest = new ResolveHandleFalloutRequest();
		resolveHandleFalloutRequest.setCaseId("");
		resolveHandleFalloutRequest.setStepName("");
		resolveHandleFalloutRequest.setProcessName("");

		ResolveFalloutService resolveFallOutServiceSpy = Mockito.spy(resolveFalloutService);
		resolveFallOutServiceSpy.handleFallout(resolveHandleFalloutRequest);

	}

	@Test
	public void testHandleFalloutWhenConfigIsNotNull() throws ApplicationException {

		ResolveWorkflowFalloutConfig config = new ResolveWorkflowFalloutConfig();
		config.setWorkFlowFalloutErrorCode("");
		config.setWorkFlowFalloutErrorCategory("");
		config.setMaxRetryCounter(8);

		when(configRepo.findByWorkFlowStepNameAndWorkFlowFalloutErrorCode(anyString(), anyString())).thenReturn(config);
		ResolveHandleFalloutRequest resolveHandleFalloutRequest = new ResolveHandleFalloutRequest();
		resolveHandleFalloutRequest.setCaseId("");
		resolveHandleFalloutRequest.setStepName("");
		resolveHandleFalloutRequest.setProcessName("");

		ResolveFalloutService resolveFallOutServiceSpy = Mockito.spy(resolveFalloutService);
		resolveFallOutServiceSpy.handleFallout(resolveHandleFalloutRequest);

	}
	


}
