package com.vz.uiam.onenet.ods.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class OdsRequestLogServiceTest {
	private static final Logger LOGGER = Logger.getLogger(OdsRequestLogServiceTest.class);
	@InjectMocks
	OdsRequestLogService odsRequestLogService;

	@Mock
	OdsRequestLogRepository odsRequestLogRepository;

	@Mock
	OdsParamConfigRepository odsParamConfigRepository;
	
	@Mock
	ServiceUtils serviceUtils;

	@Test
	public void testCreateOdsRequestLogEntry() throws ApplicationException {

		LOGGER.info("Entering testCreateOdsRequestLogEntry");
		JSONObject workflowRequest = new JSONObject();
		workflowRequest.put(Constants.ACTIVITY_INSTANCE_ID, "123456");
		workflowRequest.put(Constants.FLOW_STEP_NAME, "flow_step_name");
		String title = "37731303";
		String titleVersion = "0";
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		when(odsRequestLogRepository.findByWfTaskId(Mockito.anyString())).thenReturn(odsRequestLog);
		when(odsRequestLogRepository.save(Mockito.any(OdsRequestLog.class))).thenReturn(odsRequestLog);
		OdsParamConfig odsParam = new OdsParamConfig();
		odsParam.setValue("1");
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsParam);
		when(serviceUtils.getCurrentTimestamp()).thenReturn(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
		odsRequestLogService.createOdsRequestLogEntry(workflowRequest, title, titleVersion);
		LOGGER.info("Exiting testCreateOdsRequestLogEntry");
	}

	@Test
	public void testCreateOdsRequestLogEntry1() throws ApplicationException {

		LOGGER.info("Entering testCreateOdsRequestLogEntry1");
		JSONObject workflowRequest = new JSONObject();
		workflowRequest.put(Constants.ACTIVITY_INSTANCE_ID, "123456");
		workflowRequest.put(Constants.FLOW_STEP_NAME, "flow_step_name");
		String title = "37731303";
		String titleVersion = "0";
		when(odsRequestLogRepository.findByWfTaskId(Mockito.anyString())).thenReturn(null);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		when(odsRequestLogRepository.save(Mockito.any(OdsRequestLog.class))).thenReturn(odsRequestLog);
		OdsParamConfig odsParam = new OdsParamConfig();
		odsParam.setValue("1");
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsParam);
		when(serviceUtils.getCurrentTimestamp()).thenReturn(new java.sql.Timestamp(Calendar.getInstance().getTime().getTime()));
		odsRequestLogService.createOdsRequestLogEntry(workflowRequest, title, titleVersion);
		LOGGER.info("Exiting testCreateOdsRequestLogEntry1");
	}
	
	@Test
	public void testgetOdsRequestLogEntryBywfTaskId()throws ApplicationException{
		LOGGER.info("Entering testgetOdsRequestLogEntryBywfTaskId");
		String request = "{\"wfTaskId\": \"3531346\"}";
		JSONObject logEntryRequest = new JSONObject(request);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setTitle("52720185");
		odsRequestLog.setTitleVersion("0");
		odsRequestLog.setWfTaskId("3531346");
		when(odsRequestLogRepository.findByWfTaskId(logEntryRequest.getString(Constants.WF_TASK_ID))).thenReturn(odsRequestLog);
		odsRequestLogService.getOdsRequestLogEntryBywfTaskId(logEntryRequest);
		
		LOGGER.info("Exiting testgetOdsRequestLogEntryBywfTaskId");
		
	}
	
	@Test
	public void testgetOdsRequestLogEntryBywfTaskId1()throws ApplicationException{
		LOGGER.info("Entering testgetOdsRequestLogEntryBywfTaskId1");
		String request = "{\"wfTaskId\": \"3531346\"}";
		JSONObject logEntryRequest = new JSONObject(request);
		OdsRequestLog odsRequestLog = null;		
	
		when(odsRequestLogRepository.findByWfTaskId(logEntryRequest.getString(Constants.WF_TASK_ID))).thenReturn(odsRequestLog);
		odsRequestLogService.getOdsRequestLogEntryBywfTaskId(logEntryRequest);
		LOGGER.info(odsRequestLogService.getOdsRequestLogEntryBywfTaskId(logEntryRequest));
		LOGGER.info("Exiting testgetOdsRequestLogEntryBywfTaskId1");
		
	}
	
		
	/**
	 * test case to check if the return value is a list 
	 * @throws ApplicationException
	 */
	@Test
	public void testgetOdsRequestLogEntryByTitleAndTVersion() throws ApplicationException{
		LOGGER.info("Entering testgetOdsRequestLogEntryByTitleAndTVersion");
		String title = "52820181";
		String titleVersion = "0";
		List<OdsRequestLog> odsRequestLogList = new ArrayList<>();
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setTitle(title);
		odsRequestLog.setTitleVersion(titleVersion);
		odsRequestLogList.add(odsRequestLog);
		when(odsRequestLogRepository.findByTitleAndTitleVersion(title, titleVersion)).thenReturn(odsRequestLogList);
		LOGGER.info(odsRequestLogService.getOdsRequestLogEntryByTitleAndTitleVersion(title, titleVersion));
		LOGGER.info("Exiting testgetOdsRequestLogEntryByTitleAndTVersion");
		
	}
	
	/**
	 * test case to check if the return value is null 
	 * @throws ApplicationException
	 */
	
	 
	@Test
	public void testgetOdsRequestLogEntryByTitleAndTVersion1() throws ApplicationException{
		LOGGER.info("Entering testgetOdsRequestLogEntryByTitleAndTVersion");
		String title = "0";
		String titleVersion = "0";
		List<OdsRequestLog> odsRequestLogList = null;
		when(odsRequestLogRepository.findByTitleAndTitleVersion(Mockito.anyString(),Mockito.anyString())).thenReturn(odsRequestLogList);
        LOGGER.info(odsRequestLogService.getOdsRequestLogEntryByTitleAndTitleVersion(title, titleVersion));
		LOGGER.info("Exiting testgetOdsRequestLogEntryByTitleAndTVersion");
		
	}
	

}