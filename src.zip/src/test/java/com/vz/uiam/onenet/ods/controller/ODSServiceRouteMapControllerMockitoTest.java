package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.service.OdsServiceRouteMapService;

@RunWith(MockitoJUnitRunner.class)
public class ODSServiceRouteMapControllerMockitoTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSServiceRouteMapControllerMockitoTest.class);

	@InjectMocks
	ODSServiceRouteMapController odsServiceRouteMapController;

	@Mock
	OdsServiceRouteMapService odsServiceRouteMapService;

	/**
	 * @throws ApplicationException
	 * 
	 */
	@Test
	public void testCreateOrUpdateServiceRouteMap() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testCreateOrUpdateServiceRouteMap*****************************");

		OdsServiceRouterMapDetails odsServiceRouterMapDetails = new OdsServiceRouterMapDetails();
		odsServiceRouterMapDetails.setAppKey("TEST-Process-Name_TEST-Step-Name");
		odsServiceRouterMapDetails.setFlowNodeProcessName("TEST-Process-Name");
		odsServiceRouterMapDetails.setFlowNodeStepName("TEST-Step-Name");
		odsServiceRouterMapDetails.setRequestDocumentName("TEST-Message");
		odsServiceRouterMapDetails.setRequestSchema("{test:$.test}");
		odsServiceRouterMapDetails.setResponseDocumentName("Test-doc");
		odsServiceRouterMapDetails.setRouterProtocol("REST");
		odsServiceRouterMapDetails.setTargetEndPointUrl("http://test.com");
		odsServiceRouterMapDetails.setTransformationType("JSON");

		OdsServiceRouterMapDetails odsSvcRoutMapResp = null;
		when(odsServiceRouteMapService.createOrUpdateServiceRouteMap(odsServiceRouterMapDetails))
				.thenReturn(odsSvcRoutMapResp);
		odsServiceRouteMapController.createOrUpdateServiceRouteMap(odsServiceRouterMapDetails);

		LOGGER.info(
				"****************************Exiting from testCreateOrUpdateServiceRouteMap*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testCreateOrUpdateServiceRouteMap1() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testCreateOrUpdateServiceRouteMap*****************************");

		OdsServiceRouterMapDetails odsServiceRouterMapDetails = new OdsServiceRouterMapDetails();

		when(odsServiceRouteMapService.createOrUpdateServiceRouteMap(odsServiceRouterMapDetails))
				.thenThrow(NullPointerException.class);
		odsServiceRouteMapController.createOrUpdateServiceRouteMap(odsServiceRouterMapDetails);

		LOGGER.info(
				"****************************Exiting from testCreateOrUpdateServiceRouteMap*****************************");
	}

	@Test
	public void testGetServiceRouteMap() throws ApplicationException {
		LOGGER.info("****************************Entering to testGetServiceRouteMap*****************************");

		OdsServiceRouterMapDetails odsServiceRouterMapDetails = new OdsServiceRouterMapDetails();
		odsServiceRouterMapDetails.setFlowNodeProcessName("TEST-Process-Name");
		odsServiceRouterMapDetails.setFlowNodeStepName("TEST-Step-Name");
		List<OdsServiceRouterMapDetails> odsSvcRoutMapResp = null;
		when(odsServiceRouteMapService.getServiceRouteMapRecords(odsServiceRouterMapDetails))
				.thenReturn(odsSvcRoutMapResp);
		odsServiceRouteMapController.getServiceRouteMap(odsServiceRouterMapDetails);
		LOGGER.info("****************************Exiting from testGetServiceRouteMap*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetServiceRouteMap1() throws ApplicationException {

		LOGGER.info("****************************Entering to testGetServiceRouteMap1*****************************");
		OdsServiceRouterMapDetails odsServiceRouterMapDetails = new OdsServiceRouterMapDetails();

		when(odsServiceRouteMapService.getServiceRouteMapRecords(odsServiceRouterMapDetails))
				.thenThrow(SQLException.class);
		odsServiceRouteMapController.getServiceRouteMap(odsServiceRouterMapDetails);
		LOGGER.info("****************************Exiting from testGetServiceRouteMap1*****************************");

	}

	@Test
	public void testDeleteServiceRouteMap() throws ApplicationException {

		LOGGER.info("****************************Entering to testDeleteServiceRouteMap*****************************");

		OdsServiceRouterMapDetails odsServiceRouterMapDetails = new OdsServiceRouterMapDetails();
		odsServiceRouterMapDetails.setFlowNodeProcessName("Test11");
		odsServiceRouterMapDetails.setFlowNodeStepName("TestOneDispatcher");
		List<OdsServiceRouterMapDetails> attrList = new ArrayList<>();
		attrList.add(odsServiceRouterMapDetails);
		Mockito.doThrow(NullPointerException.class).when(odsServiceRouteMapService)
				.deleteServiceRouteMapRecord(attrList);
		odsServiceRouteMapController.deleteServiceRouteMap(attrList);
		LOGGER.info("****************************Exiting from testDeleteServiceRouteMap*****************************");

	}

}
