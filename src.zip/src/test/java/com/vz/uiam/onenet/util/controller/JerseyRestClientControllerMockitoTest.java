package com.vz.uiam.onenet.util.controller;

import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;

import com.vz.uiam.onenet.util.exception.ApplicationException;
import com.vz.uiam.onenet.util.service.JerseyRestClientService;

@RunWith(MockitoJUnitRunner.class)
public class JerseyRestClientControllerMockitoTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(JerseyRestClientControllerMockitoTest.class);

	@InjectMocks
	JerseyRestClientController jerseyRestClientController;

	@Mock
	JerseyRestClientService jerseyRestClientService;
	

	
	@Test
	public void testRoute() throws ApplicationException  {
		LOGGER.info("Entering testRoute");
		String request ="{\"endpointUrl\": \"http://google.com\",\"contentType\": \"application/json\",	\"accept\": \"application/json\",\"requestMethod\": \"POST\",\n" + 
				"			\"payload\": {}}";
		String response ="{\"status\":\"success\"}";
		when(jerseyRestClientService.routeWithJerseyClient(request)).thenReturn(response);
		jerseyRestClientController.route(request);
		LOGGER.info("Exiting testRoute");
	}
	@SuppressWarnings("unchecked")
	@Test
	public void testRoute11() throws ApplicationException  {
		LOGGER.info("Entering testRoute11");
		String request ="{\"endpointUrl\": \"http://google.com\",\"contentType\": \"application/json\",	\"accept\": \"application/json\",\"requestMethod\": \"POST\",\n" + 
				"			\"payload\": {}}";
		
		when(jerseyRestClientService.routeWithJerseyClient(request)).thenThrow(ApplicationException.class);
		jerseyRestClientController.route(request);
		LOGGER.info("Exiting testRoute11");
	}
	
}
