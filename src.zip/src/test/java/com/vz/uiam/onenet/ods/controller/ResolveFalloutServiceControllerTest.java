package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveHandleFalloutRequest;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResolveWorkflowFalloutRequest;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class ResolveFalloutServiceControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ResolveFalloutServiceControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	ResolveFalloutServiceController resolveFalloutServiceController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	/**
	 * 
	 */
	@Test
	public void testResolveHandleFallout() {
		try {
			LOGGER.info("****************************Entering to testResolveHandleFallout*****************************");
			URI url = new URI("/oneDispatcher/fallout/resolveHandleFallout");
			ResolveHandleFalloutRequest resolveHandleFalloutRequest =new ResolveHandleFalloutRequest();
			resolveHandleFalloutRequest.setCaseId("8855320");
			resolveHandleFalloutRequest.setErrorCode("");
			resolveHandleFalloutRequest.setProcessName("OneNetVPSEVCGenericOrder");
			resolveHandleFalloutRequest.setStepName("VPSCompleteOrder");
			resolveHandleFalloutRequest.setRootCaseId("985520");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(resolveHandleFalloutRequest)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testResolveHandleFallout*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for handleFallout: ",e);
		}
	}
	@Test
	public void testResolveHandleFallout1() {
		try {
			LOGGER.info("****************************Entering to testResolveHandleFallout1*****************************");
			URI url = new URI("/oneDispatcher/fallout/resolveHandleFallout");
			ResolveHandleFalloutRequest handleFalloutRequest =new ResolveHandleFalloutRequest();
			handleFalloutRequest.setCaseId("8897530");
			handleFalloutRequest.setErrorCode("");
			handleFalloutRequest.setProcessName("OneNetVPSEVCGenericOrder");
			handleFalloutRequest.setStepName("VPSCompleteOrder");
			handleFalloutRequest.setRootCaseId("5565520");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(handleFalloutRequest)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testResolveHandleFallout1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for handleFallout: ",e);
		}
	}
	@Test
	public void testResolveCreateFallout() {
		try {
			LOGGER.info("****************************Entering to testResolveCreateFallout*****************************");
			URI url = new URI("/oneDispatcher/fallout/resolveCreateFallout");
			ResolveWorkflowFalloutRequest	resolveWorkflowFalloutRequest = new ResolveWorkflowFalloutRequest();
			resolveWorkflowFalloutRequest.setCaseId("8855620");
			resolveWorkflowFalloutRequest.setWorkFlowFalloutErrorCode("404");
			resolveWorkflowFalloutRequest.setWorkFlowProcessName("OneNetVPSEVCGenericOrder");
			resolveWorkflowFalloutRequest.setWorkFlowStepName("OneNetVPSGenericOrder");
			resolveWorkflowFalloutRequest.setRootCaseId("669930");
			resolveWorkflowFalloutRequest.setWorkFlowFalloutErrorDesc("INTERNAL_ERROR");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(resolveWorkflowFalloutRequest)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testResolveCreateFallout*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createFallout: ",e);
		}
	}
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_workflow_fallout_table.sql") })
	public void testResolveCreateFallout1() {
		try {
			LOGGER.info("****************************Entering to testCreateFallout1*****************************");
			URI url = new URI("/oneDispatcher/fallout/resolveCreateFallout");
			ResolveWorkflowFalloutRequest	resolveWorkflowFalloutRequest = new ResolveWorkflowFalloutRequest();
			resolveWorkflowFalloutRequest.setCaseId("887720");
			resolveWorkflowFalloutRequest.setWorkFlowProcessName("OneNetVPSCollectOrder");
			resolveWorkflowFalloutRequest.setWorkFlowStepName("Collect-Order");
			resolveWorkflowFalloutRequest.setWorkFlowFalloutErrorCode("");
			resolveWorkflowFalloutRequest.setRootCaseId("2247810");
			resolveWorkflowFalloutRequest.setWorkFlowFalloutErrorDesc("Unauthorized");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(resolveWorkflowFalloutRequest)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testResolveCreateFallout1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createFallout: ",e);
		}
	}
	
	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}
	
	

}
