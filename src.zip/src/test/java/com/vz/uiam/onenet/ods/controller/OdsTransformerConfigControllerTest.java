package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsTransformerConfig;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsTransformerConfigDto;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class OdsTransformerConfigControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(OdsTransformerConfigControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	OdsTransformerConfigController odsTransformerConfigController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	/**
	 * 
	 */
	@Test
	public void testTransform() {
		try {
			LOGGER.info("****************************Entering to testTransform*****************************");
			URI url = new URI("/oneDispatcher/tranform");
			OdsTransformerConfigDto odsTransformerConfigDto = new OdsTransformerConfigDto();
			odsTransformerConfigDto.setTransformerKey("TEST_CONFIG");
			odsTransformerConfigDto.setTransformerType("JSON");
			odsTransformerConfigDto.setRequestDocument(getTransformRequest());
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfigDto)))
					.andExpect(status().isExpectationFailed()).andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testTransform*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	@Test
	public void testTransform1() {
		try {
			LOGGER.info("****************************Entering to testTransform1*****************************");
			URI url = new URI("/oneDispatcher/tranform");
			OdsTransformerConfigDto odsTransformerConfigDto = new OdsTransformerConfigDto();
			odsTransformerConfigDto.setTransformerKey("GET_Data_DETAILS123");
			odsTransformerConfigDto.setTransformerType("JSON");
			odsTransformerConfigDto.setRequestDocument(getRequestDocument());
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfigDto)))
					.andExpect(status().isExpectationFailed()).andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testTransform1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	@Test
	@SqlGroup({
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql") })
	public void testTransform2() {
		try {
			LOGGER.info("****************************Entering to testTransform2*****************************");
			URI url = new URI("/oneDispatcher/tranform");
			OdsTransformerConfigDto odsTransformerConfigDto = new OdsTransformerConfigDto();
			odsTransformerConfigDto.setTransformerKey("LCI_OVER_NGPON2_Pre_Activation_RetrieveONTSerialNumber");
			odsTransformerConfigDto.setTransformerType("XML");
			odsTransformerConfigDto.setRequestDocument(
					"<ODSResponse><SplsFttpResp xmlns=\"\"><StatusCode>0</StatusCode><StatusDesc>Success</StatusDesc><FttpCapableFlag>No</FttpCapableFlag><AddrSesCapableFlag>No</AddrSesCapableFlag><WirecenterSesEnableFlag>Yes</WirecenterSesEnableFlag></SplsFttpResp><transactionId>1519814790601| 12338 | 4566 </transactionId></ODSResponse>");
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfigDto)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testTransform2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	@Test
	@SqlGroup({
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql") })
	public void testCreateOrUpdateOdsTransformerConfigSuccess() {
		try {
			LOGGER.info(
					"****************************Entering to createOrUpdateOdsTransformerConfig*****************************");
			URI url = new URI("/oneDispatcher/odsTransformerConfig/createOrUpdate");
			OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
			odsTransformerConfig.setTransformerKey("Test_Transformation121");
			odsTransformerConfig.setTransformerSchema(getTransformerShema());
			odsTransformerConfig.setTransformerType("JSON");
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testTransform2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	@Test
	@SqlGroup({
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql") })
	public void testCreateOrUpdateOdsTransformerConfigFail() {
		try {
			LOGGER.info(
					"****************************Entering to createOrUpdateOdsTransformerConfig*****************************");
			URI url = new URI("/oneDispatcher/odsTransformerConfig/createOrUpdate");
			OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
			odsTransformerConfig.setTransformerKey("Test_Transformation121");
			odsTransformerConfig.setTransformerSchema(getTransformerShema());
			odsTransformerConfig.setTransformerType("JSON");
			odsTransformerConfig.setOdsTransformerId(999999999);
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testTransform2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	@Test
	@SqlGroup({
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql") })
	public void testCreateOrUpdateOdsTransformerConfigUpdate() {
		try {
			LOGGER.info(
					"****************************Entering to createOrUpdateOdsTransformerConfig*****************************");
			URI url = new URI("/oneDispatcher/odsTransformerConfig/createOrUpdate");
			OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
			odsTransformerConfig.setTransformerKey("Test_Transformation122");
			odsTransformerConfig.setTransformerSchema(getTransformerShema());
			odsTransformerConfig.setTransformerType("JSON");
			odsTransformerConfig.setOdsTransformerId(9499899);
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testTransform2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	@Test
	@SqlGroup({
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql") })
	public void testGetOdsTransformerConfig() {
		try {
			LOGGER.info(
					"****************************Entering to gtOdsTransformerConfig()*****************************");
			URI url = new URI("/oneDispatcher/odsTransformerConfig/get");
			OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
			odsTransformerConfig.setOdsTransformerId(9499899);
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************gtOdsTransformerConfig()*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	@Test
	@SqlGroup({
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql") })
	public void deleteOdsTransformerConfigSuccess() {
		try {
			LOGGER.info(
					"****************************Entering to gtOdsTransformerConfig()*****************************");
			URI url = new URI("/oneDispatcher/odsTransformerConfig/delete");
			OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
			odsTransformerConfig.setOdsTransformerId(9499899);
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************gtOdsTransformerConfig()*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	@Test
	@SqlGroup({
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql") })
	public void deleteOdsTransformerConfigSuccess2() {
		try {
			LOGGER.info(
					"****************************Entering to gtOdsTransformerConfig()*****************************");
			URI url = new URI("/oneDispatcher/odsTransformerConfig/delete");
			OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
			odsTransformerConfig.setTransformerKey("Test_Transformation122");
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************gtOdsTransformerConfig()*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	@Test
	public void deleteOdsTransformerConfigFail() {
		try {
			LOGGER.info(
					"****************************Entering to gtOdsTransformerConfig()*****************************");
			URI url = new URI("/oneDispatcher/odsTransformerConfig/delete");
			OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
			odsTransformerConfig.setTransformerKey("Test_Transformation120");
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************gtOdsTransformerConfig()*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	@Test
	public void deleteOdsTransformerConfigFail2() {
		try {
			LOGGER.info(
					"****************************Entering to gtOdsTransformerConfig()*****************************");
			URI url = new URI("/oneDispatcher/odsTransformerConfig/delete");
			OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************gtOdsTransformerConfig()*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	@Test
	@SqlGroup({
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_transformer_config.sql"),
			@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_transformer_config.sql") })

	public void testCreateOrUpdateOdsTransformerConfigValidation() {
		try {
			LOGGER.info(
					"****************************Entering to createOrUpdateOdsTransformerConfig*****************************");
			URI url = new URI("/oneDispatcher/odsTransformerConfig/createOrUpdate");
			OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
			odsTransformerConfig.setTransformerKey("");
			odsTransformerConfig.setTransformerSchema(getTransformerShema());
			odsTransformerConfig.setTransformerType("JSON");
			odsTransformerConfig.setOdsTransformerId(9499899);
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConfig)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			OdsTransformerConfig odsTransformerConf = new OdsTransformerConfig();
			odsTransformerConf.setTransformerKey("transKey");
			odsTransformerConf.setTransformerSchema(getTransformerShema());
			odsTransformerConf.setTransformerType("");
			odsTransformerConf.setOdsTransformerId(9499899);
			MvcResult result1 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerConf)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result1.getResponse().getContentAsString());

			OdsTransformerConfig odsTransformerCon = new OdsTransformerConfig();
			odsTransformerCon.setTransformerKey("transKey");
			odsTransformerCon.setTransformerSchema("");
			odsTransformerCon.setTransformerType("JSON");
			odsTransformerCon.setOdsTransformerId(9499899);
			MvcResult result2 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsTransformerCon)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result2.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testTransform2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for transform: ", e);
		}
	}

	private String getTransformerShema() {

		String schema = "{\"externalTaskId\": \"$.externalTaskId\", \"task\": { \"title\": \"$.title\"}, \"taskAttributes\":"
				+ " { \"attribute\": [{ \"Name\": \"CASE_ID\", \"Value\": \"$.caseId\" }, { \"Name\": \"STEP_NAME\", \"Value\": "
				+ "\"$.stepName\" }, { \"Name\": \"ERROR_CODE\", \"Value\": \"$.errorCode\" }, { \"Name\": \"PROCESS_NAME\", "
				+ "\"Value\": \"$.processName\" }] }, \"taskHeader\": { \"orderInfo\": { \"orderSource\": \"$.orderSource\", "
				+ "\"lineOfBusiness\": \"$.lineOfBusiness\" }, \"taskSource\": \"$.taskSource\", \"userId\": \"walter.bates\" },"
				+ " \"createDate\": \"2016-10-06T04:26:51\"}";
		return schema;
	}

	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

	public String getTransformRequest() {
		Map<String, Object> mainValues = new HashMap<>();
		Map<String, Object> subValues = new HashMap<>();
		mainValues.put("app-key", "ZZZDE-NGPON2");
		mainValues.put("processInstanceId", "34567");
		mainValues.put("parentProcessInstanceId", "45678");
		mainValues.put("rootProcessInstanceId", "56789");
		mainValues.put("flowNodeProcessName", "LCI_OVER_NGPON2_Pre_Activation");
		mainValues.put("flowNodeStepName", "AddONT");
		subValues.put("order_number", "ICOG835708993");
		subValues.put("order_version", "000");
		subValues.put("product_type", "Data");
		subValues.put("supp_type", "1");
		subValues.put("region", "NJ");
		mainValues.put("seedInfo", subValues);

		JSONObject requestJson = new JSONObject(mainValues);
		LOGGER.info("getTransformRequest ::::" + requestJson.toString());
		return requestJson.toString();

	}

	public String getRequestDocument() {
		Map<String, Object> mainValues = new HashMap<>();
		Map<String, Object> subValues = new HashMap<>();
		mainValues.put("app-key", "ZZZDE-NGPON2");
		mainValues.put("processInstanceId", "34567");
		mainValues.put("parentProcessInstanceId", "45678");
		mainValues.put("rootProcessInstanceId", "56789");
		mainValues.put("flowNodeProcessName", "LCI_OVER_NGPON2_Pre_Activation");
		mainValues.put("flowNodeStepName", "AddONT");
		subValues.put("order_number", "ICOG835708993");
		subValues.put("order_version", "000");
		subValues.put("product_type", "Data");
		subValues.put("supp_type", "1");
		subValues.put("region", "NJ");
		mainValues.put("seedInfo", subValues);
		Map<String, Object> requestDoc = new HashMap<>();
		requestDoc.put("requestPayload", mainValues);
		Map<String, Object> applicationParam = new HashMap<>();
		applicationParam.put("VNM_RESPONSE_URL", "http://woody.ebiz.verizon.com:8003/ods/ODSResponseProxy");
		applicationParam.put("VNM_PASSWORD", "ivapp");
		applicationParam.put("VNM_TIMEOUT", "60000");
		applicationParam.put("supp_type", "IVAPP");
		requestDoc.put("ApplicationParam", applicationParam);
		requestDoc.put("transactionId", 510);

		JSONObject addONT = new JSONObject();
		addONT.put("status", "V0000");
		JSONObject planningMsgRsp = new JSONObject();
		planningMsgRsp.put("PlanningMsgRsp", new JSONObject().put("AddONT", addONT));
		JSONObject documentPayload = new JSONObject();
		documentPayload.put("document-payload", planningMsgRsp);
		requestDoc.put("PlanningMessage", documentPayload);
		JSONObject requestJson = new JSONObject(requestDoc);
		LOGGER.info("getRequestDocument ::::" + requestJson.toString());
		return requestJson.toString();
	}

	public String getReqDocument() {
		String reqDoc = "{\"PlanningMessage\":{\"document-payload\":{\"PlanningMsgRsp\":{\"AeId\":\"ae12\",\"InvSystem\":\"IVAPP\",\"ActivationInfo\""
				+ ":{\"PonDetails\":{\"PonId\":\"00000000000000000000000001010111\",\"PonSystemId\":\"00000000000100001001\",\"ChannelPartitionIndex\""
				+ ":\"0010\",\"ServiceType\":\"DATA\",\"BackupPonId\""
				+ ":\"00000000000000110010000100010111\",\"PonType\":\"NGPON2\"}},\"LogicalId\":\"0660014\",\"RouterName\":\"E320\",\"AssignmentReuse\":\"NO\",\"PreActRequired\":\"YES\","
				+ "\"OrderNumber\":\"CCOG639221728\",\"OrderId\":706514,\"VersionNumber\":\"001\",\"SlipEnableFlag\":\"YES\",\"xmlns\":\"\",\"SubscriptionId\""
				+ ":\"ae12:66-14@NYCMNYWART1\",\"IpAddress\":\"34.45.67.89\",\"ReconnectONTDel\":\"NO\",\"OdnData\":{\"MDU_SIP_ALTL\":\"NO\",\"CTID\":"
				+ "\"70/VAXA/706514/ /VZNY\",\"IvappPonCircuitName\":\"S/GRCYNYGCT01/1-1-9-1\",\"DataVlan\":{\"STag\":66,\"CircuitName\":\"test\",\"CTag\":14},\"PvcNniChange\""
				+ ":\"YES\",\"IspPvcCircuitId\":\"70/VAXA/706514/ /VZNY\",\"IvappPonCircuitId\":103792,\"MocaProvisioned\":\"N\",\"ReplacementPortNumber\":\"\","
				+ "\"SvcPortNumber\":1,\"ServiceTNDetails\":{\"SwitchClli\":\"\",\"PrimaryLecTN\":\"\"}},\"RouterCilli\":\"NYCMNYWART1\",\"PonCircuit\""
				+ ":{\"DistHub\":{\"DistributionFiber\":{\"StrandNumber\":2,\"Name\":\"H8989\"},\"HubPortNumber\":2,\"Splitter\":{\"PortNumber\":1,\"Name\":"
				+ "\"H8989A\"},\"XConnectAction\":\"Make\",\"GpsParams\":{\"Latitude\":26.154106,\"Longitude\":-93.129155},\"Name\":\"H8989\",\"AddressInfo\":\"HOME\"},"
				+ "\"Ont\":{\"PAIndicator\":\"Compatible\",\"ManufacturerName\":\"ALTL\",\"DesktopModel\":\"Y\",\"Address\":{\"HouseNo\":620,\"StreetName\":\"NOTTINGHAM\","
				+ "\"TuName\":\"SYRACUSE\",\"Zip\":13224,\"Type\":\"RD\",\"SubLocation\":\"FLR GRD\",\"State\":\"NY\",\"MduSfu\":0,"
				+ "\"AddressId\":48053419},\"MocaCapable\":\"Y\",\"Make\":\"ALTL\",\"GpsParams\":{\"Latitude\":\"\",\"Longitude\":\"\"},\"EthernetSpeed\":\"N\",\"RequiredAction\":\"Install\","
				+ "\"Name\":\"GRCYNYGCT01SFU020101\",\"Type\":\"SFU\",\"SequenceNumber\":1,\"Model\":\"O-211M-E\",\"InactiveONT\":\"N\"},"
				+ "\"Olt\":{\"FeederFiber\":{\"StrandNumber\":1,\"Name\":\"F8989\"},\"SlotId\":1,\"Rack\":1,\"Group\":183433,\"ManufacturerName\":\"ALTL\","
				+ "\"Clli\":\"GRNKNYGNRCH\",\"OltPortNumber\":9,\"EmsId\":\"\",\"ShelfId\":1,\"OltTid\":\"TMPAFLERICERICE907\",\"Name\":\"ALTL-ONT211M\"},\"FiberJackCapable\""
				+ ":\"N\",\"DropTerminal\":{\"RELATED_ADDR_ID\":[90213,90132,90134,90135,189459,90214,90212,90215,237267,237232,237233,156737,189460,189461,90133,90153,143599,237268,189440],\"ConnectorType\":"
				+ "\"SC/APC\",\"DropAction\":\"TERMINATE\",\"GpsParams\":{\"Latitude\":26.154476,\"Longitude\":-93.128649},\"DropStatus\":\"TERMINATED\",\"DropType\":\"MDU_INSIDE\","
				+ "\"PortNumber\":2,\"Name\":102853,\"AddressInfo\":\"HOME\"},\"IvappPonCircuitId\":103792,\"PonCircuitName\":\"S/GRCYNYGCT01/1-1-9-1\",\"FiberDrop\":{\"StrandNumber\":2}}}}}} ";
		return reqDoc;
	}

}
