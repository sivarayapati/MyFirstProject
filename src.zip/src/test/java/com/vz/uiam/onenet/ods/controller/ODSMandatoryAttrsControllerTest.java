package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class ODSMandatoryAttrsControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSMandatoryAttrsControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	ODSMandatoryAttrsController odsMandatoryAttrsController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	/**
	 * 
	 */
	@Test
	public void testcreateOrUpdateOdsMandatoryAttrs() {
		try {
			LOGGER.info("****************************Entering to testcreateOrUpdateOdsMandatoryAttrs*****************************");
			URI url = new URI("/oneDispatcher/odsMandatoryAttrs/createOrUpdate");
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			odsMandatoryAttributes.setAttrKey("Test-Key");
			odsMandatoryAttributes.setJsonPath("$.TestJosn.Test");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMandatoryAttributes)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testcreateOrUpdateOdsMandatoryAttrs*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsMandatoryAttrs: ", e);
		}
	}
	@Test
	public void testcreateOrUpdateOdsMandatoryAttrs1() {
		try {
			LOGGER.info("****************************Entering to testcreateOrUpdateOdsMandatoryAttrs1*****************************");
			URI url = new URI("/oneDispatcher/odsMandatoryAttrs/createOrUpdate");
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMandatoryAttributes)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testcreateOrUpdateOdsMandatoryAttrs1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsMandatoryAttrs: ", e);
		}
	}
	@Test
	public void testcreateOrUpdateOdsMandatoryAttrs2() {
		try {
			LOGGER.info("****************************Entering to testcreateOrUpdateOdsMandatoryAttrs2*****************************");
			URI url = new URI("/oneDispatcher/odsMandatoryAttrs/createOrUpdate");
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			odsMandatoryAttributes.setValidationId(1000);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMandatoryAttributes)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testcreateOrUpdateOdsMandatoryAttrs2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsMandatoryAttrs: ", e);
		}
	}
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_mandatory_attrs_table.sql")
		})
	public void testcreateOrUpdateOdsMandatoryAttrs3() {
		try {
			LOGGER.info("****************************Entering to testcreateOrUpdateOdsMandatoryAttrs3*****************************");
			URI url = new URI("/oneDispatcher/odsMandatoryAttrs/createOrUpdate");
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			odsMandatoryAttributes.setAttrKey("Test-ODS");
			odsMandatoryAttributes.setJsonPath("$.TestJosn.Test");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMandatoryAttributes)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsMandatoryAttributes odsMandatoryAttribute = new OdsMandatoryAttributes();
			odsMandatoryAttribute.setAttrKey("Test-ODS-UPDATE");
			odsMandatoryAttribute.setJsonPath("$.TestJosn.Test");
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMandatoryAttribute)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			OdsMandatoryAttributes odsMandatoryAttribute1 = new OdsMandatoryAttributes();
			odsMandatoryAttribute1.setValidationId(100);
			odsMandatoryAttribute1.setAttrKey("Test-ODS");
			odsMandatoryAttribute1.setJsonPath("$.TestJosn.Test");
			MvcResult result2 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMandatoryAttribute1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result2 : " + result2.getResponse().getContentAsString());
		
			
			
			LOGGER.info("****************************Exiting from testcreateOrUpdateOdsMandatoryAttrs3*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsMandatoryAttrs: ", e);
		}
	}
	@Test
	public void testcreateOrUpdateOdsMandatoryAttrs4() {
		try {
			LOGGER.info("****************************Entering to testcreateOrUpdateOdsMandatoryAttrs4*****************************");
			URI url = new URI("/oneDispatcher/odsMandatoryAttrs/createOrUpdate");
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			odsMandatoryAttributes.setAttrKey("");
			odsMandatoryAttributes.setJsonPath("$.TestJosn.Test");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMandatoryAttributes)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsMandatoryAttributes odsMandatoryAttributes1 = new OdsMandatoryAttributes();
			odsMandatoryAttributes1.setAttrKey("Test-ODS");
			odsMandatoryAttributes1.setJsonPath("");
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMandatoryAttributes1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
		
			
			LOGGER.info("****************************Exiting from testcreateOrUpdateOdsMandatoryAttrs4*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateOdsMandatoryAttrs: ", e);
		}
	}
	@Test
	public void testGetOdsMandatoryAttrs() {
		try {
			LOGGER.info("****************************Entering to testGetOdsMandatoryAttrs*****************************");
			URI url = new URI("/oneDispatcher/odsMandatoryAttrs/get");
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			odsMandatoryAttributes.setAttrKey("Test-Key");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMandatoryAttributes)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetOdsMandatoryAttrs*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsMandatoryAttrs: ", e);
		}
	}
	@Test
	public void testGetOdsMandatoryAttrs1() {
		try {
			LOGGER.info("****************************Entering to testGetOdsMandatoryAttrs1*****************************");
			URI url = new URI("/oneDispatcher/odsMandatoryAttrs/get");
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			odsMandatoryAttributes.setAttrKey("Test-Key-Key");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsMandatoryAttributes)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetOdsMandatoryAttrs1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsMandatoryAttrs: ",e);
		}
	}
	@Test
	public void testDeleteOdsMandatoryAttrs() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsMandatoryAttrs*****************************");
			URI url = new URI("/oneDispatcher/odsMandatoryAttrs/delete");
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			odsMandatoryAttributes.setAttrKey("Test-Key");
			odsMandatoryAttributes.setJsonPath("$.TestJosn.Test");
			List<OdsMandatoryAttributes> attrList= new ArrayList<>();
			attrList.add(odsMandatoryAttributes);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteOdsMandatoryAttrs*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsMandatoryAttrs: ",e);
		}
	}
	@Test
	public void testDeleteOdsMandatoryAttrs1() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsMandatoryAttrs1*****************************");
			URI url = new URI("/oneDispatcher/odsMandatoryAttrs/delete");
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			odsMandatoryAttributes.setAttrKey("Test-Key-Key");
			List<OdsMandatoryAttributes> attrList= new ArrayList<>();
			attrList.add(odsMandatoryAttributes);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteOdsMandatoryAttrs1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsMandatoryAttrs: ",e);
		}
	}
	@Test
	public void testDeleteOdsMandatoryAttrs2() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsMandatoryAttrs2*****************************");
			URI url = new URI("/oneDispatcher/odsMandatoryAttrs/delete");
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			odsMandatoryAttributes.setAttrKey("Test-ODS");
			odsMandatoryAttributes.setJsonPath("$.TestJosn.Test");
			
			List<OdsMandatoryAttributes> attrList= new ArrayList<>();
			attrList.add(odsMandatoryAttributes);
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsMandatoryAttributes odsMandatoryAttribute = new OdsMandatoryAttributes();
			odsMandatoryAttribute.setAttrKey("Test-ODS-UPDATE");
			odsMandatoryAttribute.setJsonPath("$.TestJosn.Test");
		
			List<OdsMandatoryAttributes> attrList1= new ArrayList<>();
			attrList1.add(odsMandatoryAttributes);
			attrList1.add(odsMandatoryAttribute);
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			OdsMandatoryAttributes odsMandatoryAttribute2 = new OdsMandatoryAttributes();
			odsMandatoryAttribute2.setAttrKey("");
			odsMandatoryAttribute2.setJsonPath("");
		
			List<OdsMandatoryAttributes> attrList2= new ArrayList<>();
			attrList2.add(odsMandatoryAttributes);
			attrList2.add(odsMandatoryAttribute);
			MvcResult result2= this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList2)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result2.getResponse().getContentAsString());
			
	
			
			LOGGER.info("****************************Exiting from testDeleteOdsMandatoryAttrs2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsMandatoryAttrs: ",e);
		}
	}
	
	@Test
	public void testDeleteOdsMandatoryAttrs3() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsMandatoryAttrs3*****************************");
			URI url = new URI("/oneDispatcher/odsMandatoryAttrs/delete");
			OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
			odsMandatoryAttributes.setValidationId(100);
			odsMandatoryAttributes.setAttrKey("Test-ODS");
			odsMandatoryAttributes.setJsonPath("$.TestJosn.Test");
			
			List<OdsMandatoryAttributes> attrList= new ArrayList<>();
			attrList.add(odsMandatoryAttributes);
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsMandatoryAttributes odsMandatoryAttributes1 = new OdsMandatoryAttributes();
			odsMandatoryAttributes1.setAttrKey("Test-ODS");
						
			List<OdsMandatoryAttributes> attrList1= new ArrayList<>();
			attrList1.add(odsMandatoryAttributes1);
			
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			
			LOGGER.info("****************************Exiting from testDeleteOdsMandatoryAttrs3*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsMandatoryAttrs: ",e);
		}
	}
	
	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}
	
	

}
