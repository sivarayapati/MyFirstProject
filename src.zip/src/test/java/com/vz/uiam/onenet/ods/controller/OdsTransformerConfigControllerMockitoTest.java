package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsTransformerConfig;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsTransformerConfigDto;
import com.vz.uiam.onenet.ods.service.OdsTransformerConfigService;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class OdsTransformerConfigControllerMockitoTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(OdsTransformerConfigControllerMockitoTest.class);

	@InjectMocks
	OdsTransformerConfigController odsTransformerConfigController;

	@Mock
	OdsTransformerConfigService odsTransformerConfigService;

	@Mock
	ServiceUtils serviceUtils;

	/**
	 * @throws ApplicationException
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testTransform() throws ApplicationException {

		LOGGER.info("****************************Entering to testTransform*****************************");

		OdsTransformerConfigDto odsTransformerConfigDto = new OdsTransformerConfigDto();
		odsTransformerConfigDto.setTransformerKey("TEST_CONFIG");
		odsTransformerConfigDto.setTransformerType("JSON");
		odsTransformerConfigDto.setRequestDocument(getTransformRequest());

		when(odsTransformerConfigService.tranformDocument(odsTransformerConfigDto)).thenThrow(SQLException.class);
		odsTransformerConfigController.transform(odsTransformerConfigDto);
		LOGGER.info("****************************Exiting from testTransform*****************************");

	}

	@Test
	public void testCreateOrUpdateOdsTransformerConfig() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testCreateOrUpdateOdsTransformerConfig*****************************");
		OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
		odsTransformerConfig.setTransformerKey("Test_Transformation121");
		odsTransformerConfig.setTransformerSchema(getTransformerShema());
		odsTransformerConfig.setTransformerType("JSON");
		OdsTransformerConfig odsTransformerConfigResp = null;
		when(odsTransformerConfigService.createOrUpdateOdsTransformerConfig(odsTransformerConfig))
				.thenReturn(odsTransformerConfigResp);
		odsTransformerConfigController.createOrUpdateOdsTransformerConfig(odsTransformerConfig);
		LOGGER.info(
				"****************************Exiting from testCreateOrUpdateOdsTransformerConfig*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testCreateOrUpdateOdsTransformerConfig1() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testCreateOrUpdateOdsTransformerConfig1*****************************");
		OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
		odsTransformerConfig.setTransformerKey("Test_Transformation121");
		odsTransformerConfig.setTransformerSchema(getTransformerShema());
		odsTransformerConfig.setTransformerType("JSON");

		when(odsTransformerConfigService.createOrUpdateOdsTransformerConfig(odsTransformerConfig))
				.thenThrow(SQLException.class);
		odsTransformerConfigController.createOrUpdateOdsTransformerConfig(odsTransformerConfig);
		LOGGER.info(
				"****************************Exiting from testCreateOrUpdateOdsTransformerConfig1*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetOdsTransformerConfig() throws ApplicationException {

		LOGGER.info("****************************Entering to gtOdsTransformerConfig()*****************************");

		OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
		odsTransformerConfig.setOdsTransformerId(9499899);
		when(odsTransformerConfigService.getOdsTransformerConfig(odsTransformerConfig.getTransformerKey()))
				.thenThrow(ApplicationException.class);
		odsTransformerConfigController.getOdsTransformerConfig(odsTransformerConfig);
		LOGGER.info("****************************gtOdsTransformerConfig()*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetOdsTransformerConfig1() throws ApplicationException {

		LOGGER.info("****************************Entering to gtOdsTransformerConfig()1*****************************");

		OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
		odsTransformerConfig.setOdsTransformerId(9499899);
		when(odsTransformerConfigService.getOdsTransformerConfig(odsTransformerConfig.getTransformerKey()))
				.thenThrow(SQLException.class);
		odsTransformerConfigController.getOdsTransformerConfig(odsTransformerConfig);
		LOGGER.info("****************************gtOdsTransformerConfig()1*****************************");

	}

	@Test

	public void deleteOdsTransformerConfig() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to deleteOdsTransformerConfig()*****************************");

		OdsTransformerConfig odsTransformerConfig = new OdsTransformerConfig();
		odsTransformerConfig.setOdsTransformerId(9499899);
		Mockito.doThrow(NullPointerException.class).when(odsTransformerConfigService)
				.deleteOdsTransformerConfigRecord(odsTransformerConfig);
		odsTransformerConfigController.deleteOdsTransformerConfig(odsTransformerConfig);
		LOGGER.info("****************************deleteOdsTransformerConfig()*****************************");

	}

	public String getTransformRequest() {
		Map<String, Object> mainValues = new HashMap<>();
		Map<String, Object> subValues = new HashMap<>();
		mainValues.put("app-key", "ZZZDE-NGPON2");
		mainValues.put("processInstanceId", "34567");
		mainValues.put("parentProcessInstanceId", "45678");
		mainValues.put("rootProcessInstanceId", "56789");
		mainValues.put("flowNodeProcessName", "LCI_OVER_NGPON2_Pre_Activation");
		mainValues.put("flowNodeStepName", "AddONT");
		subValues.put("order_number", "ICOG835708993");
		subValues.put("order_version", "000");
		subValues.put("product_type", "Data");
		subValues.put("supp_type", "1");
		subValues.put("region", "NJ");
		mainValues.put("seedInfo", subValues);

		JSONObject requestJson = new JSONObject(mainValues);
		LOGGER.info("getTransformRequest ::::" + requestJson.toString());
		return requestJson.toString();

	}

	private String getTransformerShema() {

		String schema = "{\"externalTaskId\": \"$.externalTaskId\", \"task\": { \"title\": \"$.title\"}, \"taskAttributes\":"
				+ " { \"attribute\": [{ \"Name\": \"CASE_ID\", \"Value\": \"$.caseId\" }, { \"Name\": \"STEP_NAME\", \"Value\": "
				+ "\"$.stepName\" }, { \"Name\": \"ERROR_CODE\", \"Value\": \"$.errorCode\" }, { \"Name\": \"PROCESS_NAME\", "
				+ "\"Value\": \"$.processName\" }] }, \"taskHeader\": { \"orderInfo\": { \"orderSource\": \"$.orderSource\", "
				+ "\"lineOfBusiness\": \"$.lineOfBusiness\" }, \"taskSource\": \"$.taskSource\", \"userId\": \"walter.bates\" },"
				+ " \"createDate\": \"2016-10-06T04:26:51\"}";
		return schema;
	}
}
