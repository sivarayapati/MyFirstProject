package com.vz.uiam.onenet.ods.service;

import static org.mockito.Mockito.when;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.mysema.query.jpa.impl.JPAQuery;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsResponseTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.QOdsRequestTransactionIdMap;

@RunWith(MockitoJUnitRunner.class)
public class OdsRequestResponseTransactionIdMapServiceTest {

	private static final Logger LOGGER = Logger.getLogger(OdsRequestResponseTransactionIdMapServiceTest.class);
	
	@InjectMocks
	OdsRequestResponseTransactionIdMapService odsReqRspTransIdMapSvc;
	
	
	@Test
	public void testGetUpdatedOdsRequestTransactionIdMapRecord1() throws ApplicationException {
		LOGGER.info("Entering testGetUpdatedOdsRequestTransactionIdMapRecord1");
		
		OdsRequestTransactionIdMap inputOdsRequest = new OdsRequestTransactionIdMap();
		inputOdsRequest.setFlowNodeProcessName("Testing_Process");
		inputOdsRequest.setFlowNodeStepName("Testing_Step");
		inputOdsRequest.setTransactionIdKey("aaa_bbb");
		
		odsReqRspTransIdMapSvc.getUpdatedOdsRequestTransactionIdMapRecord(inputOdsRequest, new OdsRequestTransactionIdMap());
		
		LOGGER.info("Entering testGetUpdatedOdsRequestTransactionIdMapRecord1");
	}
	
	@Test(expected = ApplicationException.class)
	public void testGetOdsRequestTransIdMapRecords() throws ApplicationException {
		LOGGER.info("Entering testGetOdsRequestTransIdMapRecords");
		
		OdsRequestTransactionIdMap inputOdsRequest = new OdsRequestTransactionIdMap();
		inputOdsRequest.setFlowNodeProcessName("Testing_Process");
		inputOdsRequest.setFlowNodeStepName("Testing_Step");
		inputOdsRequest.setTransactionIdKey("aaa_bbb");
		
		JPAQuery jpaQuery = Mockito.mock(JPAQuery.class);
		
		OdsRequestResponseTransactionIdMapService odsReqRspTransIdMapSvcSpy = Mockito.spy(odsReqRspTransIdMapSvc);
		Mockito.doReturn(jpaQuery).when(odsReqRspTransIdMapSvcSpy).getJPAQryInstance();
		when(jpaQuery.list(Mockito.any(QOdsRequestTransactionIdMap.class))).thenThrow(Exception.class);
		
		odsReqRspTransIdMapSvcSpy.getOdsRequestTransIdMapRecords(inputOdsRequest);
		
		LOGGER.info("Entering testGetOdsRequestTransIdMapRecords");
	}
	
	@Test(expected = ApplicationException.class)
	public void testGetOdsResponseTransIdMapRecords() throws ApplicationException {
		LOGGER.info("Entering testGetOdsResponseTransIdMapRecords");

		JPAQuery jpaQuery = Mockito.mock(JPAQuery.class);
		
		OdsRequestResponseTransactionIdMapService odsReqRspTransIdMapSvcSpy = Mockito.spy(odsReqRspTransIdMapSvc);
		Mockito.doReturn(jpaQuery).when(odsReqRspTransIdMapSvcSpy).getJPAQryInstance();
		when(jpaQuery.list(Mockito.any(QOdsRequestTransactionIdMap.class))).thenThrow(Exception.class);
		
		odsReqRspTransIdMapSvcSpy.getOdsResponseTransIdMapRecords(new OdsResponseTransactionIdMap());
		
		LOGGER.info("Entering testGetOdsResponseTransIdMapRecords");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoOdsResponseTIdMapValidation1() throws ApplicationException {
		LOGGER.info("Entering testDoOdsResponseTIdMapValidation1");
		
		OdsResponseTransactionIdMap odsResponseTransactionIdMap = new OdsResponseTransactionIdMap();
		
		odsReqRspTransIdMapSvc.doOdsResponseTIdMapValidation(odsResponseTransactionIdMap);
		
		LOGGER.info("Entering testDoOdsResponseTIdMapValidation1");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoOdsResponseTIdMapValidation2() throws ApplicationException {
		LOGGER.info("Entering testDoOdsResponseTIdMapValidation2");
		
		OdsResponseTransactionIdMap odsResponseTransactionIdMap = new OdsResponseTransactionIdMap();
		odsResponseTransactionIdMap.setRootTagName("nbaTransaction");
		
		odsReqRspTransIdMapSvc.doOdsResponseTIdMapValidation(odsResponseTransactionIdMap);
		
		LOGGER.info("Entering testDoOdsResponseTIdMapValidation2");
	}
}
