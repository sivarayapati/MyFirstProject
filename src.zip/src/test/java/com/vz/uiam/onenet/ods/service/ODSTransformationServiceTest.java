package com.vz.uiam.onenet.ods.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.context.ApplicationContext;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformRequest;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class ODSTransformationServiceTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ODSTransformationServiceTest.class);

	@InjectMocks
	ODSTransformationService odsTransformationService;

	@Mock
	ServiceUtils serviceUtils;

	@Mock
	OdsParamConfigRepository odsParamConfigRepository;

	@Mock
	ApplicationContext appcontext;

	
	@Test(expected=NullPointerException.class)
	public void testDoTransformation1() throws ApplicationException {
		LOGGER.info("Entering testDoTransformation1");

		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setInputDocument("{\"document-payload\":{\"TransactionID\":\"123\",\"requestPayLaod\":{}}}");
		transformRequest.setTransformationType(Constants.TRANSFORMATION_XML_TYPE);
		transformRequest.setRequestSchema("{\"ApplicationParam\":{}}");
    
		odsTransformationService.doTransformation(transformRequest);

		LOGGER.info("Exiting testDoTransformation1");
	}

	
	@Test(expected=NullPointerException.class)
	public void testDoTransformation2() throws ApplicationException {
		LOGGER.info("Entering testDoTransformation2");

		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setInputDocument("{\"document-payload\":{\"TransactionID\":\"123\",\"requestPayLaod\":{}}}");
		transformRequest.setTransformationType(Constants.TRANSFORMATION_JSON_TYPE);
		transformRequest.setRequestSchema("{\"ApplicationParam\":{}}");
    
		odsTransformationService.doTransformation(transformRequest);

		LOGGER.info("Exiting testDoTransformation2");
	}

	@Test(expected=ApplicationException.class)
	public void testDoTransformation3() throws ApplicationException {
		LOGGER.info("Entering testDoTransformation3");

		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setInputDocument("{\"document-payload\":{\"TransactionID\":\"123\",\"requestPayLaod\":{}}}");
		transformRequest.setTransformationType("");
		transformRequest.setRequestSchema("{\"ApplicationParam\":{}}");
    
		odsTransformationService.doTransformation(transformRequest);

		LOGGER.info("Exiting testDoTransformation3");
	}
	
	@Test(expected=ApplicationException.class)
	public void testUpdateRequestJsonObjectWithAppParams() throws ApplicationException {
		LOGGER.info("Entering testUpdateRequestJsonObjectWithAppParams");

		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setInputDocument("{\"document-payload\":{\"TransactionID\":\"123\",\"requestPayLaod\":{}}}");
		transformRequest.setTransformationType(Constants.TRANSFORMATION_JSON_TYPE);
		transformRequest.setRequestSchema(getfinaldocument());
		
		odsTransformationService.doTransformation(transformRequest);

		LOGGER.info("Exiting testUpdateRequestJsonObjectWithAppParams");
	}
	@Test(expected=NullPointerException.class)
	public void testUpdateRequestJsonObjectWithAppParams1() throws ApplicationException {
		LOGGER.info("Entering testUpdateRequestJsonObjectWithAppParams1");
		List<OdsParamConfig> odsParamConfigList = new ArrayList<OdsParamConfig>();
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("Resp_Doc");
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setName("Test");
		odsParamConfigList.add(odsParamConfig);
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setInputDocument("{\"document-payload\":{\"TransactionID\":\"123\",\"requestPayLaod\":{}}}");
		transformRequest.setTransformationType(Constants.TRANSFORMATION_JSON_TYPE);
		transformRequest.setRequestSchema(getfinaldocument());
		Mockito.doReturn(odsParamConfigList).when(odsParamConfigRepository).findByParamKeyAndTypeAndNameIn(Mockito.anyString(),Mockito.anyString(), Mockito.anyListOf(String.class));
		odsTransformationService.doTransformation(transformRequest);

		LOGGER.info("Exiting testUpdateRequestJsonObjectWithAppParams1");
	}
	@Test(expected=NullPointerException.class)
	public void testUpdateRequestJsonObjectWithSchemaDefinedParams() throws ApplicationException {
		LOGGER.info("Entering testUpdateRequestJsonObjectWithSchemaDefinedParams");
		List<OdsParamConfig> odsParamConfigList = new ArrayList<OdsParamConfig>();
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("Resp_Doc");
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setName("Test");
		odsParamConfigList.add(odsParamConfig);
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setInputDocument("{\"document-payload\":{\"TransactionID\":\"123\",\"requestPayLaod\":{}}}");
		transformRequest.setTransformationType(Constants.TRANSFORMATION_JSON_TYPE);
		transformRequest.setRequestSchema(getfinaldocument());
		Mockito.doReturn(odsParamConfigList).when(odsParamConfigRepository).findByParamKeyAndTypeAndNameIn(Mockito.anyString(),Mockito.anyString(), Mockito.anyListOf(String.class));
		odsTransformationService.doTransformation(transformRequest);

		LOGGER.info("Exiting testUpdateRequestJsonObjectWithSchemaDefinedParams");
	}
	@Test(expected=NullPointerException.class)
	public void testUpdateRequestJsonObjectWithSchemaDefinedParams1() throws ApplicationException {
		LOGGER.info("Entering testUpdateRequestJsonObjectWithSchemaDefinedParams1");
		List<OdsParamConfig> odsParamConfigList = new ArrayList<OdsParamConfig>();
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("Resp_Doc");
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setName("Test");
		odsParamConfigList.add(odsParamConfig);
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setInputDocument("{\"document-payload\":{\"TransactionID\":\"123\",\"requestPayLaod\":{}}}");
		transformRequest.setTransformationType(Constants.TRANSFORMATION_JSON_TYPE);
		transformRequest.setRequestSchema("#define ZeroTimestamp=\"fn-concat(:,00,00,00)\";\r\n" + 
				"   {\r\n" + 
				"      \"dueDate\": \"fn-concat( ,$.order.document-payload.serviceOrder.serviceOrderHeader.dueDate,$.SchemaDefinedParam.ZeroTimestamp)\"\r\n" + 
				"   \r\n" + 
				" }");
		Mockito.doReturn(odsParamConfigList).when(odsParamConfigRepository).findByParamKeyAndTypeAndNameIn(Mockito.anyString(),Mockito.anyString(), Mockito.anyListOf(String.class));
		odsTransformationService.doTransformation(transformRequest);

		LOGGER.info("Exiting testUpdateRequestJsonObjectWithSchemaDefinedParams1");
	}
	@Test(expected=NullPointerException.class)
	public void testUpdateRequestJsonObjectWithConditionalDefinitions() throws ApplicationException {
		LOGGER.info("Entering testUpdateRequestJsonObjectWithConditionalDefinitions");
		List<OdsParamConfig> odsParamConfigList = new ArrayList<OdsParamConfig>();
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("Resp_Doc");
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setName("Test");
		odsParamConfigList.add(odsParamConfig);
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setInputDocument("{\"document-payload\":{\"TransactionID\":\"123\",\"requestPayLaod\":{}}}");
		transformRequest.setTransformationType(Constants.TRANSFORMATION_JSON_TYPE);
		transformRequest.setRequestSchema("#if $.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.STATE = FL #then #define HOUSE_STREET=fn-concat( ,$.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.HOUSE, $.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.STREET);  #if $.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.ZIP = 33602 #then #define HOUSE_STREET=fn-concat(, ,$.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.HOUSE, $.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.STREET);#endif  {\"siteName\": \"fn-concat(,,$.SchemaDefinedParam.HOUSE_STREET,  $.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.CITY,  $.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.STATE,$.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.ZIP)\",\"street\":\"fn-substring($.order.document-payload.AddOrder.ADDRESS_GROUP.SERVICE_ADDRESS.STREET,0,7)\",\"dueDate\":\"fn-formatdate($.order.document-payload.AddOrder.ORDER_HEADER.DUE_DATE,YYYY-MM-DD,YYYY-MM-DD'T'HH:mm:ss,GMT)\",\"name\":\"fn-substring($.order.document-payload.AddOrder.ORDER_HEADER.Attribute.Attribute[0].Name,0,8)\",\"name1\":\"fn-substring-before($.order.document-payload.AddOrder.ORDER_HEADER.Attribute.Attribute[0].Name,_)\",\"name2\":\"fn-substring-after($.order.document-payload.AddOrder.ORDER_HEADER.Attribute.Attribute[0].Name,_)\"}");
		Mockito.doReturn(odsParamConfigList).when(odsParamConfigRepository).findByParamKeyAndTypeAndNameIn(Mockito.anyString(),Mockito.anyString(), Mockito.anyListOf(String.class));
		when(serviceUtils.getJsonSchemaValue(Mockito.anyString(),Mockito.anyString())).thenReturn("");
		odsTransformationService.doTransformation(transformRequest);

		LOGGER.info("Exiting testUpdateRequestJsonObjectWithConditionalDefinitions");
	}

	public String getfinaldocument() {
		return " {\"requestPayload\":{\"processInstanceId\":\"34567\",\"serviceUrl\":\"https://vnmws.ebiz.verizon.com\",\"seedInfo\":{\"product_type\":\"Data\",\"supp_type\":\"Pending\",\"order_number\":\"CCOG639221728\",\"region\":\"NJ\","
				+ "\"order_version\":\"001\"},\"app-key\":\"ZZZDE-NGPON2\",\"rootProcessInstanceId\":\"56789\",\"activityInstanceId\":\"7654\",\"parentProcessInstanceId\":\"45678\",\"flowNodeProcessName\":\"LCI_OVER_NGPON2_Pre_Activation\","
				+ "\"rootProcessName\":\"Root\",\"flowNodeStepName\":\"RetrieveONTSerialNumber\"},\"transactionId\":\"1511938969413|34567|7654\",\"PlanningMessage\":{\"document-payload\":{\"PlanningMsgRsp\":{\"InvSystem\":\"IVAPP\",\"ActivationInfo\":{\"PonDetails\":{\"PonId\":\"00000000000000000000000001010111\","
				+ "\"PonSystemId\":\"00000000000100001001\",\"ChannelPartitionIndex\":\"0010\",\"ServiceType\":\"DATA\",\"BackupPonId\":\"00000000000000110010000100010111\",\"PonType\":\"NGPON2\"}},"
				+ "\"AssignmentReuse\":\"NO\",\"PreActRequired\":\"YES\",\"OrderNumber\":\"CCOGSSPDISCOTEST19\",\"OrderId\":706514,\"VersionNumber\":\"000\",\"xmlns\":\"\",\"SubscriptionId\":\":-1--1@NYCMNYWART1\","
				+ "\"ReconnectONTDel\":\"NO\",\"OdnData\":{\"MDU_SIP_ALTL\":\"NO\",\"CTID\":\"70/VAXA/706514/ /VZNY\",\"IvappPonCircuitName\":\"S/GRCYNYGCT01/1-1-9-1\",\"DataVlan\":{\"STag\":1024,"
				+ "\"CircuitName\":\"test\",\"CTag\":4095},\"PvcNniChange\":\"YES\",\"IspPvcCircuitId\":\"70/VAXA/706514/ /VZNY\",\"IvappPonCircuitId\":103792,\"MocaProvisioned\":\"N\",\"IvappSecondaryPonCircuitName\":\"S/GRCYNYGCT01/7-25-2-1\","
				+ "\"ReplacementPortNumber\":\"\",\"SvcPortNumber\":1,\"ServiceTNDetails\":{\"SwitchClli\":\"\",\"PrimaryLecTN\":\"\"}},\"RouterCilli\":\"NYCMNYWART1\",\"PonCircuit\":{\"DistHub\":{\"DistributionFiber\":{\"StrandNumber\":2,"
				+ "\"Name\":\"H8989\"},\"HubPortNumber\":2,\"Splitter\":{\"PortNumber\":1,\"Name\":\"H8989A\"},\"XConnectAction\":\"Make\",\"GpsParams\":{\"Latitude\":26.154106,\"Longitude\":-93.129155},\"Name\":\"H8989\",\"AddressInfo\":\"HOME\"},\"Ont\":{\"PAIndicator\":\"Compatible\",\"ManufacturerName\":\"ALTL\""
				+ ",\"DesktopModel\":\"Y\",\"Address\":{\"HouseNo\":620,\"StreetName\":\"NOTTINGHAM\",\"TuName\":\"SYRACUSE\",\"Zip\":13224,\"Type\":\"RD\",\"SubLocation\":\"FLR GRD\",\"State\":\"NY\",\"MduSfu\":0,\"AddressId\":48053419},\"MocaCapable\":\"Y\","
				+ "\"Make\":\"ALTL\",\"GpsParams\":{\"Latitude\":\"\",\"Longitude\":\"\"},\"EthernetSpeed\":\"N\",\"RequiredAction\":\"Install\",\"Type\":\"SFU\",\"SequenceNumber\":1,\"Model\":\"O-211M-E\",\"GponProvisioned\":\"Y\",\"InactiveONT\":\"N\"},"
				+ "\"Olt\":{\"FeederFiber\":{\"StrandNumber\":1,\"Name\":\"F8989\"},\"SlotId\":1,\"Rack\":1,\"ManufacturerName\":\"ALTL\",\"Clli\":\"GRNKNYGNRCH\",\"OltPortNumber\":9,\"EmsId\":\"\",\"ShelfId\":1,\"OltTid\":\"TMPAFLERICERICE907\",\"Name\":\"ALTL-ONT211M\"},"
				+ "\"FiberJackCapable\":\"N\",\"DropTerminal\":{\"RELATED_ADDR_ID\":[90213,90132,90134,90135,189459,90214,90212,90215,237267,237232,237233,156737,189460,189461,90133,90153,143599,237268,189440],\"ConnectorType\":\"SC/APC\",\"DropAction\":\"TERMINATE\",\"GpsParams\":{\"Latitude\":26.154476,\"Longitude\""
				+ ":-93.128649},\"DropStatus\":\"TERMINATED\",\"DropType\":\"MDU_INSIDE\","
				+ "\"PortNumber\":2,\"Name\":102853,\"AddressInfo\":\"HOME\"},\"IvappPonCircuitId\":103792,\"PonCircuitName\":\"S/GRCYNYGCT01/1-1-9-1\",\"FiberDrop\":{\"StrandNumber\":2}}}}},\"$.ApplicationParam.Test\" :{}}";
	}
}
