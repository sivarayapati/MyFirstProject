package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFalloutConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class ODSWorkFlowFalloutConfigControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSWorkFlowFalloutConfigControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	ODSWorkFlowFalloutConfigController odsWorkFlowFalloutConfigController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	/**
	 * 
	 */
	@Test
	public void testCreateOrUpdateWorkFlowFalloutConfig() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateWorkFlowFalloutConfig*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/createOrUpdate");
			WorkflowFalloutConfig config= new WorkflowFalloutConfig();
			config.setWorkflowProcessName("processName1");
			config.setWorkFlowStepName("stepName1");
			config.setMaxRetryCounter(30);
			config.setRetryInterval(5);
			config.setWorkFlowFalloutErrorCode("Error");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(config)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateWorkFlowFalloutConfig*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateWorkFlowFalloutConfig: ",e);
		}
	}
	@Test
	
	public void testCreateOrUpdateWorkFlowFalloutConfig1() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateWorkFlowFalloutConfig1*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/createOrUpdate");
			WorkflowFalloutConfig config= new WorkflowFalloutConfig();
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(config)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateWorkFlowFalloutConfig1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateWorkFlowFalloutConfig: ",e);
		}
	}
	@Test
	public void testCreateOrUpdateWorkFlowFalloutConfig2() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateWorkFlowFalloutConfig2*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/createOrUpdate");
			WorkflowFalloutConfig config= new WorkflowFalloutConfig();
			int id=1000;
			config.setId(id);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(config)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateWorkFlowFalloutConfig2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateWorkFlowFalloutConfig: ",e);
		}
	}
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_work_flow_fallout_config_table.sql")})
	public void testCreateOrUpdateWorkFlowFalloutConfig3() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateWorkFlowFalloutConfig3*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/createOrUpdate");
			WorkflowFalloutConfig config= new WorkflowFalloutConfig();
			config.setId(1000);
			config.setWorkFlowFalloutErrorCode("step1");
			config.setWorkflowProcessName("process123");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(config)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateWorkFlowFalloutConfig3*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateWorkFlowFalloutConfig: ",e);
		}
	}
	@Test
	public void testCreateOrUpdateWorkFlowFalloutConfig4() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateWorkFlowFalloutConfig4*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/createOrUpdate");
			WorkflowFalloutConfig config= new WorkflowFalloutConfig();
			config.setId(1000);
			config.setWorkflowProcessName("processName12");
			config.setWorkFlowStepName("");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(config)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			WorkflowFalloutConfig config1= new WorkflowFalloutConfig();
			config1.setWorkflowProcessName("");
			config1.setWorkFlowStepName("step1");
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(config1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
						
			LOGGER.info("****************************Exiting from testCreateOrUpdateWorkFlowFalloutConfig4*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateWorkFlowFalloutConfig: ",e);
		}
	}
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_work_flow_fallout_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_work_flow_fallout__config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_work_flow_fallout_config_table.sql")})
	public void testCreateOrUpdateWorkFlowFalloutConfig5() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateWorkFlowFalloutConfig5*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/createOrUpdate");
			WorkflowFalloutConfig config1= new WorkflowFalloutConfig();
			config1.setWorkflowProcessName("process123");
			config1.setWorkFlowStepName("step1");
			config1.setMaxRetryCounter(30);
			config1.setRetryInterval(2);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(config1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateWorkFlowFalloutConfig5*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateWorkFlowFalloutConfig: ",e);
		}
	}
	@Test
	public void testGetWorkFlowFalloutConfig() {
		try {
			LOGGER.info("****************************Entering to testGetWorkFlowFalloutConfig*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/get");
			WorkflowFalloutConfig config1= new WorkflowFalloutConfig();
			config1.setWorkflowProcessName("process123");
			config1.setWorkFlowStepName("step1");
			config1.setMaxRetryCounter(30);
			config1.setRetryInterval(2);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(config1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetWorkFlowFalloutConfig*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getWorkFlowFalloutConfig: ",e);
		}
	}
	@Test
	public void testGetWorkFlowFalloutConfig1() {
		try {
			LOGGER.info("****************************Entering to testGetWorkFlowFalloutConfig1*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/get");
			WorkflowFalloutConfig config1= new WorkflowFalloutConfig();
			config1.setWorkflowProcessName("process123");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(config1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetWorkFlowFalloutConfig1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getworkFlowFalloutConfig: ",e);
		}
	}
	@Test
	public void testGetWorkFlowFalloutConfig2() {
		try {
			LOGGER.info("****************************Entering to testGetWorkFlowFalloutConfig2*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/get");
			WorkflowFalloutConfig config1= new WorkflowFalloutConfig();
			config1.setWorkflowProcessName("");
			config1.setWorkFlowStepName("");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(config1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetworkFlowFalloutConfig2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getworkFlowFalloutConfig: ",e);
		}
	}
	
	@Test
	public void testDeleteWorkFlowFalloutConfig() {
		try {
			LOGGER.info("****************************Entering to testDeleteWorkFlowFalloutConfig*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/delete");
			WorkflowFalloutConfig config1= new WorkflowFalloutConfig();
			config1.setWorkflowProcessName("process123");
			config1.setWorkFlowStepName("step1");
			
			List<WorkflowFalloutConfig> attrList= new ArrayList<>();
			attrList.add(config1);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			
			LOGGER.info("****************************Exiting from testDeleteWorkFlowFalloutConfig*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteWorkFlowFalloutConfig: ",e);
		}
	}
	@Test
	public void testDeleteWorkFlowFalloutConfig1() {
		try {
			LOGGER.info("****************************Entering to testDeleteWorkFlowFalloutConfig1*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/delete");
			WorkflowFalloutConfig config1= new WorkflowFalloutConfig();
			config1.setId(0);
			List<WorkflowFalloutConfig> attrList= new ArrayList<>();
			attrList.add(config1);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteWorkFlowFalloutConfig1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteWorkFlowFalloutConfig: ",e);
		}
	}
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_work_flow_fallout_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_work_flow_fallout__config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_work_flow_fallout_config_table.sql")})
	public void testDeleteWorkFlowFalloutConfig2() {
		try {
			LOGGER.info("****************************Entering to testDeleteWorkFlowFalloutConfig2*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/delete");
			WorkflowFalloutConfig config1= new WorkflowFalloutConfig();
			config1.setId(100);
			List<WorkflowFalloutConfig> attrList= new ArrayList<>();
			attrList.add(config1);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteWorkFlowFalloutConfig2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteWorkFlowFalloutConfig: ",e);
		}
	}
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_work_flow_fallout_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_work_flow_fallout__config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_work_flow_fallout_config_table.sql")})
		public void testDeleteWorkFlowFalloutConfig3() {
		try {
			LOGGER.info("****************************Entering to testDeleteWorkFlowFalloutConfig3*****************************");
			URI url = new URI("/oneDispatcher/workFlowFalloutConfig/delete");
			WorkflowFalloutConfig config1= new WorkflowFalloutConfig();
			config1.setWorkflowProcessName("process123");
			config1.setWorkFlowStepName("step1");
			List<WorkflowFalloutConfig> attrList= new ArrayList<>();
			attrList.add(config1);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(attrList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			
			LOGGER.info("****************************Exiting from testDeleteWorkFlowFalloutConfig3*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsParamConfig: ",e);
		}
	}
	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}
	
	

}
