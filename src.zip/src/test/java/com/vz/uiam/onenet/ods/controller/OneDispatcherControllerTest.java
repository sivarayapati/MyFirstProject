package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;


/**
 * @author Anand Badiger
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class OneDispatcherControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(OneDispatcherControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	OneDispatcherController serviceRouterController;


	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}
	
	/**
	 *
	 */
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")
	})
	public final void testDoTransform() {
		try {
			LOGGER.info("****************************Entering to testDoTransform*****************************");
			URI url = new URI("/oneDispatcher/doTransform");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(getTransformRequest("ZZZDE-NGPON2","LCI_OVER_NGPON2_Pre_Activation","RetrieveONTSerialNumber")))
					.andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoTransform*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doTransform: ",e);
		}
	}

	@Test
	public final void testDoTransform1() {
		try {
			LOGGER.info("****************************Entering to testDoTransform*****************************");
			URI url = new URI("/oneDispatcher/doTransform");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(convertObjectToJsonBytes(getTransformRequest("ZZZDE-NGPON2","TransformTest","AddONT"))))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoTransform*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doTransform: ",e);
		}
	}

	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:update_ods_interface_request.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public final void testDoTransform2() {
		try {
			LOGGER.info("****************************Entering to testDoTransform2*****************************");
			URI url = new URI("/oneDispatcher/doTransform");
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test11_TestOneDispatcher","Test11", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoTransform2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doTransform: ",e);
		}
	}

	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public final void testDoTransform3() {
		try {
			LOGGER.info("****************************Entering to testDoTransform2*****************************");
			URI url = new URI("/oneDispatcher/doTransform");
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test111_TestOneDispatcher","Test111", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoTransform2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doTransform: ",e);
		}
	}

	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql")
	})
	public final void testDoTransform4() {
		try {
			LOGGER.info("****************************Entering to testDoTransform4*****************************");
			URI url = new URI("/oneDispatcher/doTransform");
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test246_TestOneDispatcher","Test246", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			MvcResult result1 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test247_TestOneDispatcher","Test247", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result1.getResponse().getContentAsString());

			MvcResult result2 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test247_TestOneDispatcher","Test247", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result2.getResponse().getContentAsString());

			MvcResult result3 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("","Test248", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result3.getResponse().getContentAsString());

			MvcResult result4 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("","Test2481", "TestOneDispatcher2")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result4.getResponse().getContentAsString());

			MvcResult result5 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("","Test249", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();
			LOGGER.debug("Result : " + result5.getResponse().getContentAsString());
			MvcResult result6 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test1_TestOneDispatcher","Test1", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();
			LOGGER.debug("Result : " + result6.getResponse().getContentAsString());


			LOGGER.info("****************************Exiting from testDoTransform4*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doTransform: ",e);
		}
	}

	/**
	 *
	 */
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")
	})
	public final void testDoRequestTransform() {
		try {
			LOGGER.info("****************************Entering to testDoRequestTransform*****************************");
			URI url = new URI("/oneDispatcher/doRequestTransform");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(getTransformRequest("ZZZDE-NGPON2","LCI_OVER_NGPON2_Pre_Activation","RetrieveONTSerialNumber")))
					.andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoRequestTransform*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for testDoRequestTransform: ",e);
		}
	}

	@Test
	public final void testDoRequestTransform1() {
		try {
			LOGGER.info("****************************Entering to testDoRequestTransform1*****************************");
			URI url = new URI("/oneDispatcher/doRequestTransform");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(convertObjectToJsonBytes(getTransformRequest("ZZZDE-NGPON2","TransformTest","AddONT"))))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoRequestTransform1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for testDoRequestTransform1: ",e);
		}
	}

	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:update_ods_interface_request.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public final void testDoRequestTransform2() {
		try {
			LOGGER.info("****************************Entering to testDoRequestTransform2*****************************");
			URI url = new URI("/oneDispatcher/doRequestTransform");
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test11_TestOneDispatcher","Test11", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoRequestTransform2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for testDoRequestTransform2: ",e);
		}
	}

	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_mandatory_attrs_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public final void testDoRequestTransform3() {
		try {
			LOGGER.info("****************************Entering to testDoRequestTransform3*****************************");
			URI url = new URI("/oneDispatcher/doRequestTransform");
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test111_TestOneDispatcher","Test111", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoRequestTransform3*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doTransform: ",e);
		}
	}

	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_service_route_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_service_route_map_table.sql")
	})
	public final void testDoRequestTransform4() {
		try {
			LOGGER.info("****************************Entering to testDoRequestTransform4*****************************");
			URI url = new URI("/oneDispatcher/doRequestTransform");
			MvcResult result = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test246_TestOneDispatcher","Test246", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			MvcResult result1 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test247_TestOneDispatcher","Test247", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result1.getResponse().getContentAsString());

			MvcResult result2 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test247_TestOneDispatcher","Test247", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result2.getResponse().getContentAsString());

			MvcResult result3 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("","Test248", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result3.getResponse().getContentAsString());

			MvcResult result4 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("","Test2481", "TestOneDispatcher2")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result4.getResponse().getContentAsString());

			MvcResult result5 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("","Test249", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();
			LOGGER.debug("Result : " + result5.getResponse().getContentAsString());
			MvcResult result6 = this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(getTransformRequest("Test1_TestOneDispatcher","Test1", "TestOneDispatcher")))
					.andExpect(status().isExpectationFailed()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();
			LOGGER.debug("Result : " + result6.getResponse().getContentAsString());


			LOGGER.info("****************************Exiting from testDoRequestTransform4*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for testDoRequestTransform4: ",e);
		}
	}

	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public void testDoXmlResponseTransform() {
		try {
			LOGGER.info("****************************Entering to testDoXmlResponseTransform*****************************");
			URI url = new URI("/oneDispatcher/doXmlResponseTransform");
			String transID="000|1122DISCONNECT0023";
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(getxmlResponse(transID,"V0000","SUCCESS")))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoXmlResponseTransform*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doXmlResponseTransform: ",e);
		}
	}

	@Test
	public void testDoXmlResponseTransform1() {
		try {
			LOGGER.info("****************************Entering to testDoXmlResponseTransform1*****************************");
			URI url = new URI("/oneDispatcher/doXmlResponseTransform");
			String transID="4";
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(getxmlResponse(transID,"V0001","FAILED")))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoXmlResponseTransform1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doXmlResponseTransform: ",e);
		}
	}

	@Test
	public void testDoXmlResponseTransform4() {
		try {
			LOGGER.info("****************************Entering to testDoXmlResponseTransform1*****************************");
			URI url = new URI("/oneDispatcher/doXmlResponseTransform");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(getInputxmlResponse()))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoXmlResponseTransform1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doXmlResponseTransform: ",e);
		}
	}


	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public void testDoXmlResponseTransform2() {
		try {
			LOGGER.info("****************************Entering to testDoXmlResponseTransform2*****************************");
			URI url = new URI("/oneDispatcher/doXmlResponseTransform");
			String transID="000|1122DISCONNECT0023";
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(getxmlResponse(transID,"V0001","FAILED")))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoXmlResponseTransform2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doXmlResponseTransform: ",e);
		}
	}

	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public void testDoJsonResponseTransform() {
		try {
			LOGGER.info("****************************Entering to testDoJsonResponseTransform*****************************");
			URI url = new URI("/oneDispatcher/doJsonResponseTransform");
			String transID="119968815";
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(getJsonResponse(transID)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoJsonResponseTransform*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doJsonResponseTransform: ",e);
		}
	}

	@Test
	public void testDoJsonResponseTransform1() {
		try {
			LOGGER.info("****************************Entering to testDoJsonResponseTransform1*****************************");
			URI url = new URI("/oneDispatcher/doJsonResponseTransform");
			String transID="";
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(getJsonResponse(transID)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoJsonResponseTransform1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doJsonResponseTransform: ",e);
		}
	}

	@Test
	public void testDoJsonResponseTransform2() {
		try {
			LOGGER.info("****************************Entering to testDoJsonResponseTransform2*****************************");
			URI url = new URI("/oneDispatcher/doJsonResponseTransform");
			String transID="119968815";
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(getJsonResponse(transID)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoJsonResponseTransform2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for doJsonResponseTransform: ",e);
		}
	}

	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public void testDoRestSvcXmlResponseTransform() {
		try {
			LOGGER.info("****************************Entering to testDoRestSvcXmlResponseTransform*****************************");
			
			JSONObject req = new JSONObject();
			req.put("response", getxmlResponse("000|1122DISCONNECT0023","V0000","SUCCESS"));
			req.put(Constants.TRANSACTION_ID, "000|1122DISCONNECT0023");
			
			URI url = new URI("/oneDispatcher/doRestSvcXmlResponseTransform");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(req.toString()))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoRestSvcXmlResponseTransform*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for testDoRestSvcXmlResponseTransform: ",e);
		}
	}

	@Test
	public void testDoRestSvcXmlResponseTransform1() {
		try {
			LOGGER.info("****************************Entering to testDoRestSvcXmlResponseTransform1*****************************");
			
			URI url = new URI("/oneDispatcher/doRestSvcXmlResponseTransform");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content("junkData"))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoRestSvcXmlResponseTransform1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for testDoRestSvcXmlResponseTransform1: ",e);
		}
	}

	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_param_config_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_interface_request_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_param_config_table.sql")})
	public void testDoRestSvcXmlResponseTransform2() {
		try {
			LOGGER.info("****************************Entering to testDoRestSvcXmlResponseTransform2*****************************");
			
			JSONObject req = new JSONObject();
			req.put("response", getxmlResponse("222","V0000","SUCCESS"));
			req.put(Constants.TRANSACTION_ID, "2222");
			
			URI url = new URI("/oneDispatcher/doRestSvcXmlResponseTransform");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
					.content(req.toString()))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());

			LOGGER.info("****************************Exiting from testDoRestSvcXmlResponseTransform2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for testDoRestSvcXmlResponseTransform2: ",e);
		}
	}

	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

	public String getTransformRequest(String appKey, String flowNodeProcessName,String flowNodeStepName ) {
		Map<String, Object> mainValues=new HashMap<>();
		Map<String, Object> subValues=new HashMap<>();
		mainValues.put("app-key", appKey);
		mainValues.put("processInstanceId", "34567");
		mainValues.put("parentProcessInstanceId", "45678");
		mainValues.put("rootProcessInstanceId", "56789");
		mainValues.put("activityInstanceId", "7654");
		mainValues.put("rootProcessName", "Root");
		mainValues.put("flowNodeProcessName",flowNodeProcessName);
		mainValues.put("flowNodeStepName",  flowNodeStepName);
		subValues.put("order_number",  "CCOG639221728");
		subValues.put("order_version",  "001");
		subValues.put("product_type",  "Data");
		subValues.put("supp_type",  "Pending");
		subValues.put("region",  "NJ");
		mainValues.put("seedInfo",  subValues);

		JSONObject requestJson=new JSONObject(mainValues);
		LOGGER.info("getTransformRequest ::::"+requestJson.toString());
		return requestJson.toString();
	}
	
	public String getxmlResponse(String transactionId,String statusCode, String statusDesc) {
		String xmlResponse="<nbaTransaction xsi:schemaLocation=\"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\" xmlns=\"urn:vnm.verizon.com/Schemas/NBParms\""
				+ " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi1=\"http://www.w3.org/2001/XMLSchema-instance\"> <requests xmlns=\"\">"
				+ " <requestType>VNM_RETRIEVE_OLT</requestType><groups> <trails>"
				+ "<attribute name=\"ORDER\">CHANDRA_RTRV_OLT</attribute>"
				+ "<attribute name=\"TRANSACTION_ID\">"+transactionId+"</attribute>"
				+ "<attribute name=\"RESPONSEURL\">https://s1.ebiz.verizon.com//services/vnm</attribute>"
				+ "<attribute name=\"TIMEOUT\">60000</attribute>"
				+ "<attribute name=\"PRIORITY\">PRIORITY_4</attribute>"
				+ "<attribute name=\"TID\">TMPAFLERICERICE901</attribute>"
				+ "<attribute name=\"DEVICE_TYPE\">OLT</attribute>"
				+ "<attribute name=\"DESCRIPTION\">Calix E9 System</attribute>"
				+ "<attribute name=\"VENDOR\">Calix</attribute>"
				+ "<attribute name=\"UNLOCKED_ONTS\">123,345</attribute>"
				+ "</trails></groups><statuscode>"+statusCode+"</statuscode><vnmdesc>"+statusDesc+"</vnmdesc><mne>"
				+ "<tid>TMPAFLERICERICE901</tid></mne></requests>"
				+ "<statuscode xmlns=\"\">"+statusCode+"</statuscode><vnmdesc xmlns=\"\">"+statusDesc+"</vnmdesc></nbaTransaction> ";
		return xmlResponse;
	}

	public String getJsonResponse(String transactionId) {
		String jsonResponse="{ \"status\": {\"desc\":\"SUCCESS\"},\"nbaTransaction\": {\"statuscode\""
				+ ": {\"xmlns\": \"\",\"content\": \"V0000\"	},\"xmlns\": \"urn:vnm.verizon.com/Schemas/NBParms\","
				+ "\"xmlns:xsi1\": \"http://www.w3.org/2001/XMLSchema-instance(http://www.w3.org/2001/XMLSchema-instance%27)\""
				+ " ,\"status\":\"SUCCESS\",\"xsi:schemaLocation\": \"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\""
				+ ",\"xmlns:xsi\": \"http://www.w3.org/2001/XMLSchema(http://www.w3.org/2001/XMLSchema%27)\""
				+ "  ,\"requests\": {\"code\": \"V0000\",\"status\": \"SUCCESS\",\"xmlns\": \"\""
				+ ",\"requestType\": \"VNM_RETRIEVE_OLT\",\"desc\":\"SUCCESS\",\"mne\""
				+ ": {\"tid\": \"TMPAFLERICERICE901\"},\"groups\": {\"trails\": {\"attribute\": "
				+ "[{\"name\": \"ORDER\",\"content\":\"CHANDRA_RTRV_OLT\"},{"
				+ "\"name\": \"RESPONSEURL\",\"content\": \"https://s1.ebiz.verizon.com//services/vnm(https://s1.ebiz.verizon.com//services/vnm%27)\""
				+ "},{\"name\": \"TIMEOUT\",\"content\": 60000},{\"name\": \"PRIORITY\",\"content\": \"PRIORITY_4\"},{\"name\": \"TID\","
				+ "\"content\": \"TMPAFLERICERICE901\"},{\"name\": \"DEVICE_TYPE\",\"content\": \"OLT\"},{\"name\": \"DESCRIPTION\",\"content\": \"Calix E9 System\""
				+ "	},{\"name\": \"VENDOR\",\"content\": \"Calix\""
				+ "	}]}}}},\"transactionId\":"+ transactionId
				+",\"workflowParameters\":"
				+ " {\"workflowParams\": [{\"paramName\":\"workParamName\",\"paramValue\":\"workParamValue\""
				+ "	}]} }";
		return jsonResponse;
	}

	private String  getInputxmlResponse() {

		String response="{ 	\"nbaTransaction\": { 		\"statuscode\": { 			\"xmlns\": \"\", 			\"content\": \"00000\" 		}, 		\"xmlns\": \"urn:vnm.verizon.com/Schemas/NBParms\", 		\"xmlns:xsi1\": \"http://www.w3.org/2001/XMLSchema-instance\", 		\"vnmdesc\": { 			\"xmlns\": \"\", 			\"content\": \"SUCCESS\" 		}, 		\"xsi:schemaLocation\": \"urn:vnm.verizon.com/Schemas/NBParms NBParms.xsd\", 		\"xmlns:xsi\": \"http://www.w3.org/2001/XMLSchema\", 		\"requests\": { 			\"statuscode\": \"00000\", 			\"xmlns\": \"\", 			\"requestType\": \"VNM_RTRV_UNLOCKED_ONTS\", 			\"vnmdesc\": \"SUCCESS\", 			\"mne\": { 				\"tid\": \"TMPAFLERICERICE901\" 			}, 			\"groups\": { 				\"trails\": { 					\"tpaOptical\": { 						\"rack\": 1, 						\"port\": 1, 						\"slot\": 1, 						\"shelf\": 2 					}, 					\"attribute\": [{ 						\"name\": \"TRANSACTION_ID\", 						\"content\": \"1497649132563|759480|17944142\" 					}, { 						\"name\": \"PONSYSTEMID\", 						\"content\": 60000 					}, { 						\"name\": \"PRIORITY\", 						\"content\": \"PRIORITY_4\" 					}, { 						\"name\": \"UNLOCKED_ONTS\", 						\"content\": \"12345678,87654321\" 					}] 				} 			} 		} 	} }";
		return response;
	}
}
