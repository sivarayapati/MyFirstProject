package com.vz.uiam.onenet.ods.service;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.transformer.XMLTransformer;

@RunWith(MockitoJUnitRunner.class)
public class XMLTransformerTest {
	private static final Logger LOGGER = Logger.getLogger(XMLTransformerTest.class);
	@InjectMocks
	XMLTransformer xmlTransformer;

	
	@Test(expected=ApplicationException.class)
	public void testDoTransform() throws ApplicationException {

		LOGGER.info("Entering testDoTransform");
		JSONObject inputDocument = new JSONObject();
		String requestSchema ="";
		xmlTransformer.doTransform(inputDocument, requestSchema);
		LOGGER.info("Exiting testDoTransform");

	}

	

}