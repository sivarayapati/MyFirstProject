package com.vz.uiam.onenet.ods.service;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFallout;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFalloutConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.WorkflowFalloutConfigRepo;
import com.vz.uiam.onenet.ods.jpa.dao.repository.WorkflowFalloutRepo;
import com.vz.uiam.onenet.ods.jpa.dto.model.FalloutServiceResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsTransformerConfigDto;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.WorkflowFalloutRequest;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

import ma.glasnost.orika.MapperFacade;

@RunWith(MockitoJUnitRunner.class)
public class FalloutServiceTest {
	
	private static final Logger LOGGER = Logger.getLogger(FalloutServiceTest.class);

	@InjectMocks
	FalloutService falloutService;

	@Mock
	WorkflowFalloutConfigRepo configRepo;

	@Mock
	WorkflowFalloutRepo fallOutRepo;

	@Mock
	ODSService odsService;

	@Mock
	OdsMandatoryAttrsService odsMandatoryAttrsService;

	@Mock
	OdsTransformerConfigService odsTransformerConfigService;

	@Mock
	ServiceUtils serviceUtils;

	@Mock
	OdsParamConfigRepository odsParamConfigRepo;

	@Mock
	ServiceUtils utils;

	@Mock
	MapperFacade mapper;

	@Mock
	RestTemplate restTemplate;

	@Mock
	ResponseEntity<String> responseEntity;
	
	@Mock
	OdsInterfaceRequestRepository odsInterfaceRequestRepo;
	
	@Mock
	OdsRequestLogRepository odsRequestLogRepository;
	
	@Mock
	BonitaService bonitaService;
	
	@Mock
	ManifestService manifestService;

	private static final String PARAM_NAME = "CREATE_UTE_TASK_URL";
	private static final String PARAM_KEY = "ODS";
	private static final String PARAM_TYPE = "ODS_PARAM";
	private static final String PARAM_URL = "http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask";
	private static final String DOCUMENT_PAYLOAD = "{ 	\"SampleManifest\": { 		\"document-payload\": { 			\"userId\": \"vijay\" 		} 	}, 	\"PlanningMessage\": { 		\"document-payload\": { 			\"PlanningMsgRsp\": { 				\"AeId\": \"ae12\", 				\"InvSystem\": \"IVAPP\", 				\"ActivationInfo\": { 					\"PonDetails\": { 						\"PonId\": \"00000000000000000000000001010111\", 						\"PonSystemId\": \"00000000000100001001\", 						\"ChannelPartitionIndex\": \"0010\", 						\"ServiceType\": \"DATA\", 						\"BackupPonId\": \"00000000000000110010000100010111\", 						\"PonType\": \"NGPON2\" 					} 				}, 				\"LogicalId\": \"0660014\", 				\"RouterName\": \"E320\", 				\"AssignmentReuse\": \"NO\", 				\"PreActRequired\": \"YES\", 				\"OrderNumber\": \"CCOG639221728\", 				\"OrderId\": 706514, 				\"VersionNumber\": \"001\", 				\"SlipEnableFlag\": \"YES\", 				\"xmlns\": \"\", 				\"SubscriptionId\": \"ae12:66-14@NYCMNYWART1\", 				\"IpAddress\": \"34.45.67.89\", 				\"ReconnectONTDel\": \"NO\", 				\"OdnData\": { 					\"MDU_SIP_ALTL\": \"NO\", 					\"CTID\": \"70/VAXA/706514/ /VZNY\", 					\"IvappPonCircuitName\": \"S/GRCYNYGCT01/1-1-9-1\", 					\"DataVlan\": { 						\"STag\": 66, 						\"CircuitName\": \"test\", 						\"CTag\": 14 					}, 					\"PvcNniChange\": \"YES\", 					\"IspPvcCircuitId\": \"70/VAXA/706514/ /VZNY\", 					\"IvappPonCircuitId\": 103792, 					\"MocaProvisioned\": \"N\", 					\"ReplacementPortNumber\": \"\", 					\"SvcPortNumber\": 1, 					\"ServiceTNDetails\": { 						\"SwitchClli\": \"\", 						\"PrimaryLecTN\": \"\" 					} 				}, 				\"RouterCilli\": \"NYCMNYWART1\", 				\"PonCircuit\": { 					\"DistHub\": { 						\"DistributionFiber\": { 							\"StrandNumber\": 2, 							\"Name\": \"H8989\" 						}, 						\"HubPortNumber\": 2, 						\"Splitter\": { 							\"PortNumber\": 1, 							\"Name\": \"H8989A\" 						}, 						\"XConnectAction\": \"Make\", 						\"GpsParams\": { 							\"Latitude\": 26.154106, 							\"Longitude\": -93.129155 						}, 						\"Name\": \"H8989\", 						\"AddressInfo\": \"HOME\" 					}, 					\"Ont\": { 						\"PAIndicator\": \"Compatible\", 						\"ManufacturerName\": \"ALTL\", 						\"DesktopModel\": \"Y\", 						\"Address\": { 							\"HouseNo\": 620, 							\"StreetName\": \"NOTTINGHAM\", 							\"TuName\": \"SYRACUSE\", 							\"Zip\": 13224, 							\"Type\": \"RD\", 							\"SubLocation\": \"FLR GRD\", 							\"State\": \"NY\", 							\"MduSfu\": 0, 							\"AddressId\": 48053419 						}, 						\"MocaCapable\": \"Y\", 						\"Make\": \"ALTL\", 						\"GpsParams\": { 							\"Latitude\": \"\", 							\"Longitude\": \"\" 						}, 						\"EthernetSpeed\": \"N\", 						\"RequiredAction\": \"Install\", 						\"Name\": \"GRCYNYGCT01SFU020101\", 						\"Type\": \"SFU\", 						\"SequenceNumber\": 1, 						\"Model\": \"O-211M-E\", 						\"InactiveONT\": \"N\" 					}, 					\"Olt\": { 						\"FeederFiber\": { 							\"StrandNumber\": 1, 							\"Name\": \"F8989\" 						}, 						\"SlotId\": 1, 						\"Rack\": 1, 						\"Group\": 183433, 						\"ManufacturerName\": \"ALTL\", 						\"Clli\": \"GRNKNYGNRCH\", 						\"OltPortNumber\": 9, 						\"EmsId\": \"\", 						\"ShelfId\": 1, 						\"OltTid\": \"TMPAFLERICERICE907\", 						\"Name\": \"ALTL-ONT211M\" 					}, 					\"FiberJackCapable\": \"N\", 					\"DropTerminal\": { 						\"RELATED_ADDR_ID\": [90213, 90132, 90134, 90135, 189459, 90214, 90212, 90215, 237267, 237232, 237233, 156737, 189460, 189461, 90133, 90153, 143599, 237268, 189440], 						\"ConnectorType\": \"SC/APC\", 						\"DropAction\": \"TERMINATE\", 						\"GpsParams\": { 							\"Latitude\": 26.154476, 							\"Longitude\": -93.128649 						}, 						\"DropStatus\": \"TERMINATED\", 						\"DropType\": \"MDU_INSIDE\", 						\"PortNumber\": 2, 						\"Name\": 102853, 						\"AddressInfo\": \"HOME\" 					}, 					\"IvappPonCircuitId\": 103792, 					\"PonCircuitName\": \"S/GRCYNYGCT01/1-1-9-1\", 					\"FiberDrop\": { 						\"StrandNumber\": 2 					} 				} 			} 		} 	} }";
	private static final String HANDLE_FALLOUT_REQ = "{ 	\"app-key\": \"ZZZDE-NGPON2\", 	\"processInstanceId\": \"34502\", 	\"activityInstanceId\": \"7602\", 	\"parentProcessInstanceId\": \"45672\", 	\"rootProcessInstanceId\": \"56782\", 	\"processName\": \"DS1_Migration\", 	\"stepName\": \"Estimate Cost\", 	\"seedInfo\": { 		\"order_number\": \"CCOG639221728\", 		\"order_version\": \"001\", 		\"product_type\": \"Data\", 		\"supp_type\": \"Pending\", 		\"region\": \"NJ\" 	}, 	\"caseId\": \"34002\", 	\"errorCode\": \"652\", 	\"document-name\": \"PlanningMessage,SampleManifest\" }";

	/*
	 * @param request
	 * 
	 * @return WorkflowFalloutConfig
	 * 
	 * @throws ApplicationException
	 * 
	 */
	@Test
	public void testgetFalloutConfig() throws ApplicationException {

		WorkflowFalloutConfig config = new WorkflowFalloutConfig();

		when(configRepo.findByWorkflowProcessNameAndWorkFlowStepNameAndWorkFlowFalloutErrorCode(anyString(),
				anyString(), anyString())).thenReturn(config);

		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.getFalloutConfig(new WorkflowFalloutRequest());

	}

	@Test
	public void testHandleFallout1() {
		String request = "{}";
		when(fallOutRepo.getByCaseIdAndWorkFlowProcessNameAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(
				anyString(), anyString(), anyString(), anyString(), anyString())).thenThrow(new RuntimeException());
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.handleFallout(request, new OdsRequestLog());

	}

	/**
	 * @param request
	 * @return WorkflowFalloutConfig
	 * @throws ApplicationException
	 */
	@Test
	public void testCreateFallout() throws ApplicationException {

		WorkflowFallout workflowFallout = new WorkflowFallout();
		when(fallOutRepo.getByStatusAndCaseIdAndWorkFlowStepName(anyString(), anyString(), anyString()))
				.thenReturn(workflowFallout);

		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.createFallout(new WorkflowFalloutRequest());

		workflowFallout.setStatus(Constants.STATUS_PENDING);
		fallOutRepo.save(workflowFallout);

	}

	@Test
	public void testCreateFalloutIsNull() throws ApplicationException {

		WorkflowFallout workflowFallout = new WorkflowFallout();
		WorkflowFalloutRequest workflowFalloutRequest = new WorkflowFalloutRequest();
		when(mapper.map(workflowFalloutRequest, WorkflowFallout.class)).thenReturn(workflowFallout);
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		workflowFallout.setStatus(Constants.STATUS_PENDING);
		odsServiceSpy.createFallout(workflowFalloutRequest);

	}

	@Test
	public void testHandleFallout() throws ApplicationException {

		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName(PARAM_NAME);
		odsAppParam.setParamKey(PARAM_KEY);
		odsAppParam.setType(PARAM_TYPE);
		odsAppParam.setValue(PARAM_URL);
		WorkflowFallout falloutRequest = new WorkflowFallout();
		falloutRequest.setCaseId("121");
		falloutRequest.setWorkFlowStepRetryCounter(1);
		when(fallOutRepo.getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(falloutRequest);
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.handleFallout(HANDLE_FALLOUT_REQ, new OdsRequestLog());
	}

	@Test
	public void testHandleFallout2() throws ApplicationException {

		OdsParamConfig odsAppParam = new OdsParamConfig();
		String entityData = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG639221728\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"001\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"NJ\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"Pending\" 			}] 		} 	} }";
		String finalUtePayLoad = "FinalUTEPAYLOAD";
		odsAppParam.setParamId(9);
		odsAppParam.setName(PARAM_NAME);
		odsAppParam.setParamKey(PARAM_KEY);
		odsAppParam.setType(PARAM_TYPE);
		odsAppParam.setValue(PARAM_URL);
		OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
		odsMandatoryAttributes.setAttrKey("TestKey");
		List<OdsMandatoryAttributes> mandatoryAttrbsList = new ArrayList<>();
		mandatoryAttrbsList.add(odsMandatoryAttributes);
		OdsTransformerConfigDto request = new OdsTransformerConfigDto("transformerKey", "utRequestPayLoad");
		ResponseEntity<String> responseEntity1 = new ResponseEntity<>("{\"test\":\"testValue\"}", HttpStatus.OK);

		when(fallOutRepo.getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(anyString(), anyString(),
				anyString(), anyString())).thenReturn(null);
		when(serviceUtils.buildManifestDocument(anyString(), anyString())).thenReturn(DOCUMENT_PAYLOAD);
		when(odsService.buildManifestPayload(any(), any())).thenReturn(entityData);
		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(mandatoryAttrbsList);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.CREATE_UTE_TASK_URL)).thenReturn(odsAppParam);
		when(odsTransformerConfigService.tranformDocument(request)).thenReturn(finalUtePayLoad);
		when(serviceUtils.callService(Mockito.any(), Mockito.any())).thenReturn(responseEntity1);
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.handleFallout(HANDLE_FALLOUT_REQ, new OdsRequestLog());
	}

	@Test
	public void testHandleFallout4() throws ApplicationException {
		WorkflowFallout falloutRequest = new WorkflowFallout();
		falloutRequest.setCaseId("121");
		when(fallOutRepo.getByCaseIdAndWorkFlowProcessNameAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(
				anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(falloutRequest);
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.handleFallout(HANDLE_FALLOUT_REQ, new OdsRequestLog());
	}

	@Test
	public void testHandleFallout5() throws ApplicationException {

		WorkflowFallout falloutRequest = new WorkflowFallout();
		WorkflowFalloutConfig config = new WorkflowFalloutConfig();
		falloutRequest.setCaseId("121");
		falloutRequest.setWorkFlowStepRetryCounter(1);
		config.setMaxRetryCounter(3);
		config.setRetryInterval(10);
		FalloutServiceResponse response = new FalloutServiceResponse();
		response.setIsRetry(true);
		ResponseEntity<String> responseEntity1 = new ResponseEntity<>(response.toString(), HttpStatus.OK);

		when(fallOutRepo.getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(anyString(), anyString(),
				anyString(), anyString())).thenReturn(falloutRequest);
		when(configRepo.findByWorkFlowStepNameAndWorkFlowFalloutErrorCode(anyString(), anyString())).thenReturn(config);
		when(serviceUtils.callService(Mockito.any(), Mockito.any())).thenReturn(responseEntity1);
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		Mockito.doNothing().when(odsServiceSpy).callCompleteManualTaskService(Mockito.any());
		odsServiceSpy.handleFallout(HANDLE_FALLOUT_REQ, new OdsRequestLog());
	}

	@Test
	public void testHandleFallout6() throws ApplicationException {
		WorkflowFallout falloutRequest = new WorkflowFallout();
		WorkflowFalloutConfig config = new WorkflowFalloutConfig();
		falloutRequest.setCaseId("121");
		falloutRequest.setWorkFlowStepRetryCounter(3);
		config.setMaxRetryCounter(3);
		config.setRetryInterval(10);
	
		when(fallOutRepo.getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(anyString(), anyString(),
				anyString(), anyString())).thenReturn(falloutRequest);
		when(configRepo.findByWorkFlowStepNameAndWorkFlowFalloutErrorCode(anyString(), anyString())).thenReturn(config);
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.handleFallout(HANDLE_FALLOUT_REQ, new OdsRequestLog());
	}

	@Test
	public void testCallCompleteManualTaskService() throws ApplicationException {
		OdsParamConfig odsAppParam = new OdsParamConfig();
		String request = "completeManualTask";
		odsAppParam.setParamId(9);
		odsAppParam.setName("CREATE_UTE_TASK_URL");
		odsAppParam.setParamKey("ODS");
		odsAppParam.setType("ODS_PARAM");
		odsAppParam.setValue("http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask");
		ResponseEntity<String> responseEntity1 = new ResponseEntity<>("{\"test\":\"testValue\"}", HttpStatus.OK);

		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.COMPLETE_MANUAL_TASK_URL)).thenReturn(odsAppParam);
		when(serviceUtils.callService(Mockito.any(), Mockito.any())).thenReturn(responseEntity1);
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.callCompleteManualTaskService(request);

	}

	@Test(expected = ApplicationException.class)
	public void testCreateUTETaskForFallout() throws ApplicationException {
		JSONObject request = new JSONObject();
		request.put("app-key", "231");
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.createOrUpdateUTETaskForFallout(request, new JSONObject());

	}

	@Test(expected = ApplicationException.class)
	public void testCreateUteTaskService() throws ApplicationException {
		JSONObject request = new JSONObject();
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.CREATE_UTE_TASK_URL)).thenReturn(null);
		request.put("app-key", "231");
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.createUteTaskService(request);

	}

	@Test(expected = ApplicationException.class)
	public void testcallCompleteManualTaskService() throws ApplicationException {
		String request = "Test String";
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.CREATE_UTE_TASK_URL)).thenReturn(null);
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.callCompleteManualTaskService(request);

	}
	@Test(expected = ApplicationException.class)
	public void testCallCompleteManualTaskService1() throws ApplicationException {
		OdsParamConfig odsAppParam = new OdsParamConfig();
		String request = "completeManualTask";
		odsAppParam.setParamId(9);
		odsAppParam.setName("CREATE_UTE_TASK_URL");
		odsAppParam.setParamKey("ODS");
		odsAppParam.setType("ODS_PARAM");
		odsAppParam.setValue("http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask");
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.COMPLETE_MANUAL_TASK_URL)).thenReturn(odsAppParam);
		when(serviceUtils.callService(Mockito.any(), Mockito.any())).thenReturn(responseEntity);
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.callCompleteManualTaskService(request);

	}
	@Test(expected = ApplicationException.class)
	public void testCreateUteTaskService1() throws ApplicationException {
		JSONObject request = new JSONObject();
		request.put("requestPayload", new JSONObject("{\"app-key\":\"123\"}"));
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName("CREATE_UTE_TASK_URL");
		odsAppParam.setParamKey("ODS");
		odsAppParam.setType("ODS_PARAM");
		odsAppParam.setValue("http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask");
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.CREATE_UTE_TASK_URL)).thenReturn(odsAppParam);
		FalloutService odsServiceSpy = Mockito.spy(falloutService);
		odsServiceSpy.createUteTaskService(request);

	}
	@Test(expected = ApplicationException.class)
	public void testisRetryPossible() throws ApplicationException {
		JSONObject reqJson = new JSONObject();
		reqJson.put("errorCode", "DEFAULT_ERROR_CODE");
		reqJson.put("falloutStepName", "AddONT_Test");
		reqJson.put("transactionId", "119968815");
		OdsInterfaceRequest odsInterfaceRequest = null;
		when(odsInterfaceRequestRepo.findByTransactionIdAndStatus(Mockito.any(), Mockito.any()))
				.thenReturn(odsInterfaceRequest);
		falloutService.isRetryPossible(reqJson);
	}

	@Test
	public void testisRetryPossible1() throws ApplicationException {
		JSONObject reqJson = new JSONObject();
		reqJson.put("errorCode", "DEFAULT_ERROR_CODE");
		reqJson.put("falloutStepName", "AddONT_Test");
		reqJson.put("transactionId", "119968815");
		OdsInterfaceRequest odsInterfaceRequest = new OdsInterfaceRequest();
		when(odsInterfaceRequestRepo.findByTransactionIdAndStatus(Mockito.any(), Mockito.any()))
				.thenReturn(odsInterfaceRequest);
		ResponseConfigParams responseConfigParam = new ResponseConfigParams("TEST", "AddONT_Test", "12345", "01234", "12345");
		when(serviceUtils.convertJsonStringToObject(Mockito.any(), Mockito.any())).thenReturn(responseConfigParam);
	
		WorkflowFallout fallout = null;
		when(fallOutRepo.getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(fallout);
		
		falloutService.isRetryPossible(reqJson);
	}
	
	@Test(expected=ApplicationException.class)
	public void testhandleRequest() throws ApplicationException {
		String request = "{\"wfTaskId\" : \"1234\",\"taskAction\":\"REFLOW\",\"wfTaskName\":\"ute\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setOdsRequestLogId(123);
		odsRequestLog.setResponseStatus(StatusCode.IN_PROGRESS.toString());
		odsRequestLog.setTitle("Process");
		odsRequestLog.setTitleVersion("0.2");
		odsRequestLog.setWfTaskId("12346");
		when(odsRequestLogRepository.findByWfTaskId(Mockito.anyString())).thenReturn(odsRequestLog);
		falloutServiceSpy.handleRequest(request);
		
	}

	@Test
	public void testhandleRequest1() throws ApplicationException {
		String request = "{\"wfTaskId\" : \"1234\",\"taskAction\":\"REFLOW\",\"wfTaskName\":\"ute\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setOdsRequestLogId(123);
		odsRequestLog.setResponseStatus(StatusCode.IN_PROGRESS.toString());
		odsRequestLog.setTitle("Process");
		odsRequestLog.setTitleVersion("0.2");
		odsRequestLog.setWfTaskId("12346");
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName("CREATE_UTE_TASK_URL");
		odsAppParam.setParamKey("ODS");
		odsAppParam.setType("ODS_PARAM");
		odsAppParam.setValue("http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask");
		ResponseEntity<String> responseEntityT = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.OK);
		when(odsRequestLogRepository.findByWfTaskId(Mockito.anyString())).thenReturn(odsRequestLog);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntityT);
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsAppParam);
		falloutServiceSpy.handleRequest(request);
		
	}
	
	@Test
	public void testhandleRequest2() throws ApplicationException {
		String request = "{\"wfTaskId\" : \"\",\"taskAction\":\"REFLOW\",\"wfTaskName\":\"ute\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setOdsRequestLogId(123);
		odsRequestLog.setResponseStatus("SUCCESS");
		odsRequestLog.setTitle("Process");
		odsRequestLog.setTitleVersion("0.2");
		odsRequestLog.setWfTaskId("12346");
		odsRequestLog.setWfTaskStatus("PENDING");
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName("CREATE_UTE_TASK_URL");
		odsAppParam.setParamKey("ODS");
		odsAppParam.setType("ODS_PARAM");
		odsAppParam.setValue("http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask");
		ResponseEntity<String> responseEntityT = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.OK);
		when(odsRequestLogRepository.findByTitleAndTitleVersionAndWfTaskName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsRequestLog);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntityT);
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsAppParam);
		Mockito.doNothing().when(bonitaService).completeBonitaReceiveTask(odsRequestLog.getWfTaskCompletionPayload());
		falloutServiceSpy.handleRequest(request);
		
	}
	@Test
	public void testhandleRequest3() throws ApplicationException {
		String request = "{\"wfTaskId\" : \"1234\",\"taskAction\":\"COMPLETE\",\"wfTaskName\":\"ute\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setOdsRequestLogId(123);
		odsRequestLog.setResponseStatus(StatusCode.IN_PROGRESS.toString());
		odsRequestLog.setTitle("Process");
		odsRequestLog.setTitleVersion("0.2");
		odsRequestLog.setWfTaskId("12346");
		odsRequestLog.setWfRequestPayload("{}");
		Mockito.doNothing().when(falloutServiceSpy).closePendingUteTasks(Mockito.any());
		when(odsRequestLogRepository.findByWfTaskId(Mockito.anyString())).thenReturn(odsRequestLog);
		falloutServiceSpy.handleRequest(request);
		
	}
	@Test
	public void testhandleRequest4() throws ApplicationException {
		String request = "{\"wfTaskId\" : \"1234\",\"taskAction\":\"COMPLETE\",\"wfTaskName\":\"ute\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setOdsRequestLogId(123);
		odsRequestLog.setResponseStatus(StatusCode.IN_PROGRESS.toString());
		odsRequestLog.setTitle("Process");
		odsRequestLog.setTitleVersion("0.2");
		odsRequestLog.setWfTaskId("12346");
		odsRequestLog.setWfTaskStatus("SUCCESS");
		when(odsRequestLogRepository.findByWfTaskId(Mockito.anyString())).thenReturn(odsRequestLog);
		falloutServiceSpy.handleRequest(request);
		
	}
	@Test(expected=ApplicationException.class)
	public void testCallService() throws ApplicationException {
		String request = "{\"wfTaskId\" : \"\",\"taskAction\":\"REFLOW\",\"wfTaskName\":\"ute\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName("CREATE_UTE_TASK_URL");
		odsAppParam.setParamKey("ODS");
		odsAppParam.setType("ODS_PARAM");
		odsAppParam.setValue("http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask");
		ResponseEntity<String> responseEntityT = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.BAD_REQUEST);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntityT);
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsAppParam);
		falloutServiceSpy.callService("ZZRQN", request);
		
	}
	@Test(expected=ApplicationException.class)
	public void testCallService1() throws ApplicationException {
		String request = "{\"wfTaskId\" : \"\",\"taskAction\":\"REFLOW\",\"wfTaskName\":\"ute\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName("CREATE_UTE_TASK_URL");
		odsAppParam.setParamKey("ODS");
		odsAppParam.setType("ODS_PARAM");
		odsAppParam.setValue("http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask");
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenThrow(IOException.class);
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsAppParam);
		falloutServiceSpy.callService("ZZRQN", request);
		
	}
	@Test
	public void testCallService2() throws ApplicationException {
		String request = "{\"wfTaskId\" : \"\",\"taskAction\":\"REFLOW\",\"wfTaskName\":\"ute\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName("CREATE_UTE_TASK_URL");
		odsAppParam.setParamKey("ODS");
		odsAppParam.setType("ODS_PARAM");
		odsAppParam.setValue("http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask");
		ResponseEntity<String> responseEntityT = new ResponseEntity<>("",
				HttpStatus.OK);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntityT);
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsAppParam);
		falloutServiceSpy.callService("ZZRQN", request);
		
	}
	@Test(expected=ApplicationException.class)
	public void closeBonitaTaskTest() throws ApplicationException
	{
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setOdsRequestLogId(123);
		odsRequestLog.setResponseStatus(StatusCode.IN_PROGRESS.toString());
		odsRequestLog.setTitle("Process");
		odsRequestLog.setTitleVersion("0.2");
		odsRequestLog.setWfTaskId("12346");
		odsRequestLog.setWfTaskStatus("SUCCESS");
		Mockito.doThrow(ApplicationException.class).when(bonitaService).completeBonitaReceiveTask(odsRequestLog.getWfTaskCompletionPayload());
		
		falloutService.closeBonitaTask(odsRequestLog);
	}
	@Test(expected=ApplicationException.class)
	public void completeManualTask() throws ApplicationException
	{
		FalloutServiceResponse falloutSvcResp = new FalloutServiceResponse();
		falloutService.completeManualTask(falloutSvcResp);
	}
	@Test(expected=ApplicationException.class)
	public void completeManualTask1() throws ApplicationException
	{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName("CREATE_UTE_TASK_URL");
		odsAppParam.setParamKey("ODS");
		odsAppParam.setType("ODS_PARAM");
		odsAppParam.setValue("http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask");
		FalloutServiceResponse falloutSvcResp = new FalloutServiceResponse();
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.COMPLETE_MANUAL_TASK_URL)).thenReturn(odsAppParam);
		falloutServiceSpy.completeManualTask(falloutSvcResp);
	}
	@Test
	public void completeManualTask2() throws ApplicationException
	{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		FalloutServiceResponse falloutSvcResp = new FalloutServiceResponse();
		Mockito.doNothing().when(falloutServiceSpy).callCompleteManualTaskService(Mockito.anyString());
		falloutServiceSpy.completeManualTask(falloutSvcResp);
	}

	@Test(expected = ApplicationException.class)
	public void testbuildManifestPayload() throws ApplicationException {

		JSONObject requestObj = new JSONObject();
		requestObj.put("app-key", "test-key");
		Mockito.doNothing().when(odsService).validateAppkey(requestObj);
		List<OdsMandatoryAttributes> mandatoryAttrbsList = new ArrayList<OdsMandatoryAttributes>();
		when(odsMandatoryAttrsService.getMandatoryAttributeList(Mockito.anyString())).thenReturn(mandatoryAttrbsList);
		falloutService.buildManifestPayload(requestObj);

	}

	@Test
	public void testbuildManifestPayload1() throws ApplicationException {

		JSONObject requestObj = new JSONObject();
		requestObj.put("app-key", "test-key");
		Mockito.doNothing().when(odsService).validateAppkey(requestObj);
		List<OdsMandatoryAttributes> mandatoryAttrbsList = new ArrayList<OdsMandatoryAttributes>();
		OdsMandatoryAttributes odsMandatoryattrib = new OdsMandatoryAttributes();
		odsMandatoryattrib.setAttrKey("test_key");
		odsMandatoryattrib.setValidationId(123);
		odsMandatoryattrib.setJsonPath("/jsonpath");
		mandatoryAttrbsList.add(odsMandatoryattrib);
		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(mandatoryAttrbsList);
		JSONArray manifestAttributesArray = new JSONArray();
		Mockito.doNothing().when(odsService).validateManifestAttributes(requestObj, mandatoryAttrbsList,
				manifestAttributesArray);
		when(odsService.buildManifestPayload(requestObj, manifestAttributesArray)).thenReturn(anyString());
		falloutService.buildManifestPayload(requestObj);

	}
	
	@Test
	public void testisRetryPossible2() throws ApplicationException {
		JSONObject reqJson = new JSONObject();
		reqJson.put("errorCode", "DEFAULT_ERROR_CODE");
		reqJson.put("falloutStepName", "AddONT_Test");
		reqJson.put("transactionId", "119968815");
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsInterfaceRequest odsInterfaceRequest = new OdsInterfaceRequest();
		when(odsInterfaceRequestRepo.findByTransactionIdAndStatus(Mockito.any(), Mockito.any()))
				.thenReturn(odsInterfaceRequest);
		ResponseConfigParams responseConfigParam = new ResponseConfigParams("TEST", "AddONT_Test", "12345", "01234", "12345");
		when(serviceUtils.convertJsonStringToObject(Mockito.any(), Mockito.any())).thenReturn(responseConfigParam);
	
		WorkflowFallout fallout = null;
		when(fallOutRepo.getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(fallout);
		WorkflowFalloutConfig config = new WorkflowFalloutConfig();
		config.setMaxRetryCounter(3);
		config.setRetryInterval(10);
		Mockito.doReturn(config).when(falloutServiceSpy).getFalloutConfig(Mockito.any(WorkflowFalloutRequest.class));
		falloutServiceSpy.isRetryPossible(reqJson);
	}

	@Test
	public void testisRetryPossible3() throws ApplicationException {
		JSONObject reqJson = new JSONObject();
		reqJson.put("errorCode", "DEFAULT_ERROR_CODE");
		reqJson.put("falloutStepName", "AddONT_Test");
		reqJson.put("transactionId", "119968815");
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsInterfaceRequest odsInterfaceRequest = new OdsInterfaceRequest();
		when(odsInterfaceRequestRepo.findByTransactionIdAndStatus(Mockito.any(), Mockito.any()))
				.thenReturn(odsInterfaceRequest);
		ResponseConfigParams responseConfigParam = new ResponseConfigParams("TEST", "AddONT_Test", "12345", "01234",
				"12345");
		when(serviceUtils.convertJsonStringToObject(Mockito.any(), Mockito.any())).thenReturn(responseConfigParam);

		WorkflowFallout fallout = null;
		when(fallOutRepo.getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(fallout);
		WorkflowFallout workfallout = new WorkflowFallout();
		workfallout.setWorkFlowStepRetryCounter(1);
		when(fallOutRepo.getByCaseIdAndWorkFlowStepNameAndWorkFlowFalloutErrorCodeAndStatus(Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(workfallout);
		WorkflowFalloutConfig config = new WorkflowFalloutConfig();
		config.setMaxRetryCounter(3);
		config.setRetryInterval(10);
		Mockito.doReturn(config).when(falloutServiceSpy).getFalloutConfig(Mockito.any(WorkflowFalloutRequest.class));
		falloutServiceSpy.isRetryPossible(reqJson);
	}

	@Test
	public void createUTETaskForFalloutTest() throws ApplicationException {
		JSONObject reqJson = new JSONObject(HANDLE_FALLOUT_REQ);
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName("CREATE_UTE_TASK_URL");
		odsAppParam.setParamKey("ODS");
		odsAppParam.setType("ODS_PARAM");
		odsAppParam.setValue("http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask");

		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(reqJson.getString(Constants.MANIFEST_APP_KEY_STR),
				OdsParamConfigType.APPLICATION_PARAM.toString(), Constants.UTE_REQUEST_DOCUMENT_NAMES))
						.thenReturn(odsAppParam);
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		Mockito.doReturn("{}").when(falloutServiceSpy).buildManifestPayload(Mockito.any());
		when(serviceUtils.buildManifestDocument(Mockito.anyString(), Mockito.anyString())).thenReturn("{}");
		Mockito.doReturn("{\r\n" + 
				"	\"taskHeader\": {\r\n" + 
				"		\"taskSource\": \"LCI-VBM-VES\",\r\n" + 
				"		\"userId\": \"COA\",\r\n" + 
				"		\"creator\": \"COA\",		\r\n" + 
				"		\"requestedDueDate\": \"2018-06-05T00:00:00\"\r\n" + 
				"	},	\r\n" + 
				"	\"externalTaskId\": \"1-3391540-380302113\",	\r\n" + 
				"	\"taskAction\": \"INITIATE_TASK\",\r\n" + 
				"	\"taskOutcome\": \"INITIATE\",	\r\n" + 
				"	\"internalTaskId\": \"590-1-3391540-380302113\",\r\n" + 
				"	\"statusMessage\": \"Task Initiated\",\r\n" + 
				"	\"statusCode\": \"SUCCESS\"\r\n" + 
				"}").when(falloutServiceSpy).createUteTaskService(Mockito.any());
		Mockito.doNothing().when(falloutServiceSpy).addUteTaskToManifest(Mockito.any(), Mockito.any(), Mockito.any());
		JSONObject documentPayload = new JSONObject();
		documentPayload.put("document-payload", new JSONObject());
		falloutServiceSpy.createOrUpdateUTETaskForFallout(reqJson, documentPayload);
	}
	
	@Test
	public void completeAllUteTasksTest() throws ApplicationException {
		LOGGER.info("Entering completeAllUteTasksTest");
		OdsParamConfig odsParam = new OdsParamConfig();
		odsParam.setValue("uteTaskListDocument");
		when(manifestService.fetchManifestRequestPayload(Mockito.any())).thenReturn(new JSONObject());
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsParam);
		String manifestDocStr = "{\r\n" + "	\"uteTaskListDocument\": {\r\n" + "		\"document-payload\": {\r\n"
				+ "\r\n" + "			\"1-313718-4202206\": {\r\n" + "				\"creator\": \"COA\",\r\n"
				+ "				\"externalTaskId\": \"1-313718-4202206\",\r\n"
				+ "				\"taskSource\": \"LCI-VBM-VES\",\r\n" + "				\"userId\": \"COA\",\r\n"
				+ "				\"status\": \"IN PROGRESS\"\r\n" + "			}\r\n" + "		}\r\n" + "	}\r\n"
				+ "}";
		JSONObject manifestDocument = new JSONObject(manifestDocStr);
		when(manifestService.buildManifestDocument(Mockito.any(), Mockito.anyString())).thenReturn(manifestDocument);
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		Mockito.doReturn("SUCCESS").when(falloutServiceSpy).completeUteTask(Mockito.any(), Mockito.any());
		
		Mockito.doNothing().when(falloutServiceSpy).removeUteTaskFromManifest(Mockito.any(), Mockito.any(),
				Mockito.anyString(), Mockito.anyString());
		
		Mockito.doNothing().when(falloutServiceSpy).completeUteTaskAndUpdateManifest(Mockito.any(), Mockito.any(),
				Mockito.any(), Mockito.any(), Mockito.anyString(), Mockito.anyString());
		ResponseEntity<String> responseEntity1 = new ResponseEntity<>("{\"test\":\"testValue\"}", HttpStatus.OK);
		when(serviceUtils.callService(Mockito.any(), Mockito.any())).thenReturn(responseEntity1);
		
		falloutServiceSpy.completeAllUteTasks(HANDLE_FALLOUT_REQ);
		LOGGER.info("Exiting completeAllUteTasksTest");
	}
	@Test
	public void testCompleteUteTaskAndUpdateManifest() throws ApplicationException{
		FalloutService falloutServiceSpy =Mockito.spy(falloutService);
	    Mockito.doReturn("abc").when(falloutServiceSpy).completeUteTask(Mockito.anyObject(), Mockito.anyObject());
		String manifestDocStr = "{\r\n" + "	\"uteTaskListDocument\": {\r\n" + "		\"document-payload\": {\r\n"
				+ "\r\n" + "			\"1-313718-4202206\": {\r\n" + "				\"creator\": \"COA\",\r\n"
				+ "				\"externalTaskId\": \"1-313718-4202206\",\r\n"
				+ "				\"taskSource\": \"LCI-VBM-VES\",\r\n" + "				\"userId\": \"COA\",\r\n"
				+ "				\"status\": \"IN PROGRESS\"\r\n" + "			}\r\n" + "		}\r\n" + "	}\r\n"
				+ "}";
		String entityData = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG639221728\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"001\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"NJ\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"Pending\" 			}] 		} 	} }";
		JSONObject manifestDocument = new JSONObject(manifestDocStr);
		JSONObject manifestRequestPayload = new JSONObject(entityData);
		JSONObject workflowRequest = new JSONObject();
		JSONObject externalTaskIdJson =  new JSONObject(manifestDocStr);
		falloutServiceSpy.completeUteTaskAndUpdateManifest(workflowRequest, manifestDocument, manifestRequestPayload, externalTaskIdJson, "uteTaskListDocument", "1-313718-4202206");
	}
	@Test
	public void testCompleteUteTaskAndUpdateManifestForNull() throws ApplicationException{
		FalloutService falloutServiceSpy =Mockito.spy(falloutService);
	    Mockito.doReturn("").when(falloutServiceSpy).completeUteTask(Mockito.anyObject(), Mockito.anyObject());
	    try{
	    	falloutServiceSpy.completeUteTaskAndUpdateManifest(new JSONObject(), new JSONObject(), new JSONObject(), new JSONObject(), "uteTaskListDocument", "1-313718-4202206");
		}
	    catch(Exception e){
	    	LOGGER.error(e);
	    }
	}
	
	@Test
	public void testClosePendingUteTasks() throws ApplicationException
	{
		String manifestDocStr = "{\r\n" + "	\"uteTaskListDocument\": {\r\n" + "		\"document-payload\": {\r\n"
				+ "\r\n" + "			\"1-313718-4202206\": {\r\n" + "				\"creator\": \"COA\",\r\n"
				+ "				\"externalTaskId\": \"1-313718-4202206\",\r\n"
				+ "				\"taskSource\": \"LCI-VBM-VES\",\r\n" + "				\"userId\": \"COA\",\r\n"
				+ "				\"status\": \"IN PROGRESS\"\r\n" + "			}\r\n" + "		}\r\n" + "	}\r\n"
				+ "}";
		JSONObject manifestDocument = new JSONObject(manifestDocStr);
		String workFlowRequestStr = "{\"processInstanceId\":\"1522721\",\"seedInfo\":{\"document_level\":\"VERSION\",\"order_number\":\"30049573\",\"order_version\":\"0\"},\"orderId\":\"30049573\",\"app-key\":\"ZZZDE-VRD\",\"rootProcessInstanceId\":\"1573557\",\"activityInstanceId\":\"1522721\",\"flowNodeProcessName\":\"LCI_DATA_CREATE_CLR\",\"flowNodeStepName\":\"CreateOrder\"}";
		JSONObject workFlowRequest = new JSONObject(workFlowRequestStr);
		String entityData = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG639221728\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"001\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"NJ\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"Pending\" 			}] 		} 	} }";
		JSONObject manifestRequestPayload = new JSONObject(entityData);
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("uteTaskListDocument");
		when(manifestService.fetchManifestRequestPayload(workFlowRequest)).thenReturn(manifestRequestPayload);
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(odsParamConfig);
		when(manifestService.buildManifestDocument(Mockito.anyObject(),Mockito.anyString())).thenReturn(manifestDocument);
		when(serviceUtils.buildExternalTaskId(Mockito.anyString(),Mockito.anyString())).thenReturn("1-313718-4202206");
		when(serviceUtils.getJsonSchemaValue(Mockito.anyObject(),Mockito.anyString())).thenReturn(null);
		try{
			falloutService.closePendingUteTasks(workFlowRequest);
		}
		catch(Exception e){
			LOGGER.error(e);
		}
	
	}
	
	@Test
	public void testClosePendingUteTasks1() throws ApplicationException
	{
		FalloutService falloutServiceSpy= Mockito.spy(falloutService);
		String manifestDocStr = "{\r\n" + "	\"uteTaskListDocument\": {\r\n" + "		\"document-payload\": {\r\n"
				+ "\r\n" + "			\"1-313718-4202206\": {\r\n" + "				\"creator\": \"COA\",\r\n"
				+ "				\"externalTaskId\": \"1-313718-4202206\",\r\n"
				+ "				\"taskSource\": \"LCI-VBM-VES\",\r\n" + "				\"userId\": \"COA\",\r\n"
				+ "				\"status\": \"IN PROGRESS\"\r\n" + "			}\r\n" + "		}\r\n" + "	}\r\n"
				+ "}";
		JSONObject manifestDocument = new JSONObject(manifestDocStr);
		String workFlowRequestStr = "{\"processInstanceId\":\"1522721\",\"seedInfo\":{\"document_level\":\"VERSION\",\"order_number\":\"30049573\",\"order_version\":\"0\"},\"orderId\":\"30049573\",\"app-key\":\"ZZZDE-VRD\",\"rootProcessInstanceId\":\"1573557\",\"activityInstanceId\":\"1522721\",\"flowNodeProcessName\":\"LCI_DATA_CREATE_CLR\",\"flowNodeStepName\":\"CreateOrder\"}";
		JSONObject workFlowRequest = new JSONObject(workFlowRequestStr);
		String entityData = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG639221728\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"001\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"NJ\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"Pending\" 			}] 		} 	} }";
		JSONObject manifestRequestPayload = new JSONObject(entityData);
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("uteTaskListDocument");
		when(manifestService.fetchManifestRequestPayload(workFlowRequest)).thenReturn(manifestRequestPayload);
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(odsParamConfig);
		when(manifestService.buildManifestDocument(Mockito.anyObject(),Mockito.anyString())).thenReturn(manifestDocument);
		when(serviceUtils.buildExternalTaskId(Mockito.anyString(),Mockito.anyString())).thenReturn("1-313718-4202206");
		JSONObject extId=  new JSONObject("{\"externalTaskId\": \"1-313718-4202206\"}");
		when(serviceUtils.getJsonSchemaValue(Mockito.anyObject(),Mockito.anyString())).thenReturn(extId);
		doNothing().when(falloutServiceSpy).completeUteTaskAndUpdateManifest(Mockito.anyObject(), Mockito.anyObject(), Mockito.anyObject(), Mockito.anyObject(), Mockito.anyString(), Mockito.anyString());
		try{
			falloutServiceSpy.closePendingUteTasks(workFlowRequest);
		}
		catch(Exception e){
			LOGGER.error(e);
		}
	}	
	@Test
	public void testClosePendingUteTasks2() throws ApplicationException
	{
		String manifestDocStr = "{\r\n" + "	\"uteTaskListDocument\": {\r\n" + "		\"document-payload\": {}" + "	}\r\n"
				+ "}";
		JSONObject manifestDocument = new JSONObject(manifestDocStr);
		String workFlowRequestStr = "{\"processInstanceId\":\"1522721\",\"seedInfo\":{\"document_level\":\"VERSION\",\"order_number\":\"30049573\",\"order_version\":\"0\"},\"orderId\":\"30049573\",\"app-key\":\"ZZZDE-VRD\",\"rootProcessInstanceId\":\"1573557\",\"activityInstanceId\":\"1522721\",\"flowNodeProcessName\":\"LCI_DATA_CREATE_CLR\",\"flowNodeStepName\":\"CreateOrder\"}";
		JSONObject workFlowRequest = new JSONObject(workFlowRequestStr);
		String entityData = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\", 		\"entity-attributes\": { 			\"attribute\": [{ 				\"name\": \"order_number\", 				\"value\": \"CCOG639221728\" 			}, { 				\"name\": \"order_version\", 				\"value\": \"001\" 			}, { 				\"name\": \"product_type\", 				\"value\": \"Data\" 			}, { 				\"name\": \"region\", 				\"value\": \"NJ\" 			}, { 				\"name\": \"supp_type\", 				\"value\": \"Pending\" 			}] 		} 	} }";
		JSONObject manifestRequestPayload = new JSONObject(entityData);
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("uteTaskListDocument");
		when(manifestService.fetchManifestRequestPayload(workFlowRequest)).thenReturn(manifestRequestPayload);
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(odsParamConfig);
		when(manifestService.buildManifestDocument(Mockito.anyObject(),Mockito.anyString())).thenReturn(manifestDocument);
		when(serviceUtils.buildExternalTaskId(Mockito.anyString(),Mockito.anyString())).thenReturn("1-313718-4202206");
		JSONObject extId=  new JSONObject("{}");
		when(serviceUtils.getJsonSchemaValue(Mockito.anyObject(),Mockito.anyString())).thenReturn(extId);
		try{
			falloutService.closePendingUteTasks(workFlowRequest);
		}
		catch(Exception e){
			LOGGER.error(e);
		}
	
	}

	@Test
	public void testUpdateUteTaskService() throws ApplicationException
	{
		String finalUtePayLoad = "FinalUTEPAYLOAD";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("uteTaskListDocument");
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(odsParamConfig);
		OdsTransformerConfigDto request = new OdsTransformerConfigDto("transformerKey", "utRequestPayLoad");
		ResponseEntity<String> responseEntity1 = new ResponseEntity<>("{\"test\":\"testValue\"}", HttpStatus.OK);
		JSONObject updateUteTaskPayload = new JSONObject("{\"requestPayload\":{\"app-key\":\"Str\"}}");
		when(odsTransformerConfigService.tranformDocument(request)).thenReturn(finalUtePayLoad);
		when(serviceUtils.callService(Mockito.any(), Mockito.any())).thenReturn(responseEntity1);
		falloutService.updateUteTaskService(updateUteTaskPayload) ;
	}
	@Test
	public void testUpdateUteTaskServiceForNull() throws ApplicationException
	{
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig=null;
		JSONObject updateUteTaskPayload = new JSONObject("{\"requestPayload\":{\"app-key\":\"Str\"}}");
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(odsParamConfig);
		try{
			falloutService.updateUteTaskService(updateUteTaskPayload) ;
		}catch(Exception e){
			LOGGER.error(e);
		}
	}
	@Test
	public void testUpdateUteTaskServiceForNull2() throws ApplicationException
	{
		String finalUtePayLoad = "FinalUTEPAYLOAD";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setValue("uteTaskListDocument");
		JSONObject updateUteTaskPayload = new JSONObject("{\"requestPayload\":{\"app-key\":\"Str\"}}");
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(odsParamConfig);
		OdsTransformerConfigDto request = new OdsTransformerConfigDto("transformerKey", "utRequestPayLoad");
		when(odsTransformerConfigService.tranformDocument(request)).thenReturn(finalUtePayLoad);
		when(serviceUtils.callService(Mockito.any(), Mockito.any())).thenReturn(null);
		try{
			falloutService.updateUteTaskService(updateUteTaskPayload) ;
		}catch(Exception e){
			LOGGER.error(e);
		}
	}

	@Test
	public void composeEntityAttributesForManifestRequestTest() throws ApplicationException{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		String manifestDocStr = "{\r\n" + "	\"uteTaskListDocument\": {\r\n" + "		\"document-payload\": {\r\n"
				+ "\r\n" + "			\"1-313718-4202206\": {\r\n" + "				\"creator\": \"COA\",\r\n"
				+ "				\"externalTaskId\": \"1-313718-4202206\",\r\n"
				+ "				\"taskSource\": \"LCI-VBM-VES\",\r\n" + "				\"userId\": \"COA\",\r\n"
				+ "				\"status\": \"IN PROGRESS\"\r\n" + "			}\r\n" + "		}\r\n" + "	}\r\n"
				+ "}";
		JSONObject requestDoc = new JSONObject(manifestDocStr);
		when(odsTransformerConfigService.tranformDocument(Mockito.any(OdsTransformerConfigDto.class))).thenReturn(manifestDocStr);
		falloutServiceSpy.composeEntityAttributesForManifestRequest("REQUEST_DOC",requestDoc);
	}

	@Test
	public void getManifestDocumentTest()throws ApplicationException{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		JSONObject manifestRequestPayload=new JSONObject();
		String manifestDocumentName="SVC_MANIFEST_DOC";
		JSONObject docPayLoad= new JSONObject();
		docPayLoad.put(Constants.MANIFEST_DOCPAYLOAD_KEY, new JSONObject());
		JSONObject manifestDocument =new JSONObject();
		manifestDocument.put(manifestDocumentName, docPayLoad);
		when(manifestService.buildManifestDocument(Mockito.anyObject(), Mockito.anyString())).thenReturn(manifestDocument);
		falloutServiceSpy.getManifestDocument(manifestRequestPayload,manifestDocumentName);
	}

	@Test
	public void getManifestDocumentTest1()throws ApplicationException{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		JSONObject manifestRequestPayload=new JSONObject();
		String manifestDocumentName="SVC_MANIFEST_DOC";
		JSONObject docPayLoadData= new JSONObject();
		docPayLoadData.put("key", "value");
		JSONObject docPayLoad= new JSONObject();
		docPayLoad.put(Constants.MANIFEST_DOCPAYLOAD_KEY, docPayLoadData);
		JSONObject manifestDocument =new JSONObject();
		manifestDocument.put(manifestDocumentName, docPayLoad);
		when(manifestService.buildManifestDocument(Mockito.anyObject(), Mockito.anyString())).thenReturn(manifestDocument);
		falloutServiceSpy.getManifestDocument(manifestRequestPayload,manifestDocumentName);
	}

	@Test
	public void getManifestDocumentTest2()throws ApplicationException{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		JSONObject manifestRequestPayload=new JSONObject();
		String manifestDocumentName="SVC_DOC";
		JSONObject manifestDocument =new JSONObject();
		manifestDocument.put("SVC_MANIFEST_DOC", "{}");
		when(manifestService.buildManifestDocument(Mockito.anyObject(), Mockito.anyString())).thenReturn(null);
		falloutServiceSpy.getManifestDocument(manifestRequestPayload,manifestDocumentName);
	}

	@Test
	public void getManifestDocumentTest3()throws ApplicationException{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		JSONObject manifestRequestPayload=new JSONObject();
		String manifestDocumentName="SVC_DOC";
		JSONObject manifestDocument =new JSONObject();
		manifestDocument.put("SVC_MANIFEST_DOC", new JSONObject());
		Mockito.doThrow(ApplicationException.class).when(manifestService).buildManifestDocument(Mockito.anyObject(), Mockito.anyString());
		falloutServiceSpy.getManifestDocument(manifestRequestPayload,manifestDocumentName);
	} 
	
	@Test
	public void testCompleteUteTask() throws ApplicationException{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName(PARAM_NAME);
		odsAppParam.setParamKey(PARAM_KEY);
		odsAppParam.setType(PARAM_TYPE);
		odsAppParam.setValue(PARAM_URL);
		JSONObject workflowRequest=new JSONObject();
		workflowRequest.put(Constants.MANIFEST_APP_KEY_STR, "ZZDE-IVAV");
		JSONObject externalTaskIdJson= new JSONObject();
		String finalUtePayLoad="success";
		ResponseEntity<String> localResponseEntity = new ResponseEntity<>("{\"test\":\"testValue\"}", HttpStatus.OK);
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(odsAppParam);
		when(odsTransformerConfigService.tranformDocument(Mockito.any(OdsTransformerConfigDto.class))).thenReturn(finalUtePayLoad);
		when(serviceUtils.callService(Mockito.any(), Mockito.any())).thenReturn(localResponseEntity);
		falloutServiceSpy.completeUteTask(externalTaskIdJson,workflowRequest);
	}
	@Test
	public void testCompleteUteTask1() throws ApplicationException{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		JSONObject externalTaskIdJson= new JSONObject();
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(new OdsParamConfig());
		try{
			falloutServiceSpy.completeUteTask(externalTaskIdJson,new JSONObject());
		}
		catch(Exception e){
			LOGGER.error(e);
		}
	}
	@Test
	public void testCompleteUteTask2() throws ApplicationException{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName(PARAM_NAME);
		odsAppParam.setParamKey(PARAM_KEY);
		odsAppParam.setType(PARAM_TYPE);
		odsAppParam.setValue(PARAM_URL);
		JSONObject workflowRequest=new JSONObject();
		workflowRequest.put(Constants.MANIFEST_APP_KEY_STR, "ZZDE-IVAV");
		JSONObject externalTaskIdJson= new JSONObject();
		String finalUtePayLoad="success";
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(odsAppParam);
		when(odsTransformerConfigService.tranformDocument(Mockito.any(OdsTransformerConfigDto.class))).thenReturn(finalUtePayLoad);
		when(serviceUtils.callService(Mockito.any(), Mockito.any())).thenReturn(null);
		try{
			falloutServiceSpy.completeUteTask(externalTaskIdJson,workflowRequest);
		}
		catch(Exception e){
			LOGGER.error(e);
		}
	}

	@Test(expected = ApplicationException.class)
	public void testhandleRequest5() throws ApplicationException {
		String request = "{\"wfTaskId\" : \"1234\",\"taskAction\":\"REFLOW\",\"wfTaskName\":\"ute\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setOdsRequestLogId(123);
		odsRequestLog.setResponseStatus(StatusCode.IN_PROGRESS.toString());
		odsRequestLog.setTitle("Process");
		odsRequestLog.setTitleVersion("0.2");
		odsRequestLog.setWfTaskId("12346");
		odsRequestLog.setWfTaskStatus("SUCCESS");
		falloutServiceSpy.handleRequest(request);
	}

	@Test(expected = ApplicationException.class)
	public void testhandleRequest6() throws ApplicationException {
		String request = "{\"wfTaskId\" : \"1234\",\"taskAction\":\"ABC\",\"wfTaskName\":\"ute\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setOdsRequestLogId(123);
		odsRequestLog.setResponseStatus(StatusCode.IN_PROGRESS.toString());
		odsRequestLog.setTitle("Process");
		odsRequestLog.setTitleVersion("0.2");
		odsRequestLog.setWfTaskId("12346");
		odsRequestLog.setWfTaskStatus("SUCCESS");
		falloutServiceSpy.handleRequest(request);
	}
	
	@Test(expected = ApplicationException.class)
	public void testhandleRequest7() throws ApplicationException {
		String request = "{\"wfTaskId\" : \"1234\",\"taskAction\":\"\",\"wfTaskName\":\"ute\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setOdsRequestLogId(123);
		odsRequestLog.setResponseStatus(StatusCode.IN_PROGRESS.toString());
		odsRequestLog.setTitle("Process");
		odsRequestLog.setTitleVersion("0.2");
		odsRequestLog.setWfTaskId("12346");
		odsRequestLog.setWfTaskStatus("SUCCESS");
		falloutServiceSpy.handleRequest(request);
	}

	@Test
	public void testRemovePendingRetryDuringSupp() throws ApplicationException {
		LOGGER.info("Entering testRemovePendingRetryDuringSupp");
		String request = "{\"rootProcessInstanceId\": \"	\"}";
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		List<WorkflowFallout> pendingFallOutList = new ArrayList<>();
		WorkflowFallout fallOut = new WorkflowFallout();
		fallOut.setRootCaseId("1140071");
		fallOut.setStatus(Constants.STATUS_PENDING);
		fallOut.setExpiryTime(java.sql.Timestamp.valueOf("2007-09-23 10:10:10.0"));
		pendingFallOutList.add(fallOut);
		when(fallOutRepo.getByRootCaseIdAndStatusAndExpiryTimeIsNotNull(Mockito.anyString(),Mockito.anyString())).thenReturn(pendingFallOutList);
		when(fallOutRepo.save(Mockito.any(WorkflowFallout.class))).thenReturn(fallOut);
		falloutServiceSpy.removePendingAutoRetriesDuringSupp(request);
		LOGGER.info("Entering testRemovePendingRetryDuringSupp");
	}
	
	@Test
	public void testComposeDocumentPayload()
	{
		String manifestDocStr = "{\"taskHeader\": {\"taskSource\": \"as\",\"userId\": \"as\",\"creator\": \"as\"},\"externalTaskId\": \"externalTaskId\" }";
		JSONObject js=new JSONObject(manifestDocStr);
		falloutService.composeDocumentPayload(js);		
	} 
	
	@Test
	public void testAddUteTaskToManifest() throws ApplicationException

	{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		LOGGER.info("Entering addUteTaskToManifest");
		JSONObject uteResponseJson = new JSONObject();
		uteResponseJson.put("externalTaskId", "23452");
		uteResponseJson.put("statusCode", "SUCCESS");
		uteResponseJson.put("statusMessage", "Task Initiated");
		uteResponseJson.put("UTE_TASK_CREATION_STATUS_CODE_SUCCESS", "SUCCESS");
		uteResponseJson.put("UTE_TASK_CREATION_STTUS_MSG_SUCCESS", "Task Initiated");
		uteResponseJson.put("externalTaskId", "externalTaskId");
		String entityData = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\"}}";
		JSONObject manifestRequestPayload = new JSONObject(entityData);
		when(manifestService.fetchManifestRequestPayload(Mockito.anyObject())).thenReturn(manifestRequestPayload);
		OdsParamConfig odsParam = new OdsParamConfig();
		odsParam.setName("ODS_PARAM");
		odsParam.setParamId(12345);
		odsParam.setParamKey("ODS_KEY");
		odsParam.setType("TYPE");
		odsParam.setValue("VALUE");
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsParam);
		Mockito.doReturn(new JSONObject()).when(falloutServiceSpy).composeDocumentPayload(Mockito.anyObject());
		falloutServiceSpy.addUteTaskToManifest(uteResponseJson, new JSONObject(), new JSONObject());
	}
	@Test
	public void testAddUteTaskToManifest1() throws ApplicationException

	{
		JSONObject uteResponseJson = new JSONObject();
		uteResponseJson.put("statusCode", "SUCClESS");
		uteResponseJson.put("statusMessage", "TaskInitiated");
		try{
			falloutService.addUteTaskToManifest(uteResponseJson, new JSONObject(), new JSONObject());
		}
		catch(Exception e){
			LOGGER.error(e);
		}
	}
	@Test
	public void testAddUteTaskToManifest2() throws ApplicationException

	{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		LOGGER.info("Entering addUteTaskToManifest");
		JSONObject uteResponseJson = new JSONObject();
		uteResponseJson.put("externalTaskId", "23452");
		uteResponseJson.put("statusCode", "SUCCESS");
		uteResponseJson.put("statusMessage", "Task Initiated");
		uteResponseJson.put("UTE_TASK_CREATION_STATUS_CODE_SUCCESS", "SUCCESS");
		uteResponseJson.put("UTE_TASK_CREATION_STTUS_MSG_SUCCESS", "Task Initiated");
		uteResponseJson.put("externalTaskId", "externalTaskId");
		String entityData = "{ 	\"entity-data\": { 		\"app-key\": \"ZZZDE-NGPON2\"}}";
		JSONObject manifestRequestPayload = new JSONObject(entityData);
		String mfDocStr = "{ 	\"document-payload\": { 		\"externalTaskId\": {\"ZZZDE-NGPON2\":\"as\"}}}";
		JSONObject manifestDoc= new JSONObject(mfDocStr);
		when(manifestService.fetchManifestRequestPayload(Mockito.anyObject())).thenReturn(manifestRequestPayload);
		OdsParamConfig odsParam = new OdsParamConfig();
		odsParam.setName("ODS_PARAM");
		odsParam.setParamId(12345);
		odsParam.setParamKey("ODS_KEY");
		odsParam.setType("TYPE");
		odsParam.setValue("VALUE");
		when(odsParamConfigRepo.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsParam);
		Mockito.doReturn(new JSONObject("{\"externalTaskId\":{}}")).when(falloutServiceSpy).composeDocumentPayload(Mockito.anyObject());
		falloutServiceSpy.addUteTaskToManifest(uteResponseJson, new JSONObject(), manifestDoc);
	}
	
	@Test
	public void testUpdateStatusAndExpiryTimeService() throws ApplicationException
	{
		FalloutService falloutServiceSpy = Mockito.spy(falloutService);
		LOGGER.info("Entering testUpdateStatusAndExpiryTimeService");
		List<WorkflowFallout> workflowFallOuts = new ArrayList<>();
		WorkflowFallout fallOut = new WorkflowFallout();
		fallOut.setRootCaseId("1140071");
		fallOut.setWfTaskId("12376");
		fallOut.setStatus(Constants.STATUS_PENDING);
		fallOut.setExpiryTime(java.sql.Timestamp.valueOf("2007-09-23 10:10:10.0"));
		workflowFallOuts.add(fallOut);
		when(fallOutRepo.getByStatusAndWfTaskId(Mockito.anyString(),Mockito.anyString())).thenReturn(workflowFallOuts);
		when(fallOutRepo.save(Mockito.any(WorkflowFallout.class))).thenReturn(fallOut);
		falloutServiceSpy.updateStatusAndExpiryTimeByWfTaskIdAndStatus(fallOut.getStatus(), fallOut.getWfTaskId());
		LOGGER.info("Exiting testUpdateStatusAndExpiryTimeService");
	}
	
	

	
}