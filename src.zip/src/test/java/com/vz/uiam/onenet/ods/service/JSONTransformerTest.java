package com.vz.uiam.onenet.ods.service;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.transformer.JSONTransformer;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class JSONTransformerTest {
	private static final Logger LOGGER = Logger.getLogger(JSONTransformerTest.class);
	@InjectMocks
	JSONTransformer jsonTransformer;

	@Mock
	ServiceUtils serviceUtils;

	@Test(expected = ApplicationException.class)
	public void testDoTransform() throws ApplicationException {

		LOGGER.info("Entering testDoTransform");
		String inputDocument = "";
		String requestSchema = "";
		jsonTransformer.doTransform(inputDocument, requestSchema);
		LOGGER.info("Exiting testDoTransform");

	}

	@Test
	public void testDoTransform1() throws ApplicationException {

		LOGGER.info("Entering testDoTransform1");
		JSONObject inputDocument = new JSONObject();
		inputDocument.put("test", "testVal");
		String requestSchema = "{\"test\" : \"val\"}";
		jsonTransformer.doTransform(inputDocument, requestSchema);
		LOGGER.info("Exiting testDoTransform1");

	}

	@Test
	public void testDoTransform2() throws ApplicationException {

		LOGGER.info("Entering testDoTransform2");
		String inputDocument = "{}";
		String requestSchema = "{\"test\" : \"val\"}";
		jsonTransformer.doTransform(inputDocument, requestSchema);
		LOGGER.info("Exiting testDoTransform2");

	}

}