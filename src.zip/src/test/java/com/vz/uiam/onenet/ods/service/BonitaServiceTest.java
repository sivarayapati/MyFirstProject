package com.vz.uiam.onenet.ods.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class BonitaServiceTest {

	@InjectMocks
	BonitaService bonitaService;

	@Mock
	OdsInterfaceRequestRepository odsRequestRepo;

	@Mock
	OdsParamConfigRepository odsParamConfigRepository;

	@Mock
	RestTemplate restTemplate;

	@Mock
	ServiceUtils serviceUtils;

	@Test(expected = ApplicationException.class)
	public void completeBonitaReceiveTaskFail() throws ApplicationException {
		String correlationData = "testCorrelation";
		OdsParamConfig odsAppParam = new OdsParamConfig();
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString()))
				.thenReturn(odsAppParam);
		bonitaService.completeBonitaReceiveTask(correlationData);
	}

	@Test
	public void completeBonitaReceiveTaskSuccess() throws ApplicationException {
		String correlationData = "testCorrelation";
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setValue("Test");
		ResponseEntity<String> responseEntity4 = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.OK);
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString()))
				.thenReturn(odsAppParam);
		when(serviceUtils.callService(any(), any(HttpEntity.class))).thenReturn(responseEntity4);
		bonitaService.completeBonitaReceiveTask(correlationData);
	}
	
	@Test(expected = ApplicationException.class)
	public void completeBonitaReceiveTaskFailure() throws ApplicationException {
		String correlationData = "testCorrelation";
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setValue("Test");
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString()))
				.thenReturn(odsAppParam);
		when(serviceUtils.callService(any(), any(HttpEntity.class))).thenReturn(null);
		bonitaService.completeBonitaReceiveTask(correlationData);
	}

}
