package com.vz.uiam.onenet.ods.service;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsMilestoneConfigRepository;


@RunWith(MockitoJUnitRunner.class)
public class OdsMilestoneConfigServiceTest {

private static final Logger LOGGER = Logger.getLogger(OdsMilestoneConfigServiceTest.class);
	
	@InjectMocks
	OdsMilestoneConfigService odsMilestoneConfigService;

	@Mock
	OdsMilestoneConfigRepository odsMilestoneConfigRepository;
	
	@Test(expected = ApplicationException.class)
	public void testDoMilestoneConfigValidation1() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation1");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation1");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoMilestoneConfigValidation2() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation2");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("");
		odsMilestoneConfig.setMilestoneName("Milestone1");
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation2");
	}
	@Test(expected = ApplicationException.class)
	public void testDoMilestoneConfigValidation21() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation21");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		odsMilestoneConfig.setMilestoneName("");
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation21");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoMilestoneConfigValidation3() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation3");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("");
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation3");
	}
	@Test(expected = ApplicationException.class)
	public void testDoMilestoneConfigValidation31() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation31");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("App1");
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setRequestSchema("");
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation31");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoMilestoneConfigValidation4() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation4");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("App1");
		odsMilestoneConfig.setTargetEndpointUrl("");
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation4");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoMilestoneConfigValidation5() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation5");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("App1");
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation5");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoMilestoneConfigValidation6() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation6");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("App1");
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		odsMilestoneConfig.setRequestDocumentName("TEST-Message");
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation6");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoMilestoneConfigValidation7() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation7");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("App1");
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		odsMilestoneConfig.setRequestDocumentName("TEST-Message");
		odsMilestoneConfig.setTransformationType("JSON");
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation7");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoMilestoneConfigValidation8() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation8");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("App1");
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		odsMilestoneConfig.setRequestDocumentName("TEST-Message");
		odsMilestoneConfig.setTransformationType("JSON");
		odsMilestoneConfig.setRouteProtocol("REST");
		odsMilestoneConfig.setSendMilestone("false");
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation8");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoMilestoneConfigValidation9() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation9");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("App1");
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		odsMilestoneConfig.setRequestDocumentName("TEST-Message");
		odsMilestoneConfig.setTransformationType("JSON");
		odsMilestoneConfig.setRouteProtocol("REST");
		odsMilestoneConfig.setSendMilestone("");
		odsMilestoneConfig.setSendFalloutNotification("false");
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation9");
	}
	
	@Test
	public void testDoMilestoneConfigValidation11() throws ApplicationException {
		LOGGER.info("Entering testDoMilestoneConfigValidation11");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("App1");
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		odsMilestoneConfig.setRequestDocumentName("TEST-Message");
		odsMilestoneConfig.setTransformationType("JSON");
		odsMilestoneConfig.setRouteProtocol("REST");
		odsMilestoneConfig.setSendMilestone("");
		odsMilestoneConfig.setSendFalloutNotification("");
		
		odsMilestoneConfigService.doMilestoneConfigValidation(odsMilestoneConfig);
		
		LOGGER.info("Entering testDoMilestoneConfigValidation11");
	}
	
	@Test
	public void testGetUpdatedOdsMilestoneConfigRecord1() throws ApplicationException {
		LOGGER.info("Entering testGetUpdatedOdsMilestoneConfigRecord1");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfigService.getUpdatedOdsMilestoneConfigRecord(odsMilestoneConfig, null);
		
		LOGGER.info("Entering testGetUpdatedOdsMilestoneConfigRecord1");
	}
	
	@Test
	public void testGetUpdatedOdsMilestoneConfigRecord2() throws ApplicationException {
		LOGGER.info("Entering testGetUpdatedOdsMilestoneConfigRecord2");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("App1");
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setUserName("abcd");
		odsMilestoneConfig.setPassword("xxxxxxx");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		odsMilestoneConfig.setRequestDocumentName("TEST-Message");
		odsMilestoneConfig.setTransformationType("JSON");
		odsMilestoneConfig.setRouteProtocol("REST");
		odsMilestoneConfig.setSendMilestone("");
		odsMilestoneConfig.setSendFalloutNotification("");
		
		odsMilestoneConfigService.getUpdatedOdsMilestoneConfigRecord(odsMilestoneConfig, new OdsMilestoneConfig());
		
		LOGGER.info("Entering testGetUpdatedOdsMilestoneConfigRecord2");
	}
	
	@Test
	public void testGetUpdatedOdsMilestoneConfigRecord3() throws ApplicationException {
		LOGGER.info("Entering testGetUpdatedOdsMilestoneConfigRecord3");
		
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setMilestoneName("Milestone1");
		odsMilestoneConfig.setDestinationAppName("App1");
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setUserName("abcd");
		odsMilestoneConfig.setPassword("xxxxxxx");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		odsMilestoneConfig.setRequestDocumentName("TEST-Message");
		odsMilestoneConfig.setTransformationType("JSON");
		odsMilestoneConfig.setRouteProtocol("REST");
		odsMilestoneConfig.setSendMilestone("YES");
		odsMilestoneConfig.setSendFalloutNotification("YES");
		
		odsMilestoneConfigService.getUpdatedOdsMilestoneConfigRecord(odsMilestoneConfig, new OdsMilestoneConfig());
		
		LOGGER.info("Entering testGetUpdatedOdsMilestoneConfigRecord3");
	}
	}
