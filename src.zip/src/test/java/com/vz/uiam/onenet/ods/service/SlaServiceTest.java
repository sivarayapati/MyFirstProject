package com.vz.uiam.onenet.ods.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class SlaServiceTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(SlaServiceTest.class);

	@InjectMocks
	SlaService slaService;

	@Mock
	ServiceUtils serviceUtils;

	@Mock
	OdsInterfaceRequestRepository odsRequestRepo;
	
	@Mock
	RestTemplate restTemplate;
	
	@Mock
	ResponseEntity<String> responseEntity;
	
	@Mock
	OdsParamConfigRepository odsParamConfigRepository;
	
	
	
	@Test
	public void createPayloadtoCloseBonitaTaskTest() throws ApplicationException {
		LOGGER.info("Entering createPayloadtoCloseBonitaTaskTest1");
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setName("name");
		odsParamConfig.setParamId(123);
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setType("APPLICATION_PARAM");
		odsParamConfig.setValue("{\"contents\": {	\"jobStatus\": \"$.RESPONSE_STATUS_PARAM\"}}");
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString())).thenReturn(odsParamConfig);
		
		OdsInterfaceRequest odsIntfReq = new OdsInterfaceRequest();
		odsIntfReq.setCoreleationPayload("{\r\n" + " \"bonitaProcessName\": \"WorkflowSLATest\", \r\n"
					+ " \"processInstanceId\": \" 12338 \", \r\n" + " \"activityInstanceId\": \" 4566 \", \r\n"
					+ " \"bonitaFlowNodeName\": \"CollectOrder\", \r\n" + " \"contract\": { \r\n"
					+ " \"id\": \"1516889288755|34567|7654\" \r\n" + " },\r\n" + " }\r\n" + " } \r\n" + "");
		when(odsRequestRepo.findByTransactionIdAndStatus(anyString(), anyString())).thenReturn(odsIntfReq);
		
		slaService.createPayloadtoCloseBonitaTask("{\"id\":\"001|120520170221\"}");
		
		LOGGER.info("Exiting createPayloadtoCloseBonitaTaskTest");
	}
	

	@Test
	public void createSLAEntryTest() throws ApplicationException {
		LOGGER.info("Entering createSLAEntryTest");
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setName("CREATE_SLA_URL");
		odsParamConfig.setParamId(123);
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setType("APPLICATION_PARAM");
		odsParamConfig.setValue("http://url");
		
		OdsParamConfig odsParamConfig1 = new OdsParamConfig();
		odsParamConfig1.setType("WORKFLOW_CORRELATION_PARAM");
		odsParamConfig1.setValue("$.manifestDocumentName.status.statusCode");
		odsParamConfig1.setParamKey("LCI_DATA_Pre_Activation_AddONT");
		odsParamConfig1.setName("CORRELATION_SCHEMA");
		
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString())).thenReturn(odsParamConfig1);
				
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.APPLICATION_PARAM.toString(), Constants.CREATE_TASK_SLA_URL)).thenReturn(odsParamConfig);
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		
		slaService.createSLAEntry("{\"flowNodeProcessName\": \"LCI_DATA_Pre_Activation\",\r\n" + 
				"	\"flowNodeStepName\": \"AddONT\"}");
		
		LOGGER.info("Exiting createSLAEntryTest");
	}
	

	@Test(expected = ApplicationException.class)
	public void createSLAEntryTest2() throws ApplicationException {
		LOGGER.info("Entering createSLAEntryTest2");
		OdsParamConfig odsParamConfig1 = new OdsParamConfig();
		odsParamConfig1.setType("WORKFLOW_CORRELATION_PARAM");
		odsParamConfig1.setValue("$.manifestDocumentName.status.statusCode");
		odsParamConfig1.setParamKey("LCI_DATA_Pre_Activation_AddONT");
		odsParamConfig1.setName("CORRELATION_SCHEMA");

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString()))
				.thenReturn(odsParamConfig1);

		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);

		slaService.createSLAEntry(
				"{\"flowNodeProcessName\": \"LCI_DATA_Pre_Activation\",\r\n" + "	\"flowNodeStepName\": \"AddONT\"}");
		LOGGER.info("Exiting createSLAEntryTest2");

	}
	@Test(expected=ApplicationException.class)
	public void createPayloadtoCloseBonitaTaskTest1() throws ApplicationException {
		LOGGER.info("Entering createPayloadtoCloseBonitaTaskTest1");
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setName("name");
		odsParamConfig.setParamId(123);
		odsParamConfig.setParamKey("ODS");
		odsParamConfig.setType("APPLICATION_PARAM");
		odsParamConfig.setValue("{\"contents\": {	\"jobStatus\": \"$.RESPONSE_STATUS_PARAM\"}}");
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString())).thenReturn(odsParamConfig);
		
		OdsInterfaceRequest odsIntfReq = null;
				when(odsRequestRepo.findByTransactionIdAndStatus(anyString(), anyString())).thenReturn(odsIntfReq);
		
		slaService.createPayloadtoCloseBonitaTask("{\"id\":\"001|120520170221\"}");
		
		LOGGER.info("Exiting createPayloadtoCloseBonitaTaskTest");
	}
	@SuppressWarnings("unchecked")
	@Test(expected = ApplicationException.class)
	public void createSLAEntryTest3() throws ApplicationException {
		LOGGER.info("Entering createSLAEntryTest3");
		OdsParamConfig odsParamConfig1 = new OdsParamConfig();
		odsParamConfig1.setType("WORKFLOW_CORRELATION_PARAM");
		odsParamConfig1.setValue("$.manifestDocumentName.status.statusCode");
		odsParamConfig1.setParamKey("LCI_DATA_Pre_Activation_AddONT");
		odsParamConfig1.setName("CORRELATION_SCHEMA");

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString()))
				.thenReturn(odsParamConfig1);

		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenThrow(JSONException.class);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);

		slaService.createSLAEntry(
				"{\"flowNodeProcessName\": \"LCI_DATA_Pre_Activation\",\r\n" + "	\"flowNodeStepName\": \"AddONT\"}");
		LOGGER.info("Exiting createSLAEntryTest3");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void createSLAEntryTest4() throws ApplicationException {
		LOGGER.info("Entering createSLAEntryTest4");
		OdsParamConfig odsParamConfig1 = null;

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString()))
				.thenReturn(odsParamConfig1);

		slaService.createSLAEntry(
				"{\"flowNodeProcessName\": \"LCI_DATA_Pre_Activation\",\r\n" + "	\"flowNodeStepName\": \"AddONT\"}");
		LOGGER.info("Exiting createSLAEntryTest4");

	}

	@SuppressWarnings("unchecked")
	@Test(expected = ApplicationException.class)
	public void createSLAEntryTest5() throws ApplicationException {
		LOGGER.info("Entering createSLAEntryTest5");
		OdsParamConfig odsParamConfig1 = new OdsParamConfig();
		odsParamConfig1.setType("WORKFLOW_CORRELATION_PARAM");
		odsParamConfig1.setValue("$.manifestDocumentName.status.statusCode");
		odsParamConfig1.setParamKey("LCI_DATA_Pre_Activation_AddONT");
		odsParamConfig1.setName("CORRELATION_SCHEMA");

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(anyString(), anyString(), anyString()))
				.thenReturn(odsParamConfig1);
		OdsParamConfig odsAppParam = null;
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.APPLICATION_PARAM.toString(), Constants.CREATE_TASK_SLA_URL))
						.thenReturn(odsAppParam);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenThrow(JSONException.class);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);

		slaService.createSLAEntry(
				"{\"flowNodeProcessName\": \"LCI_DATA_Pre_Activation\",\r\n" + "	\"flowNodeStepName\": \"AddONT\"}");
		LOGGER.info("Exiting createSLAEntryTest5");

	}
}
