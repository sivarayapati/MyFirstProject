package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import java.sql.SQLException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSConfigPayload;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSKeyDetails;
import com.vz.uiam.onenet.ods.service.ODSConfigService;

@RunWith(MockitoJUnitRunner.class)
public class OdsConfigControllerMockitoTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(OdsConfigControllerMockitoTest.class);

	@InjectMocks
	ODSConfigController odsConfigController;

	@Mock
	ODSConfigService odsConfigService;

	@Test
	public void testCreateOrUpdateOdsConfig() throws ApplicationException {
		LOGGER.info("Entering testCreateOrUpdateOdsConfig");

		ODSConfigPayload request = Mockito.mock(ODSConfigPayload.class);
		ODSConfigPayload odsConfigResp = null;

		when(odsConfigService.createOrUpdateOdsConfig(request)).thenReturn(odsConfigResp);

		odsConfigController.createOrUpdateOdsConfig(request);

		LOGGER.info("Exiting testCreateOrUpdateOdsConfig");
	}

	@Test
	public void testCreateOrUpdateOdsConfig1() throws ApplicationException {
		LOGGER.info("Entering testCreateOrUpdateOdsConfig");

		ODSConfigPayload request = Mockito.mock(ODSConfigPayload.class);

		when(odsConfigService.createOrUpdateOdsConfig(request)).thenThrow(SQLException.class);

		odsConfigController.createOrUpdateOdsConfig(request);

		LOGGER.info("Exiting testCreateOrUpdateOdsConfig");
	}

	@Test
	public void testGetOdsConfigurations() throws ApplicationException {
		LOGGER.info("Entering testGetOdsConfigurations");

		ODSKeyDetails request = Mockito.mock(ODSKeyDetails.class);
		ODSConfigPayload odsConfigResp = null;

		when(odsConfigService.getOdsConfigurations(request)).thenReturn(odsConfigResp);

		odsConfigController.getOdsConfigurations(request);

		LOGGER.info("Exiting testGetOdsConfigurations");
	}

	@Test
	public void testGetOdsConfigurations1() throws ApplicationException {
		LOGGER.info("Entering testGetOdsConfigurations1");

		ODSKeyDetails request = Mockito.mock(ODSKeyDetails.class);

		when(odsConfigService.getOdsConfigurations(request)).thenThrow(ApplicationException.class);

		odsConfigController.getOdsConfigurations(request);

		LOGGER.info("Exiting testGetOdsConfigurations1");
	}

	@Test
	public void testGetOdsConfigurations2() throws ApplicationException {
		LOGGER.info("Entering testGetOdsConfigurations2");

		ODSKeyDetails request = Mockito.mock(ODSKeyDetails.class);

		when(odsConfigService.getOdsConfigurations(request)).thenThrow(SQLException.class);

		odsConfigController.getOdsConfigurations(request);

		LOGGER.info("Exiting testGetOdsConfigurations2");
	}

	@Test
	public void testDeleteOdsConfigurations() throws ApplicationException {
		LOGGER.info("Entering testDeleteOdsConfigurations");

		ODSKeyDetails request = Mockito.mock(ODSKeyDetails.class);
		Mockito.doThrow(SQLException.class).when(odsConfigService).deleteOdsConfiguration(request);

		odsConfigController.deleteOdsConfigurations(request);

		LOGGER.info("Exiting testDeleteOdsConfigurations");
	}

}
