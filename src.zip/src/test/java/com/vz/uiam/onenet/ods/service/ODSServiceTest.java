package com.vz.uiam.onenet.ods.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.jayway.jsonpath.PathNotFoundException;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsServiceRouterMapDetails;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestTransactionIdMapRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsServiceRouterMapRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.OdsResponse;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.TransformRequest;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class ODSServiceTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ODSServiceTest.class);

	@InjectMocks
	ODSService odsService;

	@Mock
	ServiceUtils serviceUtils;
	
	@Mock
	OdsInterfaceRequestRepository odsRequestRepo;
	
	@Mock
	RestTemplate restTemplate;
	
	@Mock
	ResponseEntity<String> responseEntity;
	
	@Mock
	OdsMandatoryAttrsService odsMandatoryAttrsService;
	
	@Mock
	OdsParamConfigRepository odsParamConfigRepository;
	
	@Mock
	OdsRequestTransactionIdMapRepository odsRequestTransactionIdMapRepository;
	
	@Mock
	NotesService notesService;
	
	@Mock
	OdsServiceRouteMapService odsServiceRouteMapService;
	
	@Mock
	OdsServiceRouterMapRepository odsServiceRouterMapRepository;
	
	@Mock
	OdsRequestLogService odsRequestLogService;
	
	@Mock
	OdsRequestResponseTransactionIdMapService odsRequestResponseTransactionIdMapService;
	
	@Mock
	ODSTransformationService odsTransformationService;
	
	@Mock
	OdsRequestLogRepository odsRequestLogRepository;
	
	@Mock
	ODSInterfaceRequestService odsInterfaceRequestService;
	
	@Mock
	ManifestService manifestService;
	
	@Mock
	OdsParamConfigService odsParamConfigService;
	
	private static final String PARAM_NAME = "CREATE_UTE_TASK_URL";
	private static final String PARAM_KEY = "ODS";
	private static final String PARAM_TYPE = "ODS_PARAM";
	private static final String PARAM_URL = "http://woody.ebiz.verizon.com:8003/IVAV-One-Dispatcher/proxyservices/CreateUteTask";
	OdsServiceRouterMapDetails details;
	OdsParamConfig odsAppParam ;
	
	@Before
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Before
	public void setUp() {
		odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName(PARAM_NAME);
		odsAppParam.setParamKey(PARAM_KEY);
		odsAppParam.setType(PARAM_TYPE);
		odsAppParam.setValue(PARAM_URL);
		
		details= new OdsServiceRouterMapDetails();
		details.setAppKey("ZZZDE-RQN");
		details.setFlowNodeProcessName("SPLS-ORDER-VALIDATION");
		details.setFlowNodeStepName("ValidateCustomBidCaseId");
		details.setRouterProtocol("REST");
		details.setTransformationType("JSON");
		details.setTargetEndPointUrl("http://ccpe.verizon.com");
		details.setRequestDocumentName("srDocument");
	}
	
	@Test
	public void testHandleRestRouting1() throws ApplicationException {
		LOGGER.info("Entering testHandleRestRouting1");
		
		OdsInterfaceRequest odsIntfReq = new OdsInterfaceRequest();
		JSONObject workflowRequestJsonObj = new JSONObject();
		workflowRequestJsonObj.put(Constants.FLOW_STEP_NAME, "TEST_STEP");
		
		ODSService odsServiceSpy = Mockito.spy(odsService);
		
		Mockito.doReturn(new ResponseConfigParams()).when(odsServiceSpy).createResponseConfigParam(Mockito.any(), Mockito.any(), Mockito.any());
		when(serviceUtils.convertObjectToJsonString(Mockito.any())).thenReturn("{}");
		when(odsRequestRepo.findByTransactionIdAndStatus(anyString(), anyString())).thenReturn(odsIntfReq);
		Mockito.doNothing().when(notesService).addRequestInNotesService(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
		
		Mockito.doReturn("http://vnmws.ebiz.verizon.com/activateBlocking").when(serviceUtils).generateDynamicTargetEndPointUrl(any(), anyString(),anyString());
		
		odsServiceSpy.handleRestRouting(new OdsServiceRouterMapDetails(), "", "", "", workflowRequestJsonObj, "TestKey", "LCI_DATA_Pre_Activation_AddONT");
		
		LOGGER.info("Exiting testHandleRestRouting1");
	}
	
	@Test
	public void testUserNamePasswordEncoder() throws ApplicationException {
		LOGGER.info("Entering testUserNamePasswordEncoder");
		
		serviceUtils.userNamePasswordEncoder("IVAPP", "ivapp");
		
		LOGGER.info("Exiting testUserNamePasswordEncoder");
	}
	
	@Test(expected = ApplicationException.class)
	public void testGetDocumentFromCustomServicer1() throws ApplicationException {
		LOGGER.info("Entering testGetDocumentFromCustomServicer1");
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		
		odsService.getDocumentFromCustomService("http://customSvc.vz.com/getData", "{}");
		
		LOGGER.info("Exiting testGetDocumentFromCustomServicer1");
	}
	
	@Test
	public void testGetDocumentFromCustomServicer2() throws ApplicationException {
		LOGGER.info("Entering testGetDocumentFromCustomServicer2");
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		when(responseEntity.getBody()).thenReturn("{}");
		
		odsService.getDocumentFromCustomService("http://customSvc.vz.com/getData", "{}");
		
		LOGGER.info("Exiting testGetDocumentFromCustomServicer2");
	}
	
	@Test(expected = ApplicationException.class)
	public void testGetDocumentFromCustomServicer3() throws ApplicationException {
		LOGGER.info("Entering testGetDocumentFromCustomServicer3");
		
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
		
		odsService.getDocumentFromCustomService("http://customSvc.vz.com/getData", "{}");
		
		LOGGER.info("Exiting testGetDocumentFromCustomServicer3");
	}
	
	@Test(expected = ApplicationException.class)
	public void testValidateMandatoryAttributes1() throws ApplicationException {
		LOGGER.info("Entering testValidateMandatoryAttributes1");
		
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo");
		
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);

		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(odsMandatoryAttrsList);
		
		odsService.validateMandatoryAttributes(new JSONObject(), "ZZZZ-Testing");
		
		LOGGER.info("Exiting testValidateMandatoryAttributes1");
	}
	
	@Test(expected = ApplicationException.class)
	public void testValidateMandatoryAttributes2() throws ApplicationException {
		LOGGER.info("Entering testValidateMandatoryAttributes2");
		
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo[2]");
		
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);

		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(odsMandatoryAttrsList);
		
		odsService.validateMandatoryAttributes(new JSONObject("{\"a\":\"b\"}"), "ZZZZ-Testing");
		
		LOGGER.info("Exiting testValidateMandatoryAttributes2");
	}
	
	@Test(expected = ApplicationException.class)
	public void testValidateMandatoryAttributes3() throws ApplicationException {
		LOGGER.info("Entering testValidateMandatoryAttributes3");
		
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.a");
		
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);

		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(odsMandatoryAttrsList);
		
		odsService.validateMandatoryAttributes(new JSONObject("{\"a\":\"\"}"), "ZZZZ-Testing");
		
		LOGGER.info("Exiting testValidateMandatoryAttributes3");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoTransformation1() throws ApplicationException {
		LOGGER.info("Entering testDoTransformation1");
		
		TransformRequest transformRequest = new TransformRequest();
		
		odsService.doTransformation(transformRequest, "TestKey", "LCI_DATA_Pre_Activation_AddONT");
		
		LOGGER.info("Exiting testDoTransformation1");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoTransformation2() throws ApplicationException {
		LOGGER.info("Entering testDoTransformation2");
		
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setTransformationType("JSON");
		
		odsService.doTransformation(transformRequest, "TestKey", "LCI_DATA_Pre_Activation_AddONT");
		
		LOGGER.info("Exiting testDoTransformation2");
	}
	
	@Test(expected = ApplicationException.class)
	public void testDoTransformation3() throws ApplicationException {
		LOGGER.info("Entering testDoTransformation3");
		
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setTransformationType("JSON");
		transformRequest.setInputDocument("{}");
		
		odsService.doTransformation(transformRequest, "TestKey", "LCI_DATA_Pre_Activation_AddONT");
		
		LOGGER.info("Exiting testDoTransformation3");
	}
	
	@Test
	public void testValidateAndBuildCorelationPayload() throws ApplicationException {
		LOGGER.info("Entering testValidateAndBuildCorelationPayload");
		
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(null, OdsParamConfigType.WORKFLOW_CORRELATION_PARAM.toString(), Constants.CORRELATION_SCHEMA))
				.thenThrow(Exception.class);
		
		odsService.validateAndBuildCorelationPayload(new JSONObject(),anyString());
		
		LOGGER.info("Exiting testValidateAndBuildCorelationPayload");
	}
	
	@Test(expected = ApplicationException.class)
	public void testValidateManifestAttributes1() throws ApplicationException {
		LOGGER.info("Entering testValidateManifestAttributes1");
		
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo");
		
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);

		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(odsMandatoryAttrsList);
		
		odsService.validateManifestAttributes(new JSONObject(), odsMandatoryAttrsList, new JSONArray());
		
		LOGGER.info("Exiting testValidateManifestAttributes1");
	}
	
	@Test(expected = ApplicationException.class)
	public void testValidateManifestAttributes2() throws ApplicationException {
		LOGGER.info("Entering testValidateManifestAttributes2");
		
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo[2]");
		
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);

		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(odsMandatoryAttrsList);
		
		odsService.validateManifestAttributes(new JSONObject("{\"a\":\"b\"}"), odsMandatoryAttrsList, new JSONArray());
		
		LOGGER.info("Exiting testValidateManifestAttributes2");
	}
	
	@Test(expected = ApplicationException.class)
	public void testValidateManifestAttributes3() throws ApplicationException {
		LOGGER.info("Entering testValidateManifestAttributes3");
		
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.a");
		
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);

		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(odsMandatoryAttrsList);
		
		odsService.validateManifestAttributes(new JSONObject("{\"a\":\"\"}"), odsMandatoryAttrsList, new JSONArray());
		
		LOGGER.info("Exiting testValidateManifestAttributes3");
	}
	
	@Test(expected = ApplicationException.class)
	public void testGetGeneratedTransactionId1() throws ApplicationException {
		LOGGER.info("Entering testGetGeneratedTransactionId1");
		
		JSONObject workflowRequestJsonObj = new JSONObject();
		workflowRequestJsonObj.put(Constants.FLOW_PROCESS_NAME, "Testing_Process");
		workflowRequestJsonObj.put(Constants.FLOW_STEP_NAME, "Testing_Step");
		
		when(odsRequestTransactionIdMapRepository.findByFlowNodeProcessNameAndFlowNodeStepName(anyString(), anyString())).thenThrow(Exception.class);
		
		odsService.getGeneratedTransactionId(workflowRequestJsonObj, "{}");
		
		LOGGER.info("Exiting testGetGeneratedTransactionId1");
	}
	
	@Test(expected = ApplicationException.class)
	public void testGetGeneratedTransactionId2() throws ApplicationException {
		LOGGER.info("Entering testGetGeneratedTransactionId2");
		
		JSONObject workflowRequestJsonObj = new JSONObject();
		workflowRequestJsonObj.put(Constants.FLOW_PROCESS_NAME, "Testing_Process");
		workflowRequestJsonObj.put(Constants.FLOW_STEP_NAME, "Testing_Step");
		
		when(odsRequestTransactionIdMapRepository.findByFlowNodeProcessNameAndFlowNodeStepName(anyString(), anyString())).thenReturn(null);
		
		odsService.getGeneratedTransactionId(workflowRequestJsonObj, "{}");
		
		LOGGER.info("Exiting testGetGeneratedTransactionId2");
	}
	
	@Test
	public void testGetGeneratedTransactionId3() throws ApplicationException {
		LOGGER.info("Entering testGetGeneratedTransactionId3");
		
		JSONObject workflowRequestJsonObj = new JSONObject();
		workflowRequestJsonObj.put(Constants.FLOW_PROCESS_NAME, "Testing_Process");
		workflowRequestJsonObj.put(Constants.FLOW_STEP_NAME, "Testing_Step");
		
		OdsRequestTransactionIdMap odsRequestTransactionIdMap = new OdsRequestTransactionIdMap();
		odsRequestTransactionIdMap.setTransactionIdKey("123");
		
		when(serviceUtils.generateTransactionIdUsingTransactionIdKey(anyString(), anyString())).thenReturn("1111|2222");
		
		when(odsRequestTransactionIdMapRepository.findByFlowNodeProcessNameAndFlowNodeStepName(anyString(), anyString())).thenReturn(odsRequestTransactionIdMap);
		
		odsService.getGeneratedTransactionId(workflowRequestJsonObj, "{}");
		
		LOGGER.info("Exiting testGetGeneratedTransactionId3");
	}
	
	@Test
	public void testHandleTransformationAndRouting() throws ApplicationException {
		LOGGER.info("Entering testHandleTransformationAndRouting");
		String request = "{  	\"app-key\": \"ZZZDE-VRD\",  	\"flowNodeProcessName\": \"LCI_DATA_ORDER\",  	\"flowNodeStepName\": \"ORDER_DETAILS\",  	\"seedInfo\": {  		\"order_number\": \"11272017002\",  		\"order_version\": \"0\",  		\"document_level\": \"VERSION\"  	}  }";
		JSONObject workflowRequestJsonObj = new JSONObject(request);
		OdsServiceRouterMapDetails odsSericeRouteMapDetails = new OdsServiceRouterMapDetails();
		odsSericeRouteMapDetails.setAppKey("ZZZDE-VRD");
		odsSericeRouteMapDetails.setFlowNodeProcessName("LCI_DATA_ORDER");
		odsSericeRouteMapDetails.setFlowNodeStepName("ORDER_DETAILS");
		odsSericeRouteMapDetails.setTransformationType("JSON");
		odsSericeRouteMapDetails.setUserName("userName");
		odsSericeRouteMapDetails.setPassword("pwd");
		String transactionId="23435354";
		String documentPayload="{}";
		String manifestPayload="{}";
		String correlationPayload="{}";
		ODSService odsServiceSpy = Mockito.spy(odsService);
		String tranformedDocumentStr = "{}";
        Mockito.doReturn(tranformedDocumentStr).when(odsServiceSpy).doTransformation(Mockito.any(), Mockito.any(), Mockito.any());
        OdsInterfaceRequest requestFromDb = new OdsInterfaceRequest();
        requestFromDb.setRequest("{}");
        when(odsRequestRepo.findByTransactionIdAndStatus(transactionId, StatusCode.REQUEST_PENDING.toString())).thenReturn(requestFromDb);
		odsServiceSpy.handleTransformationAndRouting(transactionId, workflowRequestJsonObj, odsSericeRouteMapDetails, documentPayload, manifestPayload, correlationPayload);

		LOGGER.info("Exiting testHandleTransformationAndRouting");
	}
	@Test
	public void testHandleTransformationAndRouting1() throws ApplicationException {
		LOGGER.info("Entering testHandleTransformationAndRouting");
		String request = "{  	\"app-key\": \"ZZZDE-VRD\",  	\"flowNodeProcessName\": \"LCI_DATA_ORDER\",  	\"flowNodeStepName\": \"ORDER_DETAILS\",  	\"seedInfo\": {  		\"order_number\": \"11272017002\",  		\"order_version\": \"0\",  		\"document_level\": \"VERSION\"  	}  }";
		JSONObject workflowRequestJsonObj = new JSONObject(request);
		OdsServiceRouterMapDetails odsSericeRouteMapDetails = new OdsServiceRouterMapDetails();
		odsSericeRouteMapDetails.setAppKey("ZZZDE-VRD");
		odsSericeRouteMapDetails.setFlowNodeProcessName("LCI_DATA_ORDER");
		odsSericeRouteMapDetails.setFlowNodeStepName("ORDER_DETAILS");
		odsSericeRouteMapDetails.setTransformationType("JSON");
		odsSericeRouteMapDetails.setUserName("");
		odsSericeRouteMapDetails.setPassword("hfh");
		String transactionId="23435354";
		String documentPayload="{}";
		String manifestPayload="{}";
		String correlationPayload="{}";
		ODSService odsServiceSpy = Mockito.spy(odsService);
		String tranformedDocumentStr = "{}";
        Mockito.doReturn(tranformedDocumentStr).when(odsServiceSpy).doTransformation(Mockito.any(), Mockito.any(), Mockito.any());
       	odsServiceSpy.handleTransformationAndRouting(transactionId, workflowRequestJsonObj, odsSericeRouteMapDetails, documentPayload, manifestPayload, correlationPayload);

		LOGGER.info("Exiting testHandleTransformationAndRouting");
	}
	@Test
	public void testHandleRestRouting() throws ApplicationException {
		LOGGER.info("Entering testHandleTransformationAndRouting");
		String request = "{  	\"app-key\": \"ZZZDE-VRD\",  	\"flowNodeProcessName\": \"LCI_DATA_ORDER\",  	\"flowNodeStepName\": \"ORDER_DETAILS\",  	\"seedInfo\": {  		\"order_number\": \"11272017002\",  		\"order_version\": \"0\",  		\"document_level\": \"VERSION\"  	}  }";
		JSONObject workflowRequestJsonObj = new JSONObject(request);
		OdsServiceRouterMapDetails odsSericeRouteMapDetails = new OdsServiceRouterMapDetails();
		odsSericeRouteMapDetails.setAppKey("ZZZDE-VRD");
		odsSericeRouteMapDetails.setFlowNodeProcessName("LCI_DATA_ORDER");
		odsSericeRouteMapDetails.setFlowNodeStepName("ORDER_DETAILS");
		odsSericeRouteMapDetails.setTransformationType("JSON");
		odsSericeRouteMapDetails.setUserName("");
		odsSericeRouteMapDetails.setPassword("hfh");
		String transactionId="23435354";
		String header="";
		String appKey="appkey}";
		String requestKey="reqKey";
		ODSService odsServiceSpy = Mockito.spy(odsService);
		String tranformedDocumentStr = "{}";
        Mockito.doReturn(tranformedDocumentStr).when(odsServiceSpy).doTransformation(Mockito.any(), Mockito.any(), Mockito.any());
       	odsServiceSpy.handleRestRouting(odsSericeRouteMapDetails, request, header, transactionId, workflowRequestJsonObj, appKey, requestKey);
		LOGGER.info("Exiting testHandleTransformationAndRouting");
	}
	
	@Test(expected = ApplicationException.class)
	public void handleOdsRequestfailTest() throws ApplicationException {
		String odsRequest= "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		ODSService odsServiceSpy = Mockito.spy(odsService);
		
		List<String> titleParams = new ArrayList<>();
		titleParams.add(Constants.TITLE_LITERAL);
		titleParams.add(Constants.TITLE_VERSION_LITERAL);
		
		OdsParamConfig odsAppParamT = new OdsParamConfig();
		odsAppParamT.setParamId(9);
		odsAppParamT.setName(PARAM_NAME);
		odsAppParamT.setParamKey(PARAM_KEY);
		odsAppParamT.setType(PARAM_TYPE);
		odsAppParamT.setValue(PARAM_URL);
		
		List<OdsParamConfig> listOdsParamConfig = new ArrayList<>();
		listOdsParamConfig.add(odsAppParamT);
		
		when(odsServiceRouterMapRepository.findByFlowNodeProcessNameAndFlowNodeStepNameAndRegion(details.getFlowNodeProcessName(),
					details.getFlowNodeStepName(),"NORTH")).thenReturn(details);
		when(odsParamConfigRepository.findByParamKeyAndTypeAndNameIn(details.getAppKey(),
				OdsParamConfigType.APPLICATION_PARAM.toString(),titleParams)).thenReturn(listOdsParamConfig);
		
		odsServiceSpy.handleOdsRequest(odsRequest);
	}
	
	@Test(expected = ApplicationException.class)
	public void handleOdsRequestTest() throws ApplicationException {
		String odsRequest= "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		ODSService odsServiceSpy = Mockito.spy(odsService);
			
		List<String> titleParams = new ArrayList<>();
		titleParams.add(Constants.TITLE_LITERAL);
		titleParams.add(Constants.TITLE_VERSION_LITERAL);
		
		OdsParamConfig odsAppParamT = new OdsParamConfig();
		odsAppParamT.setParamId(9);
		odsAppParamT.setName(PARAM_NAME);
		odsAppParamT.setParamKey(PARAM_KEY);
		odsAppParamT.setType(PARAM_TYPE);
		odsAppParamT.setValue(PARAM_URL);
		
		List<OdsParamConfig> listOdsParamConfig = new ArrayList<>();
		listOdsParamConfig.add(odsAppParamT);
		
		when(odsServiceRouterMapRepository.findByFlowNodeProcessNameAndFlowNodeStepNameAndRegion(Mockito.anyString(),Mockito.anyString(), Mockito.anyString())).thenReturn(details);
		when(odsParamConfigRepository.findByParamKeyAndTypeAndNameIn(details.getAppKey(),
				OdsParamConfigType.APPLICATION_PARAM.toString(),titleParams)).thenReturn(listOdsParamConfig);
		
		odsServiceSpy.handleOdsRequest(odsRequest);
	}
	@Test
	public void handleOdsRequestTest3() throws ApplicationException {
		String odsRequest= "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		ODSService odsServiceSpy = Mockito.spy(odsService);
		List<String> titleParams = new ArrayList<>();
		titleParams.add(Constants.TITLE_LITERAL);
		titleParams.add(Constants.TITLE_VERSION_LITERAL);
				
		List<OdsParamConfig> listOdsParamConfig = new ArrayList<>();
		listOdsParamConfig.add(odsAppParam);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		JSONObject manifestRequestPayload = new JSONObject();
		JSONObject documentPayload = new JSONObject();
		OdsRequestTransactionIdMap odsRequestTransactionIdMap = new OdsRequestTransactionIdMap();
		odsRequestTransactionIdMap.setTransactionIdKey("123");
		odsRequestTransactionIdMap.setTransactionIdKey(Constants.DEFAULT);
		String transactionId = "1514976672203|34567|7654";
		
		Mockito.doNothing().when(odsServiceSpy).validateRequest(Mockito.any());
		Mockito.doNothing().when(odsServiceSpy).validateDependentAttributes(Mockito.any());
		when(odsParamConfigRepository.findByParamKeyAndTypeAndNameIn(Mockito.anyString(),Mockito.anyString(), Mockito.anyListOf(String.class))).thenReturn(listOdsParamConfig);
		when(odsRequestLogService.createOdsRequestLogEntry(Mockito.any(), Mockito.anyString(), Mockito.anyString())).thenReturn(odsRequestLog);	
		Mockito.doReturn(manifestRequestPayload).when(odsServiceSpy).buildManifestRequestPayload(Mockito.any());
		Mockito.doReturn(documentPayload).when(odsServiceSpy).fetchManifestDocuments(Mockito.any(), Mockito.any());
		Mockito.doNothing().when(odsServiceSpy).validateMandatoryAttributesinManifestResponse(Mockito.any(), Mockito.any());
		when(odsRequestResponseTransactionIdMapService.findByFlowNodeProcessNameAndFlowNodeStepName(Mockito.anyString(),Mockito.anyString())).thenReturn(odsRequestTransactionIdMap);
		Mockito.doReturn(transactionId).when(odsServiceSpy).generateDefaultTransactionId(Mockito.anyString(),Mockito.anyString());
		Mockito.doReturn(details).when(odsServiceSpy).getServiceRouterMapDetails(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		when(odsTransformationService.doTransformation(Mockito.any(TransformRequest.class))).thenReturn("");
		when(serviceUtils.mergeJSONObjects(Mockito.any(), Mockito.any())).thenReturn(new JSONObject("{}") );
		when(odsRequestLogRepository.save(odsRequestLog)).thenReturn(odsRequestLog);
		Mockito.doNothing().when(odsInterfaceRequestService).createInterfaceServiceRecord(Mockito.any());
		
		odsServiceSpy.handleOdsRequest(odsRequest);
	}
	
	@Test(expected=ApplicationException.class)
	public void testValidateRequest() throws ApplicationException
	{
		JSONObject workflowRequest = new JSONObject();
		workflowRequest.put(Constants.FLOW_PROCESS_NAME, "");
		workflowRequest.put(Constants.FLOW_STEP_NAME, "");
		odsService.validateRequest(workflowRequest);
	}
	
	@Test(expected=ApplicationException.class)
	public void testValidateRequest1() throws ApplicationException
	{
		JSONObject workflowRequest = new JSONObject();
		workflowRequest.put(Constants.FLOW_PROCESS_NAME, "processName");
		workflowRequest.put(Constants.FLOW_STEP_NAME, "");
		odsService.validateRequest(workflowRequest);
	}
	
	@Test(expected=ApplicationException.class)
	public void validateDependentAttributesTest() throws ApplicationException
	{
		JSONObject workflowRequest = new JSONObject();
		workflowRequest.put(Constants.FLOW_PROCESS_NAME, "processName");
		workflowRequest.put(Constants.FLOW_STEP_NAME, "stepName");
		ODSService odsServiceSpy = Mockito.spy(odsService);
		details =new OdsServiceRouterMapDetails();
		details.setTargetEndPointUrl("");
		details.setTransformationType("");
		details.setRouterProtocol("");
		details.setRequestDocumentName("order");
		Mockito.doReturn(details).when(odsServiceSpy).getServiceRouterMapDetails(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		odsServiceSpy.validateDependentAttributes(workflowRequest);
	}
	
	@Test
	public void validateDependentAttributesTest1() throws ApplicationException
	{
		JSONObject workflowRequest = new JSONObject();
		workflowRequest.put(Constants.FLOW_PROCESS_NAME, "processName");
		workflowRequest.put(Constants.FLOW_STEP_NAME, "stepName");
		ODSService odsServiceSpy = Mockito.spy(odsService);
		details.setRequestSchema("<TEST></TEST>");
		Mockito.doReturn(details).when(odsServiceSpy).getServiceRouterMapDetails(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		odsServiceSpy.validateDependentAttributes(workflowRequest);
	}
	
	@Test
	public void fetchManifestRequestPayloadTest() throws ApplicationException {
		JSONObject workflowRequest = new JSONObject();
		workflowRequest.put(Constants.FLOW_PROCESS_NAME, "processName");
		workflowRequest.put(Constants.FLOW_STEP_NAME, "stepName");
		ODSService odsServiceSpy = Mockito.spy(odsService);
		Mockito.doReturn(details).when(odsServiceSpy).getServiceRouterMapDetails(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		when(manifestService.fetchManifestRequestPayload(workflowRequest)).thenReturn(new JSONObject());
		odsServiceSpy.buildManifestRequestPayload(workflowRequest);
	}
	@Test
	public void fetchManifestRequestPayloadTest1() throws ApplicationException {
		JSONObject workflowRequest = new JSONObject();
		workflowRequest.put(Constants.FLOW_PROCESS_NAME, "processName");
		workflowRequest.put(Constants.FLOW_STEP_NAME, "stepName");
		ODSService odsServiceSpy = Mockito.spy(odsService);
		details =new OdsServiceRouterMapDetails();
		details.setTargetEndPointUrl("http://test.com");
		details.setTransformationType("XML");
		details.setRouterProtocol("SOAP");
		details.setRequestDocumentName("");
		details.setRequestSchema("<TEST></TEST>");
		Mockito.doReturn(details).when(odsServiceSpy).getServiceRouterMapDetails(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		odsServiceSpy.buildManifestRequestPayload(workflowRequest);
	}
	
	@Test
	public void fetchManifestRequestPayloadTest2() throws ApplicationException {
		String odsRequest= "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		
		JSONObject workflowRequest = new JSONObject(odsRequest);
		workflowRequest.put(Constants.FLOW_PROCESS_NAME, "processName");
		workflowRequest.put(Constants.FLOW_STEP_NAME, "stepName");
		ODSService odsServiceSpy = Mockito.spy(odsService);
		ResponseEntity<String> responseEntityT = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.OK);

		Mockito.doReturn(details).when(odsServiceSpy).getServiceRouterMapDetails(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(odsAppParam);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntityT);
		odsServiceSpy.buildManifestRequestPayload(workflowRequest);
	}
	
	@Test
	public void fetchManifestDocumentsTest() throws ApplicationException {
		String odsRequest= "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		
		JSONObject workflowRequest = new JSONObject(odsRequest);
		JSONObject manifestRequestPayload = new JSONObject();
		
		ODSService odsServiceSpy = Mockito.spy(odsService);
		Mockito.doReturn(details).when(odsServiceSpy).getServiceRouterMapDetails(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		odsServiceSpy.fetchManifestDocuments(manifestRequestPayload,workflowRequest);
	}

	@Test
	public void getTransformedResponseTest() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		ODSService odsServiceSpy = Mockito.spy(odsService);
		OdsRequestTransactionIdMap odsRequestTransactionIdMap = new OdsRequestTransactionIdMap();
		odsRequestTransactionIdMap.setTransactionIdKey("123");
		odsRequestTransactionIdMap.setTransactionIdKey(Constants.DEFAULT);
		ResponseEntity<String> responseEntityT = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.OK);
		String transactionId = "1514976672203|34567|7654";
	    when(odsServiceRouteMapService.getServiceRouterMapDetails(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(details);
	    when(odsParamConfigRepository.findByParamKeyAndTypeAndName(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(odsAppParam);
	    when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntityT);
	    when(odsRequestTransactionIdMapRepository.findByFlowNodeProcessNameAndFlowNodeStepName(Mockito.anyString(),Mockito.anyString())).thenReturn(odsRequestTransactionIdMap);
		Mockito.doReturn(transactionId).when(odsServiceSpy).generateDefaultTransactionId(Mockito.anyString(),Mockito.anyString());
	
		odsServiceSpy.getTransformedResponse(odsRequest);
	}
	
	@Test(expected=NullPointerException.class)
	public void getTransformedResponseTest1() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		ODSService odsServiceSpy = Mockito.spy(odsService);
		OdsRequestTransactionIdMap odsRequestTransactionIdMap = new OdsRequestTransactionIdMap();
		odsRequestTransactionIdMap.setTransactionIdKey("123");
		odsRequestTransactionIdMap.setTransactionIdKey(Constants.DEFAULT);
		ResponseEntity<String> responseEntityT = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.OK);
		String transactionId = "1514976672203|34567|7654";
		details.setRequestSchema("<Test></Test>");
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();
		
		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo");
		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);
		JSONObject workflowRequestJsonObj = new JSONObject(odsRequest);
		String documentPayload="{}";
		String manifestPayload="{}";
		String correlationPayload="{}";
        OdsResponse response = new OdsResponse();
		when(odsServiceRouteMapService.getServiceRouterMapDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(details);
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(null);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntityT);
		when(odsRequestTransactionIdMapRepository.findByFlowNodeProcessNameAndFlowNodeStepName(Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsRequestTransactionIdMap);
		Mockito.doReturn(transactionId).when(odsServiceSpy).generateDefaultTransactionId(Mockito.anyString(),
				Mockito.anyString());
		when(odsMandatoryAttrsService.getMandatoryAttributeList(Mockito.anyString())).thenReturn(odsMandatoryAttrsList);
		Mockito.doNothing().when(odsServiceSpy).validateManifestAttributes(Mockito.any(), Mockito.anyListOf(OdsMandatoryAttributes.class), Mockito.any());
		Mockito.doReturn(response).when(odsServiceSpy).handleTransformationAndRouting(transactionId, workflowRequestJsonObj, details, documentPayload, manifestPayload, correlationPayload);
		odsServiceSpy.getTransformedResponse(odsRequest);
	}

	@Test(expected = ApplicationException.class)
	public void getTransformedResponseTest2() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		ODSService odsServiceSpy = Mockito.spy(odsService);
		OdsRequestTransactionIdMap odsRequestTransactionIdMap = new OdsRequestTransactionIdMap();
		odsRequestTransactionIdMap.setTransactionIdKey("123");
		odsRequestTransactionIdMap.setTransactionIdKey(Constants.DEFAULT);
		ResponseEntity<String> responseEntityT = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.OK);
		String transactionId = "1514976672203|34567|7654";
		details.setRouterProtocol("");
		when(odsServiceRouteMapService.getServiceRouterMapDetails(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(details);
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsAppParam);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
				.thenReturn(responseEntityT);
		when(odsRequestTransactionIdMapRepository.findByFlowNodeProcessNameAndFlowNodeStepName(Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsRequestTransactionIdMap);
		Mockito.doReturn(transactionId).when(odsServiceSpy).generateDefaultTransactionId(Mockito.anyString(),
				Mockito.anyString());

		odsServiceSpy.getTransformedResponse(odsRequest);
	}

	@Test(expected = ApplicationException.class)
	public void checkRequestDocumentNamePresentTest() throws ApplicationException {
		details.setRequestDocumentName("");
		odsService.checkRequestDocumentNamePresent(details);
	}

	@Test(expected = ApplicationException.class)
	public void validateTargetEndPointUrlTest() throws ApplicationException {
		details.setTargetEndPointUrl("");
		odsService.validateTargetEndPointUrl(details);
	}

	@Test(expected = ApplicationException.class)
	public void validateAppkeyTest() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		JSONObject workflowRequest = new JSONObject(odsRequest);
		odsService.validateAppkey(workflowRequest);
	}

	@Test(expected = NullPointerException.class)
	public void doTransformationTest() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		ODSService odsServiceSpy = Mockito.spy(odsService);
		TransformRequest transformRequest = new TransformRequest();
		transformRequest.setTransformationType("JSON");
		transformRequest.setInputDocument(odsRequest);
		transformRequest.setRequestSchema("{}");
		String appKey = "ZZZDE-RQN";
		String requestKey = "reqKey";
		odsServiceSpy.doTransformation(transformRequest, appKey, requestKey);
	}

	@Test(expected = ApplicationException.class)
	public void validateMandatoryAttributesTest() throws ApplicationException {
		JSONObject manifestDocument = new JSONObject();
		String key = "ZZZDE-RQN";
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();

		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo");

		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);

		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(odsMandatoryAttrsList);
		when(serviceUtils.getJsonSchemaValue(Mockito.anyString(), Mockito.anyString()))
				.thenThrow(PathNotFoundException.class);
		odsService.validateMandatoryAttributes(manifestDocument, key);
	}

	@Test
	public void validateMandatoryAttributesTest1() throws ApplicationException {
		JSONObject manifestDocument = new JSONObject();
		String key = "ZZZDE-RQN";
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();

		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo");

		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);

		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(odsMandatoryAttrsList);
		when(serviceUtils.getJsonSchemaValue(Mockito.anyString(), Mockito.anyString())).thenReturn("order");
		odsService.validateMandatoryAttributes(manifestDocument, key);
	}

	@Test(expected = ApplicationException.class)
	public void validateMandatoryAttributesTest2() throws ApplicationException {
		JSONObject manifestDocument = new JSONObject();
		String key = "ZZZDE-RQN";
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<OdsMandatoryAttributes>();

		OdsMandatoryAttributes inputOdsMandatoryAttrs = new OdsMandatoryAttributes();
		inputOdsMandatoryAttrs.setAttrKey("ZZZZ-Testing");
		inputOdsMandatoryAttrs.setJsonPath("$.orderInfo");

		odsMandatoryAttrsList.add(inputOdsMandatoryAttrs);

		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(odsMandatoryAttrsList);
		when(serviceUtils.getJsonSchemaValue(Mockito.anyString(), Mockito.anyString())).thenReturn("");
		odsService.validateMandatoryAttributes(manifestDocument, key);
	}

	@Test(expected = ApplicationException.class)
	public void validateAndBuildManifestPayloadTest() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		JSONObject workflowRequest = new JSONObject(odsRequest);
		details.setRequestSchema("{}");
		List<OdsMandatoryAttributes> mandatoryAttrbsList = null;
		when(odsMandatoryAttrsService.getMandatoryAttributeList(anyString())).thenReturn(mandatoryAttrbsList);
		odsService.validateAndBuildManifestPayload(workflowRequest, details);
	}

	@Test(expected = ApplicationException.class)
	public void generateTransactionId() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		JSONObject workflowRequest = new JSONObject(odsRequest);
		String documentPayload = "";
		when(odsRequestTransactionIdMapRepository.findByFlowNodeProcessNameAndFlowNodeStepName(anyString(),
				anyString())).thenThrow(Exception.class);
		odsService.getGeneratedTransactionId(workflowRequest, documentPayload);
	}

	@Test
	public void validateMandatoryAttributesinManifestResponseTest() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";

		JSONObject workflowRequest = new JSONObject(odsRequest);
		JSONObject manifestDocument = new JSONObject();

		ODSService odsServiceSpy = Mockito.spy(odsService);
		odsServiceSpy.validateMandatoryAttributesinManifestResponse(manifestDocument, workflowRequest);
	}

	@Test
	public void buildContentSchemaTest() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		OdsParamConfig odsAppParamT = new OdsParamConfig();
		odsAppParamT.setParamId(9);
		odsAppParamT.setName(PARAM_NAME);
		odsAppParamT.setParamKey(PARAM_KEY);
		odsAppParamT.setType(PARAM_TYPE);
		odsAppParamT.setValue(PARAM_URL);
		JSONObject workflowRequest = new JSONObject(odsRequest);
		ODSService odsServiceSpy = Mockito.spy(odsService);
		when(odsParamConfigService.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsAppParamT);
		odsServiceSpy.buildContentSchema(workflowRequest);
	}

	@Test
	public void buildContentSchemaTest1() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		OdsParamConfig odsAppParamT = null;

		JSONObject workflowRequest = new JSONObject(odsRequest);
		ODSService odsServiceSpy = Mockito.spy(odsService);
		when(odsParamConfigService.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsAppParamT);
		odsServiceSpy.buildContentSchema(workflowRequest);
	}

	@Test
	public void getServiceRouterMapDetailsTest() throws ApplicationException {
		OdsServiceRouterMapDetails serviceRouteMapDetails = new OdsServiceRouterMapDetails();
		serviceRouteMapDetails.setAppKey("ZZZDE-VRD");
		serviceRouteMapDetails.setFlowNodeProcessName("LCI_DATA_ORDER");
		serviceRouteMapDetails.setFlowNodeStepName("ORDER_DETAILS");
		when(odsServiceRouterMapRepository.findByFlowNodeProcessNameAndFlowNodeStepName(Mockito.anyString(),
				Mockito.anyString())).thenReturn(details);
		odsService.getServiceRouterMapDetails("processName", "stepName", "");

	}

	@Test
	public void buildContentSchemaTest2() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		OdsParamConfig odsAppParamT = null;

		JSONObject workflowRequest = new JSONObject(odsRequest);
		ODSService odsServiceSpy = Mockito.spy(odsService);
		when(serviceUtils.buildKey(Mockito.anyString(), Mockito.anyString())).thenThrow(Exception.class);
		when(odsParamConfigService.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsAppParamT);
		odsServiceSpy.buildContentSchema(workflowRequest);
	}

	@Test
	public void buildCorelationPayloadTest() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		OdsParamConfig odsAppParamT = new OdsParamConfig();

		JSONObject workflowRequest = new JSONObject(odsRequest);
		ODSService odsServiceSpy = Mockito.spy(odsService);
		when(odsParamConfigService.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsAppParamT);
		odsServiceSpy.buildCorelationPayload(workflowRequest);
	}

	@Test
	public void buildCorelationPayloadTest1() throws ApplicationException {
		String odsRequest = "{ 	\"app-key\": \"ZZZDE-RQN\", 	\"processInstanceId\": \"12338\", 	\"activityInstanceId\": \"4566\", 	\"rootProcessInstanceId\": \"23452\", 	\"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", 	\"flowNodeStepName\": \"ValidateCustomBidCaseId\", 	\"appRegion\": \"North\", 	\"seedInfo\": { 		\"sr_number\": \"ZYTXAD-001\" 	} }";
		OdsParamConfig odsAppParamT = new OdsParamConfig();

		JSONObject workflowRequest = new JSONObject(odsRequest);
		ODSService odsServiceSpy = Mockito.spy(odsService);
		when(serviceUtils.buildKey(Mockito.anyString(), Mockito.anyString())).thenThrow(Exception.class);
		when(odsParamConfigService.findByParamKeyAndTypeAndName(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(odsAppParamT);
		odsServiceSpy.buildCorelationPayload(workflowRequest);
	}
	public String getfinaldocument() {
		return " {\"requestPayload\":{\"processInstanceId\":\"34567\",\"serviceUrl\":\"https://vnmws.ebiz.verizon.com\",\"seedInfo\":{\"product_type\":\"Data\",\"supp_type\":\"Pending\",\"order_number\":\"CCOG639221728\",\"region\":\"NJ\","
				+ "\"order_version\":\"001\"},\"app-key\":\"ZZZDE-NGPON2\",\"rootProcessInstanceId\":\"56789\",\"activityInstanceId\":\"7654\",\"parentProcessInstanceId\":\"45678\",\"flowNodeProcessName\":\"LCI_OVER_NGPON2_Pre_Activation\","
				+ "\"rootProcessName\":\"Root\",\"flowNodeStepName\":\"RetrieveONTSerialNumber\"},\"transactionId\":\"1511938969413|34567|7654\",\"PlanningMessage\":{\"document-payload\":{\"PlanningMsgRsp\":{\"InvSystem\":\"IVAPP\",\"ActivationInfo\":{\"PonDetails\":{\"PonId\":\"00000000000000000000000001010111\","
				+ "\"PonSystemId\":\"00000000000100001001\",\"ChannelPartitionIndex\":\"0010\",\"ServiceType\":\"DATA\",\"BackupPonId\":\"00000000000000110010000100010111\",\"PonType\":\"NGPON2\"}},"
				+ "\"AssignmentReuse\":\"NO\",\"PreActRequired\":\"YES\",\"OrderNumber\":\"CCOGSSPDISCOTEST19\",\"OrderId\":706514,\"VersionNumber\":\"000\",\"xmlns\":\"\",\"SubscriptionId\":\":-1--1@NYCMNYWART1\","
				+ "\"ReconnectONTDel\":\"NO\",\"OdnData\":{\"MDU_SIP_ALTL\":\"NO\",\"CTID\":\"70/VAXA/706514/ /VZNY\",\"IvappPonCircuitName\":\"S/GRCYNYGCT01/1-1-9-1\",\"DataVlan\":{\"STag\":1024,"
				+ "\"CircuitName\":\"test\",\"CTag\":4095},\"PvcNniChange\":\"YES\",\"IspPvcCircuitId\":\"70/VAXA/706514/ /VZNY\",\"IvappPonCircuitId\":103792,\"MocaProvisioned\":\"N\",\"IvappSecondaryPonCircuitName\":\"S/GRCYNYGCT01/7-25-2-1\","
				+ "\"ReplacementPortNumber\":\"\",\"SvcPortNumber\":1,\"ServiceTNDetails\":{\"SwitchClli\":\"\",\"PrimaryLecTN\":\"\"}},\"RouterCilli\":\"NYCMNYWART1\",\"PonCircuit\":{\"DistHub\":{\"DistributionFiber\":{\"StrandNumber\":2,"
				+ "\"Name\":\"H8989\"},\"HubPortNumber\":2,\"Splitter\":{\"PortNumber\":1,\"Name\":\"H8989A\"},\"XConnectAction\":\"Make\",\"GpsParams\":{\"Latitude\":26.154106,\"Longitude\":-93.129155},\"Name\":\"H8989\",\"AddressInfo\":\"HOME\"},\"Ont\":{\"PAIndicator\":\"Compatible\",\"ManufacturerName\":\"ALTL\""
				+ ",\"DesktopModel\":\"Y\",\"Address\":{\"HouseNo\":620,\"StreetName\":\"NOTTINGHAM\",\"TuName\":\"SYRACUSE\",\"Zip\":13224,\"Type\":\"RD\",\"SubLocation\":\"FLR GRD\",\"State\":\"NY\",\"MduSfu\":0,\"AddressId\":48053419},\"MocaCapable\":\"Y\","
				+ "\"Make\":\"ALTL\",\"GpsParams\":{\"Latitude\":\"\",\"Longitude\":\"\"},\"EthernetSpeed\":\"N\",\"RequiredAction\":\"Install\",\"Type\":\"SFU\",\"SequenceNumber\":1,\"Model\":\"O-211M-E\",\"GponProvisioned\":\"Y\",\"InactiveONT\":\"N\"},"
				+ "\"Olt\":{\"FeederFiber\":{\"StrandNumber\":1,\"Name\":\"F8989\"},\"SlotId\":1,\"Rack\":1,\"ManufacturerName\":\"ALTL\",\"Clli\":\"GRNKNYGNRCH\",\"OltPortNumber\":9,\"EmsId\":\"\",\"ShelfId\":1,\"OltTid\":\"TMPAFLERICERICE907\",\"Name\":\"ALTL-ONT211M\"},"
				+ "\"FiberJackCapable\":\"N\",\"DropTerminal\":{\"RELATED_ADDR_ID\":[90213,90132,90134,90135,189459,90214,90212,90215,237267,237232,237233,156737,189460,189461,90133,90153,143599,237268,189440],\"ConnectorType\":\"SC/APC\",\"DropAction\":\"TERMINATE\",\"GpsParams\":{\"Latitude\":26.154476,\"Longitude\""
				+ ":-93.128649},\"DropStatus\":\"TERMINATED\",\"DropType\":\"MDU_INSIDE\","
				+ "\"PortNumber\":2,\"Name\":102853,\"AddressInfo\":\"HOME\"},\"IvappPonCircuitId\":103792,\"PonCircuitName\":\"S/GRCYNYGCT01/1-1-9-1\",\"FiberDrop\":{\"StrandNumber\":2}}}}}}";
	}
	
	
	
}
