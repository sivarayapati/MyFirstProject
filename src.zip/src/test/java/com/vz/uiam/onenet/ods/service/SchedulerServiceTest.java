package com.vz.uiam.onenet.ods.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsSchedulerLock;
import com.vz.uiam.onenet.ods.jpa.dao.model.WorkflowFallout;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsInterfaceRequestRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsSchedulerLockRepository;
import com.vz.uiam.onenet.ods.jpa.dao.repository.WorkflowFalloutRepo;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class SchedulerServiceTest {

	private static final Logger LOGGER = Logger.getLogger(SchedulerServiceTest.class);
	@InjectMocks
	SchedulerService schedulerService;

	@InjectMocks
	BonitaService bonitaService;
	
	@Mock
	FalloutService falloutService;

	@Mock
	OdsRequestLogRepository odsRequestLogRepository;
	
	@Mock
	OdsSchedulerLockRepository odsSchedulerLockRepository;
	
	@Mock
	OdsParamConfigRepository odsParamConfigRepository;
	
	@Mock
	OdsInterfaceRequestRepository odsInterfaceRequestRepository;
	
	@Mock
	ServiceUtils serviceUtils;
	
	@Mock
	WorkflowFalloutRepo fallOutRepo;
	
	@Mock
	OdsParamConfigRepository odsParamConfigRepo;
	
	
    @Test
	public void testRetryBonitaTaskCompletion() throws ApplicationException {

		LOGGER.info("Entering testRetryBonitaTaskCompletion");
		OdsSchedulerLock odsSchdulerLock = new OdsSchedulerLock();
		odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_OFF);
		odsSchdulerLock.setLockKey(Constants.ODS_RETRY_BONITA_TASK_COMPLETION_KEY);
		List<OdsRequestLog> failedEntries = new ArrayList<>();
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setWfTaskCompletionPayload("testCorrelation");
		odsRequestLog.setResponseStatus(StatusCode.SUCCESS.toString());
		odsRequestLog.setWfTaskStatus(Constants.FAILURE);
		Mockito.doNothing().when(falloutService).closeBonitaTask(odsRequestLog);
		failedEntries.add(odsRequestLog);
		when(odsSchedulerLockRepository.findByLockKeyAndLockValue(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(odsSchdulerLock);
		when(odsSchedulerLockRepository.save(Mockito.any(OdsSchedulerLock.class))).thenReturn(odsSchdulerLock);
		when(odsRequestLogRepository.findByWfTaskStatusAndResponseStatus(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(failedEntries);
		schedulerService.retryBonitaTaskCompletion();
		LOGGER.info("Exiting testRetryBonitaTaskCompletion");

	}
    
    @Test
    public void testMonitorPendingTasks() throws ApplicationException {
    	LOGGER.info("Entering testMonitorPendingTasks");
    	OdsSchedulerLock odsSchdulerLock = new OdsSchedulerLock();
		odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_OFF);
		odsSchdulerLock.setLockKey(Constants.ODS_RETRY_BONITA_TASK_COMPLETION_KEY);
		List<OdsRequestLog> expiredEntries = new ArrayList<>();
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setWfTaskCompletionPayload("testCorrelation");
		odsRequestLog.setResponseStatus(Constants.ODS_REQUEST_LOG_STATUS_PENDING);
		odsRequestLog.setWfTaskStatus(Constants.ODS_REQUEST_LOG_STATUS_PENDING);
		odsRequestLog.setWfTaskName("Test Step");
		String request = "{  	\"app-key\": \"ZZZDE-VRD\",  	\"flowNodeProcessName\": \"LCI_DATA_ORDER\",  	\"flowNodeStepName\": \"ORDER_DETAILS\",  	\"seedInfo\": {  		\"order_number\": \"11272017002\",  		\"order_version\": \"0\",  		\"document_level\": \"VERSION\"  	}  }";
		odsRequestLog.setWfRequestPayload(request);
		expiredEntries.add(odsRequestLog);
		when(odsSchedulerLockRepository.findByLockKeyAndLockValue(Mockito.anyString(), Mockito.anyString()))
		.thenReturn(odsSchdulerLock);
		when(odsSchedulerLockRepository.save(Mockito.any(OdsSchedulerLock.class))).thenReturn(odsSchdulerLock);
		when(odsRequestLogRepository.findByWfTaskStatusAndResponseStatusAndExpiryTimeBefore(Mockito.anyString(), Mockito.anyString(), Mockito.any()))
		.thenReturn(expiredEntries);
		
		List<OdsInterfaceRequest> odsInterfaceRequests = new ArrayList<>();
		OdsInterfaceRequest odsInterfaceRequest = new OdsInterfaceRequest();
		odsInterfaceRequests.add(odsInterfaceRequest);
		when(odsInterfaceRequestRepository.findByTaskIdAndStatus(Mockito.anyString(), Mockito.anyString()))
		.thenReturn(odsInterfaceRequests);
		
		when(falloutService.getUteTaskListdocument(Mockito.any())).thenReturn(new JSONObject());
		Mockito.doNothing().when(falloutService).createOrUpdateUTETaskForFallout(Mockito.any(), Mockito.any());
		when(odsInterfaceRequestRepository.save(Mockito.any(OdsInterfaceRequest.class))).thenReturn(odsInterfaceRequest);
		schedulerService.monitorPendingTasks();
		LOGGER.info("Exiting testMonitorPendingTasks");
    }
    
    @Test
	public void testRetryFailedTasks() throws ApplicationException {
		LOGGER.info("Entering testRetryFailedTasks");
		OdsSchedulerLock odsSchdulerLock = new OdsSchedulerLock();
		odsSchdulerLock.setLockValue(Constants.ODS_SCHEDULER_SWITCH_OFF);
		odsSchdulerLock.setLockKey(Constants.ODS_RETRY_FAILED_TASK);
		List<WorkflowFallout> expiredEntries = new ArrayList<>();
		WorkflowFallout fallout = new WorkflowFallout();
		fallout.setExpiryTime(java.sql.Timestamp.valueOf("2018-06-23 10:10:10.0"));
		fallout.setStatus(Constants.STATUS_PENDING);
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setWfTaskCompletionPayload("testCorrelation");
		odsRequestLog.setResponseStatus(Constants.FAILURE);
		odsRequestLog.setWfTaskId(fallout.getWfTaskId());
		OdsParamConfig odsAppParam = new OdsParamConfig();
		odsAppParam.setParamId(9);
		odsAppParam.setName("asyncOdsRequestProxy");
		odsAppParam.setParamKey("ODS");
		odsAppParam.setType("ODS_PARAM");
		odsAppParam.setValue("https://gquvosbdev.ebiz.verizon.com/ods/AsyncODSRequestProxy");
		String request = "{  	\"app-key\": \"ZZZDE-VRD\",  	\"flowNodeProcessName\": \"LCI_DATA_ORDER\",  	\"flowNodeStepName\": \"ORDER_DETAILS\",  	\"seedInfo\": {  		\"order_number\": \"11272017002\",  		\"order_version\": \"0\",  		\"document_level\": \"VERSION\"  	}  }";
		odsRequestLog.setWfRequestPayload(request);
		expiredEntries.add(fallout);
		when(odsSchedulerLockRepository.findByLockKeyAndLockValue(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(odsSchdulerLock);
		when(odsSchedulerLockRepository.save(Mockito.any(OdsSchedulerLock.class))).thenReturn(odsSchdulerLock);
		when(fallOutRepo.getByStatusAndExpiryTimeBefore(Mockito.anyString(), Mockito.any())).thenReturn(expiredEntries);
		when(odsRequestLogRepository.findByWfTaskIdAndResponseStatus(Mockito.anyString(), Mockito.any()))
				.thenReturn(odsRequestLog);
		when(fallOutRepo.save(Mockito.any(WorkflowFallout.class))).thenReturn(fallout);
		Mockito.doNothing().when(serviceUtils).callService(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		schedulerService.retryFailedTasks();
		LOGGER.info("Exiting testRetryFailedTasks");
	}


}
