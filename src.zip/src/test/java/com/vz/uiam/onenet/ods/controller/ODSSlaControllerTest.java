package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class ODSSlaControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSSlaControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}
    @Test
	public void createBonitaPayloadForSLATest() {
		try {
			LOGGER.info("****************************Entering to createBonitaPayloadForSLATest*****************************");
			URI url = new URI("/sla/createBonitaPayloadForSLA");
			String payload = "{\"id\":\"001|120520170221\"}";
			this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(payload))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();
			LOGGER.info(
					"****************************Exiting from createBonitaPayloadForSLATest*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createBonitaPayloadForSLATest: ", e);
		}
	}

	@Test
	public void createSlaEntryTest() {
		LOGGER.info("****************************Entering to createSlaEntryTest*****************************");
		try {
			URI url = new URI("/sla/createSlaEntry");
			String payload = "{\r\n" + " \"flowNodeProcessName\": \"WorkflowSLATest\", \r\n"
					+ " \"processInstanceId\": \" 12338 \", \r\n" + " \"activityInstanceId\": \" 4566 \", \r\n"
					+ " \"flowNodeProcessName\": \"SPLS-ORDER-VALIDATION\", \r\n"
					+ " \"flowNodeStepName\": \"CollectOrder\", \r\n" + " \"contract\": { \r\n"
					+ " \"id\": \"1516889288755|34567|7654\" \r\n" + " },\r\n" + " }\r\n" + " } \r\n" + "";
			
			
			this.mockMvc
					.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(payload))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();
			LOGGER.info("****************************Exiting from createSlaEntryTest*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createSlaEntryTest: ", e);
		}

	}
	

	

}
