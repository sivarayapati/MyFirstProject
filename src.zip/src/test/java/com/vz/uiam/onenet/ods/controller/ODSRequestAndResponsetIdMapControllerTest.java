package com.vz.uiam.onenet.ods.controller;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.Sql.ExecutionPhase;
import org.springframework.test.context.jdbc.SqlGroup;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vz.uiam.onenet.ods.OrchestrationOneDispatcherApplication;
import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestTransactionIdMap;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsResponseTransactionIdMap;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@SpringApplicationConfiguration(classes = OrchestrationOneDispatcherApplication.class)
public class ODSRequestAndResponsetIdMapControllerTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSRequestAndResponsetIdMapControllerTest.class);

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	@Autowired
	private Filter springSecurityFilterChain;

	@Autowired
	ODSParamConfigController odsParamConfigController;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac)
				.defaultRequest(get("/").with(httpBasic("IVAPP", "ivapp"))).addFilters(springSecurityFilterChain)
				.build();
	}

	/**
	 * 
	 */
	@Test
	public void testCreateOrUpdateOdsRequestTransIdMap() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateOdsRequestTransIdMap*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/createOrUpdateRequestTransIdMap");
			OdsRequestTransactionIdMap odsRequestTransactionIdMap =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap.setFlowNodeProcessName("TestProcessName");
			odsRequestTransactionIdMap.setFlowNodeStepName("TestStepName");
			odsRequestTransactionIdMap.setTransactionIdKey("TestTransactionIdKey");
			OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
			odsResponseTIdMap.setRootTagName("TestrootTagName");
			odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKey");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsRequestTransactionIdMap odsRequestTransactionIdMap1 =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap1.setFlowNodeProcessName("");
			odsRequestTransactionIdMap1.setFlowNodeStepName("TestStepName");
			odsRequestTransactionIdMap1.setTransactionIdKey("TestTransactionIdKey");
			OdsResponseTransactionIdMap odsResponseTIdMap1=new OdsResponseTransactionIdMap();
			odsResponseTIdMap1.setRootTagName("TestrootTagName1");
			odsResponseTIdMap1.setTransactionIdKey("TestTransactionIdKey");
			
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			OdsRequestTransactionIdMap odsRequestTransactionIdMap2 =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap2.setFlowNodeProcessName("testProcess");
			odsRequestTransactionIdMap2.setFlowNodeStepName("");
			odsRequestTransactionIdMap2.setTransactionIdKey("TestTransactionIdKey");
			OdsResponseTransactionIdMap odsResponseTIdMap2=new OdsResponseTransactionIdMap();
			odsResponseTIdMap2.setRootTagName("TestrootTagName2");
			odsResponseTIdMap2.setTransactionIdKey("TestTransactionIdKey");
			MvcResult result2 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap2)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result2 : " + result2.getResponse().getContentAsString());
			
			OdsRequestTransactionIdMap odsRequestTransactionIdMap3 =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap3.setFlowNodeProcessName("testProcess");
			odsRequestTransactionIdMap3.setFlowNodeStepName("stepname");
			odsRequestTransactionIdMap3.setTransactionIdKey("");
			OdsResponseTransactionIdMap odsResponseTIdMap3=new OdsResponseTransactionIdMap();
			odsResponseTIdMap3.setRootTagName("TestrootTagName3");
			odsResponseTIdMap3.setTransactionIdKey("TestTransactionIdKey");
			
			MvcResult result3 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap2)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result3 : " + result3.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateOdsRequestTransIdMap*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateOdsRequestTransIdMap: ",e);
		}
	}
	
	@Test
	public void testCreateOrUpdateOdsRequestTransIdMap1() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateOdsRequestTransIdMap1*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/createOrUpdateRequestTransIdMap");
			OdsRequestTransactionIdMap odsRequestTransactionIdMap =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap.setFlowNodeProcessName("TestProcessName");
			odsRequestTransactionIdMap.setFlowNodeStepName("TestStepName");
			odsRequestTransactionIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");	
			OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
			odsResponseTIdMap.setRootTagName("TestrootTagName");
			odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKey");
			
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateOdsRequestTransIdMap1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateOdsRequestTransIdMap: ",e);
		}
	}
	
	@Test
	public void testCreateOrUpdateOdsRequestTransIdMap2() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateOdsRequestTransIdMap2*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/createOrUpdateRequestTransIdMap");
			OdsRequestTransactionIdMap odsRequestTransactionIdMap =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap.setFlowNodeProcessName("");
			odsRequestTransactionIdMap.setFlowNodeStepName("TestStepName");
			odsRequestTransactionIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");			
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsRequestTransactionIdMap odsRequestTransactionIdMap1 =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap1.setFlowNodeProcessName("TestProcessName");
			odsRequestTransactionIdMap1.setFlowNodeStepName("");
			odsRequestTransactionIdMap1.setTransactionIdKey("TestTransactionIdKeyUPD");			
			
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			OdsRequestTransactionIdMap odsRequestTransactionIdMap2 =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap2.setFlowNodeProcessName("TestProcessName");
			odsRequestTransactionIdMap2.setFlowNodeStepName("TestStepName1");
			odsRequestTransactionIdMap2.setTransactionIdKey("");			
			
			MvcResult result2 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap2)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result2 : " + result2.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateOdsRequestTransIdMap2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateOdsRequestTransIdMap: ",e);
		}
	}
	
	@Test
	@SqlGroup({
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_response_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_response_transaction_id_map_table.sql"),
		@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_response_transaction_id_map_table.sql")})
	public void testCreateOrUpdateOdsRequestTransIdMap3() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateOdsRequestTransIdMap3*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/createOrUpdateRequestTransIdMap");
			OdsRequestTransactionIdMap odsRequestTransactionIdMap =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap.setId(100);
			odsRequestTransactionIdMap.setFlowNodeProcessName("TestProcessName");
			odsRequestTransactionIdMap.setFlowNodeStepName("TestStepName");
			odsRequestTransactionIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");		
			OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
			odsResponseTIdMap.setRootTagName("TestrootTagName");
			odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKey");
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsRequestTransactionIdMap odsRequestTransactionIdMap1 =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap1.setId(1000);
			odsRequestTransactionIdMap1.setFlowNodeProcessName("TestProcessName");
			odsRequestTransactionIdMap1.setFlowNodeStepName("TestStepName");
			odsRequestTransactionIdMap1.setTransactionIdKey("TestTransactionIdKeyUPD");			
			OdsResponseTransactionIdMap odsResponseTIdMap1=new OdsResponseTransactionIdMap();
			odsResponseTIdMap1.setRootTagName("TestrootTagName");
			odsResponseTIdMap1.setTransactionIdKey("TestTransactionIdKey");
			
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			odsRequestTransactionIdMap1.setFlowNodeProcessName("TestProcessName");
			odsRequestTransactionIdMap1.setFlowNodeStepName("TestStepName");
			odsRequestTransactionIdMap1.setTransactionIdKey("TestTransactionIdKeyUPD");			
			OdsResponseTransactionIdMap odsResponseTIdMap2=new OdsResponseTransactionIdMap();
			odsResponseTIdMap2.setRootTagName("TestrootTagName");
			odsResponseTIdMap2.setTransactionIdKey("TestTransactionIdKey");
			
			MvcResult result2 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result2 : " + result2.getResponse().getContentAsString());
		
		
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateOdsRequestTransIdMap3*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for CreateOrUpdateOdsRequestTransIdMap: ",e);
		}
	}
	
	@Test
	public void testGetOdsRequestTransIdMap() {
		try {
			LOGGER.info("****************************Entering to testGetOdsRequestTransIdMap*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/getOdsRequestTransIdMap");
			OdsRequestTransactionIdMap odsRequestTransactionIdMap =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap.setFlowNodeProcessName("TestProcessName");
			odsRequestTransactionIdMap.setFlowNodeStepName("TestStepName");
			odsRequestTransactionIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testGetOdsRequestTransIdMap*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsRequestTransIdMap: ",e);
		}
	}
	
	@Test
	public void testGetOdsRequestTransIdMap1() {
		try {
			LOGGER.info("****************************Entering to testGetOdsRequestTransIdMap1*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/getOdsRequestTransIdMap");
			OdsRequestTransactionIdMap odsRequestTransactionIdMap =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap.setFlowNodeProcessName("");
			odsRequestTransactionIdMap.setFlowNodeStepName("TestStepName");
			odsRequestTransactionIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			LOGGER.info("****************************Exiting from testGetOdsRequestTransIdMap1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for GetOdsRequestTransIdMap: ",e);
		}
	}
	
	@Test
	public void testGetOdsRequestTransIdMap2() {
		try {
			LOGGER.info("****************************Entering to testGetOdsRequestTransIdMap2*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/getOdsRequestTransIdMap");
			OdsRequestTransactionIdMap odsRequestTransactionIdMap =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap.setFlowNodeProcessName("");
			odsRequestTransactionIdMap.setFlowNodeStepName("");
			odsRequestTransactionIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestTransactionIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			LOGGER.info("****************************Exiting from testGetOdsRequestTransIdMap*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for GetOdsRequestTransIdMap: ",e);
		}
	}
	
	@Test
	public void testDeleteOdsRequestTransIdMap() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsRequestTransIdMap*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/deleteOdsRequestTransIdMap");
			OdsRequestTransactionIdMap odsRequestTransactionIdMap =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap.setFlowNodeProcessName("TestProcessName");
			odsRequestTransactionIdMap.setFlowNodeStepName("TestStepName");
			odsRequestTransactionIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");	
			List<OdsRequestTransactionIdMap> odsRequestList=new ArrayList<>();
			odsRequestList.add(odsRequestTransactionIdMap);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteOdsRequestTransIdMap*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsRequestTransIdMap: ",e);
		}
	}
	
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql"),
				@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_request_transaction_id_map_table.sql"),
				@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_request_transaction_id_map_table.sql")})
	public void testDeleteOdsRequestTransIdMap1() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsRequestTransIdMap1*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/deleteOdsRequestTransIdMap");
			OdsRequestTransactionIdMap odsRequestTransactionIdMap =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap.setId(100);
			odsRequestTransactionIdMap.setFlowNodeProcessName("TestProcessName");
			odsRequestTransactionIdMap.setFlowNodeStepName("TestStepName");
			odsRequestTransactionIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");	
			List<OdsRequestTransactionIdMap> odsRequestList=new ArrayList<>();
			odsRequestList.add(odsRequestTransactionIdMap);
			
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

		
			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testDeleteOdsRequestTransIdMap1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for DeleteOdsRequestTransIdMap: ",e);
		}
	}
	
	@Test
	public void testDeleteOdsRequestTransIdMap2() {
		try {
			LOGGER.info("****************************Entering to testDeleteOdsRequestTransIdMap2*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/deleteOdsRequestTransIdMap");
			OdsRequestTransactionIdMap odsRequestTransactionIdMap =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap.setFlowNodeProcessName("TestProcessName1");
			odsRequestTransactionIdMap.setFlowNodeStepName("TestStepName1");
			odsRequestTransactionIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");	
			List<OdsRequestTransactionIdMap> odsRequestList=new ArrayList<>();
			odsRequestList.add(odsRequestTransactionIdMap);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsRequestTransactionIdMap odsRequestTransactionIdMap1 =new OdsRequestTransactionIdMap();
			odsRequestTransactionIdMap1.setFlowNodeProcessName("");
			odsRequestTransactionIdMap1.setFlowNodeStepName("");
			odsRequestTransactionIdMap1.setTransactionIdKey("TestTransactionIdKeyUPD");	
			List<OdsRequestTransactionIdMap> odsRequestList1=new ArrayList<>();
			odsRequestList1.add(odsRequestTransactionIdMap);
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestList1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			List<OdsRequestTransactionIdMap> odsRequestList2=new ArrayList<>();
			odsRequestList1.add(odsRequestTransactionIdMap);
			MvcResult result2 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsRequestList2)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result2 : " + result2.getResponse().getContentAsString());
		
		
			
			LOGGER.info("****************************Exiting from testDeleteOdsRequestTransIdMap2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsRequestTransIdMap: ",e);
		}
	}
	
	@Test
	public void testCreateOrUpdateResponseTransIdMap() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateResponseTransIdMap*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/createOrUpdateResponseTransIdMap");
			OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
			odsResponseTIdMap.setRootTagName("TestrootTagName");
			odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKey");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseTIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateResponseTransIdMap*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateResponseTransIdMap: ",e);
		}
	}
	
	@Test
	public void testCreateOrUpdateResponseTransIdMap1() {
		try {
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/createOrUpdateResponseTransIdMap");
			OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
			odsResponseTIdMap.setRootTagName("TestrootTagName");
			odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseTIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
				
			LOGGER.info("****************************Exiting from testCreateOrUpdateResponseTransIdMap1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateResponseTransIdMap: ",e);
		}
	}
	
	@Test
	public void testCreateOrUpdateResponseTransIdMap2() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateResponseTransIdMap2*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/createOrUpdateResponseTransIdMap");
			OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
			odsResponseTIdMap.setRootTagName("");
			odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKeyUPD");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseTIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsResponseTransactionIdMap odsResponseTIdMap1=new OdsResponseTransactionIdMap();
			odsResponseTIdMap1.setRootTagName("TestrootTagName");
			odsResponseTIdMap1.setTransactionIdKey("");
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseTIdMap1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateResponseTransIdMap2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateResponseTransIdMap: ",e);
		}
	}
	
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_response_transaction_id_map_table.sql"),
				@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_response_transaction_id_map_table.sql"),
				@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_response_transaction_id_map_table.sql")
		})
	public void testCreateOrUpdateResponseTransIdMap3() {
		try {
			LOGGER.info("****************************Entering to testCreateOrUpdateResponseTransIdMap3*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/createOrUpdateResponseTransIdMap");
			OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
			odsResponseTIdMap.setId(100);
			odsResponseTIdMap.setRootTagName("TestrootTagName");
			odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKey");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseTIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();
	
			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsResponseTransactionIdMap odsResponseTIdMap1=new OdsResponseTransactionIdMap();
			odsResponseTIdMap1.setId(1000);
			odsResponseTIdMap1.setRootTagName("TestrootTagName");
			odsResponseTIdMap1.setTransactionIdKey("TestTransactionIdKey");
			
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseTIdMap1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
		
			
			LOGGER.info("****************************Exiting from testCreateOrUpdateResponseTransIdMap3*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for createOrUpdateResponseTransIdMap: ",e);
		}
	}
	
	@Test
	public void testgetOdsResponseTransIdMap() {
		try {
			LOGGER.info("****************************Entering to testgetOdsResponseTransIdMap*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/getOdsResponseTransIdMap");
			OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
			odsResponseTIdMap.setRootTagName("TestrootTagName");
			odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKey");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseTIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			LOGGER.info("****************************Exiting from testgetOdsResponseTransIdMap*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsResponseTransIdMap: ",e);
		}
	}
	
	@Test
	public void testgetOdsResponseTransIdMap1() {
		try {
			LOGGER.info("****************************Entering to testgetOdsResponseTransIdMap1*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/getOdsResponseTransIdMap");
			OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
			odsResponseTIdMap.setRootTagName("");
			odsResponseTIdMap.setTransactionIdKey("");
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseTIdMap)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			LOGGER.info("****************************Exiting from testgetOdsResponseTransIdMap1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for getOdsResponseTransIdMap: ",e);
		}
	}
	
	@Test
	@SqlGroup({@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:clean_ods_response_transaction_id_map_table.sql"),
				@Sql(executionPhase = ExecutionPhase.BEFORE_TEST_METHOD, scripts = "classpath:create_ods_response_transaction_id_map_table.sql"),
				@Sql(executionPhase = ExecutionPhase.AFTER_TEST_METHOD, scripts = "classpath:clean_ods_response_transaction_id_map_table.sql")})
	public void testdeleteOdsResponseTransIdMap1() {
		try {
			LOGGER.info("****************************Entering to testdeleteOdsResponseTransIdMap1*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/deleteOdsResponseTransIdMap");
			OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
			odsResponseTIdMap.setId(100);
			odsResponseTIdMap.setRootTagName("TestrootTagName");
			odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKey");
			List<OdsResponseTransactionIdMap> odsResponseList=new ArrayList<>();
			odsResponseList.add(odsResponseTIdMap);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			
			LOGGER.info("****************************Exiting from testdeleteOdsResponseTransIdMap1*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsResponseTransIdMap: ",e);
		}
	}
	
	@Test
	public void testdeleteOdsResponseTransIdMap2() {
		try {
			LOGGER.info("****************************Entering to testdeleteOdsResponseTransIdMap2*****************************");
			URI url = new URI("/oneDispatcher/odsTransactionIdMap/deleteOdsResponseTransIdMap");
			OdsResponseTransactionIdMap odsResponseTIdMap=new OdsResponseTransactionIdMap();
			odsResponseTIdMap.setRootTagName("TestrootTagName");
			odsResponseTIdMap.setTransactionIdKey("TestTransactionIdKey");
			List<OdsResponseTransactionIdMap> odsResponseList=new ArrayList<>();
			odsResponseList.add(odsResponseTIdMap);
			MvcResult result = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result : " + result.getResponse().getContentAsString());
			
			OdsResponseTransactionIdMap odsResponseTIdMap1=new OdsResponseTransactionIdMap();
			odsResponseTIdMap1.setRootTagName("");
			odsResponseTIdMap1.setTransactionIdKey("TestTransactionIdKey");
			List<OdsResponseTransactionIdMap> odsResponseList1=new ArrayList<>();
			odsResponseList1.add(odsResponseTIdMap1);
			MvcResult result1 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseList1)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result1 : " + result1.getResponse().getContentAsString());
			
			OdsResponseTransactionIdMap odsResponseTIdMap2=new OdsResponseTransactionIdMap();
			odsResponseTIdMap2.setRootTagName("TestrootTagName1");
			odsResponseTIdMap2.setTransactionIdKey("TestTransactionIdKey");
			List<OdsResponseTransactionIdMap> odsResponseList2=new ArrayList<>();
			odsResponseList2.add(odsResponseTIdMap2);
			MvcResult result2 = this.mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(odsResponseList)))
					.andExpect(status().isOk()).andExpect(content().contentType(Constants.APPLICATION_JSON))
					.andReturn();

			LOGGER.debug("Result2 : " + result2.getResponse().getContentAsString());
		
			
			LOGGER.info("****************************Exiting from testdeleteOdsResponseTransIdMap2*****************************");

		} catch (Exception e) {
			LOGGER.error("Exception Occured for deleteOdsResponseTransIdMap: ",e);
		}
	}
	
	/**
	 * @param object
	 * @return byte[]
	 * @throws JsonProcessingException
	 */
	public static byte[] convertObjectToJsonBytes(Object object) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

}
