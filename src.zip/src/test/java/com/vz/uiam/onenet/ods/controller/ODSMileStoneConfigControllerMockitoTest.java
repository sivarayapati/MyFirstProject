package com.vz.uiam.onenet.ods.controller;

import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMilestoneConfig;
import com.vz.uiam.onenet.ods.service.OdsMilestoneConfigService;

@RunWith(MockitoJUnitRunner.class)
public class ODSMileStoneConfigControllerMockitoTest {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ODSMileStoneConfigControllerMockitoTest.class);

	@InjectMocks
	OdsMilestoneConfigController odsMilestoneConfigController;

	@Mock
	OdsMilestoneConfigService odsMilestoneConfigService;

	/**
	 * @throws ApplicationException
	 * 
	 */
	@Test
	public void testdeleteOdsMilestoneConfig() throws ApplicationException {
		LOGGER.info(
				"****************************Entering to testdeleteOdsMilestoneConfig*****************************");

		List<OdsMilestoneConfig> odsMilestoneConfigList = new ArrayList<>();
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();

		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setRequestDocumentName("TEST-Message");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		odsMilestoneConfig.setTransformationType("JSON");
		odsMilestoneConfig.setRouteProtocol("REST");
		odsMilestoneConfig.setSendMilestone("YES");
		odsMilestoneConfig.setSendFalloutNotification("NO");

		odsMilestoneConfigList.add(odsMilestoneConfig);
		Mockito.doThrow(NullPointerException.class).when(odsMilestoneConfigService)
				.deleteOdsMilestoneConfigRecord(odsMilestoneConfigList);
		odsMilestoneConfigController.deleteOdsMilestoneConfig(odsMilestoneConfigList);

		LOGGER.info(
				"****************************Exiting from testdeleteOdsMilestoneConfig*****************************");

	}

	/**
	 * @throws ApplicationException
	 * 
	 */
	@Test
	public void testCreateOrUpdateMilestoneConfig() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testCreateOrUpdateMilestoneConfig*****************************");

		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setTargetEndpointUrl("http://test.com");
		odsMilestoneConfig.setRequestDocumentName("TEST-Message");
		odsMilestoneConfig.setRequestSchema("{test:$.test}");
		odsMilestoneConfig.setTransformationType("JSON");
		odsMilestoneConfig.setRouteProtocol("REST");
		odsMilestoneConfig.setSendMilestone("YES");
		odsMilestoneConfig.setSendFalloutNotification("NO");
		odsMilestoneConfig.setDestinationAppName("testApp");
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		odsMilestoneConfig.setMilestoneName("Milestone2");
		OdsMilestoneConfig odsMilestoneConfigRes = null;
		when(odsMilestoneConfigService.createOrUpdateMilestoneConfig(odsMilestoneConfig))
				.thenReturn(odsMilestoneConfigRes);
		odsMilestoneConfigController.createOrUpdateOdsMilestoneConfig(odsMilestoneConfig);
		LOGGER.info(
				"****************************Exiting from testCreateOrUpdateMilestoneConfig*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testCreateOrUpdateMilestoneConfig1() throws ApplicationException {

		LOGGER.info(
				"****************************Entering to testCreateOrUpdateMilestoneConfig1*****************************");

		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();

		when(odsMilestoneConfigService.createOrUpdateMilestoneConfig(odsMilestoneConfig)).thenThrow(SQLException.class);
		odsMilestoneConfigController.createOrUpdateOdsMilestoneConfig(odsMilestoneConfig);
		LOGGER.info(
				"****************************Exiting from testCreateOrUpdateMilestoneConfig1*****************************");

	}

	@Test
	public void testgetOdsMilestoneConfig() throws ApplicationException {

		LOGGER.info("****************************Entering to testgetOdsMilestoneConfig*****************************");

		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");
		List<OdsMilestoneConfig> odsMilestoneConfigList = null;
		when(odsMilestoneConfigService.getMilestoneConfig(odsMilestoneConfig)).thenReturn(odsMilestoneConfigList);
		odsMilestoneConfigController.getOdsMilestoneConfig(odsMilestoneConfig);
		LOGGER.info("****************************Exiting from testgetOdsMilestoneConfig*****************************");

	}

	@SuppressWarnings("unchecked")
	@Test
	public void testgetOdsMilestoneConfig1() throws ApplicationException {

		LOGGER.info("****************************Entering to testgetOdsMilestoneConfig1*****************************");
		OdsMilestoneConfig odsMilestoneConfig = new OdsMilestoneConfig();
		odsMilestoneConfig.setFlowNodeProcessName("Test11");
		odsMilestoneConfig.setFlowNodeStepName("TestOneDispatcher");

		when(odsMilestoneConfigService.getMilestoneConfig(odsMilestoneConfig)).thenThrow(SQLException.class);
		odsMilestoneConfigController.getOdsMilestoneConfig(odsMilestoneConfig);

		LOGGER.info("****************************Exiting from testgetOdsMilestoneConfig1*****************************");

	}

}
