package com.vz.uiam.onenet.ods.service;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.vz.uiam.onenet.ods.constants.StatusCode;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsInterfaceRequest;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsRequestLog;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsRequestLogRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseConfigParams;
import com.vz.uiam.onenet.ods.jpa.dto.model.ResponseStatus;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class ODSJsonResponseHandlerTest {
	private static final Logger LOGGER = Logger.getLogger(ODSJsonResponseHandlerTest.class);
	@InjectMocks
	ODSJsonResponseHandler odsJsonResponseHandler;

	@Mock
	ServiceUtils serviceUtils;

	@Mock
	ODSResponseHandler odsResponseHandler;
	
	@Mock
	OdsRequestResponseTransactionIdMapService odsRequestResponseTransactionIdMapService;
	
	@Mock
	OdsRequestLogRepository odsRequestLogRepository;
	
	@Mock
	NotesService notesService;

	@Test
	public void testCheckForAckInResponse() throws ApplicationException {

		LOGGER.info("Entering testCheckForAckInResponse");
		String response = "{\"ackResponse\":\"{}\"}";
		OdsInterfaceRequest odsInterfaceReq = new OdsInterfaceRequest();
		odsResponseHandler.checkForAckInResponse(response,odsInterfaceReq);
		LOGGER.info("Exiting testCheckForAckInResponse");

	}

	@Test
	public void testCheckForAckInResponse1() throws ApplicationException {

		LOGGER.info("Entering testCheckForAckInResponse1");
		String response = "{}";
		OdsInterfaceRequest odsInterfaceReq = new OdsInterfaceRequest();
		odsResponseHandler.checkForAckInResponse(response,odsInterfaceReq);
		LOGGER.info("Exiting testCheckForAckInResponse1");

	}

	@Test(expected = ApplicationException.class)
	public void testGetTransactionIdFromJsonResponse() throws ApplicationException {

		LOGGER.info("Entering testGetTransactionIdFromJsonResponse");
		String response = "{}";
		odsJsonResponseHandler.getTransactionIdFromJsonResponse(response);
		LOGGER.info("Exiting testGetTransactionIdFromJsonResponse");

	}

	@Test
	public void testGetTransactionIdFromJsonResponse1() throws ApplicationException {

		LOGGER.info("Entering testGetTransactionIdFromJsonResponse1");
		String response = "{}";
		String rootTag = "<nbaTransaction>";
		when(serviceUtils.getRootTagFromJson(response)).thenReturn(rootTag);
		odsJsonResponseHandler.getTransactionIdFromJsonResponse(response);
		LOGGER.info("Exiting testGetTransactionIdFromJsonResponse1");

	}

	@Test
	public void testDoJsonResponseProcessing() throws ApplicationException {

		LOGGER.info("Entering testDoJsonResponseProcessing");
		String response = "{}";
		String transactionId = "1532456789";
		OdsInterfaceRequest request = new OdsInterfaceRequest();
		request.setTransactionId(transactionId);
		request.setStatus(StatusCode.REQUEST_PENDING.toString());
		ResponseConfigParams config = new ResponseConfigParams();
		config.setFlowNodeProcessName("TestProcess");
		config.setFlowNodeStepName("TestStepName");

		request.setResponseConfigParam("{\"flowNodeProcessName\": \"SPLS-UPDATE-ASSIGNMENTS-IN-TIRKS\", \r\n"
				+ " \"flowNodeStepName\": \"ProcessFacilitiesResponse\"}");
		when(odsResponseHandler.getOdsInterfaceRequestByTransactionIdAndStatus(transactionId,
				StatusCode.REQUEST_PENDING.toString())).thenReturn(request);
		when(serviceUtils.convertJsonStringToObject(request.getResponseConfigParam(), ResponseConfigParams.class))
				.thenReturn(config);
		odsJsonResponseHandler.doJsonResponseProcessing(response, transactionId);
		LOGGER.info("Exiting testDoJsonResponseProcessing");

	}

	@Test
	public void testDoJsonResponseProcessing1() throws ApplicationException {

		LOGGER.info("Entering testDoJsonResponseProcessing1");
		String response = "{\"ackResponse\":\"{}\"}";
		String transactionId = "1532456789";

		odsJsonResponseHandler.doJsonResponseProcessing(response, transactionId);
		LOGGER.info("Exiting testDoJsonResponseProcessing1");

	}

	@Test
	public void testHandleException() throws ApplicationException {

		LOGGER.info("Entering testHandleException");
		JSONObject originalResponse = new JSONObject();
		ResponseStatus failureResponseStatus = new ResponseStatus();
		OdsInterfaceRequest request = new OdsInterfaceRequest();
		request.setTransactionId("15236789");
		request.setStatus(StatusCode.REQUEST_PENDING.toString());
		ResponseConfigParams config = new ResponseConfigParams();
		config.setFlowNodeProcessName("TestProcess");
		config.setFlowNodeStepName("TestStepName");
		when(serviceUtils.convertJsonStringToObject(request.getResponseConfigParam(), ResponseConfigParams.class))
				.thenReturn(config);

		odsJsonResponseHandler.handleException(originalResponse, failureResponseStatus, request);
		LOGGER.info("Exiting testHandleException");

	}
	
	@Test
	public void testHandleJsonResponse1() throws ApplicationException {

		LOGGER.info("Entering testHandleException");
		String response= "{}";
		String transactionId="";
		String requestKey="SPLS-ORDER-VALIDATION_ValidateCustomBidCaseId";
		JSONObject originalResponse = null ;
		OdsInterfaceRequest request = new OdsInterfaceRequest();
		ResponseStatus responseStatus = new ResponseStatus();
		request.setTransactionId("15236789");
		request.setStatus(StatusCode.REQUEST_PENDING.toString());
		request.setTaskId("23456");
		ResponseConfigParams config = new ResponseConfigParams();
		config.setFlowNodeProcessName("TestProcess");
		config.setFlowNodeStepName("TestStepName");
		OdsRequestLog odsRequestLog = new OdsRequestLog();
		odsRequestLog.setTitle("12345");
		odsRequestLog.setTitleVersion("0");
		when(serviceUtils.convertJsonStringToObject(request.getResponseConfigParam(), ResponseConfigParams.class))
				.thenReturn(config);
		when(serviceUtils.buildKey(config.getFlowNodeProcessName(),config.getFlowNodeStepName()))
		.thenReturn(requestKey);
		doNothing().when(odsResponseHandler).updateResponseInNotes(transactionId, response, requestKey);
		when(odsRequestLogRepository.findByWfTaskId(request.getTaskId())).thenReturn(odsRequestLog);
		when(odsResponseHandler.processResponse(response, request)).thenReturn(responseStatus);
		doNothing().when(odsResponseHandler).addOrUpdateStatus(originalResponse,responseStatus);
		odsJsonResponseHandler.handleJsonResponse(response, transactionId, request);
		LOGGER.info("Exiting testHandleException");

	}
	

}