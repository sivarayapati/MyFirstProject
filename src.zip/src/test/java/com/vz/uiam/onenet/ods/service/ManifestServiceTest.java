package com.vz.uiam.onenet.ods.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.vz.uiam.onenet.ods.constants.Constants;
import com.vz.uiam.onenet.ods.constants.OdsParamConfigType;
import com.vz.uiam.onenet.ods.exception.ApplicationException;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsMandatoryAttributes;
import com.vz.uiam.onenet.ods.jpa.dao.model.OdsParamConfig;
import com.vz.uiam.onenet.ods.jpa.dao.repository.OdsParamConfigRepository;
import com.vz.uiam.onenet.ods.jpa.dto.model.ODSKeyDetails;
import com.vz.uiam.onenet.ods.util.ServiceUtils;

@RunWith(MockitoJUnitRunner.class)
public class ManifestServiceTest {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ManifestServiceTest.class);

	@InjectMocks
	ManifestService manifestService;

	@Mock
	ServiceUtils serviceUtils;

	@Mock
	OdsParamConfigRepository odsParamConfigRepository;

	@Mock
	RestTemplate restTemplate;
	
	@Mock
	OdsMandatoryAttrsService odsMandatoryAttrsService;
	
	@Mock
	ResponseEntity<String> responseEntity;

	
	@Test(expected=ApplicationException.class)
	public void testFetchManifestRequestPayload() throws ApplicationException {
		LOGGER.info("Entering testFetchManifestRequestPayload");

		String request = "{  	\"app-key\": \"ZZZDE-VRD\",  	\"flowNodeProcessName\": \"LCI_DATA_ORDER\",  	\"flowNodeStepName\": \"ORDER_DETAILS\",  	\"seedInfo\": {  		\"order_number\": \"11272017002\",  		\"order_version\": \"0\",  		\"document_level\": \"VERSION\"  	}  }";
		JSONObject workflowRequest = new JSONObject(request);
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<>();
		OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
		odsMandatoryAttributes.setAttrKey("processName" + Constants.KEYBUILDER_SEPERATOR
				+ "FlowNodeName");
		odsMandatoryAttributes.setJsonPath("$.flowNodeProcessName.test.test1");
		odsMandatoryAttrsList.add(odsMandatoryAttributes);
		when(odsMandatoryAttrsService.getMandatoryAttributeList(Mockito.anyString())).thenReturn(odsMandatoryAttrsList);
		manifestService.fetchManifestRequestPayload(workflowRequest);
		LOGGER.info("Exiting testFetchManifestRequestPayload");
	}
	@Test
	public void testFetchManifestRequestPayload1() throws ApplicationException {
		LOGGER.info("Entering testFetchManifestRequestPayload1");

		String request = "{  	\"app-key\": \"ZZZDE-VRD\",  	\"flowNodeProcessName\": {\"test\":{\"test1\":\"test\"}},  	\"flowNodeStepName\": \"ORDER_DETAILS\",  	\"seedInfo\": {  		\"order_number\": \"11272017002\",  		\"order_version\": \"0\",  		\"document_level\": \"VERSION\"  	}  }";
		JSONObject workflowRequest = new JSONObject(request);
		List<OdsMandatoryAttributes> odsMandatoryAttrsList = new ArrayList<>();
		OdsMandatoryAttributes odsMandatoryAttributes = new OdsMandatoryAttributes();
		odsMandatoryAttributes.setAttrKey("processName" + Constants.KEYBUILDER_SEPERATOR
				+ "FlowNodeName");
		odsMandatoryAttributes.setJsonPath("$.flowNodeProcessName.test.test1");
		odsMandatoryAttrsList.add(odsMandatoryAttributes);
		when(odsMandatoryAttrsService.getMandatoryAttributeList(Mockito.anyString())).thenReturn(odsMandatoryAttrsList);
		manifestService.fetchManifestRequestPayload(workflowRequest);
		LOGGER.info("Exiting testFetchManifestRequestPayload1");
	}

	@Test	
	public void buildManifestDocumentTest() throws ApplicationException{
		LOGGER.info("Entering buildManifestDocumentTest");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
		odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsKeyDetails.setFlowNodeStepName("AddONT_Test");
		odsKeyDetails.setAppKey("Test-ODS-Key");
		JSONObject manifestReqPayload = new JSONObject(getManifestDocumentPayload());
		String manifestDocumentNames = "srDocument,ZZDE";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setParamKey(odsKeyDetails.getFlowNodeProcessName() + Constants.KEYBUILDER_SEPERATOR
				+ odsKeyDetails.getFlowNodeStepName());
		odsParamConfig.setValue("$.flowNodeProcessName.test.test1");
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.GET_MANIFEST_ENDPOINT_URL)).thenReturn(odsParamConfig);
		
		responseEntity = new ResponseEntity<String>(getfinaldocument(), HttpStatus.OK);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntity);
		manifestService.buildManifestDocument(manifestReqPayload, manifestDocumentNames);
		
		LOGGER.info("Exiting buildManifestDocumentTest");
	}
	
	@Test	
	public void buildManifestDocumentTest1() throws ApplicationException{
		LOGGER.info("Entering buildManifestDocumentTest");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
		odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsKeyDetails.setFlowNodeStepName("AddONT_Test");
		odsKeyDetails.setAppKey("Test-ODS-Key");
		JSONObject manifestReqPayload = new JSONObject(getfinalDocumentMeta());
		String manifestDocumentNames = "#Metadata.AdmingDocSample";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setParamKey(odsKeyDetails.getFlowNodeProcessName() + Constants.KEYBUILDER_SEPERATOR
				+ odsKeyDetails.getFlowNodeStepName());
		odsParamConfig.setValue("$.flowNodeProcessName.test.test1");
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.GET_MANIFEST_ENDPOINT_URL)).thenReturn(odsParamConfig);
		
		responseEntity = new ResponseEntity<String>(getfinaldocument(), HttpStatus.OK);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntity);
		manifestService.buildManifestDocument(manifestReqPayload, manifestDocumentNames);
		
		LOGGER.info("Exiting buildManifestDocumentTest");
	}
	
	
	
	@Test(expected=ApplicationException.class)
	public void buildManifestDocumentFailureTest() throws ApplicationException{
		LOGGER.info("Entering buildManifestDocumentFailureTest");
		ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
		odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsKeyDetails.setFlowNodeStepName("AddONT_Test");
		odsKeyDetails.setAppKey("Test-ODS-Key");
		JSONObject manifestReqPayload = new JSONObject(getfinalDocumentMeta());
		String manifestDocumentNames = "srDocument,ZZDE";		
		responseEntity = new ResponseEntity<String>(getfinaldocument(), HttpStatus.OK);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntity);
		manifestService.buildManifestDocument(manifestReqPayload, manifestDocumentNames);
		
		LOGGER.info("Exiting buildManifestDocumentFailureTest");
	}
	
	@Test(expected=ApplicationException.class)	
	public void buildManifestDocumentFailureTest1() throws ApplicationException{
		LOGGER.info("Entering buildManifestDocumentTest");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		ODSKeyDetails odsKeyDetails = new ODSKeyDetails();
		odsKeyDetails.setFlowNodeProcessName("LCI_OVER_NGPON2_Pre_Activation_Test");
		odsKeyDetails.setFlowNodeStepName("AddONT_Test");
		odsKeyDetails.setAppKey("Test-ODS-Key");
		JSONObject manifestReqPayload = new JSONObject(getfinalDocumentMeta());
		String manifestDocumentNames = "#Metadata.AdmingDocSample";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setParamKey(odsKeyDetails.getFlowNodeProcessName() + Constants.KEYBUILDER_SEPERATOR
				+ odsKeyDetails.getFlowNodeStepName());	
		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.GET_MANIFEST_ENDPOINT_URL)).thenReturn(odsParamConfig);
		
		responseEntity = new ResponseEntity<String>(getfinaldocument(), HttpStatus.OK);
		when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class)))
		.thenReturn(responseEntity);
		manifestService.buildManifestDocument(manifestReqPayload, manifestDocumentNames);
		
		LOGGER.info("Exiting buildManifestDocumentTest");
	}
	
	@Test(expected = ApplicationException.class)
	public void createOrUpdateManifestDocFailure1() throws ApplicationException {
		LOGGER.info("Entering createOrUpdateManifestDoc1");
		String manifestBuildPayload = "";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.BUILD_MANIFEST_ENDPOINT_URL))
		.thenReturn(odsParamConfig);
		when(serviceUtils.callService(any(), any(HttpEntity.class))).thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
		manifestService.createOrUpdateManifestDoc(manifestBuildPayload);

		LOGGER.info("Exiting createOrUpdateManifestDoc1");
	}

	@Test
	public void createOrUpdateManifestDocFailure2() throws ApplicationException {
		LOGGER.info("Entering createOrUpdateManifestDocFailure2");
		String manifestBuildPayload = "";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.BUILD_MANIFEST_ENDPOINT_URL))
		.thenReturn(odsParamConfig);
		
		ResponseEntity<String> responseEntity1 = new ResponseEntity<>("{\"response\":{ \"docs\":[{},{}] } }",
				HttpStatus.OK);

		when(serviceUtils.callService(any(), any(HttpEntity.class))).thenReturn(responseEntity1);
		manifestService.createOrUpdateManifestDoc(manifestBuildPayload);

		LOGGER.info("Exiting createOrUpdateManifestDocFailure2");

	}

	@Test(expected = RuntimeException.class)
	public void createOrUpdateManifestDocFailure3() throws ApplicationException {
		LOGGER.info("Entering createOrUpdateManifestDocFailure3");
		String manifestBuildPayload = "";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.BUILD_MANIFEST_ENDPOINT_URL))
		.thenReturn(odsParamConfig);
		when(serviceUtils.callService(any(), any(HttpEntity.class))).thenThrow(new RuntimeException());
		manifestService.createOrUpdateManifestDoc(manifestBuildPayload);

		LOGGER.info("Exiting createOrUpdateManifestDocFailure3");
	}

	@Test(expected = ApplicationException.class)
	public void createOrUpdateManifestDocFailure4() throws ApplicationException {
		LOGGER.info("Entering createOrUpdateManifestDocFailure4");
		String manifestBuildPayload = "";
		OdsParamConfig odsParamConfig = new OdsParamConfig();
		odsParamConfig.setType("ODS_PARAM");
		odsParamConfig.setValue("http://test.com");
		odsParamConfig.setParamKey("ODS");

		when(odsParamConfigRepository.findByParamKeyAndTypeAndName(OdsParamConfigType.ODS.toString(),
				OdsParamConfigType.ODS_PARAM.toString(), Constants.BUILD_MANIFEST_ENDPOINT_URL))
		.thenReturn(odsParamConfig);
		when(serviceUtils.callService(any(), any(HttpEntity.class))).thenReturn(responseEntity);
		when(responseEntity.getStatusCode()).thenReturn(HttpStatus.BAD_REQUEST);
		manifestService.createOrUpdateManifestDoc(manifestBuildPayload);

		LOGGER.info("Exiting createOrUpdateManifestDocFailure4");
	}

	
	
	

	public String getfinaldocument() {
		return " {\"requestPayload\":{\"processInstanceId\":\"34567\",\"serviceUrl\":\"https://vnmws.ebiz.verizon.com\",\"seedInfo\":{\"product_type\":\"Data\",\"supp_type\":\"Pending\",\"order_number\":\"CCOG639221728\",\"region\":\"NJ\","
				+ "\"order_version\":\"001\"},\"app-key\":\"ZZZDE-NGPON2\",\"rootProcessInstanceId\":\"56789\",\"activityInstanceId\":\"7654\",\"parentProcessInstanceId\":\"45678\",\"flowNodeProcessName\":\"LCI_OVER_NGPON2_Pre_Activation\","
				+ "\"rootProcessName\":\"Root\",\"flowNodeStepName\":\"RetrieveONTSerialNumber\"},\"transactionId\":\"1511938969413|34567|7654\",\"PlanningMessage\":{\"document-payload\":{\"PlanningMsgRsp\":{\"InvSystem\":\"IVAPP\",\"ActivationInfo\":{\"PonDetails\":{\"PonId\":\"00000000000000000000000001010111\","
				+ "\"PonSystemId\":\"00000000000100001001\",\"ChannelPartitionIndex\":\"0010\",\"ServiceType\":\"DATA\",\"BackupPonId\":\"00000000000000110010000100010111\",\"PonType\":\"NGPON2\"}},"
				+ "\"AssignmentReuse\":\"NO\",\"PreActRequired\":\"YES\",\"OrderNumber\":\"CCOGSSPDISCOTEST19\",\"OrderId\":706514,\"VersionNumber\":\"000\",\"xmlns\":\"\",\"SubscriptionId\":\":-1--1@NYCMNYWART1\","
				+ "\"ReconnectONTDel\":\"NO\",\"OdnData\":{\"MDU_SIP_ALTL\":\"NO\",\"CTID\":\"70/VAXA/706514/ /VZNY\",\"IvappPonCircuitName\":\"S/GRCYNYGCT01/1-1-9-1\",\"DataVlan\":{\"STag\":1024,"
				+ "\"CircuitName\":\"test\",\"CTag\":4095},\"PvcNniChange\":\"YES\",\"IspPvcCircuitId\":\"70/VAXA/706514/ /VZNY\",\"IvappPonCircuitId\":103792,\"MocaProvisioned\":\"N\",\"IvappSecondaryPonCircuitName\":\"S/GRCYNYGCT01/7-25-2-1\","
				+ "\"ReplacementPortNumber\":\"\",\"SvcPortNumber\":1,\"ServiceTNDetails\":{\"SwitchClli\":\"\",\"PrimaryLecTN\":\"\"}},\"RouterCilli\":\"NYCMNYWART1\",\"PonCircuit\":{\"DistHub\":{\"DistributionFiber\":{\"StrandNumber\":2,"
				+ "\"Name\":\"H8989\"},\"HubPortNumber\":2,\"Splitter\":{\"PortNumber\":1,\"Name\":\"H8989A\"},\"XConnectAction\":\"Make\",\"GpsParams\":{\"Latitude\":26.154106,\"Longitude\":-93.129155},\"Name\":\"H8989\",\"AddressInfo\":\"HOME\"},\"Ont\":{\"PAIndicator\":\"Compatible\",\"ManufacturerName\":\"ALTL\""
				+ ",\"DesktopModel\":\"Y\",\"Address\":{\"HouseNo\":620,\"StreetName\":\"NOTTINGHAM\",\"TuName\":\"SYRACUSE\",\"Zip\":13224,\"Type\":\"RD\",\"SubLocation\":\"FLR GRD\",\"State\":\"NY\",\"MduSfu\":0,\"AddressId\":48053419},\"MocaCapable\":\"Y\","
				+ "\"Make\":\"ALTL\",\"GpsParams\":{\"Latitude\":\"\",\"Longitude\":\"\"},\"EthernetSpeed\":\"N\",\"RequiredAction\":\"Install\",\"Type\":\"SFU\",\"SequenceNumber\":1,\"Model\":\"O-211M-E\",\"GponProvisioned\":\"Y\",\"InactiveONT\":\"N\"},"
				+ "\"Olt\":{\"FeederFiber\":{\"StrandNumber\":1,\"Name\":\"F8989\"},\"SlotId\":1,\"Rack\":1,\"ManufacturerName\":\"ALTL\",\"Clli\":\"GRNKNYGNRCH\",\"OltPortNumber\":9,\"EmsId\":\"\",\"ShelfId\":1,\"OltTid\":\"TMPAFLERICERICE907\",\"Name\":\"ALTL-ONT211M\"},"
				+ "\"FiberJackCapable\":\"N\",\"DropTerminal\":{\"RELATED_ADDR_ID\":[90213,90132,90134,90135,189459,90214,90212,90215,237267,237232,237233,156737,189460,189461,90133,90153,143599,237268,189440],\"ConnectorType\":\"SC/APC\",\"DropAction\":\"TERMINATE\",\"GpsParams\":{\"Latitude\":26.154476,\"Longitude\""
				+ ":-93.128649},\"DropStatus\":\"TERMINATED\",\"DropType\":\"MDU_INSIDE\","
				+ "\"PortNumber\":2,\"Name\":102853,\"AddressInfo\":\"HOME\"},\"IvappPonCircuitId\":103792,\"PonCircuitName\":\"S/GRCYNYGCT01/1-1-9-1\",\"FiberDrop\":{\"StrandNumber\":2}}}}},\"$.ApplicationParam.Test\" :{},\"document-payload\":{\"OntSerialNumber\":\"CCNK4BABABAB\"},\"status\":{\"code\":\"604\"}}";
	}
	
	public String getManifestDocumentPayload(){
		
		return "{\"entity-data\":{\"entity-attributes\":{\"attribute\":[{\"name\":\"region\",\"value\":\"NY\"},{\"name\":\"product_type\",\"value\":\"SES\"},{\"name\":\"order_number\",\"value\":\"ACOB_TLS_8474647462017_0003\"},{\"name\":\"order_version\",\"value\":\"000\"},{\"name\":\"supp_type\",\"value\":1}]},\"app-key\":\"ZZZDE-NGPON2\",\"document-name\":\"OntSerialNumber\"},\"document-payload\":{\"OntSerialNumber\":\"CCNK4BABABAB\"}}";
	}
	
	public String getfinalDocumentMeta(){
		
		return "{ \"entity-data\": { \"document-name\": \"AdmingDocSample\", \"app-key\": \"ZZZDE-ODS\", \"entity-attributes\": { \"attribute\": [{ \"name\": \"application_key\", \"value\": \"ZZZDE-VRD\" }, { \"name\": \"data_type\", \"value\": \"META_DATA\" }, { \"name\": \"document_level\", \"value\": \"GLOBAL\" } ] } } } ";
	}
	
	public String getResponseDocumentMeta(){
		
		return "{\"entity-data\":{\"document-name\":\"AdmingDocSample\",\"app-key\":\"ZZZDE-ODS\",\"entity-attributes\":{\"attribute\":[{\"name\":\"application_key\",\"value\":\"ZZZDE-VRD\"},{\"name\":\"data_type\",\"value\":\"META_DATA\"},{\"name\":\"document_level\",\"value\":\"GLOBAL\"}]}},\"document-payload\":{\"sysName\":\"COA\",\"dipVer\":\"5.0\",\"sysId\":\"COA_1234\",\"dTimeOut\":30,\"tSys\":\"10.1.1.2\",\"rSys\":\"11.1.1.1\",\"stafWdTime\":\"120\",\"empId\":\"A1234IVAPP\",\"testType\":\"QT\"}}";
	}
	
}
